// WhatsApp links: phones open the app via wa.me; computers go straight to WhatsApp Web in a new tab,
// skipping the api.whatsapp.com share page (which can ask visitors to update their browser).
let CRT_WA = '250796356035';
function crtIsDesktop(){ return !/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) && window.matchMedia('(hover: hover) and (pointer: fine)').matches; }
function crtWaUrl(text){
  const t = encodeURIComponent(text || '');
  return crtIsDesktop() ? 'https://web.whatsapp.com/send?phone=' + CRT_WA + (t ? '&text=' + t : '') : 'https://wa.me/' + CRT_WA + (t ? '?text=' + t : '');
}
// ---------------------------------------------------------------
// v17 Prices, edited in /admin → Content → Prices & packages. Saved as site_content.price_map
// {"1200000": 1300000, ...} (old amount → new amount). Every place that shows an amount follows it:
// page text, menus, guides, offers, the Book page (data-price), the project builder and the print shop.
// The wedding early-booking prices (30% off) follow their package automatically.
// Each text and price is always worked out from its original value, so applying twice never changes it twice.
// ---------------------------------------------------------------
window.crtPrices = (function(){
  const KEY = 'crt-price-map', fmt = n => Number(n).toLocaleString('en-US');
  const WEDDING = [1200000, 2000000, 3000000, 4500000];
  let num = {}, fmtMap = {}, re = null, waiting = [], ready = false;
  function setMap(m){
    num = {};
    Object.keys(m || {}).forEach(k => { const a = parseInt(String(k).replace(/\D/g, ''), 10), b = parseInt(String(m[k]).replace(/\D/g, ''), 10); if(a >= 1000 && b > 0 && a !== b) num[a] = b; });
    WEDDING.forEach(a => { if(num[a] && !num[Math.round(a * 0.7)]) num[Math.round(a * 0.7)] = Math.round(num[a] * 0.7 / 1000) * 1000; });
    fmtMap = {}; Object.keys(num).forEach(a => { fmtMap[fmt(a)] = fmt(num[a]); });
    const keys = Object.keys(fmtMap).sort((x, y) => y.length - x.length).map(k => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    re = keys.length ? new RegExp('(^|[^\\d,])(' + keys.join('|') + ')(?![\\d,])', 'g') : null;
    window.__CRT_PRICE_MAP = fmtMap;
  }
  const swapText = t => re ? t.replace(re, (m, pre, k) => pre + fmtMap[k]) : t;
  function patchData(o){   // builder / print data: numbers and text inside
    if(Array.isArray(o)) return o.map(patchData);
    if(o && typeof o === 'object'){ const r = {}; Object.keys(o).forEach(k => { const v = o[k]; r[k] = (typeof v === 'number' && num[v] && /^(p|pr|price|from|min|max)$/.test(k)) ? num[v] : patchData(v); }); return r; }
    return typeof o === 'string' ? swapText(o) : o;
  }
  function apply(root){
    root = root || document.body; if(!root) return;
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {acceptNode: n => (n.parentElement && n.parentElement.closest('script,style,textarea,input')) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT});
    const nodes = []; while(w.nextNode()) nodes.push(w.currentNode);
    nodes.forEach(n => {
      if(n._crtPriceFrom === undefined){ if(!/\d,\d{3}/.test(n.nodeValue)) return; n._crtPriceFrom = n.nodeValue; }
      const v = swapText(n._crtPriceFrom); if(n.nodeValue !== v) n.nodeValue = v;
    });
    root.querySelectorAll('[data-price]').forEach(el => {
      if(el.dataset.priceFrom === undefined) el.dataset.priceFrom = el.dataset.price;
      const a = parseInt(el.dataset.priceFrom, 10); el.dataset.price = num[a] ? String(num[a]) : el.dataset.priceFrom;
    });
  }
  function load(m){ setMap(m); if(document.body) apply(); }
  function done(){ if(ready) return; ready = true; waiting.splice(0).forEach(f => { try{ f(); }catch(e){ console.error(e); } }); }
  // 1) the copy this browser saved last time: applies before anything is drawn
  try{ const c = JSON.parse(localStorage.getItem(KEY) || 'null'); if(c){ setMap(c); done(); } }catch(e){}
  document.addEventListener('DOMContentLoaded', () => apply());
  // 2) the live copy
  const CFG = window.CRT_CONFIG || {};
  if(CFG.SUPABASE_URL && CFG.SUPABASE_ANON_KEY){
    fetch(CFG.SUPABASE_URL.replace(/\/$/, '') + '/rest/v1/site_content?select=key,value&key=in.(price_map,prices_v2)', {headers: {'apikey': CFG.SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + CFG.SUPABASE_ANON_KEY}})
      .then(r => r.ok ? r.json() : []).then(rows => {
        const c = {}; (rows || []).forEach(r => { c[r.key] = r.value; });
        let m = c.price_map || null;
        if(!m && c.prices_v2){ const B = {basic: 1200000, standard: 2000000, premium: 3000000, vip: 4500000}; m = {}; Object.keys(B).forEach(k => { if(+c.prices_v2[k] > 0 && +c.prices_v2[k] !== B[k]) m[B[k]] = +c.prices_v2[k]; }); }
        m = m || {};
        try{ localStorage.setItem(KEY, JSON.stringify(m)); }catch(e){}
        load(m); done();
      }).catch(done);
    setTimeout(done, 1500);   // never hold the builder back for long
  } else done();
  window.addEventListener('load', () => apply());
  return {apply, patchData, swapText, after: f => { if(ready) f(); else waiting.push(f); }};
})();

// ---------------------------------------------------------------
// v19 CMS: offers, packages and extras, availability, print products, home hero campaigns, questions,
// and search & sharing, edited in /admin → Content and published to Supabase site_content (cms_<name>).
// A collection that was never published leaves the page exactly as built. Published items are cached in
// the browser so they draw before first paint on later visits; the live copy refreshes in the background.
// ?cms_preview=1 shows the dashboard's unpublished drafts (same browser only), and the dashboard's live
// preview sends drafts by postMessage as you type.
// ---------------------------------------------------------------
window.crtCMS = (function(){
  const KEY = 'crt-cms-v1', COLS = ['offers', 'packages', 'availability', 'print', 'hero', 'faq', 'seo'];
  const CFG = window.CRT_CONFIG || {};
  const PREVIEW = /[?&]cms_preview=1/.test(location.search);
  let pub = null, live = null, ready = false, waiting = [];
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));
  const fmt = n => Number(n).toLocaleString('en-US') + ' RWF';
  const day = (d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'))(new Date());
  const path = (location.pathname.replace(/index\.html$/, '').replace(/\/?$/, '/')).replace(/^\/+/, '/');
  // links and images are saved site-absolute (/offers/); keep them working when the site is opened from a sub-folder
  const url = u => { u = String(u || ''); return /^(https?:|mailto:|tel:|data:|#)/.test(u) ? u : u; };
  const on = it => !!it && it.live !== false && !(it.start && day < it.start) && !(it.end && day > it.end);
  function data(){
    const d = Object.assign({}, pub || {});
    if(PREVIEW){ try{ const dr = JSON.parse(localStorage.getItem('crt-cms-draft') || '{}'); Object.keys(dr).forEach(k => { d[k] = {items: dr[k]}; }); }catch(e){} }
    if(live) Object.keys(live).forEach(k => { d[k] = {items: live[k]}; });
    return d;
  }
  const items = col => { const c = data()[col]; return c && Array.isArray(c.items) ? c.items : null; };

  // ---- offers: the Offers page grid; an offer page whose offer ended or is hidden says so
  function offers(){
    const list = items('offers'); if(!list) return;
    const root = document.querySelector('[data-offer-filter] .container');
    if(root){
      const show = list.filter(on), wa = t => 'https://wa.me/250796356035?text=' + encodeURIComponent('Hi CRT, I’m interested in the “' + t + '” offer.');
      const price = o => `<span>${esc(o.price_label || 'From')}</span><strong>${o.was ? `<s>${fmt(o.was)}</s> ` : ''}${o.price ? fmt(o.price) + (o.per ? ' / ' + esc(o.per) : '') : 'Price on request'}</strong>${o.price_note ? `<small>${esc(o.price_note)}</small>` : ''}`;
      const proof = (o, cls) => o.proof_link && o.proof_text ? `<a class="${cls}" href="${esc(url(o.proof_link))}" data-track="deal_proof">${o.proof_img ? `<img src="${esc(url(o.proof_img))}" alt="" width="80" height="100" loading="lazy" decoding="async">` : ''}<span>${esc(o.proof_text)} <i aria-hidden="true">→</i></span></a>` : '';
      const incl = (o, cls) => (o.incl || []).filter(Boolean).length ? `<ul class="${cls}">${o.incl.filter(Boolean).map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : '';
      const spot = show.find(o => o.spotlight), rest = show.filter(o => o !== spot);
      const catName = {business: 'Business', events: 'Events', weddings: 'Weddings'};
      let html = '';
      if(spot) html += `<article class="offer-spotlight" data-cat="${esc(spot.cat)}" data-cms><a class="spot-art${/\.svg$/.test(spot.cover || '') ? ' icon-cover' : ''}" href="${esc(url(spot.link))}" tabindex="-1" aria-hidden="true"><img src="${esc(url(spot.cover))}" alt="" width="800" height="500" decoding="async"></a><div class="spot-body"><div class="spot-tags">${spot.badge ? `<span class="spot-badge">${esc(spot.badge)}</span>` : ''}<span class="offer2-cat">${esc(spot.label || catName[spot.cat] || '')}</span></div><h2><a href="${esc(url(spot.link))}">${esc(spot.title)}</a></h2><p class="spot-hook">${esc(spot.hook)}</p>${incl(spot, 'spot-incl')}${proof(spot, 'offer2-proof')}<div class="spot-foot"><p class="spot-price">${price(spot)}</p><div class="spot-actions"><a class="btn" href="${esc(url(spot.link))}" data-track="deal_cta">${esc(spot.cta || 'See the offer')}</a><a class="btn secondary" href="${wa(spot.title)}" target="_blank" rel="noopener" data-track="deal_whatsapp">Ask on WhatsApp ↗</a></div></div></div></article>`;
      html += '<div class="offer2-grid" data-cms>' + rest.map(o => `<article class="offer2" data-cat="${esc(o.cat)}"><a class="offer2-cover${/\.svg$/.test(o.cover || '') ? ' icon-cover' : ''}" href="${esc(url(o.link))}" tabindex="-1" aria-hidden="true"><img src="${esc(url(o.cover))}" alt="" loading="lazy" width="800" height="500" decoding="async"></a><div class="offer2-body">${o.badge ? `<div class="spot-tags"><span class="spot-badge">${esc(o.badge)}</span><span class="offer2-cat">${esc(o.label || catName[o.cat] || '')}</span></div>` : `<span class="offer2-cat">${esc(o.label || catName[o.cat] || '')}</span>`}<h3><a href="${esc(url(o.link))}">${esc(o.title)}</a></h3><p class="offer2-hook">${esc(o.hook)}</p><p class="offer2-price">${price(o)}</p>${incl(o, 'offer2-incl')}${proof(o, 'offer2-proof')}<div class="offer2-actions"><a class="btn" href="${esc(url(o.link))}" data-track="deal_cta">${esc(o.cta || 'See the offer')}</a><a class="offer2-wa" href="${wa(o.title)}" target="_blank" rel="noopener" data-track="deal_whatsapp" aria-label="Ask about ${esc(o.title)} on WhatsApp">Ask on WhatsApp ↗</a></div></div></article>`).join('') + '</div>';
      root.querySelectorAll('.offer-spotlight,.offer2-grid,.offer-none').forEach(el => el.remove());
      root.insertAdjacentHTML('beforeend', show.length ? html : '<p class="offer-none" data-cms>New offers are on the way. <a href="../book/index.html">Book any package ›</a></p>');
      const n = c => show.filter(o => c === 'all' || o.cat === c).length;
      root.querySelectorAll('[data-filter]').forEach(t => { const b = t.querySelector('b'); if(b) b.textContent = n(t.dataset.filter); t.hidden = t.dataset.filter !== 'all' && !n(t.dataset.filter); });
      const cur = root.querySelector('[data-filter][aria-selected="true"]');
      if(cur && cur.dataset.filter !== 'all') root.querySelectorAll('article[data-cat]').forEach(a => { a.hidden = a.dataset.cat !== cur.dataset.filter; });
    }
    const mine = list.find(o => o.link && o.link.replace(/\/?$/, '/') === path);
    const main = document.querySelector('main');
    const old = document.querySelector('.cms-ended'); if(old) old.remove();
    if(mine && !on(mine) && main) main.insertAdjacentHTML('afterbegin', `<div class="cms-ended" role="status" data-cms><p><strong>${mine.end && day > mine.end ? 'This offer has ended.' : 'This offer isn’t available right now.'}</strong> <a href="../offers/index.html">See today’s offers ›</a></p></div>`);
  }

  // ---- packages and extras: the Book page
  function packages(){
    const list = items('packages'), root = document.querySelector('[data-book]'); if(!list || !root) return;
    const priceTxt = (p, per) => p == null || p === '' ? 'Priced on request' : (+p === 0 ? 'Included' : 'From ' + fmt(p) + (per ? ' / ' + per : ''));
    root.querySelectorAll('.bk-group[data-svc]').forEach(g => {
      const s = g.dataset.svc; if(s === 'print') return;
      const mine = list.filter(x => x.service === s && x.live !== false);
      const grids = g.querySelectorAll('.bk-grid'), pGrid = grids[0], xGrid = [...grids].filter(x => !x.closest('.bk-offers')).pop();
      const chosen = (root.querySelector(`input[name="bk-p-${s}"]:checked`) || {}).value, ticked = [...root.querySelectorAll(`input[name="bk-x-${s}"]:checked`)].map(i => i.value);
      const pid = x => x.id.split(':').pop();
      if(pGrid) pGrid.innerHTML = mine.filter(x => x.kind === 'package').map(x => `<label class="bk-opt" data-cms><input type="radio" name="bk-p-${s}" value="${esc(pid(x))}" data-name="${esc(x.name)}" data-price="${x.price == null ? '' : +x.price}" data-per="${x.per ? ' / ' + esc(x.per) : ''}"${pid(x) === chosen ? ' checked' : ''}><span><strong>${esc(x.name)}</strong><small>${esc(x.line || '')}</small><em>${priceTxt(x.price, x.per)}</em></span></label>`).join('');
      if(xGrid && xGrid !== pGrid){
        const xs = mine.filter(x => x.kind === 'extra');
        xGrid.innerHTML = xs.map(x => `<label class="bk-opt bk-x" data-cms${x.days ? ' data-only="days" hidden' : ''}><input type="checkbox" name="bk-x-${s}" value="${esc(pid(x))}" data-name="${esc(x.name)}" data-price="${x.price == null ? '' : +x.price}"${ticked.includes(pid(x)) ? ' checked' : ''}><span><strong>${esc(x.name)}</strong><em>${x.price == null || x.price === '' ? 'Priced on request' : (+x.price ? 'From ' + fmt(x.price) : 'Free')}</em></span></label>`).join('');
        const step = xGrid.closest('.bk-step'); if(step) step.hidden = !xs.length;
      }
    });
    if(ready) root.dispatchEvent(new Event('change', {bubbles: true}));
  }

  // ---- availability: a date check on the Book page and on every "Check your date" section
  function availability(){
    const list = items('availability'); if(!list) return;
    const svcOf = () => { const r = document.querySelector('input[name="bk-s"]:checked'); return r ? r.value : (path.match(/^\/(weddings|events|business)\//) || [])[1] || ''; };
    const state = (d, s) => { const hit = list.filter(x => x.date === d && (!x.service || x.service === 'all' || !s || x.service === s)); return hit.some(x => x.status === 'booked') ? 'booked' : (hit.length ? 'limited' : 'free'); };
    const say = {free: ['is-free', ' is free.', 'Book now to hold it.'], limited: ['is-limited', ' is almost full.', 'Book soon, or ask us on WhatsApp.'], booked: ['is-booked', ' is booked.', 'Try another date, or ask us about a second team.']};
    const nice = v => new Date(v + 'T12:00').toLocaleDateString('en-GB', {weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'});
    let n = 0;
    const box = (cls, label) => { const id = 'cms-date-' + (++n); return `<div class="cms-date ${cls}" data-cms><label class="cms-date-l" for="${id}">${label}</label><div class="cms-date-f"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/></svg><input type="date" id="${id}" min="${day}" data-cms-date aria-describedby="${id}-out"></div><p class="cms-date-out" id="${id}-out" role="status" aria-live="polite"></p></div>`; };
    const wire = el => {
      if(el._cms) return; el._cms = 1;
      const inp = el.querySelector('[data-cms-date]'), out = el.querySelector('.cms-date-out');
      const run = () => { const v = inp.value; el.classList.remove('is-free', 'is-limited', 'is-booked'); if(!v){ out.textContent = ''; return; } const st = state(v, svcOf()); el.classList.add(say[st][0]); out.innerHTML = '<i aria-hidden="true"></i><span><b>' + esc(nice(v)) + say[st][1] + '</b> ' + say[st][2] + '</span>';
        const f = document.querySelector('[data-book-form] [name="date"]'); if(f && el.closest('[data-book]') && (!f.value || f.dataset.cmsSet || /^\d{4}-\d\d-\d\d$/.test(f.value))){ f.dataset.cmsSet = 1; f.value = new Date(v + 'T12:00').toLocaleDateString('en-GB', {day: 'numeric', month: 'long', year: 'numeric'}); }
        const b = el.parentElement.querySelector('.bk-end-cta .btn'); if(b){ const u = new URL(b.href, location.href); u.searchParams.set('date', v); b.href = u.href; } };
      inp.addEventListener('change', run); inp.addEventListener('input', run);
      document.addEventListener('change', e => { if(e.target.name === 'bk-s') run(); });
      const q = new URLSearchParams(location.search).get('date'); if(q && /^\d{4}-\d\d-\d\d$/.test(q)){ inp.value = q; run(); setTimeout(run, 0); window.addEventListener('load', run); }
    };
    const f = document.querySelector('[data-book-form] [name="date"]');
    if(f && !document.querySelector('[data-book] .cms-date')) f.closest('.field').insertAdjacentHTML('beforebegin', box('cms-date-book', 'Check your date'));
    document.querySelectorAll('.bk-end .bk-end-cta').forEach(c => { if(!/weddings|events/.test((c.querySelector('.btn') || {}).href || '') || c.parentElement.querySelector('.cms-date')) return; c.insertAdjacentHTML('beforebegin', box('cms-date-end', 'Is your date free?')); });
    document.querySelectorAll('.cms-date').forEach(wire);
  }

  // ---- print products: the Print page tiles and the data its quick view reads
  function printShop(){
    const list = items('print'), el = document.getElementById('shop-data'); if(!list || !el) return;
    const D = {};
    list.filter(x => x.live !== false && x.name).forEach(x => {
      const o = {}; (x.options || []).forEach(g => { const v = (g.values || []).filter(Boolean); if(g.name && v.length) o[g.name] = v; });
      D[x.id] = {n: x.name, c: x.cat, l: x.line || '', o, p: x.price ? +x.price : null, u: [x.unit_one || 'item', x.unit_many || 'items'],
        m: x.image ? `<div class="sp-m sp-canvas"><div class="cv"><img src="${esc(url(x.image))}" alt="" loading="lazy" decoding="async"></div></div>` : (x.mock || '<div class="sp-m sp-canvas"><div class="cv"></div></div>')};
    });
    if(!ready) el.textContent = JSON.stringify(D);
    if(window.__CRT_SHOP){ Object.keys(window.__CRT_SHOP).forEach(k => delete window.__CRT_SHOP[k]); Object.assign(window.__CRT_SHOP, D); }
    const grid = document.querySelector('[data-shop-grid]');
    if(grid){
      const cat = (document.querySelector('.sp-tab.is-on') || {dataset: {}}).dataset.shopCat || '';
      grid.innerHTML = Object.keys(D).map(id => { const p = D[id]; return `<li class="sp-tile" data-cat="${esc(p.c)}" data-cms${cat && p.c !== cat ? ' hidden' : ''}><button type="button" class="sp-open" data-product="${esc(id)}" aria-label="View ${esc(p.n)}"><span class="sp-stage">${p.m}</span><span class="sp-name">${esc(p.n)}</span><span class="sp-price">${p.p ? 'From ' + fmt(p.p) : 'Price on request'}</span></button></li>`; }).join('');
    }
  }

  // ---- home hero: every live campaign (its dates include today) takes a turn, 8 seconds each, with a soft cross-fade.
  // Dots pick a campaign; the pause button stops it (WCAG 2.2.2). It also holds while the pointer or keyboard focus is
  // on the hero, while the tab is hidden, and never starts by itself for visitors who ask for reduced motion.
  const HERO_MS = 8000;
  function hero(){
    const list = items('hero'), sec = document.querySelector('.hero-home'); if(!list || !sec) return;
    const live = list.filter(on); if(!live.length) return;
    const h1 = sec.querySelector('h1'), lead = sec.querySelector('.lead'), btn = sec.querySelector('.hm-copy .btn'), img = sec.querySelector('.hm-bg'), copy = sec.querySelector('.hm-copy');
    const S = sec._cmsHero || (sec._cmsHero = {i: 0, timer: 0, paused: matchMedia('(prefers-reduced-motion: reduce)').matches, hold: false});
    clearInterval(S.timer); S.live = live; if(S.i >= live.length) S.i = 0;
    const draw = c => {
      if(h1 && c.title) h1.innerHTML = esc(c.title) + (c.title_sub ? ` <span class="h1-for">${esc(c.title_sub)}</span>` : '');
      if(lead){ lead.textContent = c.lead || ''; lead.hidden = !c.lead; }
      if(btn && c.cta){ btn.textContent = c.cta; if(c.cta_link) btn.href = url(c.cta_link); }
      if(img && c.image && img.dataset.cmsSrc !== c.image){ img.dataset.cmsSrc = c.image; img.removeAttribute('srcset'); img.src = url(c.image); img.alt = c.image_alt || ''; }
      sec.setAttribute('data-cms', c.id || '');
      sec.querySelectorAll('.cms-hero-dot').forEach((d, i) => { const now = i === S.i; d.classList.toggle('is-on', now); d.setAttribute('aria-current', now ? 'true' : 'false'); });
    };
    const go = (n, fade) => {
      S.i = (n + S.live.length) % S.live.length; const c = S.live[S.i];
      if(!fade){ draw(c); return; }
      sec.classList.add('cms-hero-out');
      setTimeout(() => { draw(c); sec.classList.remove('cms-hero-out'); }, 280);
    };
    const tick = () => { if(!S.paused && !S.hold && !document.hidden) go(S.i + 1, true); };
    let nav = sec.querySelector('.cms-hero-nav');
    if(live.length > 1){
      live.forEach(c => { if(c.image){ const im = new Image(); im.src = url(c.image); } });   // no blank frame on the first turn
      if(!nav){
        nav = document.createElement('div'); nav.className = 'cms-hero-nav'; nav.setAttribute('data-cms', '');
        (copy || sec).appendChild(nav);
        nav.addEventListener('click', e => {
          const d = e.target.closest('.cms-hero-dot'), p = e.target.closest('.cms-hero-pause');
          if(d){ go(+d.dataset.i, true); restart(); }
          if(p){ S.paused = !S.paused; paintPause(); restart(); }
        });
        sec.addEventListener('mouseenter', () => { S.hold = true; }); sec.addEventListener('mouseleave', () => { S.hold = false; });
        sec.addEventListener('focusin', () => { S.hold = true; }); sec.addEventListener('focusout', () => { S.hold = false; });
      }
      nav.innerHTML = live.map((c, i) => `<button type="button" class="cms-hero-dot" data-i="${i}" aria-label="Show ${esc(c.name || c.title)}"></button>`).join('')
        + '<button type="button" class="cms-hero-pause"></button>';
      nav.hidden = false;
    } else if(nav) nav.hidden = true;
    function paintPause(){ const p = sec.querySelector('.cms-hero-pause'); if(!p) return; p.setAttribute('aria-label', S.paused ? 'Play the campaigns' : 'Pause the campaigns'); p.setAttribute('aria-pressed', String(S.paused)); p.innerHTML = S.paused ? '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M5 3.5v9l7.5-4.5z"/></svg>' : '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4.5 3h2.5v10H4.5zM9 3h2.5v10H9z"/></svg>'; }
    function restart(){ clearInterval(S.timer); if(S.live.length > 1) S.timer = setInterval(tick, HERO_MS); }
    paintPause(); go(S.i, false); restart();
  }

  // ---- questions: the "Before you book" list on any page (added before the closing section when the page has none)
  function faq(){
    const list = items('faq'); if(!list) return;
    const mine = list.filter(x => x.page && x.page.replace(/\/?$/, '/') === path && x.live !== false && x.q && x.a);
    let box = document.querySelector('.faq-list');
    if(!mine.length){ if(box && box.closest('[data-cms-faq]')) box.closest('[data-cms-faq]').remove(); else if(box) box.closest('section').hidden = true; return; }
    if(!box){
      const end = document.querySelector('main .bk-end') || null, main = document.querySelector('main'); if(!main) return;
      const s = document.createElement('section'); s.className = 'section'; s.setAttribute('data-cms-faq', '');
      s.innerHTML = '<div class="container"><div class="section-intro"><h2>Before you book.</h2></div><div class="faq-list"></div></div>';
      end ? end.before(s) : main.appendChild(s); box = s.querySelector('.faq-list');
    }
    box.closest('section').hidden = false;
    box.innerHTML = mine.map(x => `<details class="faq-item" data-cms><summary>${esc(x.q)}</summary><p>${esc(x.a)}</p></details>`).join('');
  }

  // ---- search & sharing: page title, description and share image (also written into the pages at each upload)
  function seo(){
    const list = items('seo'); if(!list) return;
    const m = list.find(x => (x.path || '').replace(/\/?$/, '/') === path); if(!m) return;
    const set = (sel, attr, v) => { const el = document.head.querySelector(sel); if(el && v) el.setAttribute(attr, v); };
    if(m.title) document.title = m.title;
    set('meta[name="description"]', 'content', m.desc); set('meta[property="og:description"]', 'content', m.desc); set('meta[name="twitter:description"]', 'content', m.desc);
    set('meta[property="og:title"]', 'content', m.title); set('meta[name="twitter:title"]', 'content', m.title);
    if(m.image){ const abs = /^https?:/.test(m.image) ? m.image : 'https://crt.rw' + m.image; set('meta[property="og:image"]', 'content', abs); set('meta[name="twitter:image"]', 'content', abs); }
  }

  function apply(){ [seo, hero, offers, packages, availability, printShop, faq].forEach(f => { try{ f(); }catch(e){ console.error(e); } }); if(window.crtPrices) window.crtPrices.apply(); }
  function done(){ if(ready) return; apply(); ready = true; waiting.splice(0).forEach(f => { try{ f(); }catch(e){ console.error(e); } }); }
  try{ pub = JSON.parse(localStorage.getItem(KEY) || 'null'); }catch(e){}
  if(pub || PREVIEW) done();
  if(CFG.SUPABASE_URL && CFG.SUPABASE_ANON_KEY){
    fetch(CFG.SUPABASE_URL.replace(/\/$/, '') + '/rest/v1/site_content?select=key,value&key=in.(' + COLS.map(c => 'cms_' + c).join(',') + ')', {headers: {'apikey': CFG.SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + CFG.SUPABASE_ANON_KEY}})
      .then(r => r.ok ? r.json() : Promise.reject(r.status)).then(rows => {
        const next = {}; (rows || []).forEach(r => { if(r.value && Array.isArray(r.value.items)) next[r.key.slice(4)] = {items: r.value.items}; });
        const changed = JSON.stringify(next) !== JSON.stringify(pub || {});
        pub = next; try{ localStorage.setItem(KEY, JSON.stringify(next)); }catch(e){}
        if(!ready) done(); else if(changed) apply();
      }).catch(done);
    setTimeout(done, 1200);   // never hold a page back for long
  } else done();
  // the dashboard's live preview: drafts arrive as you type
  window.addEventListener('message', e => {
    if(e.origin !== location.origin || !e.data || !e.data.crtCms) return;
    live = e.data.crtCms; apply();
  });
  return {after: f => { if(ready) f(); else waiting.push(f); }, items, on};
})();

// ---------------------------------------------------------------
// v9.6 Content layer: words, photos, links and site-wide details edited in /admin → Content.
// The pages keep their built-in content as the fallback. Saved changes are stored in Supabase
// (site_content: page_edits, site_settings), cached in the browser so they apply before first paint
// on later visits, and refreshed in the background.
//   page_edits    {"*": [...], "/weddings": [...]}   each item {k:"text"|"img"|"link", from, to}
//   site_settings {contact:{phone,email}, announcement:{on,text,link,href}, showreel:{mp4}}
// ---------------------------------------------------------------
(function(){
  const CFG = window.CRT_CONFIG || {};
  const me = document.currentScript, ROOT = me ? new URL('.', me.src).href : new URL('.', location.href).href;
  const EDIT = /[?&]crt_edit=1/.test(location.search) && window.parent !== window;   // page shown inside the admin editor
  if(EDIT){ window.__CRT_EDIT = true; document.documentElement.classList.add('crt-edit'); }
  const KEY = 'crt-content-v1';
  const norm = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
  const rel = href => { try{ const h = new URL(href, location.href).href; return h.startsWith(ROOT) ? '/' + h.slice(ROOT.length) : h; }catch(e){ return String(href || ''); } };
  const page = (() => { const k = rel(location.href.split(/[?#]/)[0]).replace(/(^|\/)index\.html$/, '$1').replace(/\/$/, ''); return k || '/'; })();
  const keyOfImg = img => img._crtFrom || rel(img.getAttribute('src') || '');
  const keyOfLink = a => a._crtFrom || rel(a.getAttribute('href') || '');
  const resolve = to => /^\//.test(to) && !/^\/\//.test(to) ? new URL(to.slice(1), ROOT).href : to;
  const safe = u => { try{ const x = new URL(resolve(u), location.href); return /^(https?:|mailto:|tel:)$/.test(x.protocol); }catch(e){ return false; } };
  const textNodes = root => {
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {acceptNode: n => (!n.nodeValue.trim() || (n.parentElement && n.parentElement.closest('script,style,textarea,noscript,select'))) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT});
    const out = []; while(w.nextNode()) out.push(w.currentNode); return out;
  };
  const setText = (n, to) => { const v = n.nodeValue; n.nodeValue = (/^\s/.test(v) ? ' ' : '') + to + (/\s$/.test(v) ? ' ' : ''); };
  function stamp(){ textNodes(document.body).forEach(n => { if(n._crtFrom === undefined) n._crtFrom = norm(n.nodeValue); }); }
  function applyEdits(list){
    if(!Array.isArray(list) || !list.length || !document.body) return;
    const T = new Map(), I = new Map(), L = new Map();
    list.forEach(e => { if(!e || typeof e.from !== 'string' || typeof e.to !== 'string') return; (e.k === 'img' ? I : e.k === 'link' ? L : T).set(e.from, e.to); });
    if(T.size) textNodes(document.body).forEach(n => {
      const from = n._crtFrom !== undefined ? n._crtFrom : norm(n.nodeValue);
      if(T.has(from)){ n._crtFrom = from; if(norm(n.nodeValue) !== T.get(from)) setText(n, T.get(from)); }
    });
    if(I.size) document.querySelectorAll('img[src]').forEach(img => {
      const from = keyOfImg(img); if(!I.has(from) || !safe(I.get(from))) return;
      img._crtFrom = from; const to = resolve(I.get(from)); if(img.src !== to){ img.removeAttribute('srcset'); img.removeAttribute('sizes'); img.src = to; }
    });
    if(L.size) document.querySelectorAll('a[href]').forEach(a => {
      const from = keyOfLink(a); if(!L.has(from) || !safe(L.get(from))) return;
      a._crtFrom = from; a.href = resolve(L.get(from));
    });
  }
  const PHONE = {digits:'250796356035', shown:'+250 796 356 035'}, MAIL = 'hello@crt.rw';
  function applySettings(st){
    if(!st) return;
    const c = st.contact || {};
    const digits = String(c.phone || '').replace(/\D/g, '');
    if(digits.length >= 10 && digits !== PHONE.digits){
      const shown = norm(c.phone);
      CRT_WA = digits;
      document.querySelectorAll('a[href]').forEach(a => { const h = a.getAttribute('href'); if(h.indexOf(PHONE.digits) > -1) a.setAttribute('href', h.split(PHONE.digits).join(digits)); });
      textNodes(document.body).forEach(n => { if(n.nodeValue.indexOf(PHONE.shown) > -1) n.nodeValue = n.nodeValue.split(PHONE.shown).join(shown); });
    }
    const mail = norm(c.email);
    if(/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(mail) && mail !== MAIL){
      document.querySelectorAll('a[href^="mailto:' + MAIL + '"]').forEach(a => a.setAttribute('href', a.getAttribute('href').replace(MAIL, mail)));
      textNodes(document.body).forEach(n => { if(n.nodeValue.indexOf(MAIL) > -1) n.nodeValue = n.nodeValue.split(MAIL).join(mail); });
    }
    if(st.announcement) window.CRT_ANNOUNCE = st.announcement;
    if(st.showreel && st.showreel.mp4 && safe(st.showreel.mp4)) window.CRT_SHOWREEL = {mp4: resolve(st.showreel.mp4)};
  }
  let current = null;
  // Client logos on the home page: {"oryx-energies": "/work-oryx-energies/", "norrsken": ""}.
  // A page address makes that logo a link to the work; an empty value removes the link. Logos not listed keep the page's own setting.
  function applyLogos(map){
    if(!map || typeof map !== 'object') return;
    document.querySelectorAll('.logo-marquee .lm-slot[data-logo]').forEach(li => {
      const k = li.dataset.logo; if(!(k in map)) return;
      const to = String(map[k] || '').trim(), hidden = !!li.closest('[aria-hidden="true"]');
      let a = li.querySelector('.lm-link'); const img = li.querySelector('img'); if(!img) return;
      if(!to || !safe(to)){ if(a){ li.appendChild(img); a.remove(); } return; }
      if(!a){
        a = document.createElement('a'); a.className = 'lm-link';
        if(hidden) a.tabIndex = -1; else a.setAttribute('aria-label', (img.alt || 'Client') + ': see the work');
        const cta = document.createElement('span'); cta.className = 'lm-cta'; cta.setAttribute('aria-hidden', 'true'); cta.innerHTML = 'See the work <i>›</i>';
        li.appendChild(a); a.append(img, cta);
      }
      a.href = resolve(to);
    });
  }
  function run(c){
    if(!c) return;
    current = c;
    if(!EDIT){ const pe = c.page_edits || {}; applyEdits([].concat(pe['*'] || [], pe[page] || [])); }
    applySettings(c.site_settings);
    applyLogos(c.client_logos);
    document.dispatchEvent(new CustomEvent('crt:content', {detail: c}));
  }
  if(EDIT){ stamp(); window.__CRT_EDITOR = {page, norm, rel, keyOfImg, keyOfLink, textNodes, setText, apply: applyEdits, stamp}; }
  let cached = null; try{ cached = JSON.parse(localStorage.getItem(KEY) || 'null'); }catch(e){}
  run(cached);
  // The menu, forms and other parts are built by script after this point: apply again once they exist.
  const again = () => run(current);
  document.addEventListener('DOMContentLoaded', () => setTimeout(again, 0));
  window.addEventListener('load', () => setTimeout(again, 1600));
  if(CFG.SUPABASE_URL && CFG.SUPABASE_ANON_KEY){
    fetch(CFG.SUPABASE_URL.replace(/\/$/, '') + '/rest/v1/site_content?select=key,value&key=in.(page_edits,site_settings,client_logos)',
      {headers: {'apikey': CFG.SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + CFG.SUPABASE_ANON_KEY}})
      .then(r => r.ok ? r.json() : null)
      .then(rows => {
        if(!rows) return;
        const c = {}; rows.forEach(r => { c[r.key] = r.value; });
        const txt = JSON.stringify(c);
        try{ localStorage.setItem(KEY, txt); }catch(e){}
        if(txt !== JSON.stringify(cached || {})) run(c);
      }).catch(() => {});
  }
})();

document.addEventListener('click', e => {
  const a = e.target.closest && e.target.closest('a[href*="wa.me/"]'); if(!a || !crtIsDesktop()) return;
  try{ const u = new URL(a.href); const num = u.pathname.replace(/\D/g, '') || CRT_WA;
    a.href = 'https://web.whatsapp.com/send?phone=' + num + (u.searchParams.get('text') ? '&text=' + encodeURIComponent(u.searchParams.get('text')) : '');
    a.target = '_blank'; a.rel = 'noopener'; }catch(err){}
}, true);
(function(){
  // The site works straight from a folder (no server), so links are built relative
  // to the folder that holds this script. u('/contact#inquiry') -> .../contact/index.html#inquiry
  const ROOT = (document.currentScript && document.currentScript.src)
    ? new URL('.', document.currentScript.src).href : new URL('/', location.href).href;
  const u = p=>{
    if(!p || p[0] !== '/') return p;
    const m = p.match(/^([^?#]*)(.*)$/); let path = m[1];
    if(path === '/' && location.protocol !== 'file:') return new URL(m[2], ROOT).href;   // home is crt.rw/, never /index.html
    if(path === '/' || path.endsWith('/')) path += 'index.html';
    else if(!/\.[a-z0-9]+$/i.test(path.split('/').pop())) path += '/index.html';
    return new URL(path.slice(1) + m[2], ROOT).href;
  };
  // '.../business/index.html' -> '/business' (used to match menu entries)
  const pageKey = href=>{
    const h = new URL(href, location.href).href.split(/[?#]/)[0];
    if(!h.startsWith(ROOT)) return null;
    return '/' + h.slice(ROOT.length).replace(/(^|\/)index\.html$/, '').replace(/\/$/, '');
  };
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.nav-links');
  if(nav) nav.querySelectorAll(':scope > a').forEach(a=>{ if(pageKey(a.href) === '/about') a.classList.add('nav-about'); });
  if(toggle && nav){
    // Phone menu: Escape closes, focus moves into the menu and back to the button, Tab stays inside, page behind stops scrolling.
    const isOpenNav = ()=>nav.classList.contains('open');
    const focusables = ()=>[toggle, ...nav.querySelectorAll('a[href], button')].filter(el=>!el.hidden && el.offsetParent !== null);
    const setNav = (open, moveFocus)=>{
      nav.classList.toggle('open', open);
      toggle.setAttribute('aria-expanded', String(open));
      toggle.textContent = open ? 'Close' : 'Menu';
      document.documentElement.classList.toggle('nav-locked', open);
      if(moveFocus){ if(open){ const f = focusables()[1]; if(f) f.focus({preventScroll:true}); } else toggle.focus({preventScroll:true}); }
    };
    toggle.addEventListener('click', e=>setNav(!isOpenNav(), e.detail === 0));
    document.addEventListener('click', e=>{ if(isOpenNav() && !e.target.closest('.site-header')) setNav(false, false); });
    nav.addEventListener('click', e=>{ if(e.target.closest('a')) setNav(false, false); });
    document.addEventListener('keydown', e=>{
      if(!isOpenNav()) return;
      if(e.key === 'Escape'){ e.preventDefault(); setNav(false, true); return; }
      if(e.key !== 'Tab') return;
      const f = focusables(); if(!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if(e.shiftKey && document.activeElement === first){ e.preventDefault(); last.focus(); }
      else if(!e.shiftKey && document.activeElement === last){ e.preventDefault(); first.focus(); }
    });
    const navWide = window.matchMedia('(min-width: 761px)');
    navWide.addEventListener && navWide.addEventListener('change', ()=>{ if(navWide.matches && isOpenNav()) setNav(false, false); });
  }
  const params = new URLSearchParams(window.location.search);

  // Swap prices in visible text, e.g. {"600,000":"1,200,000"}. One pass, so a new
  // price is never swapped twice. Skips scripts, styles and form fields.
  function crtReplaceNumbers(root, map){
    const keys = Object.keys(map);
    if(!root || !keys.length) return;
    const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const re = new RegExp('(^|[^\\d,])(' + keys.map(esc).join('|') + ')(?![\\d,])', 'g');
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: n => (n.parentElement && n.parentElement.closest('script,style,textarea,input')) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT
    });
    const nodes = []; while(walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(n => { const t = n.nodeValue; if(re.test(t)){ re.lastIndex = 0; n.nodeValue = t.replace(re, (m, a, b) => a + map[b]); } re.lastIndex = 0; });
  }

  // ---------------------------------------------------------------
  // Analytics: paste your IDs here to switch tracking on.
  //   GA_ID         e.g. 'G-XXXXXXXXXX'   (Google Analytics 4)
  //   META_PIXEL_ID e.g. '123456789012345' (Meta / Facebook Pixel)
  // While they are empty, no tracking code loads at all.
  // ---------------------------------------------------------------
  // Enquiries are saved as leads; the database files each one into the hello@ mailbox (Dashboard → Mail).
  // Public address shown to visitors if sending fails.
  const PUBLIC_EMAIL = 'hello@crt.rw';
  const GA_ID = 'G-J6F328BM6H';
  const META_PIXEL_ID = '1506800021342255';
  // Tracking only loads after the visitor accepts the cookie notice (Rwanda data
  // protection law, Law No. 058/2021). With both IDs empty, no notice is shown.
  const CONSENT_KEY = 'crt_consent';
  const getConsent = ()=>{ try{ return localStorage.getItem(CONSENT_KEY); }catch(e){ return null; } };
  const setConsent = v=>{ try{ localStorage.setItem(CONSENT_KEY, v); }catch(e){} };
  function loadTracking(){
    if(GA_ID){
      const s=document.createElement('script'); s.async=true; s.src='https://www.googletagmanager.com/gtag/js?id='+GA_ID; document.head.appendChild(s);
      window.dataLayer=window.dataLayer||[]; window.gtag=function(){dataLayer.push(arguments);}; gtag('js', new Date()); gtag('config', GA_ID, {anonymize_ip:true});
    }
    if(META_PIXEL_ID){
      !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', META_PIXEL_ID); fbq('track','PageView');
    }
  }
  if((GA_ID || META_PIXEL_ID) && !window.__CRT_EDIT){
    const choice = getConsent();
    if(choice === 'yes') loadTracking();
    else if(choice !== 'no'){
      const bar = document.createElement('div');
      bar.className = 'consent'; bar.setAttribute('role','region'); bar.setAttribute('aria-label','Cookie notice');
      bar.innerHTML = '<p>We use cookies to see which pages and ads work. <a href="/privacy/#cookies">Privacy</a></p>'+
        '<div class="consent-actions"><button type="button" class="btn small ghost" data-c="no">Decline</button><button type="button" class="btn small" data-c="yes">Accept</button></div>';
      bar.addEventListener('click', e=>{
        const b = e.target.closest('[data-c]'); if(!b) return;
        setConsent(b.dataset.c); bar.remove();
        if(b.dataset.c === 'yes') loadTracking();
      });
      // The notice is a slim bar docked to the bottom edge. It lifts the floating buttons instead of covering them,
      // and on the home page it waits for the first scroll so it never sits over the three price cards on arrival.
      const root = document.documentElement;
      const dock = ()=>{ root.style.setProperty('--consent-h', bar.offsetHeight + 'px'); };
      const show = ()=>{ if(bar.isConnected || getConsent() !== null) return; document.body.appendChild(bar); root.classList.add('has-consent'); dock(); window.addEventListener('resize', dock); };
      bar.addEventListener('click', e=>{ if(e.target.closest('[data-c]')){ root.classList.remove('has-consent'); root.style.removeProperty('--consent-h'); window.removeEventListener('resize', dock); } });
      if(document.querySelector('.hero-paths')){
        const onScroll = ()=>{ if(window.scrollY > 200){ window.removeEventListener('scroll', onScroll); show(); } };
        window.addEventListener('scroll', onScroll, {passive:true}); onScroll();
      } else show();
    }
  }
  // Privacy page: "Choose again" clears the saved cookie choice and shows the notice again.
  document.addEventListener('click', e=>{
    if(!e.target.closest('[data-consent-reset]')) return;
    try{ localStorage.removeItem(CONSENT_KEY); }catch(err){}
    location.reload();
  });
  const trackLead = (label)=>{
    if(typeof window.gtag==='function') gtag('event','generate_lead',{form_location:location.pathname,label:label});
    if(typeof window.fbq==='function') fbq('track','Lead',{content_name:label});
  };

  // Where did this visitor come from? Remember the ad / campaign for the session.
  const SOURCE_KEY = 'crt_source';
  (function(){
    const utm = ['utm_source','utm_medium','utm_campaign'].map(k=>params.get(k)).filter(Boolean);
    let src = utm.length ? utm.join(' / ') : (params.get('fbclid') ? 'facebook / instagram ad' : (params.get('gclid') ? 'google ad' : ''));
    try{
      if(src) sessionStorage.setItem(SOURCE_KEY, src);
      else if(!sessionStorage.getItem(SOURCE_KEY)){
        const ref = document.referrer && new URL(document.referrer).hostname;
        sessionStorage.setItem(SOURCE_KEY, ref && ref !== location.hostname ? ref : 'direct');
      }
    }catch(e){}
  })();
  const getSource = ()=>{ try{ return sessionStorage.getItem(SOURCE_KEY) || 'direct'; }catch(e){ return 'unknown'; } };

  document.querySelectorAll('[data-booking-form]').forEach(form=>{
    const formService = form.dataset.service || params.get('service') || 'Creative project';
    const formOffer = form.dataset.offer || params.get('offer') || '';
    const serviceField = form.querySelector('[name="service"]');
    const offerField = form.querySelector('[name="offer"]');
    if(serviceField) serviceField.value = params.get('service') || formService;
    if(offerField) offerField.value = params.get('offer') || formOffer;
    if(params.get('date')) { const dateField=form.querySelector('[name="date"]'); if(dateField) dateField.value=params.get('date'); }
    // Contact form: tick the matching "What do you need?" chips from ?service=
    const pre = (params.get('service') || '').toLowerCase();
    if(pre) [['photo','Photography'],['video','Video'],['film','Video'],['event','Event coverage'],['brand','Branding & design'],['design','Branding & design'],['social','Social media'],['web','Website'],['wedding','Wedding']]
      .forEach(([k, v]) => { if(pre.includes(k)){ const c = form.querySelector('[name="need"][value="' + v + '"]'); if(c) c.checked = true; } });
    const status = form.querySelector('.form-status');
    const sendBtn = form.querySelector('button[type="submit"]');
    const waBtn = form.querySelector('[data-send-whatsapp]');
    const sendLabel = sendBtn ? sendBtn.textContent : '';
    const collect = ()=>{
      const set = (n,v)=>{ const f=form.querySelector('[name="'+n+'"]'); if(f) f.value=v; };
      set('page', location.pathname);
      set('source', getSource());
      const data = new FormData(form);
      const needs = data.getAll('need');
      return {data, service: needs.length ? needs.join(', ') : (data.get('service') || formService), offer: data.get('offer') || formOffer};
    };
    // A copy of every enquiry goes to the admin dashboard (Supabase), if connected.
    const saveLead = ({data, service, offer}, channel)=>{
      const CFG = window.CRT_CONFIG || {};
      if(!CFG.SUPABASE_URL || !CFG.SUPABASE_ANON_KEY || data.get('bot-field')) return Promise.resolve(false);
      const cut = (v,n)=> (v||'').toString().slice(0,n) || null;
      try{
        return fetch(CFG.SUPABASE_URL.replace(/\/$/,'') + '/rest/v1/leads', {
          method:'POST', keepalive:true,
          headers:{'apikey':CFG.SUPABASE_ANON_KEY,'Authorization':'Bearer '+CFG.SUPABASE_ANON_KEY,'Content-Type':'application/json','Prefer':'return=minimal'},
          body: JSON.stringify({
            name: cut(data.get('name'),120) || 'Unknown', contact: cut(data.get('contact'),160) || 'Unknown',
            service: cut(service,120), offer: cut(offer,120), event_date: cut(data.get('date'),120),
            details: cut([data.get('company') ? 'Company: ' + data.get('company') : '', data.get('budget') ? 'Budget: ' + data.get('budget') : '', data.get('details')].filter(Boolean).join('\n'),2000), page: cut(location.pathname,200),
            source: cut(getSource() + ' · via ' + channel, 200)
          })
        }).then(r => r.ok).catch(() => false);
      }catch(err){ return Promise.resolve(false); }
    };
    const show = (kind, html)=>{ if(!status) return; status.className = 'form-status is-' + kind; status.innerHTML = html; status.hidden = false; };
    const waLink = ({data, service, offer})=>{
      const lines = [
        'Hi CRT Media Agency, I would like to enquire about a project.',
        'Service: ' + service,
        offer ? 'Offer/package: ' + offer : '',
        data.get('name') ? 'Name: ' + data.get('name') : '',
        data.get('company') ? 'Company: ' + data.get('company') : '',
        data.get('budget') ? 'Budget: ' + data.get('budget') : '',
        data.get('contact') ? 'Email or phone: ' + data.get('contact') : '',
        data.get('date') ? 'Preferred date/timeline: ' + data.get('date') : '',
        data.get('details') ? 'Project details: ' + data.get('details') : '',
      ].filter(Boolean);
      return crtWaUrl(lines.join('\n'));
    };

    // Choice 1 (default): email the enquiry to our inbox.
    form.addEventListener('submit', function(e){
      e.preventDefault();
      const info = collect(), data = info.data;
      if(data.get('bot-field')) return;
      const leadSaved = saveLead(info, 'email');
      trackLead(info.offer || info.service);
      if(sendBtn){ sendBtn.disabled = true; sendBtn.textContent = 'Sending…'; }
      if(status) status.hidden = true;
      // Saved as a lead; the database also files it into the hello@ mailbox (Dashboard → Mail) and forwards a copy if set.
      leadSaved
        .then(l => {
          if(!l) throw new Error('not sent');
          const name = (data.get('name') || '').toString().split(' ')[0];
          show('ok', '<strong>Thank you' + (name ? ', ' + name.replace(/[<>&]/g,'') : '') + '!</strong> Your enquiry has reached us. We usually reply within 2 hours.');
          form.reset();
          const sf = form.querySelector('[name="service"]'), of = form.querySelector('[name="offer"]');
          if(sf) sf.value = info.service; if(of) of.value = info.offer;
        })
        .catch(() => {
          show('error', 'Sorry, we couldn’t send that just now. Please <a href="' + waLink(info) + '" target="_blank" rel="noopener">send it on WhatsApp</a> or write to <a href="mailto:' + PUBLIC_EMAIL + '">' + PUBLIC_EMAIL + '</a>.');
        })
        .finally(() => { if(sendBtn){ sendBtn.disabled = false; sendBtn.textContent = sendLabel; } });
    });

    // Choice 2: send the same details on WhatsApp instead.
    if(waBtn) waBtn.addEventListener('click', function(){
      if(!form.reportValidity()) return;
      const info = collect();
      if(info.data.get('bot-field')) return;
      saveLead(info, 'WhatsApp');
      trackLead(info.offer || info.service);
      const url = waLink(info);
      if(crtIsDesktop()){
        window.open(url, '_blank', 'noopener');
        show('ok', '<strong>WhatsApp is opening in a new tab</strong> with your message ready. Press send there. Didn’t open? Use <em>Send enquiry</em> instead, or message us on +250 796 356 035.');
      } else window.location.href = url;
    });
  });
  document.querySelectorAll('[data-prefill-service]').forEach(link=>{
    const target = new URL(link.href, window.location.href);
    target.searchParams.set('service', link.dataset.prefillService);
    if(link.dataset.prefillOffer) target.searchParams.set('offer', link.dataset.prefillOffer);
    link.href = target.toString();
  });
  // Bottom action bar on every page: "Ask a question" (WhatsApp) + the page's main action.
  // Replaces the old floating WA circle and phone-only enquiry button.
  (function(){
    if(document.querySelector('[data-builder],[data-book]')){ document.querySelectorAll('.whatsapp-float,.mobile-booking').forEach(el => el.remove()); return; } // the builder has its own summary bar with the booking action
    const oldMain = document.querySelector('.mobile-booking a');
    const oldWa = document.querySelector('.whatsapp-float');
    const hasForm = !!document.getElementById('inquiry');
    const bar = document.createElement('div');
    bar.className = 'action-bar' + (document.querySelector('.hero-paths,.wd-hero,.ts-hero') ? ' is-hidden' : '');
    const ask = document.createElement('a');
    ask.className = 'action-ask';
    ask.href = oldWa ? oldWa.href : 'https://wa.me/250796356035';
    ask.target = '_blank'; ask.rel = 'noopener';
    ask.dataset.track = 'bar_whatsapp';
    ask.innerHTML = '<span class="action-dot"></span><span class="lbl-long">Ask a question</span><span class="lbl-short">Ask</span>';
    const main = document.createElement('a');
    main.className = 'btn action-main';
    const BK_FAM = {business:'business','commercial-photography-video':'business','branding-graphic-design':'business','web-digital':'business','social-media-content':'business','business-photo-video-branding-prices-kigali':'business',events:'events','event-photography-prices-kigali':'events',weddings:'weddings','wedding-photography-prices-kigali':'weddings'}[(pageKey(location.href) || '/').split('/')[1]];
    main.href = u('/book/') + (BK_FAM ? '?s=' + BK_FAM : '');
    main.dataset.track = 'bar_main';
    main.textContent = 'Book';
    // "Book a call" (filled with BOOKING_URL below; stays hidden if there is no link)
    const CAL_ICON = '<svg class="cal-ico" viewBox="0 0 20 20" aria-hidden="true"><rect x="3" y="4.5" width="14" height="12.5" rx="2.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M3 8.5h14M7 2.8v3.4M13 2.8v3.4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>';
    const call = document.createElement('a');
    call.className = 'action-call';
    call.href = u('/contact'); call.hidden = true;
    call.setAttribute('data-booking-link','');
    call.dataset.track = 'bar_book_call';
    call.innerHTML = CAL_ICON + '<span class="lbl-long">Book a free call</span><span class="lbl-short">Call</span>';
    bar.append(ask, call, main);
    document.body.appendChild(bar);
    // Header: "Book a call" beside "Get a quote"
    const navCta = document.querySelector('.nav-links .nav-cta');
    if(navCta){
      const actions = document.createElement('div');
      actions.className = 'nav-actions';
      const navCall = document.createElement('a');
      navCall.className = 'nav-call';
      navCall.href = u('/contact'); navCall.hidden = true;
      navCall.setAttribute('data-booking-link','');
      navCall.dataset.track = 'nav_book_call';
      navCall.innerHTML = CAL_ICON + '<span>Book a call</span>';
      navCta.parentNode.insertBefore(actions, navCta);
      actions.append(navCall, navCta);
      const navShop = document.querySelector('.nav-links .nav-shop');
      if(navShop) actions.append(navShop); // Shop sits at the far right, after "Get a quote"
    }
    document.querySelectorAll('.mobile-booking,.whatsapp-float').forEach(el=>el.remove());
    document.body.classList.add('has-action-bar');
    // Get out of the way when the form, the footer or the home hero tiles are on screen.
    const targets = [document.getElementById('inquiry'), document.querySelector('footer'), document.querySelector('.hero-paths'), document.querySelector('.wd-hero .cta-row'), document.querySelector('.ts-hero .ts-cta')].filter(Boolean);
    if('IntersectionObserver' in window && targets.length){
      const seen = new Set();
      const io = new IntersectionObserver(entries=>{
        entries.forEach(e=>e.isIntersecting ? seen.add(e.target) : seen.delete(e.target));
        bar.classList.toggle('is-hidden', seen.size > 0);
      }, {threshold: 0.15});
      targets.forEach(t=>io.observe(t));
    }
  })();

  // ---------------------------------------------------------------
  // "Book a call": paste your Cal.com / Calendly / Google Calendar
  // booking-page link here. While it is empty, every "Book a call"
  // button stays hidden, so nothing broken ever shows.
  // ---------------------------------------------------------------
  const BOOKING_URL = 'https://cal.com/crt-media-agency-djafrq/20-minutes-meeting-with-crt';
  document.querySelectorAll('[data-booking-link]').forEach(el=>{
    if(!BOOKING_URL) return;
    el.href = BOOKING_URL;
    el.target = '_blank'; el.rel = 'noopener';
    (el.closest('[data-booking]') || el).hidden = false;
  });

  // ---------------------------------------------------------------
  // Menu panels (desktop): every menu item opens a panel with photos
  // and quick links; the page is blurred behind it.
  // Footer: Kigali local time (helps clients abroad plan a call)
  (function(){
    const el = document.querySelector('[data-kigali-time]'); if(!el || !window.Intl) return;
    let fmt; try{ fmt = new Intl.DateTimeFormat('en-GB', {hour:'2-digit', minute:'2-digit', timeZone:'Africa/Kigali'}); }catch(e){ return; }
    const tick = () => { el.textContent = 'Kigali time ' + fmt.format(new Date()); };
    tick(); el.hidden = false; setInterval(tick, 30000);
  })();

  // ---------------------------------------------------------------
  // Main menu (v8.9): audience-led top bar, grouped panels with prices,
  // one proof card and one quote card per panel. To change a panel, edit PANELS.
  // Each item: [icon key or 'img:/path', name, one line, link]
  // ---------------------------------------------------------------
  (function(){
    const nav = document.querySelector('.nav-links'), header = document.querySelector('.site-header');
    if(!nav || !header) return;
  const I = {
      camera:'<path d="M4 8h3l2-2.5h6L17 8h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
      film:'<rect x="3.5" y="6" width="12" height="12" rx="2"/><path d="M15.5 10.5l5-3v9l-5-3"/>',
      event:'<rect x="4" y="5.5" width="16" height="14" rx="2"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/><path d="M9.5 14.5l2 2 3.5-3.5"/>',
      brand:'<path d="M12 3.5l2.4 5 5.4.6-4 3.7 1.1 5.4L12 15.5l-4.9 2.7 1.1-5.4-4-3.7 5.4-.6z"/>',
      design:'<path d="M4 20l4-1 10.5-10.5a2.1 2.1 0 0 0-3-3L5 16z"/><path d="M14 7l3 3"/>',
      web:'<rect x="3.5" y="5" width="17" height="12" rx="2"/><path d="M8.5 20h7M12 17v3"/><path d="M9.5 9.5L7.5 11l2 1.5M14.5 9.5l2 1.5-2 1.5"/>',
      social:'<path d="M5 18.5V12M10 18.5V8.5M15 18.5v-5M20 18.5V5"/>',
      rocket:'<path d="M14 4.5c3 0 5.5 2.5 5.5 5.5L13 16.5 7.5 11z"/><path d="M7.5 11l-3 .5 2-3.5h4M13 16.5l-.5 3 3.5-2v-4"/><circle cx="14.5" cy="9.5" r="1.3"/>',
      ring:'<circle cx="12" cy="14" r="5.5"/><path d="M9.5 4.5h5l1.5 2.5-4 2-4-2z"/>',
      grow:'<path d="M4 17l5-5 4 4 7-7"/><path d="M15 9h5v5"/>',
      hotel:'<path d="M4 20V6h10v14M14 10h6v10M7 9.5h1.5M10 9.5h1.5M7 13h1.5M10 13h1.5M8 20v-3h3v3"/>',
      food:'<path d="M7 3.5v7M5 3.5v4a2 2 0 0 0 4 0v-4M7 10.5v10M16.5 20.5V3.5c-2 1.5-3 4-3 7h3"/>',
      corp:'<rect x="4" y="7.5" width="16" height="11.5" rx="2"/><path d="M9 7.5V5.5h6v2M4 12.5h16"/>',
      well:'<path d="M12 20s-7-4.3-7-9.5A4 4 0 0 1 12 8a4 4 0 0 1 7 2.5C19 15.7 12 20 12 20z"/>'
    };
  const PANELS = {
      business: {
        label: 'For Businesses', all: ['All business services','/business/'], cta: ['Book','/book/?s=business'],
        groups: [
          ['Capture', [
            ['camera','Photography','Product, food and brand photos, from 400,000 RWF','/commercial-photography-video/'],
            ['film','Video','Brand videos and reels for launches and ads','/commercial-photography-video/'] ]],
          ['Build your brand', [
            ['brand','Branding & identity','Logos, colours and brand kits, from 250,000 RWF','/branding-graphic-design/'],
            ['design','Graphic design','Posters, banners and social posts','/branding-graphic-design/'],
            ['web','Websites','Fast, mobile-first sites, from 600,000 RWF','/web-digital/'] ]],
          ['Grow', [
            ['social','Social media & content','Planned, shot and posted, from 500,000 RWF / month','/social-media-content/'],
            ['grow','Content session','One half-day shoot, a month of content, from 400,000 RWF','/offer-commercial-content-session/'],
            ['rocket','Fixed-price offers','Launch bundle, brand kit and more','/offers/#business'] ]]
        ],
        feature: ['/assets/work/cases/oryx-energies/03-800.webp','Case study · ORYX Energies','Engine oil, shot like a premium product','/work-oryx-energies/']
      },
      events: {
        label: 'Event Coverage', all: ['Events overview','/events/'], cta: ['Check my date','/book/?s=events'],
        groups: [
          ['Book coverage', [
            ['event','Event coverage','3 packages, from 200,000 RWF','/events/#packages'],
            ['social','Event + social bundle','Coverage plus ready-to-post content, from 200,000 RWF','/offer-event-social-bundle/'],
            ['brand','Event branding','Badges, banners, stage and roll-ups','/work-rwanda-mining-week/'] ]],
          ['Recent events', [
            ['corp','SanlamAllianz Agents Day','An appreciation day where every agent made the frame','/work-sanlam-allianz-agents-day/'],
            ['corp','Old Mutual year-end','A year-end party with the whole team in the frame','/work-old-mutual-year-end/'],
            ['film','All event case studies','Conferences, launches and workshops','/work/#for-corporate-events'] ]]
        ],
        feature: ['/assets/work/cases/rwanda-mining-week/site-accreditation-800.webp','Case study · Rwanda Mining Week','One visual system, from badge to main stage','/work-rwanda-mining-week/']
      },
      weddings: {
        label: 'Weddings', all: ['Weddings overview','/weddings/'], cta: ['Check my date','/book/?s=weddings'],
        groups: [
          ['Packages', [
            ['img:/assets/work/cases/wedding-sandra-mathias/cover-800.webp','Basic','1,200,000 RWF · photos of all four days','/weddings/#packages'],
            ['img:/assets/work/cases/wedding-sandra-mathias/01-800.webp','Standard','2,000,000 RWF · photos and video','/weddings/#packages'],
            ['img:/assets/work/cases/wedding-mirindi-ange/05-800.webp','Premium','3,000,000 RWF · the complete journey, with livestream','/weddings/#packages'],
            ['img:/assets/work/cases/wedding-mirindi-ange/06-800.webp','VIP','4,500,000 RWF · everything, plus a same-day edit','/weddings/#packages'] ]],
          ['More for your day', [
            ['event','Build your own','Only the days you need, from 200,000 RWF','/weddings/#days'],
            ['grow','Book early, save 30%','Packages from 840,000 RWF','/offer-wedding-early-booking/'],
            ['design','Albums & prints','Keep the day in print','/print/#weddings'] ]]
        ],
        feature: ['/assets/work/cases/wedding-mirindi-ange/06-800.webp','Wedding stories','See real couples and their full galleries','/work/#for-weddings']
      },
      work: {
        label: 'Our Work', all: ['All work','/work/'], cta: ['Get a quote','/contact/'],
        groups: [
          ['By service', [
            ['camera','Photography','Products, food, hotels and events','/work/#photography'],
            ['film','Video','Highlight videos and reels','/work/#film'],
            ['brand','Branding','Logos and event identities','/work/#branding'],
            ['design','Graphic design','Posters, banners and social posts','/work/#graphic-design'] ]],
          ['By industry', [
            ['hotel','Hotels & hospitality','TR-5 Resort, Million Views, Zora Lounge','/work/#for-hospitality'],
            ['food','Food & drink brands','Inka Steak House, Phizer Wines, Terrassa Wines','/work/#for-food-drink'],
            ['corp','Corporate & finance','Old Mutual, SanlamAllianz, Rwanda Mining Week','/work/#for-corporate-events'],
            ['well','Beauty, sport & wellness',"L'OU Aesthetic Center, SportsPark",'/work/#for-beauty-wellness'] ]]
        ],
        feature: ['/assets/work/cases/inka-steak-house/01-800.webp','Portfolio','See all our work','/work/']
      },
      offers: { label: 'Offers', all: ['All offers','/offers/'], cta: ['Book','/book/'], groups: [] },
      print: { label: 'Print', all: ['All print','/print/'], cta: ['Send a request','/print/'], groups: [] }
    };
    const esc = s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;');
    const ico = k=> k.startsWith('img:') ? `<span class="mm-ico mm-thumb" aria-hidden="true"><img src="${u(k.slice(4))}" alt="" loading="lazy" decoding="async"></span>` : `<span class="mm-ico" aria-hidden="true"><svg viewBox="0 0 24 24">${I[k]}</svg></span>`;
    const item = ([k,n,d,h])=>`<a class="mm-item" href="${u(h)}">${ico(k)}<span><strong>${esc(n)}</strong><small>${esc(d)}</small></span></a>`;
    const allRow = p=>`<a class="mm-all" href="${u(p.all[1])}">${esc(p.all[0])} <span aria-hidden="true">→</span></a>`;
    const quote = p=>`<a class="mm-quote" data-track="menu_quote_click" href="${u(p.cta[1])}"><strong>${esc(p.cta[0])} <span aria-hidden="true">→</span></strong><small>We usually reply within 2 hours.</small></a>`;
    const KEYS = {'/business':'business','/events':'events','/weddings':'weddings','/work':'work','/offers':'offers','/print':'print'};
    const here = pageKey(location.href) || '';
    const triggers = [];
    // Swap the four section links for menu buttons (the plain links stay in the HTML for no-JS and search engines)
    [...nav.querySelectorAll(':scope > a')].forEach(a=>{
      const key = KEYS[pageKey(a.href)], p = key && PANELS[key]; if(!p) return;
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'mm-trigger' + (a.classList.contains('nav-offers') ? ' nav-offers' : ''); b.dataset.key = key;   // Offers keeps its tinted pill
      b.setAttribute('aria-expanded','false'); b.setAttribute('aria-controls','mm-' + key);
      b.innerHTML = `${esc(p.label)}<svg class="mm-chev" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 4.5l3 3 3-3"/></svg>`;
      const root = pageKey(a.href);
      if(here === root || here.startsWith(root + '/') || (key === 'work' && here.startsWith('/work-'))) b.classList.add('is-current');
      const sub = document.createElement('div');
      sub.className = 'mm-sub'; sub.id = 'mm-sub-' + key; sub.hidden = true;
      sub.innerHTML = allRow(p) + p.groups.map(([g, items])=>`<p class="mm-glabel">${esc(g)}</p>` + items.map(item).join('')).join('');
      a.replaceWith(b, sub); triggers.push(b);
    });
    if(!triggers.length) return;
    // Desktop: centre the menu in the free space between the logo and the buttons (their widths differ)
    const brand = header.querySelector('.brand');
    const balance = ()=>{
      if(!brand) return;
      const acts = nav.querySelector('.nav-actions');
      const h = header.getBoundingClientRect(), b = brand.getBoundingClientRect();
      if(!acts){ const side = Math.round(b.right - h.left + 24) + 'px'; nav.style.setProperty('--nav-l', side); nav.style.setProperty('--nav-r', side); return; }   // no buttons on the right: centre the menu in the bar, like apple.com
      const a = acts.getBoundingClientRect();
      if(!a.width) return;
      nav.style.setProperty('--nav-l', Math.round(b.right - h.left + 24) + 'px');
      nav.style.setProperty('--nav-r', Math.round(h.right - a.left + 24) + 'px');
    };
    balance(); window.addEventListener('resize', balance, {passive:true}); window.addEventListener('load', balance);
    if(document.fonts && document.fonts.ready) document.fonts.ready.then(balance);
    new MutationObserver(balance).observe(nav, {subtree:true, attributes:true, attributeFilter:['hidden']});
    const panel = document.createElement('div');
    panel.className = 'mm-panel';
    // v10.2 Apple-style panels: a big-link column ("Explore ..."), small link columns, no icons or photos.
    // [name, link, optional grey note]. First group is shown large, the rest small. Edit here to change the menu.
    // Apple's pattern per panel: "Explore" = the lineup (big links), "Shop" = how to buy (quote, help me choose,
    // prices, offers, a call), "More from" = support and proof (questions, what's included, case studies).
    const CALL = 'https://cal.com/crt-media-agency-djafrq/20-minutes-meeting-with-crt';
    const APPLE = {
      business: [
        ['Explore Business', [['All business services','/business/'],['Photo & video','/commercial-photography-video/'],['Branding & design','/branding-graphic-design/'],['Websites','/web-digital/'],['Social media content','/social-media-content/']]],
        ['Book for business', [['Book','/book/?s=business'],['Help me choose','/build/?for=business'],['Fixed-price offers','/offers/#business'],['Compare & prices','/business-photo-video-branding-prices-kigali/'],['Book a 20-minute call',CALL]]],
        ['More for business', [['Business case studies','/work/#wk-business'],['About CRT','/about/']]]
      ],
      events: [
        ['Explore Events', [['Events overview','/events/'],['Event coverage packages','/events/#packages'],['Event + social bundle','/offer-event-social-bundle/']]],
        ['Book an event', [['Book','/book/?s=events'],['Help me choose','/build/?for=events'],['Compare & prices','/event-photography-prices-kigali/'],['Book a 20-minute call',CALL]]],
        ['More for events', [['What every package includes','/events/#whats-included'],['Recent events','/work/#wk-events']]]
      ],
      weddings: [
        ['Explore Weddings', [['Weddings overview','/weddings/'],['Wedding packages','/weddings/#packages'],['Compare packages & prices','/wedding-photography-prices-kigali/'],['Book only the days you need','/weddings/#days'],['Albums & prints','/print/#weddings']]],
        ['Book your wedding', [['Book','/book/?s=weddings'],['Help me choose','/build/?for=weddings'],['Book early, save 30%','/offer-wedding-early-booking/'],['Book a 20-minute call',CALL]]],
        ['More for couples', [['Included in every wedding','/weddings/#included'],['Wedding stories','/work/#wk-weddings']]]
      ],
      work: [
        ['Explore Our Work', [['All work','/work/'],['Photography','/work/#photography'],['Video','/work/#film'],['Branding','/work/#branding'],['Websites','/work/#web']]],
        ['By industry', [['Hotels & hospitality','/work/#for-hospitality'],['Food & drink','/work/#for-food-drink'],['Corporate events','/work/#for-corporate-events'],['Weddings','/work/#for-weddings']]],
        ['More from CRT', [['About CRT','/about/'],['Price guides','/guides/'],['Leave a review','/review/'],['Contact us','/contact/']]]
      ],
      offers: [
        ['Explore Offers', [['All offers','/offers/'],['Launch bundle','/offer-launch-bundle/'],['Brand starter kit','/offer-brand-starter-kit/'],['Content session','/offer-commercial-content-session/'],['Website launch','/offer-website-launch/'],['Monthly content plan','/offer-monthly-content/']]],
        ['Events and weddings', [['Event + social bundle','/offer-event-social-bundle/','From 200,000 RWF'],['Book early, save 30%','/offer-wedding-early-booking/','Weddings 6+ months away']]],
        ['Book with confidence', [['Book','/book/'],['Help me choose','/build/'],['Compare prices','/guides/']]]
      ],
      print: [
        ['Explore Print', [['All print','/print/'],['Business print','/print/#business'],['Event print','/print/#events'],['Wedding print','/print/#weddings'],['Custom print','/print/#custom']]],
        ['Popular', [['Business cards','/print/#business-cards'],['Roll-up banners','/print/#rollup-banner'],['Lay-flat albums','/print/#layflat-album']]],
        ['Questions', [['Ask about print on WhatsApp','https://wa.me/250796356035?text=Hi%20CRT%2C%20I%20have%20a%20question%20about%20print.'],['Contact us','/contact/']]]
      ]
    };
    const alink = ([n,h,note])=>`<a class="mm-link2" href="${u(h)}"${/^https?:/.test(h) ? ' target="_blank" rel="noopener"' : ''}>${esc(n)}${note ? `<small>${esc(note)}</small>` : ''}</a>`;
    // Phone menu: the same Explore / Book / More columns as the desktop panels
    triggers.forEach(t=>{ const sub = nav.querySelector('#mm-sub-' + t.dataset.key), g = APPLE[t.dataset.key]; if(!sub || !g) return;
      sub.innerHTML = g.map(([h, items], i)=>`<p class="mm-glabel">${esc(h)}</p>` + items.map(it=>alink(it).replace('class="mm-link2"', 'class="mm-link2 ' + (i ? 'mm-s' : 'mm-b') + '"')).join('')).join(''); });
    panel.innerHTML = triggers.map(t=>{ const key = t.dataset.key, p = PANELS[key], g = APPLE[key];
      return `<div class="mm-pane" id="mm-${key}" data-key="${key}" role="region" aria-label="${esc(p.label)}" hidden><div class="mm-inner">` +
        g.map(([h, items], i)=>`<div class="mm-col ${i ? 'mm-small' : 'mm-big'}"><p class="mm-glabel">${esc(h)}</p>${items.map(alink).join('')}</div>`).join('') + `</div></div>`; }).join('');
    const scrim = document.createElement('div'); scrim.className = 'mm-scrim';
    // v9.7 Stripe-style morph: a caret that slides to the hovered item, and panes that slide
    // sideways (direction follows the menu order) while the panel eases to the new height.
    const caret = document.createElement('div'); caret.className = 'mm-caret'; caret.setAttribute('aria-hidden','true');
    document.body.append(scrim, panel, caret);
    if(window.crtPrices){ window.crtPrices.apply(panel); window.crtPrices.apply(nav); }

    const wide = window.matchMedia('(hover: hover) and (pointer: fine) and (min-width: 761px)');
    const desk = window.matchMedia('(min-width: 761px)');
    let current = null, openT, closeT;
    const mv = {x:0, y:0, px:0, py:0};
    document.addEventListener('pointermove', e=>{ if(!current) return; mv.px = mv.x; mv.py = mv.y; mv.x = e.clientX; mv.y = e.clientY; }, {passive:true});
    const place = ()=>{ panel.style.top = Math.round(header.getBoundingClientRect().bottom) + 'px'; };
    const links = key=>[...panel.querySelectorAll('#mm-' + key + ' a')];
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
    const order = triggers.map(t=>t.dataset.key), EASE = 'cubic-bezier(.22,.8,.24,1)';
    let morphT;
    const aim = (key, instant)=>{
      const t = triggers.find(x=>x.dataset.key === key); if(!t) return;
      const r = t.getBoundingClientRect(), pl = panel.getBoundingClientRect().left, x = Math.round(r.left + r.width / 2);
      caret.classList.toggle('no-anim', !!instant);
      caret.style.left = x + 'px'; caret.style.top = panel.style.top;
      panel.style.transformOrigin = Math.round(x - pl) + 'px 0';
    };
    const settle = ()=>{
      clearTimeout(morphT); panel.classList.remove('mm-morph'); panel.style.height = '';
      panel.querySelectorAll('.mm-pane').forEach(p=>{
        if(p.getAnimations) p.getAnimations().forEach(a=>a.cancel());
        if(p.classList.contains('mm-leave')){ p.classList.remove('mm-leave'); p.style.cssText = ''; }
        p.hidden = p.dataset.key !== current;
      });
    };
    const show = key=>{
      clearTimeout(closeT); place();
      const wasOpen = document.body.classList.contains('mm-open') && !!current;
      if(wasOpen && current === key){ aim(key); return; }
      // Read the live height and opacity first, so a morph interrupted mid-way carries on without a snap
      const from = wasOpen && panel.querySelector('#mm-' + current), to = panel.querySelector('#mm-' + key);
      const h0 = panel.getBoundingClientRect().height, op0 = from ? +getComputedStyle(from).opacity : 1;
      settle();
      if(from && to && !reduce.matches && to.animate){
        const dir = order.indexOf(key) > order.indexOf(current) ? 1 : -1;
        from.style.cssText = `position:absolute;top:${from.offsetTop}px;left:${from.offsetLeft}px;width:${from.offsetWidth}px;margin:0;pointer-events:none`;
        from.classList.add('mm-leave'); to.hidden = false;
        const h1 = panel.offsetHeight;
        panel.classList.add('mm-morph'); panel.style.height = h0 + 'px'; void panel.offsetHeight; panel.style.height = h1 + 'px';
        from.animate([{opacity:op0, transform:'none'}, {opacity:0, transform:`translateX(${-dir * 56}px)`}], {duration:220, easing:EASE, fill:'forwards'});
        to.animate([{opacity:0, transform:`translateX(${dir * 56}px)`}, {opacity:1, transform:'none'}], {duration:340, easing:EASE});
        morphT = setTimeout(settle, 380);
      } else {
        panel.querySelectorAll('.mm-pane').forEach(p=>p.hidden = p.dataset.key !== key);
      }
      current = key; aim(key, !wasOpen);
      triggers.forEach(t=>t.setAttribute('aria-expanded', String(t.dataset.key === key)));
      document.body.classList.add('mm-open');
    };
    const hide = ()=>{ document.body.classList.remove('mm-open'); current = null; triggers.forEach(t=>t.setAttribute('aria-expanded','false')); };
    const close = d=>{ clearTimeout(openT); clearTimeout(closeT); closeT = setTimeout(hide, d == null ? 200 : d); };
    triggers.forEach(t=>{
      const key = t.dataset.key, sub = nav.querySelector('#mm-sub-' + key);
      t.addEventListener('pointerenter', ()=>{ if(!wide.matches) return; clearTimeout(closeT); clearTimeout(openT);
        if(!current){ openT = setTimeout(()=>show(key), 90); return; }
        // Stripe-style intent: a pointer heading down toward the open panel only grazes this item,
        // so wait a beat before switching; it switches at once when moving along the bar.
        const dx = mv.x - mv.px, dy = mv.y - mv.py;
        if(current !== key && dy > 1 && dy > Math.abs(dx) * .6) openT = setTimeout(()=>show(key), 140); else show(key); });
      t.addEventListener('pointerleave', ()=>{ if(wide.matches) close(); });
      t.addEventListener('click', e=>{
        if(desk.matches){
          if(e.detail && wide.matches){ clearTimeout(openT); show(key); return; }   // mouse: hover already opened it, a click keeps it open
          if(current === key){ hide(); return; }
          show(key); if(e.detail === 0){ const f = links(key)[0]; if(f) f.focus(); }
          return;
        }
        const open = sub.hidden; sub.hidden = !open; t.setAttribute('aria-expanded', String(open));
      });
    });
    nav.querySelectorAll(':scope > a, .nav-actions a').forEach(a=>a.addEventListener('pointerenter', ()=>{ if(wide.matches) close(60); }));
    panel.addEventListener('pointerenter', ()=>clearTimeout(closeT));
    panel.addEventListener('pointerleave', ()=>{ if(wide.matches) close(); });
    scrim.addEventListener('click', ()=>close(0));
    // Keyboard: Tab runs through the open panel, then on to the next item in the bar
    panel.addEventListener('keydown', e=>{
      if(e.key !== 'Tab' || !current) return;
      const l = links(current), t = triggers.find(x=>x.dataset.key === current);
      if(e.shiftKey && document.activeElement === l[0]){ e.preventDefault(); t.focus(); }
      else if(!e.shiftKey && document.activeElement === l[l.length - 1]){
        e.preventDefault(); const all = [...nav.querySelectorAll(':scope > button, :scope > a, .nav-actions a')].filter(el=>!el.hidden && el.offsetParent !== null);
        const nx = all[all.indexOf(t) + 1]; hide(); (nx || t).focus();
      }
    });
    document.addEventListener('keydown', e=>{ if(e.key === 'Escape' && current){ const t = triggers.find(x=>x.dataset.key === current); hide(); if(t) t.focus(); } });
    document.addEventListener('focusin', e=>{ if(!current || panel.contains(e.target)) return; const t = e.target.closest && e.target.closest('.mm-trigger'); if(!t || t.dataset.key !== current) hide(); });
    window.addEventListener('scroll', ()=>{ if(current){ place(); aim(current, true); } }, {passive:true});
    desk.addEventListener && desk.addEventListener('change', hide);
  })();

  // Breadcrumb at the foot of every page, like apple.com ("Apple > Mac > MacBook Air")
  (function(){
    const f = document.querySelector('footer.footer'); if(!f || f.querySelector('.crumbs')) return;
    const path = (pageKey(location.href) || '/').replace(/\/index\.html$/, '').replace(/\/$/, '') || '/';
    const seg = path.split('/')[1] || '';
    const CAT = {business:['Business','/business'], events:['Events','/events'], weddings:['Weddings','/weddings'], work:['Our work','/work'], offers:['Offers','/offers'], print:['Print','/print']};
    const PARENT = {'commercial-photography-video':'business','branding-graphic-design':'business','web-digital':'business','social-media-content':'business',
      'business-photo-video-branding-prices-kigali':'business','offer-launch-bundle':'business','offer-brand-starter-kit':'business','offer-commercial-content-session':'business',
      'offer-monthly-content':'business','offer-website-launch':'business','event-photography-prices-kigali':'events','offer-event-social-bundle':'events',
      'wedding-photography-prices-kigali':'weddings','offer-wedding-early-booking':'weddings'};
    const NAME = {'business-photo-video-branding-prices-kigali':'Compare & prices','event-photography-prices-kigali':'Compare & prices','wedding-photography-prices-kigali':'Compare & prices',
      'commercial-photography-video':'Photo & video','branding-graphic-design':'Branding & design','web-digital':'Websites','social-media-content':'Social media content',
      print:'Print', build:'Help me choose', guides:'Price guides', about:'About CRT', contact:'Contact', review:'Leave a review', privacy:'Privacy policy', terms:'Terms of service'};
    if(!seg) return;
    const trail = [];
    if(CAT[seg]) trail.push([CAT[seg][0]]);
    else {
      const par = seg.startsWith('work-') ? 'work' : PARENT[seg];
      if(par) trail.push(CAT[par]);
      const h1 = document.querySelector('main h1');
      let name = NAME[seg] || (seg.startsWith('work-') ? (document.title.split(':')[0] || '').trim() : (h1 ? h1.textContent.trim() : ''));
      if(name.length > 48) name = name.slice(0, 46).trim() + '…';
      trail.push([name]);
    }
    const nav = document.createElement('nav'); nav.className = 'crumbs'; nav.setAttribute('aria-label', 'Breadcrumb');
    nav.innerHTML = '<ol>' + trail.map(([n, h], i)=> '<li>' + (h && i < trail.length - 1 ? `<a href="${u(h)}">${n.replace(/&/g,'&amp;')}</a>` : `<span aria-current="page">${n.replace(/&/g,'&amp;')}</span>`) + '</li>').join('') + '</ol>';
    const top = f.querySelector('.footer-top'), logo = top && top.querySelector('.footer-logo');
    if(logo){
      if(!logo.closest('a')){ const home = document.createElement('a'); home.href = u('/'); home.className = 'footer-home'; home.setAttribute('aria-label', 'CRT Media Agency home'); logo.replaceWith(home); home.appendChild(logo); }
      (logo.closest('a') || logo).after(nav);
    } else f.prepend(nav);
  })();

  // ---------------------------------------------------------------
  // Live prices + wedding package contents, edited in /admin.
  // The pages keep today's prices as a fallback; when the dashboard
  // has different values, every matching price on the page is swapped.
  // ---------------------------------------------------------------
  (function(){
    const CFG = window.CRT_CONFIG || {};
    if(!CFG.SUPABASE_URL || !CFG.SUPABASE_ANON_KEY) return;
    // Prices exactly as written in the pages today. Don't edit these here; edit them in /admin.
    const BASE = {basic:1200000, standard:2000000, premium:3000000, vip:4500000};
    const fmt = n => Number(n).toLocaleString('en-US');
    const url = CFG.SUPABASE_URL.replace(/\/$/,'') + '/rest/v1/site_content?select=key,value';
    fetch(url, {headers:{'apikey':CFG.SUPABASE_ANON_KEY,'Authorization':'Bearer '+CFG.SUPABASE_ANON_KEY}})
      .then(r => r.ok ? r.json() : [])
      .then(rows => {
        const c = {}; (rows||[]).forEach(r => { c[r.key] = r.value; });
        c.prices = c.prices_v2; c.packages = c.wedding_packages;
        if(Array.isArray(c.testimonials) && c.testimonials.length){
          // Reviews added in /admin → Content → Testimonials: same card as the built-in one, before the "Leave a review" card.
          const sec = document.querySelector('[data-testimonials]'), list = sec && sec.querySelector('[data-testimonials-list]');
          if(list){
            list.querySelectorAll(':scope > :not([data-static])').forEach(n => n.remove());
            const ask = list.querySelector('[data-ask]');
            const okUrl = x => { try{ const z = new URL(x, document.baseURI); return z.origin === location.origin ? z.href : ''; }catch(e){ return ''; } };
            c.testimonials.slice(0, 6).forEach(t => {
              if(!t || !t.quote || !t.name) return;
              const li = document.createElement('li'); li.className = 'rv3-card';
              const top = document.createElement('div'); top.className = 'rv3-top';
              if(t.tag){ const tg = document.createElement('span'); tg.className = 'rv3-tag'; tg.textContent = String(t.tag).slice(0, 40); top.appendChild(tg); }
              const q = document.createElement('blockquote'); q.textContent = '“' + String(t.quote).slice(0, 400) + '”';
              const foot = document.createElement('div'); foot.className = 'rv3-foot';
              const who = document.createElement('div'); who.className = 'rv3-who';
              const b = document.createElement('strong'); b.textContent = t.name; who.appendChild(b);
              // job title and company on their own lines; older reviews kept both in one box ("Title, Company")
              let title = String(t.role || '').trim(), co = String(t.company || '').trim();
              if(!co && title.indexOf(', ') > 0){ const k = title.lastIndexOf(', '); co = title.slice(k + 2); title = title.slice(0, k); }
              if(title){ const r = document.createElement('span'); r.className = 'rv3-title'; r.textContent = title; who.appendChild(r); }
              if(co){ const r = document.createElement('span'); r.className = 'rv3-co'; r.textContent = co; who.appendChild(r); }
              foot.appendChild(who);
              const href = t.link && okUrl(String(t.link).replace(/^\//, ''));
              if(href){ const a = document.createElement('a'); a.className = 'rv3-link'; a.href = href; a.innerHTML = 'See the work <span aria-hidden="true">›</span>'; foot.appendChild(a); }
              li.append(top, q, foot);
              list.insertBefore(li, ask || null);
            });
          }
        }
        if(c.packages){
          document.querySelectorAll('[data-compare]').forEach(el => el.hidden = true);   // admin changed package contents: hide the fixed comparison table rather than show stale rows
          document.querySelectorAll('ul.package-list[data-package]').forEach(ul => {
            const items = c.packages[ul.dataset.package];
            if(!Array.isArray(items) || !items.length) return;
            const short = !!ul.querySelector('li.more');
            const shown = short ? items.slice(0,3) : items;
            ul.innerHTML = '';
            shown.forEach(t => { const li = document.createElement('li'); li.textContent = t; ul.appendChild(li); });
            if(short && items.length > 3){ const li = document.createElement('li'); li.className = 'more'; li.textContent = 'and ' + (items.length - 3) + ' more'; ul.appendChild(li); }
          });
        }
      }).catch(()=>{});
  })();

  // ---------------------------------------------------------------
  // Work pages: ONE template for every case study (v14).
  // Every work page, old or added in /admin → Case studies, is drawn from the same data shape:
  //   title, category, kicker, headline, summary, cover, facts{client,type,location,date,services},
  //   brief, approach, results[], gallery_title, video, photos[], review, credits[], published.
  // Built pages carry their own copy (<script id="case3-data">) so they draw at once; the live copy
  // saved in /admin (site_content.case_studies) then replaces it. /case/?s=slug shows works added in
  // /admin that have no built page yet. Add ?preview=1 to see empty sections as placeholders.
  // ---------------------------------------------------------------
  (function(){
    const main = document.querySelector('main[data-case3]'); if(!main) return;
    const CFG = window.CRT_CONFIG || {}, preview = params.has('preview');
    const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const safeUrl = u => { try{ const x = new URL(u, location.href); return (x.protocol === 'https:' || x.origin === location.origin) ? x.href : ''; }catch(e){ return ''; } };
    const T = (v, n) => String(v == null ? '' : v).trim().slice(0, n || 900);
    const CAT = {business: ['Business', '/business'], events: ['Events', '/events'], weddings: ['Weddings', '/weddings']};
    let seedAll = null;
    const embedded = (() => { try{ return JSON.parse((document.getElementById('case3-data') || {}).textContent || 'null'); }catch(e){ return null; } })();
    const slug = main.dataset.case3 || params.get('s') || '';

    // Old dashboard entries (saved before v14) kept their text under "fields": read them into the same shape.
    function normalise(seed, live){
      if(seed && seed.v !== 2 && seed.fields) seed = normalise({}, seed);   // an older copy of the data file
      const c = JSON.parse(JSON.stringify(seed || {}));
      if(!live) return c;
      if(live.v === 2) return Object.assign(c, JSON.parse(JSON.stringify(live)));
      const F = live.fields || {};
      const pick = (...k) => { for(const x of k){ if(F[x] != null) return F[x]; } return undefined; };
      const set = (obj, key, val) => { if(val !== undefined) obj[key] = val; };
      set(c, 'title', pick('client')); set(c, 'headline', pick('headline')); set(c, 'summary', pick('summary'));
      set(c, 'brief', pick('challenge')); set(c, 'approach', pick('approach'));
      c.facts = c.facts || {};
      set(c.facts, 'client', pick('fact-Client', 'fact-Couple', 'fact-Clients')); set(c.facts, 'type', pick('fact-Industry', 'fact-Event'));
      set(c.facts, 'location', pick('fact-Location')); set(c.facts, 'date', pick('fact-Year', 'fact-Date', 'fact-When')); set(c.facts, 'services', pick('fact-Services', 'fact-Delivered'));
      if(['result-0','result-1','result-2','result-3'].some(k => F[k] != null)) c.results = [0,1,2,3].map(i => F['result-' + i] || '').filter(Boolean);
      if(live.photos && (live.photos.length || live.gallery_full)) c.photos = live.photos;
      if(live.video && live.video.url) c.video = live.video;
      if(live.review && live.review.quote) c.review = live.review;
      if(live.credits && live.credits.length) c.credits = live.credits;
      ['published', 'category', 'kicker', 'cover', 'gallery_title'].forEach(k => { if(live[k] !== undefined) c[k] = live[k]; });
      return c;
    }
    function filmHTML(v){
      const url = safeUrl(v.url); if(!url) return '';
      const yt = url.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)([\w-]{11})/);
      if(yt) return `<iframe src="https://www.youtube-nocookie.com/embed/${yt[1]}?rel=0" title="Highlight video" loading="lazy" allow="accelerometer; autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>`;
      const ig = url.match(/instagram\.com\/(?:[\w.]+\/)?(?:reel|reels|p|tv)\/([\w-]+)/);
      if(ig) return `<iframe class="film-ig" src="https://www.instagram.com/reel/${ig[1]}/embed/" title="Highlight video" loading="lazy" scrolling="no" allowtransparency="true" allow="autoplay; encrypted-media; picture-in-picture"></iframe>`;
      const gd = url.match(/drive\.google\.com\/(?:file\/d\/|open\?id=|uc\?(?:export=\w+&)?id=)([\w-]{20,})/);
      if(gd) return `<iframe src="https://drive.google.com/file/d/${gd[1]}/preview" title="Highlight video" loading="lazy" allow="autoplay; fullscreen" allowfullscreen></iframe>`;
      const vm = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
      if(vm) return `<iframe src="https://player.vimeo.com/video/${vm[1]}" title="Highlight video" loading="lazy" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>`;
      if(v.type === 'file' || /\.(mp4|webm|mov)(\?|$)/i.test(url)) return `<video src="${esc(url)}" controls preload="metadata" playsinline></video>`;
      return `<a class="btn" href="${esc(url)}" target="_blank" rel="noopener">Watch the highlight video ↗</a>`;
    }
    // Gallery rows: two portraits side by side, a landscape across, or a portrait next to a landscape (same as before).
    function galleryHTML(photos){
      const tiles = photos.map(p => ({p, land: p.w && p.h ? p.w > p.h * 1.15 : false}));
      const rows = [], pend = [];
      tiles.forEach(t => {
        if(t.land){ if(pend.length) rows.push([[pend.pop(), 'p2'], [t, 'l4']]); else rows.push([[t, 'l6']]); }
        else { pend.push(t); if(pend.length === 2){ rows.push([[pend[0], 'p3'], [pend[1], 'p3']]); pend.length = 0; } }
      });
      if(pend.length){
        const last = rows[rows.length - 1];
        if(last && last.length === 2 && last.every(x => x[1] === 'p3')) rows[rows.length - 1] = [[last[0][0], 'p2'], [last[1][0], 'p2'], [pend[0], 'p2']];
        else if(last && last.length === 1) rows[rows.length - 1] = [[pend[0], 'p2'], [last[0][0], 'l4']];
        else rows.push([[pend[0], 'p6']]);
      }
      return rows.map(r => r.map(([t, k]) => {
        const big = safeUrl(t.p.url), sm = t.p.sm && safeUrl(t.p.sm), cap = T(t.p.caption, 160);
        return `<figure class="cs-tile cs2-t ${k}" tabindex="0" role="button" data-lb="1" aria-label="Open photo${cap ? ': ' + esc(cap) : ''}"><img src="${esc(big)}"${sm ? ` srcset="${esc(sm)} 800w, ${esc(big)} 1600w" sizes="(max-width: 760px) 100vw, 50vw"` : ''} alt="${esc(cap)}" loading="lazy" decoding="async"${t.p.w ? ` width="${+t.p.w}" height="${+t.p.h}"` : ''}>${cap ? `<figcaption>${esc(cap)}</figcaption>` : ''}</figure>`;
      }).join('')).join('');
    }
    // v20 Branding work: photos of the printed pieces in use and the design files sit in two groups.
    // A photo's group comes from the dashboard ("print" or "design"); older photos named site-… are the printed ones.
    function photoGroup(p){ return p.group === 'print' || p.group === 'design' ? p.group : (/\/site-[^\/]*$/.test(p.url || '') ? 'print' : 'design'); }
    function galleryGroups(photos){
      const pr = photos.filter(p => photoGroup(p) === 'print'), de = photos.filter(p => photoGroup(p) === 'design');
      if(!pr.length || !de.length) return `<div class="cs-gallery cs2-grid">${galleryHTML(photos)}</div>`;
      const n = (k, one, many) => k + ' ' + (k === 1 ? one : many);
      return `<div class="cs3-group"><div class="cs3-group-head"><h3>Printed and in place</h3><span>${n(pr.length, 'photo', 'photos')} from the event</span></div><div class="cs-gallery cs2-grid">${galleryHTML(pr)}</div></div>`
        + `<div class="cs3-group"><div class="cs3-group-head"><h3>The designs</h3><span>${n(de.length, 'design', 'designs')}, as delivered</span></div><div class="cs-gallery cs2-grid">${galleryHTML(de)}</div></div>`;
    }
    function render(c, index){
      if(!c || !c.title){ main.innerHTML = `<section class="cs3-gone"><div class="cs2-wrap"><h1>This project isn’t here.</h1><p>It may have moved or been taken down.</p><a class="btn" href="${u('/work/')}">See all our work</a></div></section>`; return; }
      if(c.published === false && !preview){ main.innerHTML = `<section class="cs3-gone"><div class="cs2-wrap"><h1>This project isn’t public yet.</h1><a class="btn" href="${u('/work/')}">See all our work</a></div></section>`; return; }
      const cat = CAT[c.category] || CAT.business, f = c.facts || {};
      const cover = c.cover && safeUrl(c.cover.url) ? c.cover : null;
      const coverHTML = cover ? `<figure class="cs3-cover${cover.contain ? ' is-contain' : ''}"><img src="${esc(safeUrl(cover.url))}"${cover.sm && safeUrl(cover.sm) ? ` srcset="${esc(safeUrl(cover.sm))} 800w, ${esc(safeUrl(cover.url))} 1600w" sizes="(max-width: 1240px) 100vw, 1200px"` : ''} alt="${esc(c.title)}" fetchpriority="high" decoding="async" style="object-position:${esc(T(cover.pos, 20) || '50% 50%')}"></figure>` : '';
      const facts = [['Client', f.client], ['Type', f.type], ['Location', f.location], ['Date', f.date], ['Services', f.services]].filter(([, v]) => T(v));
      const results = (c.results || []).map(r => T(r, 300)).filter(Boolean).slice(0, 4);
      const photos = (c.photos || []).filter(p => p && safeUrl(p.url));
      const video = c.video && c.video.url ? filmHTML(c.video) : '';
      const rv = c.review && T(c.review.quote) ? c.review : null;
      const credits = (c.credits || []).filter(x => x && T(x.name) && T(x.role));
      const ph = (title, hint) => preview ? `<div class="ph-box"><span>${esc(title)}</span><small>${esc(hint)}</small></div>` : '';
      const more = (index || []).filter(x => x.slug !== slug && x.published !== false && x.title);
      const same = more.filter(x => x.category === c.category), pick = same.concat(more.filter(x => x.category !== c.category)).slice(0, 3);
      const href = s => s.page ? u('/' + s.slug + '/') : u('/case/') + '?s=' + encodeURIComponent(s.slug);
      main.innerHTML = `
<section class="cs3-hero"><div class="cs2-wrap">
  <p class="cs3-crumb"><a href="${u('/work/')}">← All work</a><span aria-hidden="true">·</span><a href="${u(cat[1])}">${esc(cat[0])}</a>${c.kicker ? `<span aria-hidden="true">·</span><span>${esc(T(c.kicker, 80))}</span>` : ''}</p>
  <p class="cs3-client">${esc(T(c.title, 120))}</p>
  <h1>${esc(T(c.headline, 160) || T(c.title, 120))}</h1>
  ${T(c.summary) ? `<p class="cs3-lead">${esc(T(c.summary, 600))}</p>` : ''}
</div>${coverHTML ? `<div class="cs2-wrap">${coverHTML}</div>` : ''}</section>
${facts.length ? `<section class="cs3-facts-sec"><div class="cs2-wrap"><dl class="cs3-facts">${facts.map(([k, v]) => `<div><dt>${k}</dt><dd>${esc(T(v, 200))}</dd></div>`).join('')}</dl></div></section>` : ''}
${video || preview ? `<section class="cs3-film"><div class="cs2-wrap"><div class="cs2-sec-head"><span class="cs2-label">Highlight video</span><h2>Watch it in motion.</h2></div><div class="cs-film-frame${/film-ig|\/shorts\//.test(video + ((c.video || {}).url || '')) ? ' is-vertical' : ''}">${video || ph('Highlight video', 'Add a YouTube, Instagram, Google Drive or Vimeo link in /admin')}</div></div></section>` : ''}
${photos.length || preview ? `<section class="cs2-story cs3-gallery"><div class="cs2-wrap"><div class="cs2-sec-head"><span class="cs2-label">The work</span><h2>${esc(T(c.gallery_title, 120) || 'The work, up close.')}</h2><p>Tap any photo to see it full screen.</p></div>${photos.length ? galleryGroups(photos) : `<div class="cs-gallery cs2-grid"><figure class="cs-tile cs2-t ph-tile l6">${ph('Photos', 'Add photos in /admin')}</figure></div>`}</div></section>` : ''}
${T(c.brief) || T(c.approach) || results.length ? `<section class="cs3-story"><div class="cs2-wrap"><div class="cs2-sec-head"><span class="cs2-label">The story</span><h2>How it came together.</h2></div><ol class="cs3-steps">
  ${T(c.brief) ? `<li><span class="cs3-num">01</span><h3>The brief</h3><p>${esc(T(c.brief))}</p></li>` : ''}
  ${T(c.approach) ? `<li><span class="cs3-num">02</span><h3>What we did</h3><p>${esc(T(c.approach))}</p></li>` : ''}
  ${results.length ? `<li><span class="cs3-num">03</span><h3>What we delivered</h3><ul class="cs3-checks">${results.map(r => `<li>${esc(r)}</li>`).join('')}</ul></li>` : ''}
</ol></div></section>` : ''}
${rv ? `<section class="cs3-review"><div class="cs2-wrap"><figure class="tq"><blockquote>“${esc(T(rv.quote, 600))}”</blockquote><figcaption>${rv.logo && safeUrl(rv.logo) ? `<img src="${esc(safeUrl(rv.logo))}" alt="${esc(rv.logo_alt || '')}" loading="lazy" decoding="async">` : ''}<span><strong>${esc(T(rv.name, 80))}</strong>${T(rv.role) ? `<span>${esc(T(rv.role, 120))}</span>` : ''}</span></figcaption></figure></div></section>` : (preview ? `<section class="cs3-review"><div class="cs2-wrap">${ph('Client review', 'Add the quote in /admin')}</div></section>` : '')}
${credits.length ? `<section class="cs3-credits"><div class="cs2-wrap"><span class="cs2-label">Made by</span><dl>${credits.map(x => `<div><dt>${esc(T(x.role, 80))}</dt><dd>${esc(T(x.name, 80))}</dd></div>`).join('')}</dl></div></section>` : ''}
<section class="cs3-cta"><div class="cs2-wrap cs3-cta-in"><div><h2>Planning something like this?</h2><p>Tell us what you need and get your price in writing. We usually reply within 2 hours.</p></div>
  <div class="cta-row"><a class="btn" href="${u('/book/')}?s=${esc(c.category || 'business')}" data-track="case_end_book">Book</a><a class="btn secondary" href="${u(cat[1])}">See ${esc(cat[0].toLowerCase())} prices</a></div></div></section>
${pick.length ? `<section class="cs2-more"><div class="cs2-wrap"><div class="cs2-sec-head"><span class="cs2-label">More stories</span><h2>More work like this.</h2></div><ul class="cs2-more-grid">${pick.map(s => {
  const im = (s.card && safeUrl(s.card)) || (s.cover && safeUrl(s.cover)) || '';
  return `<li><a class="cs2-more-card" href="${esc(href(s))}"><span class="cs2-more-img">${im ? `<img src="${esc(im)}" alt="" loading="lazy" decoding="async">` : ''}</span><span class="cs2-more-body"><strong>${esc(s.title)}</strong><span class="cs2-label">${esc(s.kicker || '')}</span><span class="cs2-more-go">View project <span aria-hidden="true">›</span></span></span></a></li>`; }).join('')}</ul>
  <p class="cs2-ask"><a class="cs2-all-link" href="${u('/work/')}">See all our work <span aria-hidden="true">›</span></a></p></div></section>` : ''}`;
      if(!main.dataset.case3) document.title = `${T(c.title, 80)}: ${T(c.headline, 120).replace(/\.$/, '')} | CRT Media Agency`;
      main.classList.add('is-drawn');
      fitHeadline();
      document.dispatchEvent(new CustomEvent('crt:case-drawn'));
    }
    // Work headlines always sit on two lines: start from the site's headline size and step down until they fit.
    function fitHeadline(){
      const h = main.querySelector('.cs3-hero h1'); if(!h) return;
      h.style.removeProperty('font-size');
      const lh = () => parseFloat(getComputedStyle(h).lineHeight) || parseFloat(getComputedStyle(h).fontSize) * 1.05;
      let fs = parseFloat(getComputedStyle(h).fontSize);
      for(let i = 0; i < 40 && h.getBoundingClientRect().height > lh() * 2 + 2 && fs > 22; i++){ fs -= 1; h.style.setProperty('font-size', fs + 'px', 'important'); }
    }
    let fitT; window.addEventListener('resize', () => { clearTimeout(fitT); fitT = setTimeout(fitHeadline, 120); });
    if(document.fonts && document.fonts.ready) document.fonts.ready.then(fitHeadline);
    // index of all works for "More work like this": the built list, plus works added in /admin, minus hidden ones
    function indexFrom(base, live){
      const out = {}; (base || []).forEach(x => { out[x.slug] = Object.assign({}, x); });
      Object.keys(live || {}).forEach(s => {
        const e = live[s]; if(!e) return;
        if(e.deleted){ delete out[s]; return; }
        const n = out[s] || {slug: s, page: false};
        if(e.v === 2 || !out[s]) Object.assign(n, {title: e.title || n.title, kicker: e.kicker || n.kicker, category: e.category || n.category, card: (e.card && e.card.url) || (e.cover && e.cover.url) || n.card, published: e.published !== false});
        else if(e.published === false) n.published = false;
        if(n.title) out[s] = n;
      });
      return Object.values(out).sort((a, b) => (a.order ?? 999) - (b.order ?? 999));
    }
    function seedIndex(all){ return Object.keys(all || {}).map(s => ({slug: s, page: true, title: all[s].title, kicker: all[s].kicker, category: all[s].category, card: (all[s].card || {}).url, cover: (all[s].cover || {}).url, published: all[s].published !== false, order: all[s].order})); }
    async function loadSeedAll(){
      if(seedAll) return seedAll;
      try{ seedAll = await (await fetch(u('/data/case-studies.json'), {cache: 'no-cache'})).json(); }catch(e){ seedAll = {}; }
      return seedAll;
    }
    // 1) draw at once from the copy built into the page
    if(embedded && embedded.case) render(embedded.case, embedded.index);
    // 2) then the live copy saved in /admin
    (async () => {
      let live = null;
      if(CFG.SUPABASE_URL && CFG.SUPABASE_ANON_KEY){
        try{
          const r = await fetch(CFG.SUPABASE_URL.replace(/\/$/, '') + '/rest/v1/site_content?select=value&key=eq.case_studies', {headers: {'apikey': CFG.SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + CFG.SUPABASE_ANON_KEY}});
          const rows = r.ok ? await r.json() : []; live = rows && rows[0] && rows[0].value || null;
        }catch(e){}
      }
      const own = live && live[slug];
      if(embedded && embedded.case && !own){ if(!live) return; render(embedded.case, indexFrom(embedded.index, live)); return; }
      const all = embedded ? null : await loadSeedAll();
      const seed = embedded && embedded.case ? embedded.case : (all && all[slug]) || null;
      const idx = indexFrom(embedded ? embedded.index : seedIndex(all), live);
      if(own && own.deleted){ render(null, idx); return; }
      render(normalise(seed, own), idx);
    })();
  })();

  // Click tracking (only active once GA_ID / META_PIXEL_ID are set above).
  document.querySelectorAll('[data-track]').forEach(el=>el.addEventListener('click',()=>{
    const eventName = el.dataset.track;
    if(typeof window.gtag === 'function') window.gtag('event', eventName);
    if(typeof window.fbq === 'function'){
      if(/book_call/.test(eventName)) fbq('track','Schedule');
      else if(/whatsapp/.test(eventName)) fbq('track','Contact');
    }
  }));
})();

// Footer: keep the copyright year current
document.querySelectorAll('[data-year]').forEach(el=>{ el.textContent = new Date().getFullYear(); });

// ---------------------------------------------------------------
// Photo framing: every photo cropped with object-fit:cover gets a
// focal point, so faces and subjects stay in frame at any shape.
// Add an entry here (file name without -800 / .webp) to fine-tune.
// ---------------------------------------------------------------
(function(){
  const FOCUS = {
    'workshop':'25% 35%',
    'wedding-mirindi-ange/cover':'50% 24%', 'wedding-mirindi-ange/06':'50% 26%', 'wedding-sandra-mathias/01':'50% 40%', 'eloge-alice/cover':'50% 38%', 'wedding-sandra-mathias/cover':'50% 34%',
    'zora-lounge/cover':'50% 45%', 'kings-memo/cover':'50% 50%', 'intore-dancers':'50% 40%', 'church-celebration':'50% 48%',
    'church-ceremony':'45% 38%', 'table-styling':'50% 55%', 'floral-centerpiece':'50% 55%',
    'decor-lounge':'50% 62%', 'decor-reception-lounge':'50% 62%', 'zora-lounge-poster':'50% 38%',
    'kings-memo-logo':'50% 50%', 'crt-website':'50% 45%', 'proposal-eloge-alice':'50% 40%',
    'wedding-sandra-mathias':'50% 32%', 'reception-sandra-mathias':'50% 48%',
    'wedding-party-mirindi-ange':'50% 72%',
    'alain-cedrick':'50% 22%', 'thierry-ziggy-nteziryayo':'50% 22%'
  };
  const key = src => { try{ return decodeURIComponent(new URL(src, location.href).pathname.split('/').pop()).replace(/(-800)?\.(webp|jpe?g|png)$/i,''); }catch(e){ return ''; } };
  const caseKey = src => { const m = String(src).match(/cases\/([^/]+)\/([^/.]+?)(-800)?\.webp/); return m ? m[1] + '/' + m[2] : ''; };
  function frame(img){
    if(img.dataset.framed || img.style.objectPosition) return;
    if(getComputedStyle(img).objectFit !== 'cover') return;
    const src = img.currentSrc || img.src, k = key(src), ck = caseKey(src);
    let pos = FOCUS[ck] || FOCUS[k] || (/^cover-/.test(k) ? '50% 50%' : '');
    if(!pos){
      const w = img.naturalWidth, h = img.naturalHeight;
      if(!w || !h) return;                       // try again once it has loaded
      pos = h > w * 1.05 ? '50% 30%' : '50% 42%'; // portraits: keep heads in; landscapes: slightly above centre
    }
    img.style.objectPosition = pos; img.dataset.framed = '1';
  }
  function scan(root){ (root || document).querySelectorAll('img').forEach(img=>{ frame(img); if(!img.dataset.framed && !img.complete) img.addEventListener('load', ()=>frame(img), {once:true}); }); }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ()=>scan()); else scan();
  window.addEventListener('load', ()=>scan());
  new MutationObserver(ms=>ms.forEach(m=>m.addedNodes.forEach(n=>{ if(n.nodeType===1){ if(n.tagName==='IMG') frame(n); else scan(n); } }))).observe(document.documentElement, {childList:true, subtree:true});
})();

// ---------------------------------------------------------------
// Portfolio pop-up: click any photo in a case-study gallery to see it
// large, then browse left/right (arrows, keyboard ← →, or swipe).
// ---------------------------------------------------------------
(function(){
  const SEL = '.cs-gallery .cs-tile:not(.ph-tile) img';
  let box, imgEl, countEl, capEl, list = [], idx = 0, lastFocus = null;
  const big = img => {
    const ss = img.getAttribute('srcset');
    if(ss){ const best = ss.split(',').map(s=>s.trim().split(/\s+/)).sort((a,b)=>parseInt(b[1])-parseInt(a[1]))[0]; if(best) return new URL(best[0], location.href).href; }
    return (img.currentSrc || img.src).replace(/-800(\.\w+)$/, '$1');
  };
  function build(){
    box = document.createElement('div');
    box.className = 'lightbox'; box.hidden = true;
    box.setAttribute('role','dialog'); box.setAttribute('aria-modal','true'); box.setAttribute('aria-label','Photo viewer');
    box.innerHTML = '<button class="lb-close" type="button" aria-label="Close">×</button>'+
      '<button class="lb-nav lb-prev" type="button" aria-label="Previous photo">‹</button>'+
      '<figure class="lb-stage"><img alt=""><figcaption class="lb-cap"></figcaption></figure>'+
      '<button class="lb-nav lb-next" type="button" aria-label="Next photo">›</button>'+
      '<div class="lb-count" aria-live="polite"></div>';
    document.body.appendChild(box);
    imgEl = box.querySelector('.lb-stage img'); countEl = box.querySelector('.lb-count'); capEl = box.querySelector('.lb-cap');
    box.querySelector('.lb-close').addEventListener('click', close);
    box.querySelector('.lb-prev').addEventListener('click', e=>{ e.stopPropagation(); go(-1); });
    box.querySelector('.lb-next').addEventListener('click', e=>{ e.stopPropagation(); go(1); });
    box.addEventListener('click', e=>{ if(e.target === box || e.target.classList.contains('lb-stage')) close(); });
    // swipe
    let x0 = null, y0 = null;
    box.addEventListener('touchstart', e=>{ x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; }, {passive:true});
    box.addEventListener('touchend', e=>{
      if(x0 === null) return;
      const dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0; x0 = null;
      if(Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy)) go(dx < 0 ? 1 : -1);
      else if(dy > 90 && Math.abs(dy) > Math.abs(dx)) close();
    });
    document.addEventListener('keydown', e=>{
      if(box.hidden) return;
      if(e.key === 'Escape') close();
      else if(e.key === 'ArrowRight') go(1);
      else if(e.key === 'ArrowLeft') go(-1);
      else if(e.key === 'Tab'){ // keep focus inside the viewer
        const f = [...box.querySelectorAll('button')]; const i = f.indexOf(document.activeElement);
        e.preventDefault(); f[(i + (e.shiftKey ? -1 : 1) + f.length) % f.length].focus();
      }
    });
  }
  function show(){
    const img = list[idx];
    box.classList.add('is-loading');
    imgEl.onload = ()=>box.classList.remove('is-loading');
    imgEl.src = big(img); imgEl.alt = img.alt || '';
    capEl.textContent = img.alt || ''; capEl.hidden = !img.alt;
    countEl.textContent = (idx + 1) + ' / ' + list.length;
    const multi = list.length > 1;
    box.querySelectorAll('.lb-nav').forEach(b=>b.hidden = !multi);
    [idx + 1, idx - 1].forEach(j=>{ const n = list[(j + list.length) % list.length]; if(n){ const p = new Image(); p.src = big(n); } });
  }
  function go(d){ if(list.length < 2) return; idx = (idx + d + list.length) % list.length; show(); }
  function open(img){
    if(!box) build();
    const gal = img.closest('.cs-gallery');
    list = [...gal.querySelectorAll('.cs-tile:not(.ph-tile) img')];
    idx = Math.max(0, list.indexOf(img));
    lastFocus = document.activeElement;
    box.hidden = false; document.documentElement.classList.add('lb-open');
    requestAnimationFrame(()=>box.classList.add('is-open'));
    show(); box.querySelector('.lb-close').focus();
  }
  function close(){
    box.classList.remove('is-open'); document.documentElement.classList.remove('lb-open');
    setTimeout(()=>{ box.hidden = true; imgEl.removeAttribute('src'); }, 200);
    if(lastFocus && lastFocus.focus) lastFocus.focus();
  }
  // Make gallery photos clickable and keyboard-reachable (also ones added later from the dashboard)
  function prep(root){ (root || document).querySelectorAll('.cs-gallery .cs-tile:not(.ph-tile)').forEach(t=>{ if(t.dataset.lb) return; t.dataset.lb = '1'; t.tabIndex = 0; t.setAttribute('role','button'); t.setAttribute('aria-label','Open photo' + (t.querySelector('img') && t.querySelector('img').alt ? ': ' + t.querySelector('img').alt : '')); }); }
  prep();
  new MutationObserver(()=>prep()).observe(document.body, {childList:true, subtree:true});
  document.addEventListener('click', e=>{ const t = e.target.closest('.cs-gallery .cs-tile:not(.ph-tile)'); if(t && t.querySelector('img')){ e.preventDefault(); open(t.querySelector('img')); } });
  document.addEventListener('keydown', e=>{ if((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('.cs-gallery .cs-tile[data-lb]')){ e.preventDefault(); open(e.target.querySelector('img')); } });
})();

// ---------------------------------------------------------------
// Offers page: filter tabs (All / Business / Events / Weddings).
// Links such as /offers#weddings open with that tab selected.
// ---------------------------------------------------------------
window.crtCMS.after(function(){
  const root = document.querySelector('[data-offer-filter]');
  if(!root) return;
  const tabs = [...root.querySelectorAll('[data-filter]')];
  const items = () => [...root.querySelectorAll('article[data-cat]')];
  const apply = (cat, scroll)=>{
    tabs.forEach(t => t.setAttribute('aria-selected', String(t.dataset.filter === cat)));
    items().forEach(el => { el.hidden = !(cat === 'all' || el.dataset.cat === cat); });
    root.classList.toggle('is-filtered', cat !== 'all');
    if(scroll) root.scrollIntoView({behavior:'smooth', block:'start'});
  };
  tabs.forEach(t => t.addEventListener('click', ()=>{
    apply(t.dataset.filter, false);
    try{ history.replaceState(null, '', t.dataset.filter === 'all' ? '#offers' : '#' + t.dataset.filter); }catch(e){}
  }));
  // keyboard: arrow keys move between tabs
  root.querySelector('[role="tablist"]').addEventListener('keydown', e=>{
    const i = tabs.indexOf(document.activeElement); if(i < 0) return;
    if(e.key === 'ArrowRight' || e.key === 'ArrowLeft'){
      e.preventDefault(); const n = tabs[(i + (e.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length]; n.focus(); n.click();
    }
  });
  const fromHash = ()=>{ const h = location.hash.slice(1); if(['business','events','weddings'].includes(h)) apply(h, true); };
  fromHash(); window.addEventListener('hashchange', fromHash);
});

// Work page: "We make [what] for [who]" filter. Hash: #photography, #for-weddings, #film/for-corporate-events
(function(){
  const say = document.querySelector('.wk-say'); if(!say) return;
  const sel = {d: say.querySelector('select[data-dim="d"]'), s: say.querySelector('select[data-dim="s"]')};
  let cards = [...document.querySelectorAll('.wk-all .wk-card')];
  const countEl = document.querySelector('[data-wk-count]'), empty = document.querySelector('[data-wk-empty]');
  const resets = document.querySelectorAll('[data-wk-reset]'), topReset = document.querySelector('.wk-meta [data-wk-reset]');
  const ALIAS = {commercial:'photography', events:'for-corporate-events', weddings:'for-weddings', design:'graphic-design', all:''};
  const has = (c, dim, v) => !v || (c.dataset[dim] || '').split(' ').includes(v);
  function parse(h){
    h = decodeURIComponent(h || '').replace(/^#/, ''); h = ALIAS[h] !== undefined ? ALIAS[h] : h;
    let d = '', s = '';
    h.split('/').forEach(p => { if(p.startsWith('for-')) s = p.slice(4); else if(p) d = p; });
    const ok = (el, v) => [...el.options].some(o => o.value === v);
    return {d: ok(sel.d, d) ? d : '', s: ok(sel.s, s) ? s : ''};
  }
  function render(push){
    const d = sel.d.value, s = sel.s.value; let n = 0;
    cards.forEach(c => { const on = has(c, 'd', d) && has(c, 's', s); c.hidden = !on; if(on) n++; });
    // live counts in each list, and impossible pairs disabled
    [['d', 's'], ['s', 'd']].forEach(([dim, other]) => [...sel[dim].options].forEach(o => {
      const k = cards.filter(c => has(c, dim, o.value) && has(c, other, sel[other].value)).length;
      o.textContent = (o.dataset.name || o.dataset.say.replace(/^./, m => m.toUpperCase())) + ' (' + k + ')';
      o.disabled = k === 0 && o.value !== sel[dim].value;
    }));
    say.querySelectorAll('select').forEach(x => { const o = x.options[x.selectedIndex]; x.previousElementSibling.textContent = (x.closest('.wk-ind') && o.dataset.name) || o.dataset.say; x.parentElement.classList.toggle('is-set', !!x.value); });
    document.querySelectorAll('[data-wk-chip]').forEach(b => { const on = b.dataset.wkChip === d; b.classList.toggle('is-on', on); b.setAttribute('aria-pressed', on);
      const k = cards.filter(c => has(c, 'd', b.dataset.wkChip) && has(c, 's', s)).length; b.querySelector('span').textContent = k; b.disabled = k === 0 && !on; });
    document.querySelectorAll('[data-wk-group]').forEach(g => { const k = [...g.querySelectorAll('.wk-card')].filter(c => !c.hidden).length; g.hidden = k === 0; const el = g.querySelector('[data-wk-gcount]'); if(el) el.textContent = k; });
    if(countEl) countEl.textContent = n === 1 ? '1 case study' : n + ' case studies';
    if(topReset) topReset.hidden = !d && !s;
    if(empty) empty.hidden = n > 0;
    if(push){ const h = [d, s && 'for-' + s].filter(Boolean).join('/'); history.replaceState(null, '', h ? '#' + h : location.pathname); }
  }
  function apply(h){ const v = parse(h); sel.d.value = v.d; sel.s.value = v.s; render(false); }
  Object.values(sel).forEach(x => x.addEventListener('change', () => render(true)));
  document.querySelectorAll('[data-wk-chip]').forEach(b => b.addEventListener('click', () => { sel.d.value = b.dataset.wkChip; render(true); }));
  resets.forEach(b => b.addEventListener('click', () => { sel.d.value = ''; sel.s.value = ''; render(true); }));
  window.addEventListener('hashchange', () => apply(location.hash));
  apply(location.hash);
  // works added, hidden or deleted in /admin (v14): recount after the list changes
  document.addEventListener('crt:work-list', () => { cards = [...document.querySelectorAll('.wk-all .wk-card')]; render(false); });
})();

// Work page: show works added in /admin → Case studies, and drop works hidden or deleted there.
(function(){
  const all = document.querySelector('.wk-all'); if(!all) return;
  const CFG = window.CRT_CONFIG || {}; if(!CFG.SUPABASE_URL || !CFG.SUPABASE_ANON_KEY) return;
  const esc = v => String(v == null ? '' : v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const safe = x => { try{ const z = new URL(x, location.href); return (z.protocol === 'https:' || z.origin === location.origin) ? z.href : ''; }catch(e){ return ''; } };
  fetch(CFG.SUPABASE_URL.replace(/\/$/, '') + '/rest/v1/site_content?select=value&key=eq.case_studies', {headers: {'apikey': CFG.SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + CFG.SUPABASE_ANON_KEY}})
    .then(r => r.ok ? r.json() : []).then(rows => {
      const live = rows && rows[0] && rows[0].value; if(!live) return;
      let changed = false;
      const slugOf = a => { const m = (a.getAttribute('href') || '').match(/(work-[\w-]+)\/index\.html|[?&]s=([\w-]+)/); return m ? (m[1] || m[2]) : ''; };
      const have = new Set();
      all.querySelectorAll('.wk-card').forEach(a => { const sl = slugOf(a), e = live[sl]; have.add(sl); if(e && (e.deleted || e.published === false)){ a.remove(); changed = true; } });
      Object.keys(live).sort((x, y) => (live[x].order ?? 999) - (live[y].order ?? 999)).forEach(sl => {
        const e = live[sl]; if(!e || e.v !== 2 || e.deleted || e.published === false || have.has(sl) || !e.title) return;
        const grid = document.querySelector('#wk-' + (e.category || 'business') + ' .wk-grid'); if(!grid) return;
        const im = safe((e.card && e.card.url) || (e.cover && e.cover.url) || ((e.photos || [])[0] || {}).url || '');
        grid.insertAdjacentHTML('beforeend', `<a class="wk-card" href="../case/?s=${encodeURIComponent(sl)}" data-d="photography" data-s=""><div class="wk-img">${im ? `<img src="${esc(im)}" alt="${esc((e.kicker || 'Work') + ' for ' + e.title)}" loading="lazy" decoding="async">` : ''}</div><div class="wk-body"><h3>${esc(e.title)}</h3><span class="wk-kicker">${esc(e.kicker || '')}</span><span class="wk-go">View project <span aria-hidden="true">›</span></span></div></a>`);
        changed = true;
      });
      if(changed) document.dispatchEvent(new CustomEvent('crt:work-list'));
    }).catch(() => {});
})();

// Logo presentation: anatomy (take apart / put together), construction toggle, copy colour codes
(function(){
  const anat = document.querySelector('[data-lg-anatomy] .lg-anat-wrap');
  if(anat){
    const btn = anat.querySelector('[data-lg-assemble]');
    const set = whole => { anat.classList.toggle('is-whole', whole); if(btn){ btn.textContent = whole ? 'Take it apart' : 'Put it together'; btn.setAttribute('aria-pressed', whole); } };
    set(true);
    if('IntersectionObserver' in window && !matchMedia('(prefers-reduced-motion: reduce)').matches){
      const io = new IntersectionObserver(es => es.forEach(e => { if(e.isIntersecting){ setTimeout(() => set(false), 350); io.disconnect(); } }), {threshold:.55});
      io.observe(anat);
    } else set(false);
    if(btn) btn.addEventListener('click', () => set(!anat.classList.contains('is-whole')));
  }
  const tg = document.querySelector('[data-lg-construct]'), wrap = document.querySelector('[data-lg-wrap]');
  if(tg && wrap) tg.addEventListener('click', () => { const on = !wrap.classList.contains('is-on'); wrap.classList.toggle('is-on', on); tg.setAttribute('aria-pressed', on); tg.textContent = on ? 'Hide construction' : 'Show construction'; });
  document.querySelectorAll('.lg-sw[data-copy]').forEach(b => b.addEventListener('click', () => {
    const t = b.dataset.copy; (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).catch(()=>{}).finally(() => { b.classList.add('is-copied'); setTimeout(() => b.classList.remove('is-copied'), 1600); });
  }));
})();

// Build your project: drag services into a 3-stage pipeline, see an estimate, book the combination.
// Pointer events, so the same drag works with a mouse, a finger or a pen. Tap or Enter adds a service.
;(window.crtPrices ? window.crtPrices.after : (f => f()))(function(){
  const root = document.querySelector('[data-builder]'); if(!root) return;
  const DATA = window.crtPrices ? window.crtPrices.patchData(JSON.parse(document.getElementById('bx-data').textContent)) : JSON.parse(document.getElementById('bx-data').textContent);
  const KEY = 'crt-builder';
  const lists = {1: root.querySelector('[data-lane-list="1"]'), 2: root.querySelector('[data-lane-list="2"]'), 3: root.querySelector('[data-lane-list="3"]')};
  const rwf = n => Number(n).toLocaleString('en-US');
  const escH = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  let pipe = {1:[], 2:[], 3:[]};

  // restore: link (#b=1:id.id|2:id) first, then this browser's last build
  function fromHash(){
    const m = location.hash.match(/^#b=(.+)$/); if(!m) return null;
    const p = {1:[], 2:[], 3:[]};
    decodeURIComponent(m[1]).split('|').forEach(part => { const [l, ids] = part.split(':'); if(p[l] && ids) p[l] = ids.split('.').filter(id => DATA[id]); });
    return p;
  }
  try{ pipe = fromHash() || JSON.parse(localStorage.getItem(KEY) || 'null') || pipe; }catch(e){}
  [1, 2, 3].forEach(l => { pipe[l] = (pipe[l] || []).filter(id => DATA[id]); });

  const all = () => [1, 2, 3].flatMap(l => pipe[l]);
  function save(){
    try{ localStorage.setItem(KEY, JSON.stringify(pipe)); }catch(e){}
    const h = [1, 2, 3].filter(l => pipe[l].length).map(l => l + ':' + pipe[l].join('.')).join('|');
    history.replaceState(null, '', h ? '#b=' + h : location.pathname);
  }
  function render(){
    [1, 2, 3].forEach(l => {
      lists[l].innerHTML = pipe[l].map((id, i) => {
        const s = DATA[id];
        return `<li class="bx-item" data-item="${id}" data-lane="${l}" data-i="${i}"><span class="bx-grip" aria-hidden="true"></span><span class="bx-item-t"><b>${escH(s.n)}</b><small>${s.p ? 'from ' + rwf(s.p) + ' RWF' : 'Priced on request'}</small></span>` +
          `<button type="button" class="bx-x" data-remove="${l}:${i}" aria-label="Remove ${escH(s.n)}">×</button></li>`;
      }).join('');
      lists[l].closest('.bx-lane').classList.toggle('is-empty', !pipe[l].length);
    });
    const ids = all(), known = ids.filter(id => DATA[id].p), unknown = ids.length - known.length, total = known.reduce((s, id) => s + DATA[id].p, 0);
    root.querySelectorAll('.bx-card').forEach(c => c.classList.toggle('is-in', ids.includes(c.dataset.svc)));
    root.querySelector('[data-bx-count]').textContent = ids.length ? ids.length + ' service' + (ids.length > 1 ? 's' : '') + ' in your pipeline' : 'No services yet';
    const tot = !ids.length ? 'Add a service to see an estimate' : known.length ? 'From ' + rwf(total) + ' RWF' + (unknown ? ' + ' + unknown + ' priced on request' : '') : 'Priced on request';
    root.querySelector('[data-bx-total]').textContent = tot;
    const book = root.querySelector('[data-bx-book]'); book.setAttribute('aria-disabled', String(!ids.length));
    root.querySelector('[data-bx-share]').hidden = !ids.length;
    root.querySelector('[data-bx-list]').innerHTML = [1, 2, 3].filter(l => pipe[l].length).map(l => `<li><span>${['', 'Before', 'On the day', 'After'][l]}</span>${pipe[l].map(id => escH(DATA[id].n)).join(', ')}</li>`).join('');
    root.querySelector('[data-bx-total2]').textContent = ids.length ? tot : '';
    // keep the booking form in sync
    const form = root.querySelector('[data-builder-form]');
    if(form){
      const lines = [1, 2, 3].filter(l => pipe[l].length).map(l => ['', 'Before', 'On the day', 'After'][l] + ': ' + pipe[l].map(id => DATA[id].n).join(', '));
      form.querySelector('[name="service"]').value = ids.map(id => DATA[id].n).join(', ').slice(0, 120) || 'Custom project';
      form.querySelector('[name="offer"]').value = ids.length ? 'Custom pipeline · ' + tot : '';
      const det = form.querySelector('[name="details"]');
      det.value = (ids.length ? 'My pipeline:\n' + lines.join('\n') + '\nEstimate: ' + tot + '\n\n' : '') + (det.dataset.own || '');
    }
    save();
  }
  function add(id, lane, index){
    if(!DATA[id]) return;
    [1, 2, 3].forEach(l => { pipe[l] = pipe[l].filter(x => x !== id); });
    lane = lane || DATA[id].s;
    const list = pipe[lane]; list.splice(index == null ? list.length : Math.min(index, list.length), 0, id);
    render();
    const el = root.querySelector(`.bx-item[data-item="${id}"]`); if(el){ el.classList.add('is-new'); setTimeout(() => el.classList.remove('is-new'), 600); }
  }

  // ---- drag (pointer events) ----
  let drag = null;
  function laneAt(x, y){
    const el = document.elementFromPoint(x, y); const lane = el && el.closest('.bx-lane');
    if(!lane) return null;
    const l = Number(lane.dataset.lane), items = [...lists[l].querySelectorAll('.bx-item:not(.is-ghosted)')];
    let index = items.length;
    for(let i = 0; i < items.length; i++){ const r = items[i].getBoundingClientRect(); if(y < r.top + r.height / 2){ index = i; break; } }
    return {l, index, lane};
  }
  root.addEventListener('pointerdown', e => {
    if(e.button !== 0 || e.target.closest('button')) return;
    const src = e.target.closest('.bx-card, .bx-item'); if(!src) return;
    drag = {src, id: src.dataset.svc || src.dataset.item, from: src.dataset.lane ? Number(src.dataset.lane) : null, x0: e.clientX, y0: e.clientY, moved: false};
    src.setPointerCapture(e.pointerId);
  });
  root.addEventListener('pointermove', e => {
    if(!drag) return;
    if(!drag.moved){
      if(Math.hypot(e.clientX - drag.x0, e.clientY - drag.y0) < 6) return;
      drag.moved = true;
      const r = drag.src.getBoundingClientRect();
      drag.ghost = drag.src.cloneNode(true); drag.ghost.className = 'bx-ghost'; drag.ghost.style.width = r.width + 'px';
      drag.dx = e.clientX - r.left; drag.dy = e.clientY - r.top;
      document.body.appendChild(drag.ghost); document.body.classList.add('bx-dragging');
      if(drag.from) drag.src.classList.add('is-ghosted');
      drag.marker = document.createElement('li'); drag.marker.className = 'bx-marker';
    }
    e.preventDefault();
    drag.ghost.style.transform = `translate(${e.clientX - drag.dx}px, ${e.clientY - drag.dy}px) rotate(-1.5deg)`;
    const t = laneAt(e.clientX, e.clientY);
    root.querySelectorAll('.bx-lane.is-over').forEach(x => x !== (t && t.lane) && x.classList.remove('is-over'));
    if(t){ t.lane.classList.add('is-over'); const items = [...lists[t.l].querySelectorAll('.bx-item:not(.is-ghosted)')]; if(items[t.index]) items[t.index].before(drag.marker); else lists[t.l].appendChild(drag.marker); }
    else drag.marker.remove();
  });
  function end(e, cancel){
    if(!drag) return;
    const d = drag; drag = null;
    document.body.classList.remove('bx-dragging');
    root.querySelectorAll('.bx-lane.is-over').forEach(x => x.classList.remove('is-over'));
    if(!d.moved){ if(!cancel && d.src.classList.contains('bx-card')) add(d.id); return; }
    d.ghost.remove(); d.marker.remove(); d.src.classList.remove('is-ghosted');
    if(cancel) return;
    const t = laneAt(e.clientX, e.clientY);
    if(t){
      let index = t.index;
      if(d.from === t.l){ const old = pipe[t.l].indexOf(d.id); if(old > -1 && old < index) index--; }
      add(d.id, t.l, index);
    } else if(d.from){ pipe[d.from] = pipe[d.from].filter(x => x !== d.id); render(); } // dragged out of the pipeline: remove
  }
  root.addEventListener('pointerup', e => end(e, false));
  root.addEventListener('pointercancel', e => end(e, true));
  root.addEventListener('keydown', e => { const c = e.target.closest('.bx-card'); if(c && (e.key === 'Enter' || e.key === ' ')){ e.preventDefault(); add(c.dataset.svc); } });

  // Help me choose, tailored: /build/?for=weddings|events|business starts from the matching template
  const FOR = {weddings:'Wedding', events:'Conference', business:'New brand'}[new URLSearchParams(location.search).get('for')];
  if(FOR) setTimeout(() => { const b = [...root.querySelectorAll('[data-tpl]')].find(x => x.textContent.trim() === FOR); if(b) b.click(); }, 0);
  root.addEventListener('click', e => {
    const rm = e.target.closest('[data-remove]');
    if(rm){ const [l, i] = rm.dataset.remove.split(':').map(Number); pipe[l].splice(i, 1); render(); return; }
    const tpl = e.target.closest('[data-tpl]');
    if(tpl){ pipe = {1:[], 2:[], 3:[]}; tpl.dataset.tpl.split(',').forEach(id => { if(DATA[id]) pipe[DATA[id].s].push(id); }); render(); return; }
    if(e.target.closest('[data-bx-clear]')){ pipe = {1:[], 2:[], 3:[]}; render(); return; }
    if(e.target.closest('[data-bx-share]')){
      const url = location.href;
      (navigator.share ? navigator.share({title: 'My CRT project', url}) : navigator.clipboard.writeText(url)).then(() => { const b = e.target.closest('[data-bx-share]'); const t = b.textContent; b.textContent = navigator.share ? 'Shared' : 'Link copied'; setTimeout(() => b.textContent = t, 1600); }).catch(() => {});
      return;
    }
    const book = e.target.closest('[data-bx-book]');
    if(book){
      e.preventDefault();
      if(!all().length){ root.querySelector('.bx-lib').scrollIntoView({behavior:'smooth', block:'start'}); return; }
      const b = root.querySelector('.bx-book'); b.hidden = false; b.scrollIntoView({behavior:'smooth', block:'start'});
      setTimeout(() => { const n = b.querySelector('[name="name"]'); if(n) n.focus({preventScroll:true}); }, 500);
      return;
    }
    if(e.target.closest('[data-bx-edit]')){ root.querySelector('.bx-board').scrollIntoView({behavior:'smooth', block:'start'}); }
  });
  const det = root.querySelector('[data-builder-form] [name="details"]');
  if(det) det.addEventListener('input', () => { const i = det.value.indexOf('\n\n'); det.dataset.own = det.value.startsWith('My pipeline:') && i > -1 ? det.value.slice(i + 2) : det.value; });
  render();
});

// Home page: each collection shows one row; "See more" opens the rest in place. Rows are measured live,
// so one row is 4 tiles on a laptop and 1 card on a phone.
(function(){
  if(!document.querySelector('.hero-home')) return;
  const SEL = '.svc-grid, .deals-grid, .card-grid.four';   // reviews always show in full // the work bento shows in full; its header links to all work
  // Collections with a full page of their own: "See more" goes there instead of expanding in place.
  const PAGE = {'bento': ['work/index.html', 'See all our work']};
  const state = new WeakMap();
  function apply(grid){
    const items = [...grid.children].filter(el => el.nodeType === 1);
    const page = Object.keys(PAGE).find(c => grid.classList.contains(c));
    const ownCta = grid.nextElementSibling && grid.nextElementSibling.classList.contains('cta-row'); // e.g. "See all offers"
    let st = state.get(grid);
    if(!st){
      st = {open: false};
      const row = document.createElement('div'); row.className = 'more-row';
      if(page){
        row.innerHTML = `<a class="btn secondary more-btn" href="${PAGE[page][0]}">${PAGE[page][1]} <span aria-hidden="true">→</span></a>`;
      } else {
        row.innerHTML = '<button type="button" class="btn secondary more-btn" aria-expanded="false"></button>';
        row.querySelector('button').addEventListener('click', () => { st.open = !st.open; apply(grid); if(!st.open) grid.scrollIntoView({block:'nearest'}); });
      }
      if(!ownCta) grid.after(row);
      st.row = row; st.btn = row.querySelector('button');
      state.set(grid, st);
    }
    items.forEach(el => el.classList.remove('is-more-hidden'));
    grid.classList.toggle('is-one-row', !st.open);
    if(!items.length){ st.row.hidden = true; return; }
    if(page || ownCta){
      // one row only; the link (ours or the section's own) opens the full page
      const top0 = Math.min(...items.map(el => el.offsetTop));
      items.filter(el => el.offsetTop > top0 + 4).forEach(el => el.classList.add('is-more-hidden'));
      st.row.hidden = false;
      return;
    }
    const top = Math.min(...items.map(el => el.offsetTop));
    const extra = items.filter(el => el.offsetTop > top + 4);
    const shown = items.length - extra.length;
    if(!st.open) extra.forEach(el => el.classList.add('is-more-hidden'));
    // when open, count what the collapsed row would hide
    let hidden = extra.length;
    if(st.open){ grid.classList.add('is-one-row'); const t2 = Math.min(...items.map(el => el.offsetTop)); hidden = items.filter(el => el.offsetTop > t2 + 4).length; grid.classList.remove('is-one-row'); }
    st.row.hidden = hidden === 0;
    st.btn.setAttribute('aria-expanded', String(st.open));
    st.btn.textContent = st.open ? 'See less' : 'See more (' + hidden + ')';
  }
  const run = () => document.querySelectorAll(SEL).forEach(apply);
  run();
  let t; window.addEventListener('resize', () => { clearTimeout(t); t = setTimeout(run, 120); });
  if(document.readyState === 'complete') run(); else window.addEventListener('load', run);
})();

// Shop: category tabs, quick view with options, a request list that is sent through the normal enquiry form.
;window.crtCMS.after(() => (window.crtPrices ? window.crtPrices.after : (f => f()))(function(){
  const root = document.querySelector('[data-shop]'); if(!root) return;
  const D = window.__CRT_SHOP = window.crtPrices ? window.crtPrices.patchData(JSON.parse(document.getElementById('shop-data').textContent)) : JSON.parse(document.getElementById('shop-data').textContent);
  const KEY = 'crt-shop-bag';
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const price = p => p ? Number(p).toLocaleString('en-US') + ' RWF' : 'Price on request';
  let bag = []; try{ bag = JSON.parse(localStorage.getItem(KEY) || '[]').filter(x => D[x.id]); }catch(e){}
  const qv = root.querySelector('[data-shop-qv]'), drawer = root.querySelector('[data-shop-drawer]'), scrim = root.querySelector('[data-shop-scrim]');
  const units = (id, q) => q + ' ' + (q === 1 ? D[id].u[0] : D[id].u[1]);
  const label = it => D[it.id].n + (Object.keys(it.o).length ? ' (' + Object.values(it.o).join(', ') + ')' : '') + ': ' + units(it.id, it.q);

  function filter(cat){
    root.querySelectorAll('.sp-tab').forEach(b => { const on = b.dataset.shopCat === cat; b.classList.toggle('is-on', on); b.setAttribute('aria-pressed', on); });
    root.querySelectorAll('.sp-tile').forEach(t => { t.hidden = !!cat && t.dataset.cat !== cat; });
    history.replaceState(null, '', cat ? '#' + cat : location.pathname);
  }
  function openQV(id){
    const p = D[id]; if(!p) return;
    const opts = Object.entries(p.o).map(([k, vals]) => `<fieldset class="sp-opt"><legend>${esc(k)}</legend><div>` +
      vals.map((v, i) => `<label><input type="radio" name="o-${esc(k)}" value="${esc(v)}"${i ? '' : ' checked'}><span>${esc(v)}</span></label>`).join('') + '</div></fieldset>').join('');
    qv.innerHTML = `<form method="dialog" class="sp-qv-in" data-qv-form data-id="${id}">
      <div class="sp-qv-stage">${p.m}</div>
      <div class="sp-qv-info"><button type="button" class="sp-x" data-qv-close aria-label="Close">×</button>
        <h2>${esc(p.n)}</h2><p class="sp-qv-price">${price(p.p)}</p><p class="sp-qv-line">${esc(p.l)}</p>${opts}
        <div class="sp-qty"><span>Number of ${esc(p.u[1])}</span><div class="sp-qty-ctl"><button type="button" data-qty="-1" aria-label="One fewer ${esc(p.u[0])}">−</button><output data-qty-val aria-live="polite">1</output><button type="button" data-qty="1" aria-label="One more ${esc(p.u[0])}">+</button><span class="sp-qty-unit" data-qty-unit>${esc(p.u[0])}</span></div></div>
        <button class="btn sp-add" type="submit">Add to request list</button>
        ${p.c === 'weddings' && /album/.test(p.n.toLowerCase()) ? '<p class="sp-qv-note">Booked your wedding with us? Ask us about adding an album when you send your request.</p>' : ''}
        <p class="sp-qv-small">Made to order. We confirm the price and delivery with you first.</p></div></form>`;
    qv.showModal();
  }
  function save(){ try{ localStorage.setItem(KEY, JSON.stringify(bag));
    localStorage.setItem('crt-print-request', JSON.stringify(bag.map(it => ({name: D[it.id].n, opts: Object.entries(it.o).map(([k, v]) => k + ': ' + v), qty: units(it.id, it.q), q: it.q, price: D[it.id].p || null}))));   // read by /book/?s=print
  }catch(e){} }
  function renderBag(){
    const n = bag.reduce((s, x) => s + x.q, 0);
    root.querySelectorAll('[data-bag-count]').forEach(el => { el.textContent = bag.length; el.hidden = !bag.length; el.setAttribute('aria-label', bag.length + (bag.length === 1 ? ' product' : ' products') + ' in your request list'); });
    root.querySelector('[data-bag-list]').innerHTML = bag.map((it, i) => `<li><div class="sp-bag-thumb">${D[it.id].m}</div><div class="sp-bag-txt"><b>${esc(D[it.id].n)}</b>` +
      `<small>${esc(Object.values(it.o).join(' · '))}</small><small><strong>Quantity: ${esc(units(it.id, it.q))}</strong> · ${price(D[it.id].p)}</small></div>` +
      `<button type="button" class="sp-x sm" data-bag-remove="${i}" aria-label="Remove ${esc(D[it.id].n)}">×</button></li>`).join('');
    root.querySelector('[data-bag-empty]').hidden = !!bag.length;
    root.querySelector('[data-bag-form]').hidden = !bag.length;
    const form = root.querySelector('[data-shop-form]');
    if(form){
      const lines = bag.map(it => '- ' + label(it));
      form.querySelector('[name="service"]').value = ('Shop: ' + bag.map(it => D[it.id].n).join(', ')).slice(0, 120);
      form.querySelector('[name="offer"]').value = bag.length ? bag.length + ' product' + (bag.length > 1 ? 's' : '') + ' from CRT Print' : '';
      const det = form.querySelector('[name="details"]');
      det.value = (bag.length ? 'Request list:\n' + lines.join('\n') + '\n\n' : '') + (det.dataset.own || '');
    }
    save();
    const sticky = root.querySelector('[data-shop-sticky]');
    if(sticky){ sticky.hidden = !bag.length; sticky.querySelector('[data-sticky-n]').textContent = bag.length + (bag.length === 1 ? ' item' : ' items'); }
    document.body.classList.toggle('sp-has-bar', !!bag.length);
    window.dispatchEvent(new CustomEvent('crt:bag', {detail: bag.length}));
  }
  const openBag = () => { drawer.hidden = false; scrim.hidden = false; requestAnimationFrame(() => drawer.classList.add('is-open')); };
  const closeBag = () => { drawer.classList.remove('is-open'); scrim.hidden = true; setTimeout(() => drawer.hidden = true, 250); };

  root.addEventListener('click', e => {
    const t = e.target;
    const tab = t.closest('[data-shop-cat]'); if(tab){ filter(tab.dataset.shopCat); return; }
    const jump = t.closest('[data-shop-jump]'); if(jump){ e.preventDefault(); filter(jump.dataset.shopJump); root.querySelector('.sp-tabs').scrollIntoView({behavior:'smooth'}); return; }
    const op = t.closest('[data-product]'); if(op){ openQV(op.dataset.product); return; }
    if(t.closest('[data-qv-close]')){ qv.close(); return; }
    const q = t.closest('[data-qty]'); if(q){ const o = qv.querySelector('[data-qty-val]'); o.textContent = Math.max(1, Math.min(50, Number(o.textContent) + Number(q.dataset.qty))); const id = qv.querySelector('[data-qv-form]').dataset.id; qv.querySelector('[data-qty-unit]').textContent = Number(o.textContent) === 1 ? D[id].u[0] : D[id].u[1]; return; }
    if(t.closest('[data-shop-bag]')){ openBag(); return; }
    if(t.closest('[data-shop-close]') || t.closest('[data-shop-scrim]')){ closeBag(); return; }
    const rm = t.closest('[data-bag-remove]'); if(rm){ bag.splice(Number(rm.dataset.bagRemove), 1); renderBag(); return; }
  });
  qv.addEventListener('click', e => { if(e.target === qv) qv.close(); });
  root.addEventListener('submit', e => {
    const f = e.target.closest('[data-qv-form]'); if(!f) return;
    e.preventDefault();
    const o = {}; f.querySelectorAll('.sp-opt').forEach(fs => { const c = fs.querySelector('input:checked'); if(c) o[fs.querySelector('legend').textContent] = c.value; });
    const it = {id: f.dataset.id, o, q: Number(f.querySelector('[data-qty-val]').textContent) || 1};
    const same = bag.find(x => x.id === it.id && JSON.stringify(x.o) === JSON.stringify(it.o));
    if(same) same.q += it.q; else bag.push(it);
    qv.close(); renderBag(); openBag();
  });
  const det = root.querySelector('[data-shop-form] [name="details"]');
  if(det) det.addEventListener('input', () => { const i = det.value.indexOf('\n\n'); det.dataset.own = det.value.startsWith('Request list:') && i > -1 ? det.value.slice(i + 2) : det.value; });
  document.addEventListener('keydown', e => { if(e.key === 'Escape' && !drawer.hidden) closeBag(); });
  const h = location.hash.slice(1); if(h && root.querySelector(`[data-shop-cat="${h}"]`)) filter(h);
  else if(/^[a-z-]+$/.test(h) && root.querySelector(`[data-product="${h}"]`)) openQV(h); // e.g. /print/#rollup-banner from the menu
  renderBag();
}));

// Legal pages: highlight the section being read in the "On this page" list.
(function(){
  const links = [...document.querySelectorAll('.legal-toc a[href^="#"]')];
  if(!links.length || !('IntersectionObserver' in window)) return;
  const byId = new Map(links.map(a => [a.getAttribute('href').slice(1), a]));
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => { if(e.isIntersecting){ links.forEach(a => a.classList.remove('is-current')); const a = byId.get(e.target.id); if(a) a.classList.add('is-current'); } });
  }, {rootMargin: '-30% 0px -60% 0px'});
  byId.forEach((a, id) => { const el = document.getElementById(id); if(el) io.observe(el); });
})();

/* Privacy policy pop-up: footer link opens the policy in a dialog (falls back to the page) */
(function(){
  if(typeof HTMLDialogElement === 'undefined' || /\/privacy(\/|$)/.test(location.pathname)) return;
  let dlg = null, cache = null;
  const build = () => {
    dlg = document.createElement('dialog');
    dlg.className = 'pv-modal';
    dlg.setAttribute('aria-labelledby', 'pv-title');
    dlg.innerHTML = '<div class="pv-head"><div class="pv-head-txt"><span class="pv-kicker">CRT Media Agency</span><h2 id="pv-title"></h2><p class="pv-date"></p></div>' +
      '<div class="pv-actions"><a class="pv-full" href="">Full page ↗</a><button type="button" class="pv-x" aria-label="Close privacy policy">×</button></div></div>' +
      '<div class="pv-body legal-content" tabindex="-1"></div>';
    document.body.appendChild(dlg);
    dlg.querySelector('.pv-x').addEventListener('click', () => dlg.close());
    dlg.addEventListener('click', e => { if(e.target === dlg) dlg.close(); });
    dlg.addEventListener('close', () => document.documentElement.classList.remove('pv-lock'));
    dlg.querySelector('.pv-body').addEventListener('click', e => {
      const a = e.target.closest('a[href^="#pv-"]'); if(!a) return;
      e.preventDefault(); const t = dlg.querySelector(a.getAttribute('href')); if(t) t.scrollIntoView({behavior:'smooth', block:'start'});
    });
  };
  const load = async url => {
    if(cache && cache.url === url) return cache;
    const r = await fetch(url, {credentials:'same-origin'}); if(!r.ok) throw new Error('fetch');
    const doc = new DOMParser().parseFromString(await r.text(), 'text/html');
    const c = doc.querySelector('.legal-content'); if(!c) throw new Error('content');
    const base = new URL(url, location.href);
    c.querySelectorAll('[id]').forEach(x => { x.id = 'pv-' + x.id; });
    c.querySelectorAll('a[href]').forEach(x => {
      const h = x.getAttribute('href');
      if(h.startsWith('#')) x.setAttribute('href', '#pv-' + h.slice(1)); else x.href = new URL(h, base).href;
    });
    c.querySelectorAll('script').forEach(s => s.remove());
    const txt = sel => { const n = doc.querySelector(sel); return n ? n.textContent.trim() : ''; };
    return cache = {url, title: txt('.legal-hero h1') || 'Privacy policy', date: txt('.legal-date'), html: c.innerHTML};
  };
  document.addEventListener('click', async e => {
    const a = e.target.closest('.footer-legal a[href*="privacy"], .site-footer a[href*="privacy"]');
    if(!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    e.preventDefault();
    let d; try { d = await load(a.href); } catch(err){ location.href = a.href; return; }
    if(!dlg) build();
    dlg.querySelector('#pv-title').textContent = d.title;
    dlg.querySelector('.pv-date').textContent = d.date;
    dlg.querySelector('.pv-full').href = a.href;
    const body = dlg.querySelector('.pv-body'); body.innerHTML = d.html; body.scrollTop = 0;
    document.documentElement.classList.add('pv-lock');
    dlg.showModal(); body.focus({preventScroll:true});
  });
})();

/* Selected work row: arrow buttons scroll one card at a time; disabled at either end */
document.querySelectorAll('[data-sw]').forEach(row => {
  const sec = row.closest('section'), prev = sec.querySelector('[data-sw-prev]'), next = sec.querySelector('[data-sw-next]');
  const step = () => { const c = row.querySelector('li'); return c ? c.getBoundingClientRect().width + parseFloat(getComputedStyle(row).columnGap || 16) : row.clientWidth; };
  const sync = () => { const max = row.scrollWidth - row.clientWidth - 2; if(prev) prev.disabled = row.scrollLeft <= 2; if(next) next.disabled = row.scrollLeft >= max; };
  prev && prev.addEventListener('click', () => row.scrollBy({left: -step(), behavior: 'smooth'}));
  next && next.addEventListener('click', () => row.scrollBy({left: step(), behavior: 'smooth'}));
  row.addEventListener('scroll', () => requestAnimationFrame(sync), {passive: true});
  window.addEventListener('resize', sync); sync();
});

// ---------------------------------------------------------------
// Reels pop-up (Car Biz and any .reel-row): click a reel to watch it large,
// browse with ‹ › / ← → / swipe, close with ×, Esc or a click outside. Same viewer feel as the photos.
// ---------------------------------------------------------------
(function(){
  const reels = [...document.querySelectorAll('.reel-row .reel')]; if(!reels.length) return;
  const items = reels.map((r, i) => { const f = r.querySelector('iframe'); return f ? {src: f.getAttribute('src'), title: f.title || ('Reel ' + (i + 1))} : null; }).filter(Boolean);
  let box, frame, countEl, idx = 0, lastFocus = null;
  function build(){
    box = document.createElement('div');
    box.className = 'lightbox reel-lb'; box.hidden = true;
    box.setAttribute('role','dialog'); box.setAttribute('aria-modal','true'); box.setAttribute('aria-label','Reel viewer');
    box.innerHTML = '<button class="lb-close" type="button" aria-label="Close">×</button>'+
      '<button class="lb-nav lb-prev" type="button" aria-label="Previous reel">‹</button>'+
      '<figure class="lb-stage"><div class="reel-frame reel-lb-frame"></div></figure>'+
      '<button class="lb-nav lb-next" type="button" aria-label="Next reel">›</button>'+
      '<div class="lb-count" aria-live="polite"></div>';
    document.body.appendChild(box);
    frame = box.querySelector('.reel-lb-frame'); countEl = box.querySelector('.lb-count');
    box.querySelector('.lb-close').addEventListener('click', close);
    box.querySelector('.lb-prev').addEventListener('click', e=>{ e.stopPropagation(); go(-1); });
    box.querySelector('.lb-next').addEventListener('click', e=>{ e.stopPropagation(); go(1); });
    box.addEventListener('click', e=>{ if(e.target === box || e.target.classList.contains('lb-stage')) close(); });
    let x0 = null, y0 = null;
    box.addEventListener('touchstart', e=>{ x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; }, {passive:true});
    box.addEventListener('touchend', e=>{ if(x0 === null) return; const dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0; x0 = null;
      if(Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy)) go(dx < 0 ? 1 : -1); else if(dy > 90 && Math.abs(dy) > Math.abs(dx)) close(); });
    document.addEventListener('keydown', e=>{
      if(box.hidden) return;
      if(e.key === 'Escape') close(); else if(e.key === 'ArrowRight') go(1); else if(e.key === 'ArrowLeft') go(-1);
      else if(e.key === 'Tab'){ const f = [...box.querySelectorAll('button')]; const i = f.indexOf(document.activeElement); e.preventDefault(); f[(i + (e.shiftKey ? -1 : 1) + f.length) % f.length].focus(); }
    });
  }
  function show(){
    const it = items[idx];
    frame.innerHTML = `<iframe src="${it.src}" title="${it.title.replace(/"/g,'&quot;')}" scrolling="no" frameborder="0" allowtransparency="true" allow="autoplay; encrypted-media; picture-in-picture"></iframe>`;
    countEl.textContent = (idx + 1) + ' / ' + items.length;
    box.querySelectorAll('.lb-nav').forEach(b=>b.hidden = items.length < 2);
  }
  function go(d){ idx = (idx + d + items.length) % items.length; show(); }
  function open(i){
    if(!box) build();
    idx = i; lastFocus = document.activeElement;
    box.hidden = false; document.documentElement.classList.add('lb-open');
    requestAnimationFrame(()=>box.classList.add('is-open'));
    show(); box.querySelector('.lb-close').focus();
  }
  function close(){
    box.classList.remove('is-open'); document.documentElement.classList.remove('lb-open');
    setTimeout(()=>{ box.hidden = true; frame.innerHTML = ''; }, 200);   // stops playback
    if(lastFocus && lastFocus.focus) lastFocus.focus();
  }
  reels.forEach((r, i) => {
    const fr = r.querySelector('.reel-frame'); if(!fr) return;
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'reel-open'; b.setAttribute('aria-label', 'Play ' + (items[i] ? items[i].title : 'reel'));
    b.innerHTML = '<span class="reel-play" aria-hidden="true"></span>';
    b.addEventListener('click', () => open(i));
    fr.appendChild(b);
  });
  const hint = document.querySelector('.reel-head p'); if(hint && /Tap a reel/i.test(hint.textContent)) hint.textContent = 'Tap a reel to watch it full screen.';
})();


// Header Shop link: label for phones, and a count of items in the request list (shown only when > 0).
(function(){
  const links = [...document.querySelectorAll('.nav-shop')]; if(!links.length) return;
  links.forEach(a => {
    if(!a.querySelector('.nav-shop-sub')){ const sub = document.createElement('span'); sub.className = 'nav-shop-sub'; sub.textContent = 'Albums & prints'; a.appendChild(sub); }
    if(!a.querySelector('.nav-shop-count')){ const c = document.createElement('em'); c.className = 'nav-shop-count'; c.hidden = true; c.setAttribute('aria-hidden', 'true'); a.appendChild(c); }
  });
  const read = () => { try{ const b = JSON.parse(localStorage.getItem('crt-shop-bag') || '[]'); return Array.isArray(b) ? b.length : 0; }catch(e){ return 0; } };
  let last = null;
  const paint = n => links.forEach(a => {
    const c = a.querySelector('.nav-shop-count'); c.textContent = n; c.hidden = !n;
    a.setAttribute('aria-label', n ? `Shop, ${n} ${n === 1 ? 'item' : 'items'} in your request list` : 'Shop');
    if(last !== null && n > last){ a.classList.remove('is-bump'); void a.offsetWidth; a.classList.add('is-bump'); }
  });
  const update = n => { n = typeof n === 'number' ? n : read(); paint(n); last = n; };
  window.addEventListener('crt:bag', e => update(e.detail));
  window.addEventListener('storage', e => { if(e.key === 'crt-shop-bag') update(); });
  update();
})();

// Seasonal ribbon (home page only), like apple.com's timely top line. Add a season to SEASONS
// with month/day start and end; it shows only inside its window, and a visitor can dismiss it.
(function(){
  if(!document.querySelector('.hero-home')) return;
  const SEASONS = [
  ];
  const esc = v => String(v == null ? '' : v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function build(){
    const old = document.querySelector('.season-bar'); if(old) old.remove();
    const now = new Date(), md = (now.getMonth()+1)*100 + now.getDate();
    let s = SEASONS.find(x => md >= x.from[0]*100 + x.from[1] && md <= x.to[0]*100 + x.to[1]);
    // The admin's announcement (Content → Announcement bar) replaces the seasonal one, or switches the bar off.
    const A = window.CRT_ANNOUNCE;
    if(A){
      if(A.on === false || !String(A.text || '').trim()) return;
      const t = String(A.text).trim().slice(0, 120);
      let id = 0; for(let i = 0; i < t.length; i++) id = (id * 31 + t.charCodeAt(i)) >>> 0;
      let href = String(A.href || '').trim(); if(href && !/^(https?:\/\/|\/|[a-z0-9_-]+\/)/i.test(href)) href = '';
      if(href[0] === '/') href = href.slice(1) || 'index.html';
      s = {id: 'a' + id, text: t, link: href ? String(A.link || 'See more').trim().slice(0, 40) : '', href};
    }
    if(!s) return;
    const key = 'crt-season-' + s.id;
    try{ if(localStorage.getItem(key) === 'x') return; }catch(e){}
    const header = document.querySelector('.site-header'); if(!header) return;
    const bar = document.createElement('div');
    bar.className = 'season-bar';
    bar.setAttribute('role', 'region'); bar.setAttribute('aria-label', 'Announcement');
    bar.innerHTML = `<p><span>${esc(s.text)}</span>${s.link ? ` <a href="${esc(s.href)}" data-track="season_${esc(s.id)}">${esc(s.link)} <i aria-hidden="true">›</i></a>` : ''}</p><button type="button" class="season-x" aria-label="Hide this message">×</button>`;
    header.before(bar);
    bar.querySelector('.season-x').addEventListener('click', () => { bar.remove(); const b = header.querySelector('.brand'); if(b) b.focus(); try{ localStorage.setItem(key, 'x'); }catch(e){} });
  }
  build();
  document.addEventListener('crt:content', e => { if(e.detail && e.detail.site_settings && e.detail.site_settings.announcement) build(); });
})();


// v9.1 Section links bar (apple.com product pages): highlight the section on screen.
(function(){
  const bar = document.querySelector('[data-subnav]'); if(!bar || !('IntersectionObserver' in window)) return;
  const links = [...bar.querySelectorAll('.subnav-links a')];
  const secs = links.map(a => document.getElementById(a.hash.slice(1))).filter(Boolean);
  const seen = new Map();
  const io = new IntersectionObserver(es => {
    es.forEach(e => seen.set(e.target.id, e.isIntersecting ? e.intersectionRatio : 0));
    let best = null, top = 0;
    secs.forEach(s => { const r = seen.get(s.id) || 0; if(r > top){ top = r; best = s.id; } });
    links.forEach(a => {
      const on = a.hash.slice(1) === best; a.classList.toggle('is-on', on);
      if(on){ a.setAttribute('aria-current', 'true'); const box = a.parentElement;
        if(a.offsetLeft < box.scrollLeft || a.offsetLeft + a.offsetWidth > box.scrollLeft + box.clientWidth) box.scrollTo({left: a.offsetLeft - 12, behavior: 'smooth'}); }
      else a.removeAttribute('aria-current');
    });
  }, {rootMargin: '-140px 0px -45% 0px', threshold: [0, .1, .25, .5]});
  secs.forEach(s => io.observe(s));
  // The comparison table opens when someone jumps to it
  links.forEach(a => a.addEventListener('click', () => { const t = document.getElementById(a.hash.slice(1)); if(t && t.tagName === 'DETAILS') t.open = true; }));
})();

// v9.1 Contact form in two steps (stripe.com sales form): what you need + how to reach you, then the details.
(function(){
  document.querySelectorAll('form[data-booking-form]').forEach(form => {
    const needs = form.querySelector('.need-set'), grid = form.querySelector('.form-grid');
    const name = form.querySelector('[name="name"]'), contact = form.querySelector('[name="contact"]');
    if(!needs || !grid || !name || !contact) return;
    const sub = form.querySelector('.form-subtitle');
    const steps = document.createElement('p'); steps.className = 'form-steps'; steps.setAttribute('aria-hidden', 'true');
    steps.innerHTML = '<span class="is-on">You</span><span>Your project</span>';
    (sub || needs).insertAdjacentElement(sub ? 'afterend' : 'beforebegin', steps);
    const live = document.createElement('p'); live.className = 'sr-only'; live.setAttribute('aria-live', 'polite'); steps.after(live);
    // Step 1: chips + name + contact + Continue
    const grid1 = document.createElement('div'); grid1.className = 'form-grid'; grid1.dataset.step = '1';
    grid1.append(name.closest('.field'), contact.closest('.field'));
    needs.dataset.step = '1'; needs.after(grid1);
    const act1 = document.createElement('div'); act1.className = 'form-actions'; act1.dataset.step = '1';
    act1.innerHTML = '<button class="btn" type="button" data-track="form_step1_continue">Continue →</button>';
    grid1.after(act1);
    // Step 2: everything else
    const back = document.createElement('button'); back.type = 'button'; back.className = 'form-step-back'; back.dataset.step = '2'; back.textContent = '← Back';
    const rest = [grid, form.querySelector('.form-actions:not([data-step])'), form.querySelector('.form-disclaimer')].filter(Boolean);
    grid.before(back);
    [back, ...rest].forEach(el => { el.dataset.step = '2'; el.hidden = true; });
    const req2 = [...grid.querySelectorAll('[required]')]; req2.forEach(el => el.required = false);
    let step = 1;
    const go = n => {
      step = n;
      form.querySelectorAll('[data-step]').forEach(el => el.hidden = el.dataset.step !== String(n));
      req2.forEach(el => el.required = n === 2);
      steps.children[1].classList.toggle('is-on', n === 2); steps.children[0].classList.toggle('is-on', n === 1);
      live.textContent = n === 2 ? 'Step 2 of 2: your project' : 'Step 1 of 2: about you';
      const f = n === 2 ? grid.querySelector('input,select,textarea') : name;
      if(f) f.focus({preventScroll: true});
      const top = form.getBoundingClientRect().top; if(top < 90) window.scrollBy({top: top - 110, behavior: 'smooth'});
    };
    const next = () => { if(!name.reportValidity() || !contact.reportValidity()) return; go(2); };
    act1.querySelector('button').addEventListener('click', next);
    back.addEventListener('click', () => go(1));
    // After a successful send the form resets: start again at step 1, so name and contact are visible.
    form.addEventListener('reset', () => setTimeout(() => go(1), 0));
    // Enter on step 1 means "Continue", never a half-filled send
    form.addEventListener('submit', e => { if(step === 1){ e.preventDefault(); e.stopImmediatePropagation(); next(); } }, true);
    // Arriving from a package or service link with the chips already ticked: start at step 1 all the same (name + contact first).
  });
})();

// v9.2 "Skip to content" for keyboard and screen-reader users (apple.com, gov.uk)
(function(){
  const main = document.querySelector('main'); if(!main || document.querySelector('.skip-link')) return;
  if(!main.id) main.id = 'main';
  if(!main.hasAttribute('tabindex')) main.setAttribute('tabindex', '-1');
  const a = document.createElement('a'); a.className = 'skip-link'; a.href = '#' + main.id; a.textContent = 'Skip to content';
  document.body.insertBefore(a, document.body.firstChild);
})();


// v9.3 Review form (/review/): sends the client's review to CRT (Leads + the hello@ mailbox). Nothing is published automatically.
(function(){
  const form = document.querySelector('[data-review-form]'); if(!form) return;
  const status = form.querySelector('.form-status'), btn = form.querySelector('button[type="submit"]'), label = btn.textContent;
  const show = (k, h)=>{ status.className = 'form-status is-' + k; status.innerHTML = h; status.hidden = false; };
  form.addEventListener('submit', e=>{
    e.preventDefault();
    const d = new FormData(form); if(d.get('bot-field')) return;
    btn.disabled = true; btn.textContent = 'Sending…'; status.hidden = true;
    // Saved in the dashboard (Leads, service "Client review"); the database also files it into the hello@ mailbox.
    const CFG = window.CRT_CONFIG || {}, cut = (v, n) => (v || '').toString().slice(0, n);
    const saved = (CFG.SUPABASE_URL && CFG.SUPABASE_ANON_KEY) ? fetch(CFG.SUPABASE_URL.replace(/\/$/, '') + '/rest/v1/leads', {method: 'POST', keepalive: true,
      headers: {'apikey': CFG.SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + CFG.SUPABASE_ANON_KEY, 'Content-Type': 'application/json', 'Prefer': 'return=minimal'},
      body: JSON.stringify({name: cut(d.get('name'), 120) || 'Unknown', contact: 'Client review (no contact given)', service: 'Client review', offer: cut(d.get('publish'), 120),
        details: cut('Project: ' + (d.get('project') || '') + '\nRole: ' + (d.get('role') || '—') + '\nPublish: ' + (d.get('publish') || '') + '\n\n' + (d.get('review') || ''), 2000), page: '/review/', source: 'Review form'})
    }).then(r => r.ok).catch(() => false) : Promise.resolve(false);
    saved
      .then(l => { if(!l) throw new Error('not sent');
        const n = (d.get('name') || '').toString().split(' ')[0].replace(/[<>&]/g, '');
        show('ok', '<strong>Thank you' + (n ? ', ' + n : '') + '!</strong> Your review is with us.'); form.reset();
        if(typeof window.gtag === 'function') window.gtag('event', 'review_submitted'); })
      .catch(() => show('error', 'Sorry, that didn’t send. Please email your review to <a href="mailto:hello@crt.rw">hello@crt.rw</a> or send it on <a href="https://wa.me/250796356035" target="_blank" rel="noopener">WhatsApp</a>.'))
      .finally(() => { btn.disabled = false; btn.textContent = label; });
  });
})();


// ---------------------------------------------------------------
// Book page (/book/), like apple.com's Buy: service → package → extras, a live estimate, then the booking form.
// Deep links: ?s=weddings|events|business|print and &p=<package id>. The form sends to the same inbox as every enquiry.
// ---------------------------------------------------------------
window.crtCMS.after(function(){
  const root = document.querySelector('[data-book]'); if(!root) return;
  const form = root.querySelector('[data-book-form]'), lines = root.querySelector('[data-bk-lines]'), totalEl = root.querySelector('[data-bk-total]');
  const det = form && form.querySelector('[name="details"]');
  const fmt = n => n.toLocaleString('en-US') + ' RWF';
  const q = new URLSearchParams(location.search);
  let gen = '', own = '', complete = false, notes = null;
  const group = s => root.querySelector('.bk-group[data-svc="' + s + '"]');
  // Simpler details (apple.com checkout): the booking is written for us in a hidden field; visitors only add notes if they want.
  if(det && form){
    det.required = false;
    const fld = det.closest('.field');
    if(fld){
      fld.hidden = true;
      fld.insertAdjacentHTML('afterend', '<div class="field full bk-notes"><label for="k-notes">Anything else we should know? <span class="bk-opt-l">Optional</span></label><textarea id="k-notes" rows="3" placeholder="Venue, timings, ideas, or links to examples you like."></textarea></div>');
      notes = form.querySelector('#k-notes');
      notes.addEventListener('input', () => { own = notes.value.trim(); det.value = gen + (own ? '\n\nNotes: ' + own : ''); });
    }
    // nothing is sent before a package (or a print item) is chosen: say so where the choice is made
    const guard = e => {
      if(complete) return;
      e.preventDefault(); e.stopImmediatePropagation();
      const s = svc(), t = s ? (group(s) || root).querySelector('.bk-step') : root.querySelector('.bk-step-s');
      if(t) t.scrollIntoView({behavior: 'smooth', block: 'start'});
      const n = root.querySelector('.bk-need'); if(n){ n.hidden = false; n.textContent = !s ? 'Choose a service and a package first.' : (s === 'print' ? 'Add a print product first.' : 'Choose a package first.'); }
    };
    form.addEventListener('submit', guard, true);
    const wa = form.querySelector('[data-send-whatsapp]'); if(wa) wa.addEventListener('click', guard, true);
    const sum = root.querySelector('.bk-total'); if(sum) sum.insertAdjacentHTML('afterend', '<p class="bk-need" role="alert" hidden></p>');
  }
  function svc(){ const r = root.querySelector('input[name="bk-s"]:checked'); return r ? r.value : ''; }
  function update(){
    const s = svc();
    root.querySelectorAll('.bk-group').forEach(g => g.hidden = g.dataset.svc !== s);
    complete = false;
    if(!s){ lines.innerHTML = '<li class="bk-empty">Choose a service to start.</li>'; totalEl.textContent = '—'; return; }
    if(s === 'print'){ printRequest(); needDone(); return; }
    const sIn = root.querySelector('input[name="bk-s"]:checked'), g = group(s), name = sIn.closest('label').textContent.trim();
    const sl = root.querySelector('[data-bk-svc-line]'); if(sl) sl.textContent = sIn.dataset.line || '';
    const pk = g.querySelector('input[name="bk-p-' + s + '"]:checked');
    g.querySelectorAll('[data-only="days"]').forEach(el => { el.hidden = !(pk && pk.value === 'days'); if(el.hidden) el.querySelector('input').checked = false; });
    const xs = [...g.querySelectorAll('input[name="bk-x-' + s + '"]:checked')];
    complete = !!pk;
    const early = s === 'weddings' && root.querySelector('input[name="bk-early"]:checked') && pk && pk.dataset.price;
    let total = 0, onRequest = false, per = pk ? pk.dataset.per : '';
    const rows = [['Service', name]];
    const days = pk && pk.value === 'days';
    if(pk){ const p = pk.dataset.price; rows.push([pk.dataset.name, p ? fmt(+p) + per : (days ? 'Pick your days below' : 'Priced on request')]); if(p){ total += +p; } else if(!days) onRequest = true; }
    if(early){ const off = Math.round(+pk.dataset.price * 0.3); total -= off; rows.push(['Early booking, 30% off', '−' + fmt(off)]); }
    xs.forEach(x => { const p = x.dataset.price; rows.push([x.dataset.name, p === '' ? 'On request' : (+p ? '+' + fmt(+p) : 'Free')]); if(p === '') onRequest = true; else total += +p; });
    const esc = t => String(t).replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
    lines.innerHTML = rows.map(([a, b]) => `<li><span>${esc(a)}</span><b>${esc(b)}</b></li>`).join('') + (pk ? '' : '<li class="bk-empty">Choose a package.</li>');
    totalEl.textContent = total ? 'From ' + fmt(total) + per + (onRequest ? ' + items on request' : '') : (pk ? (days ? 'Pick your days' : 'Priced on request') : '—');
    if(form){
      form.querySelector('[name="service"]').value = name;
      form.querySelector('[name="offer"]').value = pk ? pk.dataset.name + (early ? ' (early booking)' : '') : '';
      // A tidy, line-by-line booking (the dashboard turns this into a table; emails keep the lines)
      const L = ['BOOKING', 'Service: ' + name];
      if(pk) L.push('Package: ' + pk.dataset.name + ' · ' + (pk.dataset.price ? fmt(+pk.dataset.price) + per : (days ? 'days chosen below' : 'priced on request')));
      if(early) L.push('Offer: Early booking, 30% off · −' + fmt(Math.round(+pk.dataset.price * 0.3)));
      if(xs.length) L.push('Extras:', ...xs.map(x => '- ' + x.dataset.name + ' · ' + (x.dataset.price === '' ? 'on request' : (+x.dataset.price ? '+' + fmt(+x.dataset.price) : 'free'))));
      L.push('Estimate: ' + totalEl.textContent);
      gen = L.join('\n');
      if(det) det.value = gen + (own ? '\n\nNotes: ' + own : '');
    }
    try{ const u = new URL(location.href); u.searchParams.set('s', s); if(pk) u.searchParams.set('p', pk.value); else u.searchParams.delete('p'); history.replaceState(null, '', u); }catch(e){}
    needDone();
  }
  function needDone(){ const n = root.querySelector('.bk-need'); if(n && complete) n.hidden = true; }
  // Tesla-style: the big photo follows the chosen service; the bottom bar mirrors the estimate
  const VIS = {weddings:['wedding-sandra-mathias/cover','Weddings: all four days, in photos and video.'], events:['old-mutual/08','Events: the room, the speeches, the people.'],
    business:['phizer-wines/08','Business: products, brands and content that sells.'], print:['rwanda-mining-week/site-presswall','Print: made to order, by the team that shot and designed it.']};
  const vImg = root.querySelector('[data-bk-img]'), vCap = root.querySelector('[data-bk-cap]'), barT = root.querySelector('[data-bk-bar-total]');
  function visual(){
    const v = VIS[svc()]; if(vImg && v){ const src = '../assets/work/cases/' + v[0] + '.webp'; if(!vImg.src.endsWith(src.slice(2))){ vImg.classList.add('is-swap'); setTimeout(() => { vImg.onload = vImg.onerror = () => vImg.classList.remove('is-swap'); vImg.src = src; setTimeout(() => vImg.classList.remove('is-swap'), 1500); }, 160); } if(vCap) vCap.textContent = v[1]; }
    if(barT) barT.textContent = totalEl.textContent;
  }
  function printRequest(){
    const fmtR = n => n.toLocaleString('en-US') + ' RWF', escH = t => String(t).replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
    let list = []; try{ list = JSON.parse(localStorage.getItem('crt-print-request') || '[]'); }catch(e){}
    const sl = root.querySelector('[data-bk-svc-line]'), sIn = root.querySelector('input[name="bk-s"]:checked'); if(sl && sIn) sl.textContent = sIn.dataset.line || '';
    const ul = root.querySelector('[data-bk-print]'), empty = root.querySelector('[data-bk-print-empty]');
    if(ul) ul.innerHTML = list.map(it => `<li><strong>${escH(it.name)}</strong><span>${escH(it.opts.join(' · '))}</span><em>${escH(it.qty)}</em></li>`).join('');
    if(empty) empty.hidden = !!list.length;
    let total = 0, onRequest = false;
    complete = list.length > 0;
    list.forEach(it => { if(it.price) total += it.price * (it.q || 1); else onRequest = true; });
    lines.innerHTML = '<li><span>Service</span><b>Print</b></li>' + (list.length ? list.map(it => `<li><span>${escH(it.name)}</span><b>${escH(it.qty)}</b></li>`).join('') : '<li class="bk-empty">Your request list is empty.</li>');
    totalEl.textContent = !list.length ? '—' : (total ? 'From ' + fmtR(total) + (onRequest ? ' + items on request' : '') : 'Priced on request');
    if(form){
      form.querySelector('[name="service"]').value = 'Print';
      form.querySelector('[name="offer"]').value = list.length ? list.length + ' product' + (list.length > 1 ? 's' : '') + ' from CRT Print' : '';
      const L = ['BOOKING', 'Service: Print'];
      if(list.length) L.push('Items:', ...list.map(it => '- ' + it.name + (it.opts.length ? ' (' + it.opts.join(', ') + ')' : '') + ' · ' + it.qty));
      L.push('Estimate: ' + totalEl.textContent);
      gen = L.join('\n'); if(det) det.value = gen + (own ? '\n\nNotes: ' + own : '');
    }
    try{ const u2 = new URL(location.href); u2.searchParams.set('s', 'print'); u2.searchParams.delete('p'); history.replaceState(null, '', u2); }catch(e){}
  }
  root.addEventListener('change', () => { update(); visual(); });
  if(det) det.addEventListener('input', () => { own = (det.value.startsWith(gen) ? det.value.slice(gen.length) : det.value).replace(/^\s*Notes:\s*/, '').trim(); });
  // deep link
  const s0 = q.get('s'), r0 = s0 && root.querySelector('input[name="bk-s"][value="' + s0 + '"]');
  if(r0){ r0.checked = true; const p0 = q.get('p'), pr = p0 && root.querySelector('input[name="bk-p-' + s0 + '"][value="' + p0 + '"]'); if(pr) pr.checked = true; }
  if(q.get('early') === '1'){ const e = root.querySelector('input[name="bk-early"]'); if(e) e.checked = true; }   // from the early-booking offer
  update(); visual();
  if(r0) setTimeout(() => { const g = group(s0); const t = (g && q.get('p')) ? g.querySelector('.bk-step:nth-child(2)') : g; if(t && window.innerWidth < 900) t.scrollIntoView({block:'start'}); }, 0);
});

// v11.2 Footer, apple.com style: group each heading with its links; on phones each group folds open/closed.
(function(){
  const cols = document.querySelector('footer.footer:not(.lp-footer) .footer-cols'); if(!cols) return;
  cols.querySelectorAll(':scope > div').forEach(col => {
    let grp = null;
    [...col.childNodes].forEach(n => {
      if(n.nodeType === 1 && n.tagName === 'H3'){
        grp = document.createElement('div'); grp.className = 'fc-grp';
        const links = document.createElement('div'); links.className = 'fc-links';
        col.insertBefore(grp, n); grp.append(n, links);
        n.setAttribute('role', 'button'); n.tabIndex = 0; n.setAttribute('aria-expanded', 'false');
        const toggle = () => { if(!window.matchMedia('(max-width: 734px)').matches) return; const o = grp.classList.toggle('is-open'); n.setAttribute('aria-expanded', String(o)); };
        n.addEventListener('click', toggle);
        n.addEventListener('keydown', e => { if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); toggle(); } });
      } else if(grp && n !== grp){ grp.lastElementChild.appendChild(n); }
    });
  });
})();

// v15 Photo protection (apple.com): no "Save image", "Copy image" or "Open image in new tab" on any photo or video,
// no dragging photos out of the page, no photos in a copy, no download button on videos.
// Text stays selectable and copyable (addresses, prices). Applies to every page that loads this script.
(function(){
  const MEDIA = 'img,picture,video,svg image,canvas,.lightbox,.lb-stage,.cs-tile,.sw-img,.wk-img,.hp-img,.path-img,.cs3-cover,.showreel,.lm-slot';
  const hasBg = el => { for(let i = 0; el && i < 4; i++, el = el.parentElement){ if(el.nodeType === 1 && /url\(/.test(getComputedStyle(el).backgroundImage)) return true; } return false; };
  const isMedia = t => t && t.nodeType === 1 && (t.closest(MEDIA) || hasBg(t));
  // right-click, or a long press on Android: no image menu
  document.addEventListener('contextmenu', e => { if(isMedia(e.target)) e.preventDefault(); }, true);
  // drag a photo to the desktop or another tab
  document.addEventListener('dragstart', e => { if(isMedia(e.target)) e.preventDefault(); }, true);
  // copying a selection that includes photos: copy the words only
  document.addEventListener('copy', e => {
    const sel = window.getSelection(); if(!sel || !sel.rangeCount) return;
    const frag = sel.getRangeAt(0).cloneContents();
    if(!frag.querySelector || !frag.querySelector('img,picture,video,svg')) return;
    e.preventDefault(); if(e.clipboardData) e.clipboardData.setData('text/plain', sel.toString());
  }, true);
  // videos: no download button, no picture-in-picture, no remote playback menu
  const lockVideo = v => { v.setAttribute('controlsList', 'nodownload noremoteplayback'); v.disablePictureInPicture = true; v.setAttribute('disablepictureinpicture', ''); v.setAttribute('oncontextmenu', 'return false'); };
  const scan = root => (root || document).querySelectorAll && (root || document).querySelectorAll('video').forEach(lockVideo);
  const lockImg = im => { im.setAttribute('draggable', 'false'); };
  const scanImgs = root => (root || document).querySelectorAll && (root || document).querySelectorAll('img').forEach(lockImg);
  const go = () => { scan(); scanImgs(); };
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go); else go();
  new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(n => {
    if(n.nodeType !== 1) return;
    if(n.tagName === 'VIDEO') lockVideo(n); else if(n.tagName === 'IMG') lockImg(n); else { scan(n); scanImgs(n); }
  }))).observe(document.documentElement, {childList: true, subtree: true});
})();

// v15.2 Work thumbnails chosen in /admin → Case studies → Thumbnail: used on every card that links to that work
// (home "Selected work", the Work page, "More work like this"). Works without a chosen thumbnail keep their picture.
(function(){
  const CFG = window.CRT_CONFIG || {}; if(!CFG.SUPABASE_URL || !CFG.SUPABASE_ANON_KEY) return;
  const CARDS = 'a.sw-card,a.wk-card,a.cs2-more-card,a.tl-card';
  if(!document.querySelector(CARDS) && !document.querySelector('main[data-case3]')) return;
  const safe = x => { try{ const z = new URL(x, location.href); return (z.protocol === 'https:' || z.origin === location.origin) ? z.href : ''; }catch(e){ return ''; } };
  const slugOf = a => { const m = (a.getAttribute('href') || '').match(/(work-[\w-]+)(?:\/|$)|[?&]s=([\w-]+)/); return m ? (m[1] || m[2]) : ''; };
  let thumbs = null;
  const apply = () => { if(!thumbs) return; document.querySelectorAll(CARDS).forEach(a => {
    const url = thumbs[slugOf(a)]; if(!url) return;
    const im = a.querySelector('img'); if(!im || im.dataset.thumb === url) return;
    im.removeAttribute('srcset'); im.removeAttribute('sizes'); im.src = url; im.dataset.thumb = url; im.style.objectPosition = '50% 50%';
  }); };
  fetch(CFG.SUPABASE_URL.replace(/\/$/, '') + '/rest/v1/site_content?select=value&key=eq.case_studies', {headers: {'apikey': CFG.SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + CFG.SUPABASE_ANON_KEY}})
    .then(r => r.ok ? r.json() : []).then(rows => {
      const live = rows && rows[0] && rows[0].value; if(!live) return;
      thumbs = {}; Object.keys(live).forEach(sl => { const e = live[sl]; if(e && e.card_custom && e.card && safe(e.card.url)) thumbs[sl] = safe(e.card.url); });
      apply();
    }).catch(() => {});
  ['crt:case-drawn', 'crt:work-list'].forEach(ev => document.addEventListener(ev, () => setTimeout(apply, 0)));
})();

// v18 Reviews: cards stay one size; a long review gets "Read the full review", which opens it in place.
(function(){
  const list = document.querySelector('[data-testimonials-list]'); if(!list) return;
  function fit(){
    list.querySelectorAll('.rv3-card blockquote').forEach(q => {
      const card = q.closest('.rv3-card'); if(card.classList.contains('is-open')) return;
      let b = card.querySelector('.rv3-more');
      const over = q.scrollHeight - q.clientHeight > 2;
      if(over && !b){ b = document.createElement('button'); b.type = 'button'; b.className = 'rv3-more'; b.textContent = 'Read the full review';
        b.addEventListener('click', () => { card.classList.add('is-open'); b.remove(); }); q.after(b); }
      else if(!over && b) b.remove();
    });
  }
  new MutationObserver(() => requestAnimationFrame(fit)).observe(list, {childList: true});
  window.addEventListener('resize', () => requestAnimationFrame(fit));
  if(document.fonts && document.fonts.ready) document.fonts.ready.then(fit); else fit();
})();
