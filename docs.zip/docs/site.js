(function(){
  // The site works straight from a folder (no server), so links are built relative
  // to the folder that holds this script. u('/contact#inquiry') -> .../contact/index.html#inquiry
  const ROOT = (document.currentScript && document.currentScript.src)
    ? new URL('.', document.currentScript.src).href : new URL('/', location.href).href;
  const u = p=>{
    if(!p || p[0] !== '/') return p;
    const m = p.match(/^([^?#]*)(.*)$/); let path = m[1];
    if(path === '/' || path.endsWith('/')) path += 'index.html';
    else if(!/\.[a-z0-9]+$/i.test(path.split('/').pop())) path += '/index.html';
    return new URL(path.slice(1) + m[2], ROOT).href;
  };
  // '.../business/index.html' -> '/business' (used to match menu entries)
  const pageKey = href=>{
    const h = new URL(href, location.href).href.split(/[?#]/)[0];
    if(!h.startsWith(ROOT)) return null;
    return '/' + h.slice(ROOT.length).replace(/(^|\/)index\.html$/, '').replace(/\/$/, '');
  };
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.nav-links');
  if(toggle && nav){
    toggle.addEventListener('click', function(){
      const isOpen = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(isOpen));
      toggle.textContent = isOpen ? 'Close' : 'Menu';
    });
    nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{
      nav.classList.remove('open'); toggle.setAttribute('aria-expanded','false'); toggle.textContent='Menu';
    }));
  }
  const params = new URLSearchParams(window.location.search);

  // Swap prices in visible text, e.g. {"600,000":"1,200,000"}. One pass, so a new
  // price is never swapped twice. Skips scripts, styles and form fields.
  function crtReplaceNumbers(root, map){
    const keys = Object.keys(map);
    if(!root || !keys.length) return;
    const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const re = new RegExp('(^|[^\\d,])(' + keys.map(esc).join('|') + ')(?![\\d,])', 'g');
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: n => (n.parentElement && n.parentElement.closest('script,style,textarea,input')) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT
    });
    const nodes = []; while(walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(n => { const t = n.nodeValue; if(re.test(t)){ re.lastIndex = 0; n.nodeValue = t.replace(re, (m, a, b) => a + map[b]); } re.lastIndex = 0; });
  }

  // ---------------------------------------------------------------
  // Analytics: paste your IDs here to switch tracking on.
  //   GA_ID         e.g. 'G-XXXXXXXXXX'   (Google Analytics 4)
  //   META_PIXEL_ID e.g. '123456789012345' (Meta / Facebook Pixel)
  // While they are empty, no tracking code loads at all.
  // ---------------------------------------------------------------
  // Where website enquiries are emailed (FormSubmit form-to-email service).
  const ENQUIRY_EMAIL = 'kigalimediaagency@gmail.com';
  // Public address shown to visitors if sending fails.
  const PUBLIC_EMAIL = 'hello@crt.rw';
  const GA_ID = '';
  const META_PIXEL_ID = '';
  // Tracking only loads after the visitor accepts the cookie notice (Rwanda data
  // protection law, Law No. 058/2021). With both IDs empty, no notice is shown.
  const CONSENT_KEY = 'crt_consent';
  const getConsent = ()=>{ try{ return localStorage.getItem(CONSENT_KEY); }catch(e){ return null; } };
  const setConsent = v=>{ try{ localStorage.setItem(CONSENT_KEY, v); }catch(e){} };
  function loadTracking(){
    if(GA_ID){
      const s=document.createElement('script'); s.async=true; s.src='https://www.googletagmanager.com/gtag/js?id='+GA_ID; document.head.appendChild(s);
      window.dataLayer=window.dataLayer||[]; window.gtag=function(){dataLayer.push(arguments);}; gtag('js', new Date()); gtag('config', GA_ID, {anonymize_ip:true});
    }
    if(META_PIXEL_ID){
      !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', META_PIXEL_ID); fbq('track','PageView');
    }
  }
  if(GA_ID || META_PIXEL_ID){
    const choice = getConsent();
    if(choice === 'yes') loadTracking();
    else if(choice !== 'no'){
      const bar = document.createElement('div');
      bar.className = 'consent'; bar.setAttribute('role','region'); bar.setAttribute('aria-label','Cookie notice');
      bar.innerHTML = '<p>We use cookies to see which pages and ads work. <a href="/privacy#analytics">Privacy</a></p>'+
        '<div class="consent-actions"><button type="button" class="btn small ghost" data-c="no">Decline</button><button type="button" class="btn small" data-c="yes">Accept</button></div>';
      bar.addEventListener('click', e=>{
        const b = e.target.closest('[data-c]'); if(!b) return;
        setConsent(b.dataset.c); bar.remove();
        if(b.dataset.c === 'yes') loadTracking();
      });
      document.body.appendChild(bar);
    }
  }
  const trackLead = (label)=>{
    if(typeof window.gtag==='function') gtag('event','generate_lead',{form_location:location.pathname,label:label});
    if(typeof window.fbq==='function') fbq('track','Lead',{content_name:label});
  };

  // Where did this visitor come from? Remember the ad / campaign for the session.
  const SOURCE_KEY = 'crt_source';
  (function(){
    const utm = ['utm_source','utm_medium','utm_campaign'].map(k=>params.get(k)).filter(Boolean);
    let src = utm.length ? utm.join(' / ') : (params.get('fbclid') ? 'facebook / instagram ad' : (params.get('gclid') ? 'google ad' : ''));
    try{
      if(src) sessionStorage.setItem(SOURCE_KEY, src);
      else if(!sessionStorage.getItem(SOURCE_KEY)){
        const ref = document.referrer && new URL(document.referrer).hostname;
        sessionStorage.setItem(SOURCE_KEY, ref && ref !== location.hostname ? ref : 'direct');
      }
    }catch(e){}
  })();
  const getSource = ()=>{ try{ return sessionStorage.getItem(SOURCE_KEY) || 'direct'; }catch(e){ return 'unknown'; } };

  document.querySelectorAll('[data-booking-form]').forEach(form=>{
    const formService = form.dataset.service || params.get('service') || 'Creative project';
    const formOffer = form.dataset.offer || params.get('offer') || '';
    const serviceField = form.querySelector('[name="service"]');
    const offerField = form.querySelector('[name="offer"]');
    if(serviceField) serviceField.value = params.get('service') || formService;
    if(offerField) offerField.value = params.get('offer') || formOffer;
    if(params.get('date')) { const dateField=form.querySelector('[name="date"]'); if(dateField) dateField.value=params.get('date'); }
    // Contact form: tick the matching "What do you need?" chips from ?service=
    const pre = (params.get('service') || '').toLowerCase();
    if(pre) [['photo','Photography'],['video','Video'],['film','Video'],['event','Event coverage'],['brand','Branding & design'],['design','Branding & design'],['social','Social media'],['web','Website'],['wedding','Wedding']]
      .forEach(([k, v]) => { if(pre.includes(k)){ const c = form.querySelector('[name="need"][value="' + v + '"]'); if(c) c.checked = true; } });
    const status = form.querySelector('.form-status');
    const sendBtn = form.querySelector('button[type="submit"]');
    const waBtn = form.querySelector('[data-send-whatsapp]');
    const sendLabel = sendBtn ? sendBtn.textContent : '';
    const collect = ()=>{
      const set = (n,v)=>{ const f=form.querySelector('[name="'+n+'"]'); if(f) f.value=v; };
      set('page', location.pathname);
      set('source', getSource());
      const data = new FormData(form);
      const needs = data.getAll('need');
      return {data, service: needs.length ? needs.join(', ') : (data.get('service') || formService), offer: data.get('offer') || formOffer};
    };
    // A copy of every enquiry goes to the admin dashboard (Supabase), if connected.
    const saveLead = ({data, service, offer}, channel)=>{
      const CFG = window.CRT_CONFIG || {};
      if(!CFG.SUPABASE_URL || !CFG.SUPABASE_ANON_KEY || data.get('bot-field')) return;
      const cut = (v,n)=> (v||'').toString().slice(0,n) || null;
      try{
        fetch(CFG.SUPABASE_URL.replace(/\/$/,'') + '/rest/v1/leads', {
          method:'POST', keepalive:true,
          headers:{'apikey':CFG.SUPABASE_ANON_KEY,'Authorization':'Bearer '+CFG.SUPABASE_ANON_KEY,'Content-Type':'application/json','Prefer':'return=minimal'},
          body: JSON.stringify({
            name: cut(data.get('name'),120) || 'Unknown', contact: cut(data.get('contact'),160) || 'Unknown',
            service: cut(service,120), offer: cut(offer,120), event_date: cut(data.get('date'),120),
            details: cut([data.get('company') ? 'Company: ' + data.get('company') : '', data.get('budget') ? 'Budget: ' + data.get('budget') : '', data.get('details')].filter(Boolean).join('\n'),2000), page: cut(location.pathname,200),
            source: cut(getSource() + ' · via ' + channel, 200)
          })
        }).catch(()=>{});
      }catch(err){}
    };
    const show = (kind, html)=>{ if(!status) return; status.className = 'form-status is-' + kind; status.innerHTML = html; status.hidden = false; };
    const waLink = ({data, service, offer})=>{
      const lines = [
        'Hi CRT Media Agency, I would like to enquire about a project.',
        'Service: ' + service,
        offer ? 'Offer/package: ' + offer : '',
        data.get('name') ? 'Name: ' + data.get('name') : '',
        data.get('company') ? 'Company: ' + data.get('company') : '',
        data.get('budget') ? 'Budget: ' + data.get('budget') : '',
        data.get('contact') ? 'Email or phone: ' + data.get('contact') : '',
        data.get('date') ? 'Preferred date/timeline: ' + data.get('date') : '',
        data.get('details') ? 'Project details: ' + data.get('details') : '',
      ].filter(Boolean);
      return 'https://wa.me/250796356035?text=' + encodeURIComponent(lines.join('\n'));
    };

    // Choice 1 (default): email the enquiry to our inbox.
    form.addEventListener('submit', function(e){
      e.preventDefault();
      const info = collect(), data = info.data;
      if(data.get('bot-field')) return;
      saveLead(info, 'email');
      trackLead(info.offer || info.service);
      const contact = (data.get('contact') || '').toString();
      const payload = {
        _subject: 'New website enquiry: ' + (info.offer || info.service) + ' – ' + (data.get('name') || ''),
        _template: 'table', _captcha: 'false',
        Name: data.get('name') || '', Company: data.get('company') || '—', 'WhatsApp or email': contact, Budget: data.get('budget') || '—',
        Service: info.service, 'Offer / package': info.offer || '—',
        'Date / timeline': data.get('date') || '—', Details: data.get('details') || '—',
        Page: location.href.split('#')[0], Source: getSource()
      };
      if(/@/.test(contact)) payload._replyto = contact;
      if(sendBtn){ sendBtn.disabled = true; sendBtn.textContent = 'Sending…'; }
      if(status) status.hidden = true;
      fetch('https://formsubmit.co/ajax/' + ENQUIRY_EMAIL, {
        method:'POST', headers:{'Content-Type':'application/json','Accept':'application/json'}, body: JSON.stringify(payload)
      }).then(r => r.json().then(j => ({ok: r.ok, j})).catch(() => ({ok: r.ok, j: {}})))
        .then(({ok, j}) => {
          if(!ok || String(j.success) === 'false') throw new Error(j.message || 'not sent');
          const name = (data.get('name') || '').toString().split(' ')[0];
          show('ok', '<strong>Thank you' + (name ? ', ' + name.replace(/[<>&]/g,'') : '') + '!</strong> Your enquiry is in our inbox. We’ll get back to you soon.');
          form.reset();
          const sf = form.querySelector('[name="service"]'), of = form.querySelector('[name="offer"]');
          if(sf) sf.value = info.service; if(of) of.value = info.offer;
        })
        .catch(() => {
          show('error', 'Sorry, we couldn’t send that by email just now. Please <a href="' + waLink(info) + '" target="_blank" rel="noopener">send it on WhatsApp</a> or write to <a href="mailto:' + PUBLIC_EMAIL + '">' + PUBLIC_EMAIL + '</a>.');
        })
        .finally(() => { if(sendBtn){ sendBtn.disabled = false; sendBtn.textContent = sendLabel; } });
    });

    // Choice 2: send the same details on WhatsApp instead.
    if(waBtn) waBtn.addEventListener('click', function(){
      if(!form.reportValidity()) return;
      const info = collect();
      if(info.data.get('bot-field')) return;
      saveLead(info, 'WhatsApp');
      trackLead(info.offer || info.service);
      window.location.href = waLink(info);
    });
  });
  document.querySelectorAll('[data-prefill-service]').forEach(link=>{
    const target = new URL(link.href, window.location.href);
    target.searchParams.set('service', link.dataset.prefillService);
    if(link.dataset.prefillOffer) target.searchParams.set('offer', link.dataset.prefillOffer);
    link.href = target.toString();
  });
  // Bottom action bar on every page: "Ask a question" (WhatsApp) + the page's main action.
  // Replaces the old floating WA circle and phone-only enquiry button.
  (function(){
    if(document.querySelector('[data-builder]')){ const w = document.querySelector('.whatsapp-float'); if(w) w.hidden = true; return; } // the builder has its own summary bar with the booking action
    const oldMain = document.querySelector('.mobile-booking a');
    const oldWa = document.querySelector('.whatsapp-float');
    const hasForm = !!document.getElementById('inquiry');
    const bar = document.createElement('div');
    bar.className = 'action-bar' + (document.querySelector('.hero-paths') ? ' is-hidden' : '');
    const ask = document.createElement('a');
    ask.className = 'action-ask';
    ask.href = oldWa ? oldWa.href : 'https://wa.me/250796356035';
    ask.target = '_blank'; ask.rel = 'noopener';
    ask.dataset.track = 'bar_whatsapp';
    ask.innerHTML = '<span class="action-dot"></span><span class="lbl-long">Ask a question</span><span class="lbl-short">Ask</span>';
    const main = document.createElement('a');
    main.className = 'btn action-main';
    main.href = hasForm ? '#inquiry' : u('/contact#inquiry');
    main.dataset.track = 'bar_main';
    main.textContent = oldMain ? oldMain.textContent.trim() : 'Get a quote';
    // "Book a call" (filled with BOOKING_URL below; stays hidden if there is no link)
    const CAL_ICON = '<svg class="cal-ico" viewBox="0 0 20 20" aria-hidden="true"><rect x="3" y="4.5" width="14" height="12.5" rx="2.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M3 8.5h14M7 2.8v3.4M13 2.8v3.4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>';
    const call = document.createElement('a');
    call.className = 'action-call';
    call.href = u('/contact'); call.hidden = true;
    call.setAttribute('data-booking-link','');
    call.dataset.track = 'bar_book_call';
    call.innerHTML = CAL_ICON + '<span class="lbl-long">Book a free call</span><span class="lbl-short">Call</span>';
    bar.append(ask, call, main);
    document.body.appendChild(bar);
    // Header: "Book a call" beside "Get a quote"
    const navCta = document.querySelector('.nav-links .nav-cta');
    if(navCta){
      const actions = document.createElement('div');
      actions.className = 'nav-actions';
      const navCall = document.createElement('a');
      navCall.className = 'nav-call';
      navCall.href = u('/contact'); navCall.hidden = true;
      navCall.setAttribute('data-booking-link','');
      navCall.dataset.track = 'nav_book_call';
      navCall.innerHTML = CAL_ICON + '<span>Book a call</span>';
      navCta.parentNode.insertBefore(actions, navCta);
      actions.append(navCall, navCta);
    }
    document.querySelectorAll('.mobile-booking,.whatsapp-float').forEach(el=>el.remove());
    document.body.classList.add('has-action-bar');
    // Get out of the way when the form, the footer or the home hero tiles are on screen.
    const targets = [document.getElementById('inquiry'), document.querySelector('footer'), document.querySelector('.hero-paths')].filter(Boolean);
    if('IntersectionObserver' in window && targets.length){
      const seen = new Set();
      const io = new IntersectionObserver(entries=>{
        entries.forEach(e=>e.isIntersecting ? seen.add(e.target) : seen.delete(e.target));
        bar.classList.toggle('is-hidden', seen.size > 0);
      }, {threshold: 0.15});
      targets.forEach(t=>io.observe(t));
    }
  })();

  // ---------------------------------------------------------------
  // "Book a call": paste your Cal.com / Calendly / Google Calendar
  // booking-page link here. While it is empty, every "Book a call"
  // button stays hidden, so nothing broken ever shows.
  // ---------------------------------------------------------------
  const BOOKING_URL = 'https://cal.com/crt-media-agency-djafrq/20-minutes-meeting-with-crt';
  document.querySelectorAll('[data-booking-link]').forEach(el=>{
    if(!BOOKING_URL) return;
    el.href = BOOKING_URL;
    el.target = '_blank'; el.rel = 'noopener';
    (el.closest('[data-booking]') || el).hidden = false;
  });

  // ---------------------------------------------------------------
  // Menu panels (desktop): every menu item opens a panel with photos
  // and quick links; the page is blurred behind it.
  // Footer call-to-action band (all pages)
  (function(){
    const f = document.querySelector('footer.footer');
    // Offer landing pages (ad traffic) stay focused on their own form: no extra call-to-action band
    if(!f || f.querySelector('.footer-cta') || document.body.classList.contains('lp')) return;
    const d = document.createElement('div');
    d.className = 'footer-cta';
    d.innerHTML = '<div><span class="kicker">Have a project in mind?</span>'+
      '<p class="footer-cta-title">Your next launch, event<br>or brand. Let’s make it.</p>'+
      '<a class="footer-cta-mail" href="mailto:hello@crt.rw" data-track="footer_cta_email">hello@crt.rw</a></div>'+
      '<div class="footer-cta-actions"><a class="btn" href="'+u('/contact')+'" data-track="footer_cta_quote">Get a quote →</a>'+
      '<a class="btn ghost" href="https://wa.me/250796356035?text=Hi%20CRT%20Media%20Agency%2C%20I%27d%20like%20to%20start%20a%20project." target="_blank" rel="noopener" data-track="footer_cta_whatsapp">Chat on WhatsApp ↗</a></div>';
    // A page-specific banner just above the footer becomes the footer CTA's lead-in
    const main = document.querySelector('main'), last = main && main.lastElementChild;
    if(last && last.classList.contains('cta-banner')){
      const h = last.querySelector('h2'), p = last.querySelector('p'), b = last.querySelector('.btn');
      if(h) d.querySelector('.kicker').textContent = h.textContent;
      if(p){ const n = document.createElement('p'); n.className = 'footer-cta-note'; n.textContent = p.textContent; d.firstElementChild.appendChild(n); }
      if(b){ const q = d.querySelector('.footer-cta-actions .btn'); q.href = b.href; q.textContent = b.textContent; }
      last.remove();
    }
    f.prepend(d);
  })();

  // Footer: Kigali local time (helps clients abroad plan a call)
  (function(){
    const el = document.querySelector('[data-kigali-time]'); if(!el || !window.Intl) return;
    let fmt; try{ fmt = new Intl.DateTimeFormat('en-GB', {hour:'2-digit', minute:'2-digit', timeZone:'Africa/Kigali'}); }catch(e){ return; }
    const tick = () => { el.textContent = 'Kigali time ' + fmt.format(new Date()); };
    tick(); el.hidden = false; setInterval(tick, 30000);
  })();

  // To change a panel, edit MENU below. Each item:
  //   [name, link, image, small line under the name, [[label, link], ...]]
  // ---------------------------------------------------------------
  const S = '/assets/md/';
  const MENU = {
    '/work': { cols: 4, items: [
      ['Photography','/work#photography','/assets/work/cases/inka-steak-house/cover-800.webp','Food, products, hotels, events',[['See photography','/work#photography'],['Content session','/offer-commercial-content-session']]],
      ['Film','/work#film','/assets/work/cases/six-figure-club/01-800.webp','Highlight films and reels',[['See film','/work#film'],['Event packages','/events#packages']]],
      ['Branding','/work#branding','/assets/work/cases/kings-memo/cover-800.webp','Logos and event identities',[['See branding','/work#branding'],['Brand kit','/offer-brand-starter-kit']]],
      ['Graphic design','/work#graphic-design','/assets/work/zora-lounge-poster-800.webp','Posters, banners, social posts',[['See design','/work#graphic-design'],['Social content','/social-media-content']]]
    ], side: [['All work','/work'],['Corporate events','/work#for-corporate-events'],['Wedding stories','/work#for-weddings'],['Get a quote','/contact']] },
    '/weddings': { cols: 4, items: [
      ['Basic','/weddings#packages','/assets/work/wedding-sandra-mathias-800.webp','1,200,000 RWF',[['Check my date','/contact?service=Wedding%20photography%20%26%20film&offer=Basic#inquiry']]],
      ['Standard','/weddings#packages','/assets/work/reception-sandra-mathias-800.webp','2,000,000 RWF',[['Check my date','/contact?service=Wedding%20photography%20%26%20film&offer=Standard#inquiry']]],
      ['Premium','/weddings#packages','/assets/work/wedding-party-mirindi-ange-800.webp','3,000,000 RWF',[['Check my date','/contact?service=Wedding%20photography%20%26%20film&offer=Premium#inquiry']]],
      ['VIP','/weddings#packages','/assets/work/cases/wedding-mirindi-ange/06-800.webp','4,500,000 RWF',[['Check my date','/contact?service=Wedding%20photography%20%26%20film&offer=VIP#inquiry']]],
    ], side: [['Weddings overview','/weddings'],['Packages and prices','/weddings#packages'],['Single days and extras','/weddings#days'],['Book early, save 10%','/offer-wedding-early-booking']] },
    '/events': { cols: 2, items: [
      ['Event coverage','/events','/assets/icons/cover-svc-events.svg','3 packages, from 200,000 RWF',[['Packages','/events#packages'],['Check my date','/events#inquiry']]],
      ['Event + social bundle','/offer-event-social-bundle','/assets/icons/cover-event-bundle.svg','Content ready in 72 hours',[['See offer','/offer-event-social-bundle']]],
    ], side: [['Events overview','/events'],['Check my date','/events#inquiry'],['Event case studies','/work#events'],['Book a call','#call']] },
    '/business': { cols: 3, items: [
      ['Commercial photo & video','/commercial-photography-video','/assets/icons/cover-svc-commercial.svg','From 400,000 RWF',[['Learn','/commercial-photography-video'],['Book','/commercial-photography-video#inquiry']]],
      ['Branding & design','/branding-graphic-design','/assets/icons/cover-svc-branding.svg','From 250,000 RWF',[['Learn','/branding-graphic-design'],['Book','/branding-graphic-design#inquiry']]],
      ['Social media & content','/social-media-content','/assets/icons/cover-svc-social.svg','From 500,000 RWF / month',[['Learn','/social-media-content'],['Book','/social-media-content#inquiry']]],
      ['Web & digital','/web-digital','/assets/icons/cover-svc-web.svg','From 600,000 RWF',[['Learn','/web-digital'],['Book','/web-digital#inquiry']]],
      ['Business offers','/business#offers','/assets/icons/cover-business-offers.svg','Fixed starting prices',[['See offers','/business#offers']]],
    ], side: [['Business overview','/business'],['Get a quote','/business#inquiry'],['Book a call','#call']] },
    '/deals': { cols: 4, items: [
      ['Launch bundle','/offer-launch-bundle','/assets/icons/cover-launch-bundle.svg','Bundle 1,200,000 RWF',[['See offer','/offer-launch-bundle']]],
      ['Brand starter kit','/offer-brand-starter-kit','/assets/icons/cover-brand-kit.svg','Kit from 250,000 RWF',[['See offer','/offer-brand-starter-kit']]],
      ['Event + social bundle','/offer-event-social-bundle','/assets/icons/cover-event-bundle.svg','Bundle from 200,000 RWF',[['See offer','/offer-event-social-bundle']]],
      ['Book early, save 10%','/offer-wedding-early-booking','/assets/work/cases/wedding-mirindi-ange/06-800.webp','Weddings from 1,080,000 RWF',[['See offer','/offer-wedding-early-booking']]],
    ], side: [['All deals','/deals'],['Business deals','/deals#business'],['Event deals','/deals#events'],['Wedding deals','/deals#weddings']] },
    '/about': { cols: 3, items: [
      ['About CRT','/about','','Founded in Kigali in 2025',[['Our story','/about']]],
      ['Alain Cedrick','/about','','CEO & Creative Director',[['Meet the team','/about']]],
      ['Thierry “Ziggy” Nteziryayo','/about','','Director of Photography',[['Meet the team','/about']]],
    ], side: [['Contact','/contact'],['Book a call','#call'],['hello@crt.rw','mailto:hello@crt.rw'],['+250 796 356 035','tel:+250796356035']] },
  };
  (function(){
    const header = document.querySelector('.site-header');
    if(!header) return;
    // Hover panels only where there is a real pointer and room for them; checked live, so resizing works too.
    const wide = window.matchMedia('(hover: hover) and (pointer: fine) and (min-width: 761px)');
    const esc = s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;');
    const fix = h=> h==='#call' ? (BOOKING_URL || u('/contact')) : u(h);
    const ext = h=> h==='#call' && BOOKING_URL ? ' target="_blank" rel="noopener"' : '';
    const panel = document.createElement('div');
    panel.className = 'menu-panel';
    panel.innerHTML = '<div class="menu-bridge" aria-hidden="true"></div><div class="menu-stage"></div>';
    const stage = panel.querySelector('.menu-stage');
    const scrim = document.createElement('div');
    scrim.className = 'menu-scrim';
    document.body.append(scrim, panel);
    // Every panel is built once, up front, and kept in the page: switching between menus is an instant
    // crossfade instead of a rebuild (no photo re-decoding, no layout jump).
    const panes = {};
    const build = (key, cfg)=>{
      const pane = document.createElement('div');
      pane.className = 'menu-pane'; pane.dataset.key = key; pane.setAttribute('aria-hidden','true');
      pane.innerHTML = `<div class="menu-panel-grid cols-${cfg.cols}">` + cfg.items.slice(0, cfg.cols * 2).map(([n,h,img,meta,links])=>
        `<div class="menu-item">`+
        (img ? `<a class="menu-thumb" href="${fix(h)}" tabindex="-1" aria-hidden="true"><img src="${u(img)}" alt="" decoding="async" loading="eager"></a>` : '')+
        `<div class="menu-text"><a class="menu-name" href="${fix(h)}">${esc(n)}</a>`+
        (meta ? `<span class="menu-meta">${esc(meta)}</span>` : '')+
        `<span class="menu-links">${links.map(([l,u])=>`<a href="${fix(u)}"${ext(u)}>${esc(l)}</a>`).join('')}</span></div></div>`).join('') +
        `</div><div class="menu-panel-side">${cfg.side.map(([l,u])=>`<a href="${fix(u)}"${ext(u)}>${esc(l)}</a>`).join('')}</div>`;
      pane.querySelectorAll('a').forEach(a=>a.tabIndex = -1);
      stage.appendChild(pane); panes[key] = pane;
    };
    let built = false;
    const buildAll = ()=>{ if(built) return; built = true;
      Object.keys(MENU).forEach(k=>build(k, MENU[k]));
      if(window.__CRT_PRICE_MAP) crtReplaceNumbers(stage, window.__CRT_PRICE_MAP); };
    // Build as soon as the browser is idle, or at the latest when the pointer reaches the menu
    (window.requestIdleCallback || (f=>setTimeout(f, 600)))(()=>{ if(wide.matches) buildAll(); });
    header.addEventListener('pointerenter', ()=>{ if(wide.matches) buildAll(); });

    let openT, closeT, current = null, shownKey = null;
    const isOpen = ()=>document.body.classList.contains('menu-open');
    const place = ()=>{ panel.style.top = header.getBoundingClientRect().bottom + 'px'; };
    const show = (link)=>{
      const key = pageKey(link.href), pane = panes[key];
      if(!pane) return;
      place();
      if(shownKey !== key){
        const prev = shownKey && panes[shownKey];
        // animate the panel height between menus of different size
        const from = stage.offsetHeight;
        if(prev){ prev.classList.remove('is-active'); prev.setAttribute('aria-hidden','true'); prev.querySelectorAll('a').forEach(a=>a.tabIndex = -1); }
        pane.classList.add('is-active'); pane.setAttribute('aria-hidden','false'); pane.querySelectorAll('a').forEach(a=>a.tabIndex = 0);
        const to = pane.offsetHeight;
        if(isOpen() && from && from !== to){
          stage.style.height = from + 'px'; stage.offsetHeight; stage.style.height = to + 'px';
          clearTimeout(stage._t); stage._t = setTimeout(()=>{ stage.style.height = ''; }, 260);
        }
        shownKey = key;
      }
      if(current !== link){ if(current) current.classList.remove('is-open'); current = link; link.classList.add('is-open'); }
      document.body.classList.add('menu-open');
    };
    // Hover intent: when nothing is open, wait a beat so sweeping across the bar doesn't flash panels;
    // once a panel is open, moving to another menu item switches instantly.
    const open = (link, now)=>{
      if(!wide.matches) return;
      buildAll(); clearTimeout(closeT); clearTimeout(openT);
      if(now || isOpen()) show(link); else openT = setTimeout(()=>show(link), 90);
    };
    const hide = ()=>{
      document.body.classList.remove('menu-open');
      if(current){ current.classList.remove('is-open'); current = null; }
    };
    const close = (delay)=>{ clearTimeout(openT); clearTimeout(closeT); closeT = setTimeout(hide, delay == null ? 220 : delay); };
    const keep = ()=>{ clearTimeout(closeT); };
    document.querySelectorAll('.nav-links a').forEach(link=>{
      if(MENU[pageKey(link.href)]){
        link.setAttribute('aria-haspopup','true');
        link.addEventListener('pointerenter', ()=>open(link));
        link.addEventListener('focus', ()=>open(link, true));
        link.addEventListener('pointerleave', ()=>close());
      } else {
        link.addEventListener('pointerenter', ()=>close(60));
      }
    });
    // The bridge fills the gap between the bar and the panel, so crossing it never counts as leaving
    panel.addEventListener('pointerenter', keep);
    panel.addEventListener('pointerleave', ()=>close());
    panel.addEventListener('focusout', e=>{ if(!panel.contains(e.relatedTarget) && !(e.relatedTarget && e.relatedTarget.closest('.nav-links'))) close(0); });
    scrim.addEventListener('pointerenter', ()=>close(120));
    scrim.addEventListener('click', ()=>close(0));
    document.addEventListener('keydown', e=>{ if(e.key==='Escape' && isOpen()){ close(0); if(current) current.focus(); } });
    wide.addEventListener && wide.addEventListener('change', ()=>{ if(!wide.matches) hide(); });
    // Keyboard: close the panel once focus leaves both the menu and the panel.
    header.addEventListener('focusout', e=>{ const to = e.relatedTarget; if(!to || (!header.contains(to) && !panel.contains(to))) close(); });
    window.addEventListener('scroll', ()=>{ if(document.body.classList.contains('menu-open')) place(); }, {passive:true});
  })();

  // ---------------------------------------------------------------
  // Live prices + wedding package contents, edited in /admin.
  // The pages keep today's prices as a fallback; when the dashboard
  // has different values, every matching price on the page is swapped.
  // ---------------------------------------------------------------
  (function(){
    const CFG = window.CRT_CONFIG || {};
    if(!CFG.SUPABASE_URL || !CFG.SUPABASE_ANON_KEY) return;
    // Prices exactly as written in the pages today. Don't edit these here; edit them in /admin.
    const BASE = {basic:1200000, standard:2000000, premium:3000000, vip:4500000};
    const fmt = n => Number(n).toLocaleString('en-US');
    const url = CFG.SUPABASE_URL.replace(/\/$/,'') + '/rest/v1/site_content?select=key,value';
    fetch(url, {headers:{'apikey':CFG.SUPABASE_ANON_KEY,'Authorization':'Bearer '+CFG.SUPABASE_ANON_KEY}})
      .then(r => r.ok ? r.json() : [])
      .then(rows => {
        const c = {}; (rows||[]).forEach(r => { c[r.key] = r.value; });
        c.prices = c.prices_v2; c.packages = c.wedding_packages;
        if(c.prices){
          const map = {};
          for(const k in BASE){
            const v = Number(c.prices[k]);
            if(v > 0 && v !== BASE[k]) map[fmt(BASE[k])] = fmt(v);
          }
          ['basic','standard','premium','vip'].forEach(k => {          // early booking = 10% off
            const v = Number(c.prices[k]);
            if(v > 0 && v !== BASE[k]) map[fmt(Math.round(BASE[k]*0.9))] = fmt(Math.round(v*0.9/1000)*1000);
          });
          if(Object.keys(map).length){ window.__CRT_PRICE_MAP = map; crtReplaceNumbers(document.body, map); }
        }
        if(Array.isArray(c.testimonials) && c.testimonials.length){
          const sec = document.querySelector('[data-testimonials]'), list = sec && sec.querySelector('[data-testimonials-list]');
          if(list){
            list.innerHTML = '';
            c.testimonials.slice(0, 6).forEach(t => {
              if(!t || !t.quote || !t.name) return;
              const fig = document.createElement('figure'); fig.className = 't-card';
              const q = document.createElement('blockquote'); q.textContent = '“' + t.quote + '”';
              const cap = document.createElement('figcaption'); const b = document.createElement('strong'); b.textContent = t.name; cap.appendChild(b);
              if(t.role){ const r = document.createElement('span'); r.textContent = t.role; cap.appendChild(r); }
              fig.append(q, cap); list.appendChild(fig);
            });
            sec.hidden = !list.children.length;
          }
        }
        if(c.packages){
          document.querySelectorAll('ul.package-list[data-package]').forEach(ul => {
            const items = c.packages[ul.dataset.package];
            if(!Array.isArray(items) || !items.length) return;
            const short = !!ul.querySelector('li.more');
            const shown = short ? items.slice(0,3) : items;
            ul.innerHTML = '';
            shown.forEach(t => { const li = document.createElement('li'); li.textContent = t; ul.appendChild(li); });
            if(short && items.length > 3){ const li = document.createElement('li'); li.className = 'more'; li.textContent = 'and ' + (items.length - 3) + ' more'; ul.appendChild(li); }
          });
        }
      }).catch(()=>{});
  })();

  // ---------------------------------------------------------------
  // Case study media (film + photos), uploaded in /admin → Case studies.
  // Visitors only see sections that have content. Add ?preview=1 to the
  // page address to see the empty slots as placeholders.
  // ---------------------------------------------------------------
  (function(){
    const page = document.querySelector('[data-case]');
    if(!page) return;
    const slug = page.dataset.case;
    const preview = params.has('preview');
    const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const safeUrl = u => { try{ const x = new URL(u, location.href); return (x.protocol === 'https:' || x.origin === location.origin) ? x.href : ''; }catch(e){ return ''; } };
    function filmHTML(v){
      const url = safeUrl(v.url); if(!url) return '';
      const yt = url.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)([\w-]{11})/);
      if(yt) return `<iframe src="https://www.youtube-nocookie.com/embed/${yt[1]}?rel=0" title="Highlight film" loading="lazy" allow="accelerometer; autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>`;
      const ig = url.match(/instagram\.com\/(?:[\w.]+\/)?(?:reel|reels|p|tv)\/([\w-]+)/);
      if(ig) return `<iframe class="film-ig" src="https://www.instagram.com/reel/${ig[1]}/embed/" title="Highlight film" loading="lazy" scrolling="no" allowtransparency="true" allow="autoplay; encrypted-media; picture-in-picture"></iframe>`;
      const gd = url.match(/drive\.google\.com\/(?:file\/d\/|open\?id=|uc\?(?:export=\w+&)?id=)([\w-]{20,})/);
      if(gd) return `<iframe src="https://drive.google.com/file/d/${gd[1]}/preview" title="Highlight film" loading="lazy" allow="autoplay; fullscreen" allowfullscreen></iframe>`;
      const vm = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
      if(vm) return `<iframe src="https://player.vimeo.com/video/${vm[1]}" title="Highlight film" loading="lazy" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>`;
      if(v.type === 'file' || /\.(mp4|webm|mov)(\?|$)/i.test(url)) return `<video src="${esc(url)}" controls preload="metadata" playsinline></video>`;
      return `<a class="btn" href="${esc(url)}" target="_blank" rel="noopener">Watch the highlight film ↗</a>`;
    }
    function render(entry){
      entry = entry || {};
      const filmSec = document.querySelector('[data-case-film]'), filmSlot = filmSec && filmSec.querySelector('[data-film-slot]');
      if(filmSlot){
        const html = entry.video && entry.video.url ? filmHTML(entry.video) : '';
        if(html){ filmSlot.innerHTML = html; filmSec.hidden = false; filmSlot.classList.toggle('is-vertical', /film-ig|\/shorts\//.test(html + (entry.video.url || ''))); }
        else if(preview){ filmSlot.innerHTML = '<div class="ph-box film-ph"><span>Highlight film placeholder</span><small>Add a YouTube, Instagram, Google Drive or Vimeo link, or upload the video, in /admin → Case studies</small></div>'; filmSec.hidden = false; }
      }
      // Client review (edited in /admin -> Case studies -> Client review). Only rendered when there is a quote, so no empty space otherwise.
      const rv = entry.review && entry.review.quote ? entry.review : (preview ? {quote:'Client review placeholder. Add the quote in /admin → Case studies → Client review.', name:'Client name', role:'Role, company'} : null);
      if(rv){
        const sec = document.createElement('section');
        sec.className = 'cs2-review'; sec.setAttribute('data-case-review', '');
        sec.innerHTML = `<div class="cs2-wrap"><figure class="cs2-review-in"><span class="cs2-label">What the client said</span><blockquote><p>${esc(rv.quote)}</p></blockquote>`
          + `<figcaption><strong>${esc(rv.name || '')}</strong>${rv.role ? `<span>${esc(rv.role)}</span>` : ''}</figcaption></figure></div>`;
        const after = document.querySelector('.cs2-why');
        const before = document.querySelector('.cs2-next');
        if(after) after.after(sec); else if(before) before.before(sec); else (document.querySelector('main') || document.body).appendChild(sec);
      }
      // Credits: who worked on the project (edited in /admin -> Case studies -> Credits)
      const credits = (entry.credits || []).filter(c => c && c.name && c.role);
      if(credits.length || preview){
        const sec = document.createElement('section');
        sec.className = 'cs2-credits'; sec.setAttribute('data-case-credits', '');
        const rows = credits.length ? credits.map(c => `<div><dt>${esc(c.role)}</dt><dd>${esc(c.name)}</dd></div>`).join('')
          : '<div><dt>Role</dt><dd>Credits placeholder · add names in /admin → Case studies → Credits</dd></div>';
        sec.innerHTML = `<div class="cs2-wrap"><div class="cs2-credits-in"><span class="cs2-label">Credits</span><dl class="cs2-credit-list">${rows}</dl></div></div>`;
        const next = document.querySelector('.cs2-next') || document.querySelector('main > section:last-of-type');
        if(next) next.before(sec); else (document.querySelector('main') || document.body).appendChild(sec);
      }
      // Photos uploaded in /admin -> Case studies -> Photos: added to the case study's own gallery (same grid, same lightbox).
      const photos = (entry.photos || []).filter(p => p && safeUrl(p.url));
      if(photos.length || preview){
        let gal = document.querySelector('[data-gallery-slot]') || document.querySelector('.cs2-story .cs-gallery');
        if(!gal){
          const sec = document.createElement('section');
          sec.className = 'cs2-story'; sec.setAttribute('data-case-gallery', '');
          sec.innerHTML = '<div class="cs2-wrap"><div class="cs2-sec-head"><span class="cs2-label">The work</span><h2>More from the project.</h2><p>Tap any photo to see it full screen.</p></div><div class="cs-gallery cs2-grid" data-gallery-slot></div></div>';
          const at = document.querySelector('.cs2-why') || document.querySelector('[data-case-review]') || document.querySelector('[data-case-credits]') || document.querySelector('.cs2-next');
          if(at) at.before(sec); else (document.querySelector('main') || document.body).appendChild(sec);
          gal = sec.querySelector('[data-gallery-slot]');
        }
        let html = photos.map(p => `<figure class="cs-tile cs2-t cs-up" tabindex="0" role="button" data-lb="1" aria-label="Open photo${p.caption ? ': ' + esc(p.caption) : ''}"><img src="${esc(safeUrl(p.url))}" alt="${esc(p.caption || '')}"${p.w && p.h ? ` width="${Number(p.w)}" height="${Number(p.h)}"` : ''} loading="lazy" decoding="async">${p.caption ? `<figcaption>${esc(p.caption)}</figcaption>` : ''}</figure>`).join('');
        if(preview && !photos.length) html = '<figure class="cs-tile cs2-t ph-tile"><div class="ph-box"><span>Your uploaded photos appear here</span><small>/admin → Case studies → Photos</small></div></figure>';
        gal.insertAdjacentHTML('beforeend', html);
        const sec = gal.closest('section'); if(sec) sec.hidden = false;
      }
    }
    const CFG = window.CRT_CONFIG || {};
    if(!CFG.SUPABASE_URL || !CFG.SUPABASE_ANON_KEY){ render(null); return; }
    fetch(CFG.SUPABASE_URL.replace(/\/$/,'') + '/rest/v1/site_content?select=value&key=eq.case_studies',
          {headers:{'apikey':CFG.SUPABASE_ANON_KEY,'Authorization':'Bearer '+CFG.SUPABASE_ANON_KEY}})
      .then(r => r.ok ? r.json() : [])
      .then(rows => render(rows && rows[0] && rows[0].value ? rows[0].value[slug] : null))
      .catch(() => render(null));
  })();

  // Click tracking (only active once GA_ID / META_PIXEL_ID are set above).
  document.querySelectorAll('[data-track]').forEach(el=>el.addEventListener('click',()=>{
    const eventName = el.dataset.track;
    if(typeof window.gtag === 'function') window.gtag('event', eventName);
    if(typeof window.fbq === 'function'){
      if(/book_call/.test(eventName)) fbq('track','Schedule');
      else if(/whatsapp/.test(eventName)) fbq('track','Contact');
    }
  }));
})();

// Footer: keep the copyright year current
document.querySelectorAll('[data-year]').forEach(el=>{ el.textContent = new Date().getFullYear(); });

// ---------------------------------------------------------------
// Photo framing: every photo cropped with object-fit:cover gets a
// focal point, so faces and subjects stay in frame at any shape.
// Add an entry here (file name without -800 / .webp) to fine-tune.
// ---------------------------------------------------------------
(function(){
  const FOCUS = {
    'workshop':'25% 35%',
    'wedding-mirindi-ange/cover':'50% 24%', 'wedding-mirindi-ange/06':'50% 26%', 'wedding-sandra-mathias/01':'50% 40%', 'eloge-alice/cover':'50% 38%', 'wedding-sandra-mathias/cover':'50% 34%',
    'zora-lounge/cover':'50% 45%', 'kings-memo/cover':'50% 50%', 'intore-dancers':'50% 40%', 'church-celebration':'50% 48%',
    'church-ceremony':'45% 38%', 'table-styling':'50% 55%', 'floral-centerpiece':'50% 55%',
    'decor-lounge':'50% 62%', 'decor-reception-lounge':'50% 62%', 'zora-lounge-poster':'50% 38%',
    'kings-memo-logo':'50% 50%', 'crt-website':'50% 45%', 'proposal-eloge-alice':'50% 40%',
    'wedding-sandra-mathias':'50% 32%', 'reception-sandra-mathias':'50% 48%',
    'wedding-party-mirindi-ange':'50% 72%',
    'alain-cedrick':'50% 22%', 'thierry-ziggy-nteziryayo':'50% 22%'
  };
  const key = src => { try{ return decodeURIComponent(new URL(src, location.href).pathname.split('/').pop()).replace(/(-800)?\.(webp|jpe?g|png)$/i,''); }catch(e){ return ''; } };
  const caseKey = src => { const m = String(src).match(/cases\/([^/]+)\/([^/.]+?)(-800)?\.webp/); return m ? m[1] + '/' + m[2] : ''; };
  function frame(img){
    if(img.dataset.framed || img.style.objectPosition) return;
    if(getComputedStyle(img).objectFit !== 'cover') return;
    const src = img.currentSrc || img.src, k = key(src), ck = caseKey(src);
    let pos = FOCUS[ck] || FOCUS[k] || (/^cover-/.test(k) ? '50% 50%' : '');
    if(!pos){
      const w = img.naturalWidth, h = img.naturalHeight;
      if(!w || !h) return;                       // try again once it has loaded
      pos = h > w * 1.05 ? '50% 30%' : '50% 42%'; // portraits: keep heads in; landscapes: slightly above centre
    }
    img.style.objectPosition = pos; img.dataset.framed = '1';
  }
  function scan(root){ (root || document).querySelectorAll('img').forEach(img=>{ frame(img); if(!img.dataset.framed && !img.complete) img.addEventListener('load', ()=>frame(img), {once:true}); }); }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ()=>scan()); else scan();
  window.addEventListener('load', ()=>scan());
  new MutationObserver(ms=>ms.forEach(m=>m.addedNodes.forEach(n=>{ if(n.nodeType===1){ if(n.tagName==='IMG') frame(n); else scan(n); } }))).observe(document.documentElement, {childList:true, subtree:true});
})();

// ---------------------------------------------------------------
// Portfolio pop-up: click any photo in a case-study gallery to see it
// large, then browse left/right (arrows, keyboard ← →, or swipe).
// ---------------------------------------------------------------
(function(){
  const SEL = '.cs-gallery .cs-tile:not(.ph-tile) img';
  let box, imgEl, countEl, capEl, list = [], idx = 0, lastFocus = null;
  const big = img => {
    const ss = img.getAttribute('srcset');
    if(ss){ const best = ss.split(',').map(s=>s.trim().split(/\s+/)).sort((a,b)=>parseInt(b[1])-parseInt(a[1]))[0]; if(best) return new URL(best[0], location.href).href; }
    return (img.currentSrc || img.src).replace(/-800(\.\w+)$/, '$1');
  };
  function build(){
    box = document.createElement('div');
    box.className = 'lightbox'; box.hidden = true;
    box.setAttribute('role','dialog'); box.setAttribute('aria-modal','true'); box.setAttribute('aria-label','Photo viewer');
    box.innerHTML = '<button class="lb-close" type="button" aria-label="Close">×</button>'+
      '<button class="lb-nav lb-prev" type="button" aria-label="Previous photo">‹</button>'+
      '<figure class="lb-stage"><img alt=""><figcaption class="lb-cap"></figcaption></figure>'+
      '<button class="lb-nav lb-next" type="button" aria-label="Next photo">›</button>'+
      '<div class="lb-count" aria-live="polite"></div>';
    document.body.appendChild(box);
    imgEl = box.querySelector('.lb-stage img'); countEl = box.querySelector('.lb-count'); capEl = box.querySelector('.lb-cap');
    box.querySelector('.lb-close').addEventListener('click', close);
    box.querySelector('.lb-prev').addEventListener('click', e=>{ e.stopPropagation(); go(-1); });
    box.querySelector('.lb-next').addEventListener('click', e=>{ e.stopPropagation(); go(1); });
    box.addEventListener('click', e=>{ if(e.target === box || e.target.classList.contains('lb-stage')) close(); });
    // swipe
    let x0 = null, y0 = null;
    box.addEventListener('touchstart', e=>{ x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; }, {passive:true});
    box.addEventListener('touchend', e=>{
      if(x0 === null) return;
      const dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0; x0 = null;
      if(Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy)) go(dx < 0 ? 1 : -1);
      else if(dy > 90 && Math.abs(dy) > Math.abs(dx)) close();
    });
    document.addEventListener('keydown', e=>{
      if(box.hidden) return;
      if(e.key === 'Escape') close();
      else if(e.key === 'ArrowRight') go(1);
      else if(e.key === 'ArrowLeft') go(-1);
      else if(e.key === 'Tab'){ // keep focus inside the viewer
        const f = [...box.querySelectorAll('button')]; const i = f.indexOf(document.activeElement);
        e.preventDefault(); f[(i + (e.shiftKey ? -1 : 1) + f.length) % f.length].focus();
      }
    });
  }
  function show(){
    const img = list[idx];
    box.classList.add('is-loading');
    imgEl.onload = ()=>box.classList.remove('is-loading');
    imgEl.src = big(img); imgEl.alt = img.alt || '';
    capEl.textContent = img.alt || ''; capEl.hidden = !img.alt;
    countEl.textContent = (idx + 1) + ' / ' + list.length;
    const multi = list.length > 1;
    box.querySelectorAll('.lb-nav').forEach(b=>b.hidden = !multi);
    [idx + 1, idx - 1].forEach(j=>{ const n = list[(j + list.length) % list.length]; if(n){ const p = new Image(); p.src = big(n); } });
  }
  function go(d){ if(list.length < 2) return; idx = (idx + d + list.length) % list.length; show(); }
  function open(img){
    if(!box) build();
    const gal = img.closest('.cs-gallery');
    list = [...gal.querySelectorAll('.cs-tile:not(.ph-tile) img')];
    idx = Math.max(0, list.indexOf(img));
    lastFocus = document.activeElement;
    box.hidden = false; document.documentElement.classList.add('lb-open');
    requestAnimationFrame(()=>box.classList.add('is-open'));
    show(); box.querySelector('.lb-close').focus();
  }
  function close(){
    box.classList.remove('is-open'); document.documentElement.classList.remove('lb-open');
    setTimeout(()=>{ box.hidden = true; imgEl.removeAttribute('src'); }, 200);
    if(lastFocus && lastFocus.focus) lastFocus.focus();
  }
  // Make gallery photos clickable and keyboard-reachable (also ones added later from the dashboard)
  function prep(root){ (root || document).querySelectorAll('.cs-gallery .cs-tile:not(.ph-tile)').forEach(t=>{ if(t.dataset.lb) return; t.dataset.lb = '1'; t.tabIndex = 0; t.setAttribute('role','button'); t.setAttribute('aria-label','Open photo' + (t.querySelector('img') && t.querySelector('img').alt ? ': ' + t.querySelector('img').alt : '')); }); }
  prep();
  new MutationObserver(()=>prep()).observe(document.body, {childList:true, subtree:true});
  document.addEventListener('click', e=>{ const t = e.target.closest('.cs-gallery .cs-tile:not(.ph-tile)'); if(t && t.querySelector('img')){ e.preventDefault(); open(t.querySelector('img')); } });
  document.addEventListener('keydown', e=>{ if((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('.cs-gallery .cs-tile[data-lb]')){ e.preventDefault(); open(e.target.querySelector('img')); } });
})();

// ---------------------------------------------------------------
// Offers page: filter tabs (All / Business / Events / Weddings).
// Links such as /deals#weddings open with that tab selected.
// ---------------------------------------------------------------
(function(){
  const root = document.querySelector('[data-offer-filter]');
  if(!root) return;
  const tabs = [...root.querySelectorAll('[data-filter]')];
  const items = [...root.querySelectorAll('[data-cat]')];
  const apply = (cat, scroll)=>{
    tabs.forEach(t => t.setAttribute('aria-selected', String(t.dataset.filter === cat)));
    items.forEach(el => { el.hidden = !(cat === 'all' || el.dataset.cat === cat); });
    root.classList.toggle('is-filtered', cat !== 'all');
    if(scroll) root.scrollIntoView({behavior:'smooth', block:'start'});
  };
  tabs.forEach(t => t.addEventListener('click', ()=>{
    apply(t.dataset.filter, false);
    try{ history.replaceState(null, '', t.dataset.filter === 'all' ? '#offers' : '#' + t.dataset.filter); }catch(e){}
  }));
  // keyboard: arrow keys move between tabs
  root.querySelector('[role="tablist"]').addEventListener('keydown', e=>{
    const i = tabs.indexOf(document.activeElement); if(i < 0) return;
    if(e.key === 'ArrowRight' || e.key === 'ArrowLeft'){
      e.preventDefault(); const n = tabs[(i + (e.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length]; n.focus(); n.click();
    }
  });
  const fromHash = ()=>{ const h = location.hash.slice(1); if(['business','events','weddings'].includes(h)) apply(h, true); };
  fromHash(); window.addEventListener('hashchange', fromHash);
})();

// Work page: "We make [what] for [who]" filter. Hash: #photography, #for-weddings, #film/for-corporate-events
(function(){
  const say = document.querySelector('.wk-say'); if(!say) return;
  const sel = {d: say.querySelector('select[data-dim="d"]'), s: say.querySelector('select[data-dim="s"]')};
  const cards = [...document.querySelectorAll('.wk-all .wk-card')];
  const countEl = document.querySelector('[data-wk-count]'), empty = document.querySelector('[data-wk-empty]');
  const resets = document.querySelectorAll('[data-wk-reset]'), topReset = document.querySelector('.wk-meta [data-wk-reset]');
  const ALIAS = {commercial:'photography', events:'for-corporate-events', weddings:'for-weddings', design:'graphic-design', all:''};
  const has = (c, dim, v) => !v || (c.dataset[dim] || '').split(' ').includes(v);
  function parse(h){
    h = decodeURIComponent(h || '').replace(/^#/, ''); h = ALIAS[h] !== undefined ? ALIAS[h] : h;
    let d = '', s = '';
    h.split('/').forEach(p => { if(p.startsWith('for-')) s = p.slice(4); else if(p) d = p; });
    const ok = (el, v) => [...el.options].some(o => o.value === v);
    return {d: ok(sel.d, d) ? d : '', s: ok(sel.s, s) ? s : ''};
  }
  function render(push){
    const d = sel.d.value, s = sel.s.value; let n = 0;
    cards.forEach(c => { const on = has(c, 'd', d) && has(c, 's', s); c.hidden = !on; if(on) n++; });
    // live counts in each list, and impossible pairs disabled
    [['d', 's'], ['s', 'd']].forEach(([dim, other]) => [...sel[dim].options].forEach(o => {
      const k = cards.filter(c => has(c, dim, o.value) && has(c, other, sel[other].value)).length;
      o.textContent = (o.dataset.name || o.dataset.say.replace(/^./, m => m.toUpperCase())) + ' (' + k + ')';
      o.disabled = k === 0 && o.value !== sel[dim].value;
    }));
    say.querySelectorAll('select').forEach(x => { const o = x.options[x.selectedIndex]; x.previousElementSibling.textContent = o.dataset.say; x.parentElement.classList.toggle('is-set', !!x.value); });
    document.querySelectorAll('[data-wk-chip]').forEach(b => { const on = b.dataset.wkChip === d; b.classList.toggle('is-on', on); b.setAttribute('aria-pressed', on);
      const k = cards.filter(c => has(c, 'd', b.dataset.wkChip) && has(c, 's', s)).length; b.querySelector('span').textContent = k; b.disabled = k === 0 && !on; });
    if(countEl) countEl.textContent = n === 1 ? '1 case study' : n + ' case studies';
    if(topReset) topReset.hidden = !d && !s;
    if(empty) empty.hidden = n > 0;
    if(push){ const h = [d, s && 'for-' + s].filter(Boolean).join('/'); history.replaceState(null, '', h ? '#' + h : location.pathname); }
  }
  function apply(h){ const v = parse(h); sel.d.value = v.d; sel.s.value = v.s; render(false); }
  Object.values(sel).forEach(x => x.addEventListener('change', () => render(true)));
  document.querySelectorAll('[data-wk-chip]').forEach(b => b.addEventListener('click', () => { sel.d.value = b.dataset.wkChip; render(true); }));
  resets.forEach(b => b.addEventListener('click', () => { sel.d.value = ''; sel.s.value = ''; render(true); }));
  window.addEventListener('hashchange', () => apply(location.hash));
  apply(location.hash);
})();

// Logo presentation: anatomy (take apart / put together), construction toggle, copy colour codes
(function(){
  const anat = document.querySelector('[data-lg-anatomy] .lg-anat-wrap');
  if(anat){
    const btn = anat.querySelector('[data-lg-assemble]');
    const set = whole => { anat.classList.toggle('is-whole', whole); if(btn){ btn.textContent = whole ? 'Take it apart' : 'Put it together'; btn.setAttribute('aria-pressed', whole); } };
    set(true);
    if('IntersectionObserver' in window && !matchMedia('(prefers-reduced-motion: reduce)').matches){
      const io = new IntersectionObserver(es => es.forEach(e => { if(e.isIntersecting){ setTimeout(() => set(false), 350); io.disconnect(); } }), {threshold:.55});
      io.observe(anat);
    } else set(false);
    if(btn) btn.addEventListener('click', () => set(!anat.classList.contains('is-whole')));
  }
  const tg = document.querySelector('[data-lg-construct]'), wrap = document.querySelector('[data-lg-wrap]');
  if(tg && wrap) tg.addEventListener('click', () => { const on = !wrap.classList.contains('is-on'); wrap.classList.toggle('is-on', on); tg.setAttribute('aria-pressed', on); tg.textContent = on ? 'Hide construction' : 'Show construction'; });
  document.querySelectorAll('.lg-sw[data-copy]').forEach(b => b.addEventListener('click', () => {
    const t = b.dataset.copy; (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).catch(()=>{}).finally(() => { b.classList.add('is-copied'); setTimeout(() => b.classList.remove('is-copied'), 1600); });
  }));
})();

// Build your project: drag services into a 3-stage pipeline, see an estimate, book the combination.
// Pointer events, so the same drag works with a mouse, a finger or a pen. Tap or Enter adds a service.
(function(){
  const root = document.querySelector('[data-builder]'); if(!root) return;
  const DATA = JSON.parse(document.getElementById('bx-data').textContent);
  const KEY = 'crt-builder';
  const lists = {1: root.querySelector('[data-lane-list="1"]'), 2: root.querySelector('[data-lane-list="2"]'), 3: root.querySelector('[data-lane-list="3"]')};
  const rwf = n => Number(n).toLocaleString('en-US');
  const escH = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  let pipe = {1:[], 2:[], 3:[]};

  // restore: link (#b=1:id.id|2:id) first, then this browser's last build
  function fromHash(){
    const m = location.hash.match(/^#b=(.+)$/); if(!m) return null;
    const p = {1:[], 2:[], 3:[]};
    decodeURIComponent(m[1]).split('|').forEach(part => { const [l, ids] = part.split(':'); if(p[l] && ids) p[l] = ids.split('.').filter(id => DATA[id]); });
    return p;
  }
  try{ pipe = fromHash() || JSON.parse(localStorage.getItem(KEY) || 'null') || pipe; }catch(e){}
  [1, 2, 3].forEach(l => { pipe[l] = (pipe[l] || []).filter(id => DATA[id]); });

  const all = () => [1, 2, 3].flatMap(l => pipe[l]);
  function save(){
    try{ localStorage.setItem(KEY, JSON.stringify(pipe)); }catch(e){}
    const h = [1, 2, 3].filter(l => pipe[l].length).map(l => l + ':' + pipe[l].join('.')).join('|');
    history.replaceState(null, '', h ? '#b=' + h : location.pathname);
  }
  function render(){
    [1, 2, 3].forEach(l => {
      lists[l].innerHTML = pipe[l].map((id, i) => {
        const s = DATA[id];
        return `<li class="bx-item" data-item="${id}" data-lane="${l}" data-i="${i}"><span class="bx-grip" aria-hidden="true"></span><span class="bx-item-t"><b>${escH(s.n)}</b><small>${s.p ? 'from ' + rwf(s.p) + ' RWF' : 'Priced on request'}</small></span>` +
          `<button type="button" class="bx-x" data-remove="${l}:${i}" aria-label="Remove ${escH(s.n)}">×</button></li>`;
      }).join('');
      lists[l].closest('.bx-lane').classList.toggle('is-empty', !pipe[l].length);
    });
    const ids = all(), known = ids.filter(id => DATA[id].p), unknown = ids.length - known.length, total = known.reduce((s, id) => s + DATA[id].p, 0);
    root.querySelectorAll('.bx-card').forEach(c => c.classList.toggle('is-in', ids.includes(c.dataset.svc)));
    root.querySelector('[data-bx-count]').textContent = ids.length ? ids.length + ' service' + (ids.length > 1 ? 's' : '') + ' in your pipeline' : 'No services yet';
    const tot = !ids.length ? 'Add a service to see an estimate' : known.length ? 'From ' + rwf(total) + ' RWF' + (unknown ? ' + ' + unknown + ' priced on request' : '') : 'Priced on request';
    root.querySelector('[data-bx-total]').textContent = tot;
    const book = root.querySelector('[data-bx-book]'); book.setAttribute('aria-disabled', String(!ids.length));
    root.querySelector('[data-bx-share]').hidden = !ids.length;
    root.querySelector('[data-bx-list]').innerHTML = [1, 2, 3].filter(l => pipe[l].length).map(l => `<li><span>${['', 'Before', 'On the day', 'After'][l]}</span>${pipe[l].map(id => escH(DATA[id].n)).join(', ')}</li>`).join('');
    root.querySelector('[data-bx-total2]').textContent = ids.length ? tot : '';
    // keep the booking form in sync
    const form = root.querySelector('[data-builder-form]');
    if(form){
      const lines = [1, 2, 3].filter(l => pipe[l].length).map(l => ['', 'Before', 'On the day', 'After'][l] + ': ' + pipe[l].map(id => DATA[id].n).join(', '));
      form.querySelector('[name="service"]').value = ids.map(id => DATA[id].n).join(', ').slice(0, 120) || 'Custom project';
      form.querySelector('[name="offer"]').value = ids.length ? 'Custom pipeline · ' + tot : '';
      const det = form.querySelector('[name="details"]');
      det.value = (ids.length ? 'My pipeline:\n' + lines.join('\n') + '\nEstimate: ' + tot + '\n\n' : '') + (det.dataset.own || '');
    }
    save();
  }
  function add(id, lane, index){
    if(!DATA[id]) return;
    [1, 2, 3].forEach(l => { pipe[l] = pipe[l].filter(x => x !== id); });
    lane = lane || DATA[id].s;
    const list = pipe[lane]; list.splice(index == null ? list.length : Math.min(index, list.length), 0, id);
    render();
    const el = root.querySelector(`.bx-item[data-item="${id}"]`); if(el){ el.classList.add('is-new'); setTimeout(() => el.classList.remove('is-new'), 600); }
  }

  // ---- drag (pointer events) ----
  let drag = null;
  function laneAt(x, y){
    const el = document.elementFromPoint(x, y); const lane = el && el.closest('.bx-lane');
    if(!lane) return null;
    const l = Number(lane.dataset.lane), items = [...lists[l].querySelectorAll('.bx-item:not(.is-ghosted)')];
    let index = items.length;
    for(let i = 0; i < items.length; i++){ const r = items[i].getBoundingClientRect(); if(y < r.top + r.height / 2){ index = i; break; } }
    return {l, index, lane};
  }
  root.addEventListener('pointerdown', e => {
    if(e.button !== 0 || e.target.closest('button')) return;
    const src = e.target.closest('.bx-card, .bx-item'); if(!src) return;
    drag = {src, id: src.dataset.svc || src.dataset.item, from: src.dataset.lane ? Number(src.dataset.lane) : null, x0: e.clientX, y0: e.clientY, moved: false};
    src.setPointerCapture(e.pointerId);
  });
  root.addEventListener('pointermove', e => {
    if(!drag) return;
    if(!drag.moved){
      if(Math.hypot(e.clientX - drag.x0, e.clientY - drag.y0) < 6) return;
      drag.moved = true;
      const r = drag.src.getBoundingClientRect();
      drag.ghost = drag.src.cloneNode(true); drag.ghost.className = 'bx-ghost'; drag.ghost.style.width = r.width + 'px';
      drag.dx = e.clientX - r.left; drag.dy = e.clientY - r.top;
      document.body.appendChild(drag.ghost); document.body.classList.add('bx-dragging');
      if(drag.from) drag.src.classList.add('is-ghosted');
      drag.marker = document.createElement('li'); drag.marker.className = 'bx-marker';
    }
    e.preventDefault();
    drag.ghost.style.transform = `translate(${e.clientX - drag.dx}px, ${e.clientY - drag.dy}px) rotate(-1.5deg)`;
    const t = laneAt(e.clientX, e.clientY);
    root.querySelectorAll('.bx-lane.is-over').forEach(x => x !== (t && t.lane) && x.classList.remove('is-over'));
    if(t){ t.lane.classList.add('is-over'); const items = [...lists[t.l].querySelectorAll('.bx-item:not(.is-ghosted)')]; if(items[t.index]) items[t.index].before(drag.marker); else lists[t.l].appendChild(drag.marker); }
    else drag.marker.remove();
  });
  function end(e, cancel){
    if(!drag) return;
    const d = drag; drag = null;
    document.body.classList.remove('bx-dragging');
    root.querySelectorAll('.bx-lane.is-over').forEach(x => x.classList.remove('is-over'));
    if(!d.moved){ if(!cancel && d.src.classList.contains('bx-card')) add(d.id); return; }
    d.ghost.remove(); d.marker.remove(); d.src.classList.remove('is-ghosted');
    if(cancel) return;
    const t = laneAt(e.clientX, e.clientY);
    if(t){
      let index = t.index;
      if(d.from === t.l){ const old = pipe[t.l].indexOf(d.id); if(old > -1 && old < index) index--; }
      add(d.id, t.l, index);
    } else if(d.from){ pipe[d.from] = pipe[d.from].filter(x => x !== d.id); render(); } // dragged out of the pipeline: remove
  }
  root.addEventListener('pointerup', e => end(e, false));
  root.addEventListener('pointercancel', e => end(e, true));
  root.addEventListener('keydown', e => { const c = e.target.closest('.bx-card'); if(c && (e.key === 'Enter' || e.key === ' ')){ e.preventDefault(); add(c.dataset.svc); } });

  root.addEventListener('click', e => {
    const rm = e.target.closest('[data-remove]');
    if(rm){ const [l, i] = rm.dataset.remove.split(':').map(Number); pipe[l].splice(i, 1); render(); return; }
    const tpl = e.target.closest('[data-tpl]');
    if(tpl){ pipe = {1:[], 2:[], 3:[]}; tpl.dataset.tpl.split(',').forEach(id => { if(DATA[id]) pipe[DATA[id].s].push(id); }); render(); return; }
    if(e.target.closest('[data-bx-clear]')){ pipe = {1:[], 2:[], 3:[]}; render(); return; }
    if(e.target.closest('[data-bx-share]')){
      const url = location.href;
      (navigator.share ? navigator.share({title: 'My CRT project', url}) : navigator.clipboard.writeText(url)).then(() => { const b = e.target.closest('[data-bx-share]'); const t = b.textContent; b.textContent = navigator.share ? 'Shared' : 'Link copied'; setTimeout(() => b.textContent = t, 1600); }).catch(() => {});
      return;
    }
    const book = e.target.closest('[data-bx-book]');
    if(book){
      e.preventDefault();
      if(!all().length){ root.querySelector('.bx-lib').scrollIntoView({behavior:'smooth', block:'start'}); return; }
      const b = root.querySelector('.bx-book'); b.hidden = false; b.scrollIntoView({behavior:'smooth', block:'start'});
      setTimeout(() => { const n = b.querySelector('[name="name"]'); if(n) n.focus({preventScroll:true}); }, 500);
      return;
    }
    if(e.target.closest('[data-bx-edit]')){ root.querySelector('.bx-board').scrollIntoView({behavior:'smooth', block:'start'}); }
  });
  const det = root.querySelector('[data-builder-form] [name="details"]');
  if(det) det.addEventListener('input', () => { const i = det.value.indexOf('\n\n'); det.dataset.own = det.value.startsWith('My pipeline:') && i > -1 ? det.value.slice(i + 2) : det.value; });
  render();
})();

// Home page: each collection shows one row; "See more" opens the rest in place. Rows are measured live,
// so one row is 4 tiles on a laptop and 1 card on a phone.
(function(){
  if(!document.querySelector('.hero-home')) return;
  const SEL = '.bento, .svc-grid, .deals-grid, .card-grid.four, [data-testimonials-list]';
  // Collections with a full page of their own: "See more" goes there instead of expanding in place.
  const PAGE = {'bento': ['work/index.html', 'See all our work']};
  const state = new WeakMap();
  function apply(grid){
    const items = [...grid.children].filter(el => el.nodeType === 1);
    const page = Object.keys(PAGE).find(c => grid.classList.contains(c));
    const ownCta = grid.nextElementSibling && grid.nextElementSibling.classList.contains('cta-row'); // e.g. "See all offers"
    let st = state.get(grid);
    if(!st){
      st = {open: false};
      const row = document.createElement('div'); row.className = 'more-row';
      if(page){
        row.innerHTML = `<a class="btn secondary more-btn" href="${PAGE[page][0]}">${PAGE[page][1]} <span aria-hidden="true">→</span></a>`;
      } else {
        row.innerHTML = '<button type="button" class="btn secondary more-btn" aria-expanded="false"></button>';
        row.querySelector('button').addEventListener('click', () => { st.open = !st.open; apply(grid); if(!st.open) grid.scrollIntoView({block:'nearest'}); });
      }
      if(!ownCta) grid.after(row);
      st.row = row; st.btn = row.querySelector('button');
      state.set(grid, st);
    }
    items.forEach(el => el.classList.remove('is-more-hidden'));
    grid.classList.toggle('is-one-row', !st.open);
    if(!items.length){ st.row.hidden = true; return; }
    if(page || ownCta){
      // one row only; the link (ours or the section's own) opens the full page
      const top0 = Math.min(...items.map(el => el.offsetTop));
      items.filter(el => el.offsetTop > top0 + 4).forEach(el => el.classList.add('is-more-hidden'));
      st.row.hidden = false;
      return;
    }
    const top = Math.min(...items.map(el => el.offsetTop));
    const extra = items.filter(el => el.offsetTop > top + 4);
    const shown = items.length - extra.length;
    if(!st.open) extra.forEach(el => el.classList.add('is-more-hidden'));
    // when open, count what the collapsed row would hide
    let hidden = extra.length;
    if(st.open){ grid.classList.add('is-one-row'); const t2 = Math.min(...items.map(el => el.offsetTop)); hidden = items.filter(el => el.offsetTop > t2 + 4).length; grid.classList.remove('is-one-row'); }
    st.row.hidden = hidden === 0;
    st.btn.setAttribute('aria-expanded', String(st.open));
    st.btn.textContent = st.open ? 'See less' : 'See more (' + hidden + ')';
  }
  const run = () => document.querySelectorAll(SEL).forEach(apply);
  run();
  let t; window.addEventListener('resize', () => { clearTimeout(t); t = setTimeout(run, 120); });
  const tl = document.querySelector('[data-testimonials-list]');
  if(tl) new MutationObserver(() => apply(tl)).observe(tl, {childList: true});
  window.addEventListener('load', run);
})();
