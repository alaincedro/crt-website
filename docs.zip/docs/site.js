(function(){
  // The site works straight from a folder (no server), so links are built relative
  // to the folder that holds this script. u('/contact#inquiry') -> .../contact/index.html#inquiry
  const ROOT = (document.currentScript && document.currentScript.src)
    ? new URL('.', document.currentScript.src).href : new URL('/', location.href).href;
  const u = p=>{
    if(!p || p[0] !== '/') return p;
    const m = p.match(/^([^?#]*)(.*)$/); let path = m[1];
    if(path === '/' || path.endsWith('/')) path += 'index.html';
    else if(!/\.[a-z0-9]+$/i.test(path.split('/').pop())) path += '/index.html';
    return new URL(path.slice(1) + m[2], ROOT).href;
  };
  // '.../business/index.html' -> '/business' (used to match menu entries)
  const pageKey = href=>{
    const h = new URL(href, location.href).href.split(/[?#]/)[0];
    if(!h.startsWith(ROOT)) return null;
    return '/' + h.slice(ROOT.length).replace(/(^|\/)index\.html$/, '').replace(/\/$/, '');
  };
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.nav-links');
  if(toggle && nav){
    toggle.addEventListener('click', function(){
      const isOpen = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(isOpen));
      toggle.textContent = isOpen ? 'Close' : 'Menu';
    });
    nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{
      nav.classList.remove('open'); toggle.setAttribute('aria-expanded','false'); toggle.textContent='Menu';
    }));
  }
  const params = new URLSearchParams(window.location.search);

  // Swap prices in visible text, e.g. {"600,000":"1,200,000"}. One pass, so a new
  // price is never swapped twice. Skips scripts, styles and form fields.
  function crtReplaceNumbers(root, map){
    const keys = Object.keys(map);
    if(!root || !keys.length) return;
    const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const re = new RegExp('(^|[^\\d,])(' + keys.map(esc).join('|') + ')(?![\\d,])', 'g');
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: n => (n.parentElement && n.parentElement.closest('script,style,textarea,input')) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT
    });
    const nodes = []; while(walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(n => { const t = n.nodeValue; if(re.test(t)){ re.lastIndex = 0; n.nodeValue = t.replace(re, (m, a, b) => a + map[b]); } re.lastIndex = 0; });
  }

  // ---------------------------------------------------------------
  // Analytics: paste your IDs here to switch tracking on.
  //   GA_ID         e.g. 'G-XXXXXXXXXX'   (Google Analytics 4)
  //   META_PIXEL_ID e.g. '123456789012345' (Meta / Facebook Pixel)
  // While they are empty, no tracking code loads at all.
  // ---------------------------------------------------------------
  // Where website enquiries are emailed (FormSubmit form-to-email service).
  const ENQUIRY_EMAIL = 'hello@crt.rw';
  const GA_ID = '';
  const META_PIXEL_ID = '';
  // Tracking only loads after the visitor accepts the cookie notice (Rwanda data
  // protection law, Law No. 058/2021). With both IDs empty, no notice is shown.
  const CONSENT_KEY = 'crt_consent';
  const getConsent = ()=>{ try{ return localStorage.getItem(CONSENT_KEY); }catch(e){ return null; } };
  const setConsent = v=>{ try{ localStorage.setItem(CONSENT_KEY, v); }catch(e){} };
  function loadTracking(){
    if(GA_ID){
      const s=document.createElement('script'); s.async=true; s.src='https://www.googletagmanager.com/gtag/js?id='+GA_ID; document.head.appendChild(s);
      window.dataLayer=window.dataLayer||[]; window.gtag=function(){dataLayer.push(arguments);}; gtag('js', new Date()); gtag('config', GA_ID, {anonymize_ip:true});
    }
    if(META_PIXEL_ID){
      !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', META_PIXEL_ID); fbq('track','PageView');
    }
  }
  if(GA_ID || META_PIXEL_ID){
    const choice = getConsent();
    if(choice === 'yes') loadTracking();
    else if(choice !== 'no'){
      const bar = document.createElement('div');
      bar.className = 'consent'; bar.setAttribute('role','region'); bar.setAttribute('aria-label','Cookie notice');
      bar.innerHTML = '<p>We use cookies to see which pages and ads work. <a href="/privacy#analytics">Privacy</a></p>'+
        '<div class="consent-actions"><button type="button" class="btn small ghost" data-c="no">Decline</button><button type="button" class="btn small" data-c="yes">Accept</button></div>';
      bar.addEventListener('click', e=>{
        const b = e.target.closest('[data-c]'); if(!b) return;
        setConsent(b.dataset.c); bar.remove();
        if(b.dataset.c === 'yes') loadTracking();
      });
      document.body.appendChild(bar);
    }
  }
  const trackLead = (label)=>{
    if(typeof window.gtag==='function') gtag('event','generate_lead',{form_location:location.pathname,label:label});
    if(typeof window.fbq==='function') fbq('track','Lead',{content_name:label});
  };

  // Where did this visitor come from? Remember the ad / campaign for the session.
  const SOURCE_KEY = 'crt_source';
  (function(){
    const utm = ['utm_source','utm_medium','utm_campaign'].map(k=>params.get(k)).filter(Boolean);
    let src = utm.length ? utm.join(' / ') : (params.get('fbclid') ? 'facebook / instagram ad' : (params.get('gclid') ? 'google ad' : ''));
    try{
      if(src) sessionStorage.setItem(SOURCE_KEY, src);
      else if(!sessionStorage.getItem(SOURCE_KEY)){
        const ref = document.referrer && new URL(document.referrer).hostname;
        sessionStorage.setItem(SOURCE_KEY, ref && ref !== location.hostname ? ref : 'direct');
      }
    }catch(e){}
  })();
  const getSource = ()=>{ try{ return sessionStorage.getItem(SOURCE_KEY) || 'direct'; }catch(e){ return 'unknown'; } };

  document.querySelectorAll('[data-booking-form]').forEach(form=>{
    const formService = form.dataset.service || params.get('service') || 'Creative project';
    const formOffer = form.dataset.offer || params.get('offer') || '';
    const serviceField = form.querySelector('[name="service"]');
    const offerField = form.querySelector('[name="offer"]');
    if(serviceField) serviceField.value = params.get('service') || formService;
    if(offerField) offerField.value = params.get('offer') || formOffer;
    if(params.get('date')) { const dateField=form.querySelector('[name="date"]'); if(dateField) dateField.value=params.get('date'); }
    const status = form.querySelector('.form-status');
    const sendBtn = form.querySelector('button[type="submit"]');
    const waBtn = form.querySelector('[data-send-whatsapp]');
    const sendLabel = sendBtn ? sendBtn.textContent : '';
    const collect = ()=>{
      const set = (n,v)=>{ const f=form.querySelector('[name="'+n+'"]'); if(f) f.value=v; };
      set('page', location.pathname);
      set('source', getSource());
      const data = new FormData(form);
      return {data, service: data.get('service') || formService, offer: data.get('offer') || formOffer};
    };
    // A copy of every enquiry goes to the admin dashboard (Supabase), if connected.
    const saveLead = ({data, service, offer}, channel)=>{
      const CFG = window.CRT_CONFIG || {};
      if(!CFG.SUPABASE_URL || !CFG.SUPABASE_ANON_KEY || data.get('bot-field')) return;
      const cut = (v,n)=> (v||'').toString().slice(0,n) || null;
      try{
        fetch(CFG.SUPABASE_URL.replace(/\/$/,'') + '/rest/v1/leads', {
          method:'POST', keepalive:true,
          headers:{'apikey':CFG.SUPABASE_ANON_KEY,'Authorization':'Bearer '+CFG.SUPABASE_ANON_KEY,'Content-Type':'application/json','Prefer':'return=minimal'},
          body: JSON.stringify({
            name: cut(data.get('name'),120) || 'Unknown', contact: cut(data.get('contact'),160) || 'Unknown',
            service: cut(service,120), offer: cut(offer,120), event_date: cut(data.get('date'),120),
            details: cut(data.get('details'),2000), page: cut(location.pathname,200),
            source: cut(getSource() + ' · via ' + channel, 200)
          })
        }).catch(()=>{});
      }catch(err){}
    };
    const show = (kind, html)=>{ if(!status) return; status.className = 'form-status is-' + kind; status.innerHTML = html; status.hidden = false; };
    const waLink = ({data, service, offer})=>{
      const lines = [
        'Hi CRT Media Agency, I would like to enquire about a project.',
        'Service: ' + service,
        offer ? 'Offer/package: ' + offer : '',
        data.get('name') ? 'Name: ' + data.get('name') : '',
        data.get('contact') ? 'Email or phone: ' + data.get('contact') : '',
        data.get('date') ? 'Preferred date/timeline: ' + data.get('date') : '',
        data.get('details') ? 'Project details: ' + data.get('details') : '',
      ].filter(Boolean);
      return 'https://wa.me/250796356035?text=' + encodeURIComponent(lines.join('\n'));
    };

    // Choice 1 (default): email the enquiry to our inbox.
    form.addEventListener('submit', function(e){
      e.preventDefault();
      const info = collect(), data = info.data;
      if(data.get('bot-field')) return;
      saveLead(info, 'email');
      trackLead(info.offer || info.service);
      const contact = (data.get('contact') || '').toString();
      const payload = {
        _subject: 'New website enquiry: ' + (info.offer || info.service) + ' – ' + (data.get('name') || ''),
        _template: 'table', _captcha: 'false',
        Name: data.get('name') || '', 'WhatsApp or email': contact,
        Service: info.service, 'Offer / package': info.offer || '—',
        'Date / timeline': data.get('date') || '—', Details: data.get('details') || '—',
        Page: location.href.split('#')[0], Source: getSource()
      };
      if(/@/.test(contact)) payload._replyto = contact;
      if(sendBtn){ sendBtn.disabled = true; sendBtn.textContent = 'Sending…'; }
      if(status) status.hidden = true;
      fetch('https://formsubmit.co/ajax/' + ENQUIRY_EMAIL, {
        method:'POST', headers:{'Content-Type':'application/json','Accept':'application/json'}, body: JSON.stringify(payload)
      }).then(r => r.json().then(j => ({ok: r.ok, j})).catch(() => ({ok: r.ok, j: {}})))
        .then(({ok, j}) => {
          if(!ok || String(j.success) === 'false') throw new Error(j.message || 'not sent');
          const name = (data.get('name') || '').toString().split(' ')[0];
          show('ok', '<strong>Thank you' + (name ? ', ' + name.replace(/[<>&]/g,'') : '') + '!</strong> Your enquiry is in our inbox. We’ll get back to you soon.');
          form.reset();
          const sf = form.querySelector('[name="service"]'), of = form.querySelector('[name="offer"]');
          if(sf) sf.value = info.service; if(of) of.value = info.offer;
        })
        .catch(() => {
          show('error', 'Sorry, we couldn’t send that by email just now. Please <a href="' + waLink(info) + '" target="_blank" rel="noopener">send it on WhatsApp</a> or write to <a href="mailto:' + ENQUIRY_EMAIL + '">' + ENQUIRY_EMAIL + '</a>.');
        })
        .finally(() => { if(sendBtn){ sendBtn.disabled = false; sendBtn.textContent = sendLabel; } });
    });

    // Choice 2: send the same details on WhatsApp instead.
    if(waBtn) waBtn.addEventListener('click', function(){
      if(!form.reportValidity()) return;
      const info = collect();
      if(info.data.get('bot-field')) return;
      saveLead(info, 'WhatsApp');
      trackLead(info.offer || info.service);
      window.location.href = waLink(info);
    });
  });
  document.querySelectorAll('[data-prefill-service]').forEach(link=>{
    const target = new URL(link.href, window.location.href);
    target.searchParams.set('service', link.dataset.prefillService);
    if(link.dataset.prefillOffer) target.searchParams.set('offer', link.dataset.prefillOffer);
    link.href = target.toString();
  });
  // Bottom action bar on every page: "Ask a question" (WhatsApp) + the page's main action.
  // Replaces the old floating WA circle and phone-only enquiry button.
  (function(){
    const oldMain = document.querySelector('.mobile-booking a');
    const oldWa = document.querySelector('.whatsapp-float');
    const hasForm = !!document.getElementById('inquiry');
    const bar = document.createElement('div');
    bar.className = 'action-bar' + (document.querySelector('.hero-paths') ? ' is-hidden' : '');
    const ask = document.createElement('a');
    ask.className = 'action-ask';
    ask.href = oldWa ? oldWa.href : 'https://wa.me/250796356035';
    ask.target = '_blank'; ask.rel = 'noopener';
    ask.dataset.track = 'bar_whatsapp';
    ask.innerHTML = '<span class="action-dot"></span><span class="lbl-long">Ask a question</span><span class="lbl-short">Ask</span>';
    const main = document.createElement('a');
    main.className = 'btn action-main';
    main.href = hasForm ? '#inquiry' : u('/contact#inquiry');
    main.dataset.track = 'bar_main';
    main.textContent = oldMain ? oldMain.textContent.trim() : 'Get a quote';
    // "Book a call" (filled with BOOKING_URL below; stays hidden if there is no link)
    const CAL_ICON = '<svg class="cal-ico" viewBox="0 0 20 20" aria-hidden="true"><rect x="3" y="4.5" width="14" height="12.5" rx="2.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M3 8.5h14M7 2.8v3.4M13 2.8v3.4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>';
    const call = document.createElement('a');
    call.className = 'action-call';
    call.href = u('/contact'); call.hidden = true;
    call.setAttribute('data-booking-link','');
    call.dataset.track = 'bar_book_call';
    call.innerHTML = CAL_ICON + '<span class="lbl-long">Book a free call</span><span class="lbl-short">Call</span>';
    bar.append(ask, call, main);
    document.body.appendChild(bar);
    // Header: "Book a call" beside "Get a quote"
    const navCta = document.querySelector('.nav-links .nav-cta');
    if(navCta){
      const actions = document.createElement('div');
      actions.className = 'nav-actions';
      const navCall = document.createElement('a');
      navCall.className = 'nav-call';
      navCall.href = u('/contact'); navCall.hidden = true;
      navCall.setAttribute('data-booking-link','');
      navCall.dataset.track = 'nav_book_call';
      navCall.innerHTML = CAL_ICON + '<span>Book a call</span>';
      navCta.parentNode.insertBefore(actions, navCta);
      actions.append(navCall, navCta);
    }
    document.querySelectorAll('.mobile-booking,.whatsapp-float').forEach(el=>el.remove());
    document.body.classList.add('has-action-bar');
    // Get out of the way when the form, the footer or the home hero tiles are on screen.
    const targets = [document.getElementById('inquiry'), document.querySelector('footer'), document.querySelector('.hero-paths')].filter(Boolean);
    if('IntersectionObserver' in window && targets.length){
      const seen = new Set();
      const io = new IntersectionObserver(entries=>{
        entries.forEach(e=>e.isIntersecting ? seen.add(e.target) : seen.delete(e.target));
        bar.classList.toggle('is-hidden', seen.size > 0);
      }, {threshold: 0.15});
      targets.forEach(t=>io.observe(t));
    }
  })();

  // ---------------------------------------------------------------
  // "Book a call": paste your Cal.com / Calendly / Google Calendar
  // booking-page link here. While it is empty, every "Book a call"
  // button stays hidden, so nothing broken ever shows.
  // ---------------------------------------------------------------
  const BOOKING_URL = 'https://cal.com/crt-media-agency-djafrq/20-minutes-meeting-with-crt';
  document.querySelectorAll('[data-booking-link]').forEach(el=>{
    if(!BOOKING_URL) return;
    el.href = BOOKING_URL;
    el.target = '_blank'; el.rel = 'noopener';
    (el.closest('[data-booking]') || el).hidden = false;
  });

  // ---------------------------------------------------------------
  // Menu panels (desktop): every menu item opens a panel with photos
  // and quick links; the page is blurred behind it.
  // Footer call-to-action band (all pages)
  (function(){
    const f = document.querySelector('footer.footer');
    // Offer landing pages (ad traffic) stay focused on their own form: no extra call-to-action band
    if(!f || f.querySelector('.footer-cta') || document.body.classList.contains('lp')) return;
    const d = document.createElement('div');
    d.className = 'footer-cta';
    d.innerHTML = '<div><span class="kicker">Have a project in mind?</span>'+
      '<p class="footer-cta-title">Let’s make something<br>people remember.</p></div>'+
      '<div class="footer-cta-actions"><a class="btn" href="'+u('/contact')+'" data-track="footer_cta_quote">Get a quote →</a>'+
      '<a class="btn ghost" href="https://wa.me/250796356035?text=Hi%20CRT%20Media%20Agency%2C%20I%27d%20like%20to%20start%20a%20project." target="_blank" rel="noopener" data-track="footer_cta_whatsapp">Chat on WhatsApp ↗</a></div>';
    // A page-specific banner just above the footer becomes the footer CTA's lead-in
    const main = document.querySelector('main'), last = main && main.lastElementChild;
    if(last && last.classList.contains('cta-banner')){
      const h = last.querySelector('h2'), p = last.querySelector('p'), b = last.querySelector('.btn');
      if(h) d.querySelector('.kicker').textContent = h.textContent;
      if(p){ const n = document.createElement('p'); n.className = 'footer-cta-note'; n.textContent = p.textContent; d.firstElementChild.appendChild(n); }
      if(b){ const q = d.querySelector('.footer-cta-actions .btn'); q.href = b.href; q.textContent = b.textContent; }
      last.remove();
    }
    f.prepend(d);
  })();

  // To change a panel, edit MENU below. Each item:
  //   [name, link, image, small line under the name, [[label, link], ...]]
  // ---------------------------------------------------------------
  const S = '/assets/md/';
  const MENU = {
    '/work': { cols: 4, items: [
      ['Weddings','/work#weddings','/assets/work/cases/wedding-jones-nadia/cover-800.webp','4 stories · weddings and a proposal',[['See weddings','/work#weddings'],['Packages','/weddings#packages']]],
      ['Commercial & product','/work#commercial','/assets/work/cases/inka-steak-house/cover-800.webp','Food, products, hotels and brands',[['See commercial','/work#commercial'],['Content session','/offer-commercial-content-session']]],
      ['Events','/work#events','/assets/work/cases/sanlam-allianz-agents-day/cover-800.webp','Corporate days and workshops',[['See events','/work#events'],['Event packages','/events#packages']]],
      ['Branding & social media','/work#branding','/assets/work/zora-lounge-poster-800.webp','Logos, identities and social content',[['See branding','/work#branding'],['Brand kit','/offer-brand-starter-kit']]],
    ], side: [['All work','/work'],['Get a quote','/contact'],['Book a call','#call']] },
    '/weddings': { cols: 4, items: [
      ['Basic','/weddings#packages','/assets/work/wedding-sandra-mathias-800.webp','1,200,000 RWF',[['Check my date','/contact?service=Wedding%20photography%20%26%20film&offer=Basic#inquiry']]],
      ['Standard','/weddings#packages','/assets/work/reception-sandra-mathias-800.webp','2,000,000 RWF',[['Check my date','/contact?service=Wedding%20photography%20%26%20film&offer=Standard#inquiry']]],
      ['Premium','/weddings#packages','/assets/work/wedding-party-mirindi-ange-800.webp','3,000,000 RWF',[['Check my date','/contact?service=Wedding%20photography%20%26%20film&offer=Premium#inquiry']]],
      ['VIP','/weddings#packages','/assets/work/cases/wedding-mirindi-ange/06-800.webp','4,500,000 RWF',[['Check my date','/contact?service=Wedding%20photography%20%26%20film&offer=VIP#inquiry']]],
    ], side: [['Weddings overview','/weddings'],['Packages and prices','/weddings#packages'],['Single days and extras','/weddings#days'],['Book early, save 10%','/offer-wedding-early-booking']] },
    '/events': { cols: 2, items: [
      ['Event coverage','/events','/assets/icons/cover-svc-events.svg','3 packages, from 200,000 RWF',[['Packages','/events#packages'],['Check my date','/events#inquiry']]],
      ['Event + social bundle','/offer-event-social-bundle','/assets/icons/cover-event-bundle.svg','Content ready in 72 hours',[['See offer','/offer-event-social-bundle']]],
    ], side: [['Events overview','/events'],['Check my date','/events#inquiry'],['Event case studies','/work#events'],['Book a call','#call']] },
    '/business': { cols: 3, items: [
      ['Commercial photo & video','/commercial-photography-video','/assets/icons/cover-svc-commercial.svg','From 400,000 RWF',[['Learn','/commercial-photography-video'],['Book','/commercial-photography-video#inquiry']]],
      ['Branding & design','/branding-graphic-design','/assets/icons/cover-svc-branding.svg','From 250,000 RWF',[['Learn','/branding-graphic-design'],['Book','/branding-graphic-design#inquiry']]],
      ['Social media & content','/social-media-content','/assets/icons/cover-svc-social.svg','From 500,000 RWF / month',[['Learn','/social-media-content'],['Book','/social-media-content#inquiry']]],
      ['Web & digital','/web-digital','/assets/icons/cover-svc-web.svg','From 600,000 RWF',[['Learn','/web-digital'],['Book','/web-digital#inquiry']]],
      ['Business offers','/business#offers','/assets/icons/cover-business-offers.svg','Fixed starting prices',[['See offers','/business#offers']]],
    ], side: [['Business overview','/business'],['Get a quote','/business#inquiry'],['Book a call','#call']] },
    '/deals': { cols: 4, items: [
      ['Launch bundle','/offer-launch-bundle','/assets/icons/cover-launch-bundle.svg','Bundle 1,200,000 RWF',[['See offer','/offer-launch-bundle']]],
      ['Brand starter kit','/offer-brand-starter-kit','/assets/icons/cover-brand-kit.svg','Kit from 250,000 RWF',[['See offer','/offer-brand-starter-kit']]],
      ['Event + social bundle','/offer-event-social-bundle','/assets/icons/cover-event-bundle.svg','Bundle from 200,000 RWF',[['See offer','/offer-event-social-bundle']]],
      ['Book early, save 10%','/offer-wedding-early-booking','/assets/work/cases/wedding-mirindi-ange/06-800.webp','Weddings from 1,080,000 RWF',[['See offer','/offer-wedding-early-booking']]],
    ], side: [['All deals','/deals'],['Business deals','/deals#business'],['Event deals','/deals#events'],['Wedding deals','/deals#weddings']] },
    '/about': { cols: 3, items: [
      ['About CRT','/about','','Founded in Kigali in 2025',[['Our story','/about']]],
      ['Alain Cedrick','/about','','CEO & Creative Director',[['Meet the team','/about']]],
      ['Thierry “Ziggy” Nteziryayo','/about','','Director of Photography',[['Meet the team','/about']]],
    ], side: [['Contact','/contact'],['Book a call','#call'],['hello@crt.rw','mailto:hello@crt.rw'],['+250 796 356 035','tel:+250796356035']] },
  };
  (function(){
    const header = document.querySelector('.site-header');
    if(!header) return;
    // Hover panels only where there is a real pointer and room for them; checked live, so resizing works too.
    const wide = window.matchMedia('(hover: hover) and (pointer: fine) and (min-width: 761px)');
    const esc = s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;');
    const fix = h=> h==='#call' ? (BOOKING_URL || u('/contact')) : u(h);
    const ext = h=> h==='#call' && BOOKING_URL ? ' target="_blank" rel="noopener"' : '';
    const panel = document.createElement('div');
    panel.className = 'menu-panel';
    panel.innerHTML = '<div class="menu-bridge" aria-hidden="true"></div><div class="menu-stage"></div>';
    const stage = panel.querySelector('.menu-stage');
    const scrim = document.createElement('div');
    scrim.className = 'menu-scrim';
    document.body.append(scrim, panel);
    // Every panel is built once, up front, and kept in the page: switching between menus is an instant
    // crossfade instead of a rebuild (no photo re-decoding, no layout jump).
    const panes = {};
    const build = (key, cfg)=>{
      const pane = document.createElement('div');
      pane.className = 'menu-pane'; pane.dataset.key = key; pane.setAttribute('aria-hidden','true');
      pane.innerHTML = `<div class="menu-panel-grid cols-${cfg.cols}">` + cfg.items.slice(0, cfg.cols * 2).map(([n,h,img,meta,links])=>
        `<div class="menu-item">`+
        (img ? `<a class="menu-thumb" href="${fix(h)}" tabindex="-1" aria-hidden="true"><img src="${u(img)}" alt="" decoding="async" loading="eager"></a>` : '')+
        `<div class="menu-text"><a class="menu-name" href="${fix(h)}">${esc(n)}</a>`+
        (meta ? `<span class="menu-meta">${esc(meta)}</span>` : '')+
        `<span class="menu-links">${links.map(([l,u])=>`<a href="${fix(u)}"${ext(u)}>${esc(l)}</a>`).join('')}</span></div></div>`).join('') +
        `</div><div class="menu-panel-side">${cfg.side.map(([l,u])=>`<a href="${fix(u)}"${ext(u)}>${esc(l)}</a>`).join('')}</div>`;
      pane.querySelectorAll('a').forEach(a=>a.tabIndex = -1);
      stage.appendChild(pane); panes[key] = pane;
    };
    let built = false;
    const buildAll = ()=>{ if(built) return; built = true;
      Object.keys(MENU).forEach(k=>build(k, MENU[k]));
      if(window.__CRT_PRICE_MAP) crtReplaceNumbers(stage, window.__CRT_PRICE_MAP); };
    // Build as soon as the browser is idle, or at the latest when the pointer reaches the menu
    (window.requestIdleCallback || (f=>setTimeout(f, 600)))(()=>{ if(wide.matches) buildAll(); });
    header.addEventListener('pointerenter', ()=>{ if(wide.matches) buildAll(); });

    let openT, closeT, current = null, shownKey = null;
    const isOpen = ()=>document.body.classList.contains('menu-open');
    const place = ()=>{ panel.style.top = header.getBoundingClientRect().bottom + 'px'; };
    const show = (link)=>{
      const key = pageKey(link.href), pane = panes[key];
      if(!pane) return;
      place();
      if(shownKey !== key){
        const prev = shownKey && panes[shownKey];
        // animate the panel height between menus of different size
        const from = stage.offsetHeight;
        if(prev){ prev.classList.remove('is-active'); prev.setAttribute('aria-hidden','true'); prev.querySelectorAll('a').forEach(a=>a.tabIndex = -1); }
        pane.classList.add('is-active'); pane.setAttribute('aria-hidden','false'); pane.querySelectorAll('a').forEach(a=>a.tabIndex = 0);
        const to = pane.offsetHeight;
        if(isOpen() && from && from !== to){
          stage.style.height = from + 'px'; stage.offsetHeight; stage.style.height = to + 'px';
          clearTimeout(stage._t); stage._t = setTimeout(()=>{ stage.style.height = ''; }, 260);
        }
        shownKey = key;
      }
      if(current !== link){ if(current) current.classList.remove('is-open'); current = link; link.classList.add('is-open'); }
      document.body.classList.add('menu-open');
    };
    // Hover intent: when nothing is open, wait a beat so sweeping across the bar doesn't flash panels;
    // once a panel is open, moving to another menu item switches instantly.
    const open = (link, now)=>{
      if(!wide.matches) return;
      buildAll(); clearTimeout(closeT); clearTimeout(openT);
      if(now || isOpen()) show(link); else openT = setTimeout(()=>show(link), 90);
    };
    const hide = ()=>{
      document.body.classList.remove('menu-open');
      if(current){ current.classList.remove('is-open'); current = null; }
    };
    const close = (delay)=>{ clearTimeout(openT); clearTimeout(closeT); closeT = setTimeout(hide, delay == null ? 220 : delay); };
    const keep = ()=>{ clearTimeout(closeT); };
    document.querySelectorAll('.nav-links a').forEach(link=>{
      if(MENU[pageKey(link.href)]){
        link.setAttribute('aria-haspopup','true');
        link.addEventListener('pointerenter', ()=>open(link));
        link.addEventListener('focus', ()=>open(link, true));
        link.addEventListener('pointerleave', ()=>close());
      } else {
        link.addEventListener('pointerenter', ()=>close(60));
      }
    });
    // The bridge fills the gap between the bar and the panel, so crossing it never counts as leaving
    panel.addEventListener('pointerenter', keep);
    panel.addEventListener('pointerleave', ()=>close());
    panel.addEventListener('focusout', e=>{ if(!panel.contains(e.relatedTarget) && !(e.relatedTarget && e.relatedTarget.closest('.nav-links'))) close(0); });
    scrim.addEventListener('pointerenter', ()=>close(120));
    scrim.addEventListener('click', ()=>close(0));
    document.addEventListener('keydown', e=>{ if(e.key==='Escape' && isOpen()){ close(0); if(current) current.focus(); } });
    wide.addEventListener && wide.addEventListener('change', ()=>{ if(!wide.matches) hide(); });
    // Keyboard: close the panel once focus leaves both the menu and the panel.
    header.addEventListener('focusout', e=>{ const to = e.relatedTarget; if(!to || (!header.contains(to) && !panel.contains(to))) close(); });
    window.addEventListener('scroll', ()=>{ if(document.body.classList.contains('menu-open')) place(); }, {passive:true});
  })();

  // ---------------------------------------------------------------
  // Live prices + wedding package contents, edited in /admin.
  // The pages keep today's prices as a fallback; when the dashboard
  // has different values, every matching price on the page is swapped.
  // ---------------------------------------------------------------
  (function(){
    const CFG = window.CRT_CONFIG || {};
    if(!CFG.SUPABASE_URL || !CFG.SUPABASE_ANON_KEY) return;
    // Prices exactly as written in the pages today. Don't edit these here; edit them in /admin.
    const BASE = {basic:1200000, standard:2000000, premium:3000000, vip:4500000};
    const fmt = n => Number(n).toLocaleString('en-US');
    const url = CFG.SUPABASE_URL.replace(/\/$/,'') + '/rest/v1/site_content?select=key,value';
    fetch(url, {headers:{'apikey':CFG.SUPABASE_ANON_KEY,'Authorization':'Bearer '+CFG.SUPABASE_ANON_KEY}})
      .then(r => r.ok ? r.json() : [])
      .then(rows => {
        const c = {}; (rows||[]).forEach(r => { c[r.key] = r.value; });
        c.prices = c.prices_v2; c.packages = c.wedding_packages;
        if(c.prices){
          const map = {};
          for(const k in BASE){
            const v = Number(c.prices[k]);
            if(v > 0 && v !== BASE[k]) map[fmt(BASE[k])] = fmt(v);
          }
          ['basic','standard','premium','vip'].forEach(k => {          // early booking = 10% off
            const v = Number(c.prices[k]);
            if(v > 0 && v !== BASE[k]) map[fmt(Math.round(BASE[k]*0.9))] = fmt(Math.round(v*0.9/1000)*1000);
          });
          if(Object.keys(map).length){ window.__CRT_PRICE_MAP = map; crtReplaceNumbers(document.body, map); }
        }
        if(Array.isArray(c.testimonials) && c.testimonials.length){
          const sec = document.querySelector('[data-testimonials]'), list = sec && sec.querySelector('[data-testimonials-list]');
          if(list){
            list.innerHTML = '';
            c.testimonials.slice(0, 6).forEach(t => {
              if(!t || !t.quote || !t.name) return;
              const fig = document.createElement('figure'); fig.className = 't-card';
              const q = document.createElement('blockquote'); q.textContent = '“' + t.quote + '”';
              const cap = document.createElement('figcaption'); const b = document.createElement('strong'); b.textContent = t.name; cap.appendChild(b);
              if(t.role){ const r = document.createElement('span'); r.textContent = t.role; cap.appendChild(r); }
              fig.append(q, cap); list.appendChild(fig);
            });
            sec.hidden = !list.children.length;
          }
        }
        if(c.packages){
          document.querySelectorAll('ul.package-list[data-package]').forEach(ul => {
            const items = c.packages[ul.dataset.package];
            if(!Array.isArray(items) || !items.length) return;
            const short = !!ul.querySelector('li.more');
            const shown = short ? items.slice(0,3) : items;
            ul.innerHTML = '';
            shown.forEach(t => { const li = document.createElement('li'); li.textContent = t; ul.appendChild(li); });
            if(short && items.length > 3){ const li = document.createElement('li'); li.className = 'more'; li.textContent = 'and ' + (items.length - 3) + ' more'; ul.appendChild(li); }
          });
        }
      }).catch(()=>{});
  })();

  // ---------------------------------------------------------------
  // Case study media (film + photos), uploaded in /admin → Case studies.
  // Visitors only see sections that have content. Add ?preview=1 to the
  // page address to see the empty slots as placeholders.
  // ---------------------------------------------------------------
  (function(){
    const page = document.querySelector('[data-case]');
    if(!page) return;
    const slug = page.dataset.case;
    const preview = params.has('preview');
    const SLOTS = ['The full room during a session','Speakers on stage','Attendees in conversation between sessions','Both brands’ logos on stage','Q&A with the audience','Speakers and organisers group photo'];
    const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const safeUrl = u => { try{ const x = new URL(u, location.href); return (x.protocol === 'https:' || x.origin === location.origin) ? x.href : ''; }catch(e){ return ''; } };
    function filmHTML(v){
      const url = safeUrl(v.url); if(!url) return '';
      const yt = url.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)([\w-]{11})/);
      if(yt) return `<iframe src="https://www.youtube-nocookie.com/embed/${yt[1]}?rel=0" title="Highlight film" loading="lazy" allow="accelerometer; autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>`;
      const vm = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
      if(vm) return `<iframe src="https://player.vimeo.com/video/${vm[1]}" title="Highlight film" loading="lazy" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>`;
      if(v.type === 'file' || /\.(mp4|webm|mov)(\?|$)/i.test(url)) return `<video src="${esc(url)}" controls preload="metadata" playsinline></video>`;
      return `<a class="btn" href="${esc(url)}" target="_blank" rel="noopener">Watch the highlight film ↗</a>`;
    }
    function render(entry){
      entry = entry || {};
      const filmSec = document.querySelector('[data-case-film]'), filmSlot = filmSec && filmSec.querySelector('[data-film-slot]');
      if(filmSlot){
        const html = entry.video && entry.video.url ? filmHTML(entry.video) : '';
        if(html){ filmSlot.innerHTML = html; filmSec.hidden = false; }
        else if(preview){ filmSlot.innerHTML = '<div class="ph-box film-ph"><span>Highlight film placeholder</span><small>Add a YouTube or Vimeo link, or upload the video, in /admin → Case studies</small></div>'; filmSec.hidden = false; }
      }
      const galSec = document.querySelector('[data-case-gallery]'), gal = galSec && galSec.querySelector('[data-gallery-slot]');
      if(gal){
        const photos = (entry.photos || []).filter(p => p && safeUrl(p.url));
        let html = photos.map(p => `<figure class="cs-tile"><img src="${esc(safeUrl(p.url))}" alt="${esc(p.caption || '')}" loading="lazy"></figure>`).join('');
        if(preview) for(let i = photos.length; i < SLOTS.length; i++) html += `<figure class="cs-tile ph-tile"><div class="ph-box"><span>Photo placeholder</span><small>${esc(SLOTS[i])}</small></div></figure>`;
        if(html){ gal.innerHTML = html; galSec.hidden = false; }
      }
    }
    const CFG = window.CRT_CONFIG || {};
    if(!CFG.SUPABASE_URL || !CFG.SUPABASE_ANON_KEY){ render(null); return; }
    fetch(CFG.SUPABASE_URL.replace(/\/$/,'') + '/rest/v1/site_content?select=value&key=eq.case_studies',
          {headers:{'apikey':CFG.SUPABASE_ANON_KEY,'Authorization':'Bearer '+CFG.SUPABASE_ANON_KEY}})
      .then(r => r.ok ? r.json() : [])
      .then(rows => render(rows && rows[0] && rows[0].value ? rows[0].value[slug] : null))
      .catch(() => render(null));
  })();

  // Click tracking (only active once GA_ID / META_PIXEL_ID are set above).
  document.querySelectorAll('[data-track]').forEach(el=>el.addEventListener('click',()=>{
    const eventName = el.dataset.track;
    if(typeof window.gtag === 'function') window.gtag('event', eventName);
    if(typeof window.fbq === 'function'){
      if(/book_call/.test(eventName)) fbq('track','Schedule');
      else if(/whatsapp/.test(eventName)) fbq('track','Contact');
    }
  }));
})();

// Footer: keep the copyright year current
document.querySelectorAll('[data-year]').forEach(el=>{ el.textContent = new Date().getFullYear(); });

// ---------------------------------------------------------------
// Photo framing: every photo cropped with object-fit:cover gets a
// focal point, so faces and subjects stay in frame at any shape.
// Add an entry here (file name without -800 / .webp) to fine-tune.
// ---------------------------------------------------------------
(function(){
  const FOCUS = {
    'workshop':'25% 35%',
    'wedding-mirindi-ange/cover':'50% 24%', 'wedding-mirindi-ange/06':'50% 26%', 'wedding-sandra-mathias/01':'50% 40%', 'eloge-alice/cover':'50% 38%', 'wedding-sandra-mathias/cover':'50% 34%',
    'zora-lounge/cover':'50% 45%', 'kings-memo/cover':'50% 50%', 'intore-dancers':'50% 40%', 'church-celebration':'50% 48%',
    'church-ceremony':'45% 38%', 'table-styling':'50% 55%', 'floral-centerpiece':'50% 55%',
    'decor-lounge':'50% 62%', 'decor-reception-lounge':'50% 62%', 'zora-lounge-poster':'50% 38%',
    'kings-memo-logo':'50% 50%', 'crt-website':'50% 45%', 'proposal-eloge-alice':'50% 40%',
    'wedding-sandra-mathias':'50% 32%', 'reception-sandra-mathias':'50% 48%',
    'wedding-party-mirindi-ange':'50% 72%',
    'alain-cedrick':'50% 22%', 'thierry-ziggy-nteziryayo':'50% 22%'
  };
  const key = src => { try{ return decodeURIComponent(new URL(src, location.href).pathname.split('/').pop()).replace(/(-800)?\.(webp|jpe?g|png)$/i,''); }catch(e){ return ''; } };
  const caseKey = src => { const m = String(src).match(/cases\/([^/]+)\/([^/.]+?)(-800)?\.webp/); return m ? m[1] + '/' + m[2] : ''; };
  function frame(img){
    if(img.dataset.framed || img.style.objectPosition) return;
    if(getComputedStyle(img).objectFit !== 'cover') return;
    const src = img.currentSrc || img.src, k = key(src), ck = caseKey(src);
    let pos = FOCUS[ck] || FOCUS[k] || (/^cover-/.test(k) ? '50% 50%' : '');
    if(!pos){
      const w = img.naturalWidth, h = img.naturalHeight;
      if(!w || !h) return;                       // try again once it has loaded
      pos = h > w * 1.05 ? '50% 30%' : '50% 42%'; // portraits: keep heads in; landscapes: slightly above centre
    }
    img.style.objectPosition = pos; img.dataset.framed = '1';
  }
  function scan(root){ (root || document).querySelectorAll('img').forEach(img=>{ frame(img); if(!img.dataset.framed && !img.complete) img.addEventListener('load', ()=>frame(img), {once:true}); }); }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ()=>scan()); else scan();
  window.addEventListener('load', ()=>scan());
  new MutationObserver(ms=>ms.forEach(m=>m.addedNodes.forEach(n=>{ if(n.nodeType===1){ if(n.tagName==='IMG') frame(n); else scan(n); } }))).observe(document.documentElement, {childList:true, subtree:true});
})();

// ---------------------------------------------------------------
// Portfolio pop-up: click any photo in a case-study gallery to see it
// large, then browse left/right (arrows, keyboard ← →, or swipe).
// ---------------------------------------------------------------
(function(){
  const SEL = '.cs-gallery .cs-tile:not(.ph-tile) img';
  let box, imgEl, countEl, capEl, list = [], idx = 0, lastFocus = null;
  const big = img => {
    const ss = img.getAttribute('srcset');
    if(ss){ const best = ss.split(',').map(s=>s.trim().split(/\s+/)).sort((a,b)=>parseInt(b[1])-parseInt(a[1]))[0]; if(best) return new URL(best[0], location.href).href; }
    return (img.currentSrc || img.src).replace(/-800(\.\w+)$/, '$1');
  };
  function build(){
    box = document.createElement('div');
    box.className = 'lightbox'; box.hidden = true;
    box.setAttribute('role','dialog'); box.setAttribute('aria-modal','true'); box.setAttribute('aria-label','Photo viewer');
    box.innerHTML = '<button class="lb-close" type="button" aria-label="Close">×</button>'+
      '<button class="lb-nav lb-prev" type="button" aria-label="Previous photo">‹</button>'+
      '<figure class="lb-stage"><img alt=""><figcaption class="lb-cap"></figcaption></figure>'+
      '<button class="lb-nav lb-next" type="button" aria-label="Next photo">›</button>'+
      '<div class="lb-count" aria-live="polite"></div>';
    document.body.appendChild(box);
    imgEl = box.querySelector('.lb-stage img'); countEl = box.querySelector('.lb-count'); capEl = box.querySelector('.lb-cap');
    box.querySelector('.lb-close').addEventListener('click', close);
    box.querySelector('.lb-prev').addEventListener('click', e=>{ e.stopPropagation(); go(-1); });
    box.querySelector('.lb-next').addEventListener('click', e=>{ e.stopPropagation(); go(1); });
    box.addEventListener('click', e=>{ if(e.target === box || e.target.classList.contains('lb-stage')) close(); });
    // swipe
    let x0 = null, y0 = null;
    box.addEventListener('touchstart', e=>{ x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; }, {passive:true});
    box.addEventListener('touchend', e=>{
      if(x0 === null) return;
      const dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0; x0 = null;
      if(Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy)) go(dx < 0 ? 1 : -1);
      else if(dy > 90 && Math.abs(dy) > Math.abs(dx)) close();
    });
    document.addEventListener('keydown', e=>{
      if(box.hidden) return;
      if(e.key === 'Escape') close();
      else if(e.key === 'ArrowRight') go(1);
      else if(e.key === 'ArrowLeft') go(-1);
      else if(e.key === 'Tab'){ // keep focus inside the viewer
        const f = [...box.querySelectorAll('button')]; const i = f.indexOf(document.activeElement);
        e.preventDefault(); f[(i + (e.shiftKey ? -1 : 1) + f.length) % f.length].focus();
      }
    });
  }
  function show(){
    const img = list[idx];
    box.classList.add('is-loading');
    imgEl.onload = ()=>box.classList.remove('is-loading');
    imgEl.src = big(img); imgEl.alt = img.alt || '';
    capEl.textContent = img.alt || ''; capEl.hidden = !img.alt;
    countEl.textContent = (idx + 1) + ' / ' + list.length;
    const multi = list.length > 1;
    box.querySelectorAll('.lb-nav').forEach(b=>b.hidden = !multi);
    [idx + 1, idx - 1].forEach(j=>{ const n = list[(j + list.length) % list.length]; if(n){ const p = new Image(); p.src = big(n); } });
  }
  function go(d){ if(list.length < 2) return; idx = (idx + d + list.length) % list.length; show(); }
  function open(img){
    if(!box) build();
    const gal = img.closest('.cs-gallery');
    list = [...gal.querySelectorAll('.cs-tile:not(.ph-tile) img')];
    idx = Math.max(0, list.indexOf(img));
    lastFocus = document.activeElement;
    box.hidden = false; document.documentElement.classList.add('lb-open');
    requestAnimationFrame(()=>box.classList.add('is-open'));
    show(); box.querySelector('.lb-close').focus();
  }
  function close(){
    box.classList.remove('is-open'); document.documentElement.classList.remove('lb-open');
    setTimeout(()=>{ box.hidden = true; imgEl.removeAttribute('src'); }, 200);
    if(lastFocus && lastFocus.focus) lastFocus.focus();
  }
  // Make gallery photos clickable and keyboard-reachable (also ones added later from the dashboard)
  function prep(root){ (root || document).querySelectorAll('.cs-gallery .cs-tile:not(.ph-tile)').forEach(t=>{ if(t.dataset.lb) return; t.dataset.lb = '1'; t.tabIndex = 0; t.setAttribute('role','button'); t.setAttribute('aria-label','Open photo' + (t.querySelector('img') && t.querySelector('img').alt ? ': ' + t.querySelector('img').alt : '')); }); }
  prep();
  new MutationObserver(()=>prep()).observe(document.body, {childList:true, subtree:true});
  document.addEventListener('click', e=>{ const t = e.target.closest('.cs-gallery .cs-tile:not(.ph-tile)'); if(t && t.querySelector('img')){ e.preventDefault(); open(t.querySelector('img')); } });
  document.addEventListener('keydown', e=>{ if((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('.cs-gallery .cs-tile[data-lb]')){ e.preventDefault(); open(e.target.querySelector('img')); } });
})();

// ---------------------------------------------------------------
// Offers page: filter tabs (All / Business / Events / Weddings).
// Links such as /deals#weddings open with that tab selected.
// ---------------------------------------------------------------
(function(){
  const root = document.querySelector('[data-offer-filter]');
  if(!root) return;
  const tabs = [...root.querySelectorAll('[data-filter]')];
  const items = [...root.querySelectorAll('[data-cat]')];
  const apply = (cat, scroll)=>{
    tabs.forEach(t => t.setAttribute('aria-selected', String(t.dataset.filter === cat)));
    items.forEach(el => { el.hidden = !(cat === 'all' || el.dataset.cat === cat); });
    root.classList.toggle('is-filtered', cat !== 'all');
    if(scroll) root.scrollIntoView({behavior:'smooth', block:'start'});
  };
  tabs.forEach(t => t.addEventListener('click', ()=>{
    apply(t.dataset.filter, false);
    try{ history.replaceState(null, '', t.dataset.filter === 'all' ? '#offers' : '#' + t.dataset.filter); }catch(e){}
  }));
  // keyboard: arrow keys move between tabs
  root.querySelector('[role="tablist"]').addEventListener('keydown', e=>{
    const i = tabs.indexOf(document.activeElement); if(i < 0) return;
    if(e.key === 'ArrowRight' || e.key === 'ArrowLeft'){
      e.preventDefault(); const n = tabs[(i + (e.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length]; n.focus(); n.click();
    }
  });
  const fromHash = ()=>{ const h = location.hash.slice(1); if(['business','events','weddings'].includes(h)) apply(h, true); };
  fromHash(); window.addEventListener('hashchange', fromHash);
})();

// Work page: category filter (links like /work#events open filtered)
(function(){
  const bar = document.querySelector('.wk-filter'); if(!bar) return;
  const groups = [...document.querySelectorAll('.wk-group')];
  function show(cat, push){
    if(!groups.some(g => g.dataset.group === cat)) cat = 'all';
    bar.querySelectorAll('a').forEach(a => { const on = a.dataset.workFilter === cat; a.classList.toggle('is-active', on); a.setAttribute('aria-current', on ? 'true' : 'false'); });
    groups.forEach(g => g.hidden = cat !== 'all' && g.dataset.group !== cat);
    if(push) history.replaceState(null, '', cat === 'all' ? location.pathname : '#' + cat);
  }
  bar.addEventListener('click', e => { const a = e.target.closest('a[data-work-filter]'); if(!a) return; e.preventDefault(); show(a.dataset.workFilter, true); const top = bar.closest('.section').getBoundingClientRect().top + scrollY - 90; if(scrollY > top) scrollTo({top, behavior:'smooth'}); });
  window.addEventListener('hashchange', () => show(location.hash.slice(1)));
  show(location.hash.slice(1));
})();
