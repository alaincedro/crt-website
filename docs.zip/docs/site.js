// WhatsApp links: phones open the app via wa.me; computers go straight to WhatsApp Web in a new tab,
// skipping the api.whatsapp.com share page (which can ask visitors to update their browser).
let CRT_WA = '250796356035';
function crtIsDesktop(){ return !/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) && window.matchMedia('(hover: hover) and (pointer: fine)').matches; }
function crtWaUrl(text){
  const t = encodeURIComponent(text || '');
  return crtIsDesktop() ? 'https://web.whatsapp.com/send?phone=' + CRT_WA + (t ? '&text=' + t : '') : 'https://wa.me/' + CRT_WA + (t ? '?text=' + t : '');
}
// ---------------------------------------------------------------
// v9.6 Content layer: words, photos, links and site-wide details edited in /admin → Content.
// The pages keep their built-in content as the fallback. Saved changes are stored in Supabase
// (site_content: page_edits, site_settings), cached in the browser so they apply before first paint
// on later visits, and refreshed in the background.
//   page_edits    {"*": [...], "/weddings": [...]}   each item {k:"text"|"img"|"link", from, to}
//   site_settings {contact:{phone,email}, announcement:{on,text,link,href}, showreel:{mp4}}
// ---------------------------------------------------------------
(function(){
  const CFG = window.CRT_CONFIG || {};
  const me = document.currentScript, ROOT = me ? new URL('.', me.src).href : new URL('.', location.href).href;
  const EDIT = /[?&]crt_edit=1/.test(location.search) && window.parent !== window;   // page shown inside the admin editor
  if(EDIT){ window.__CRT_EDIT = true; document.documentElement.classList.add('crt-edit'); }
  const KEY = 'crt-content-v1';
  const norm = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
  const rel = href => { try{ const h = new URL(href, location.href).href; return h.startsWith(ROOT) ? '/' + h.slice(ROOT.length) : h; }catch(e){ return String(href || ''); } };
  const page = (() => { const k = rel(location.href.split(/[?#]/)[0]).replace(/(^|\/)index\.html$/, '$1').replace(/\/$/, ''); return k || '/'; })();
  const keyOfImg = img => img._crtFrom || rel(img.getAttribute('src') || '');
  const keyOfLink = a => a._crtFrom || rel(a.getAttribute('href') || '');
  const resolve = to => /^\//.test(to) && !/^\/\//.test(to) ? new URL(to.slice(1), ROOT).href : to;
  const safe = u => { try{ const x = new URL(resolve(u), location.href); return /^(https?:|mailto:|tel:)$/.test(x.protocol); }catch(e){ return false; } };
  const textNodes = root => {
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {acceptNode: n => (!n.nodeValue.trim() || (n.parentElement && n.parentElement.closest('script,style,textarea,noscript,select'))) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT});
    const out = []; while(w.nextNode()) out.push(w.currentNode); return out;
  };
  const setText = (n, to) => { const v = n.nodeValue; n.nodeValue = (/^\s/.test(v) ? ' ' : '') + to + (/\s$/.test(v) ? ' ' : ''); };
  function stamp(){ textNodes(document.body).forEach(n => { if(n._crtFrom === undefined) n._crtFrom = norm(n.nodeValue); }); }
  function applyEdits(list){
    if(!Array.isArray(list) || !list.length || !document.body) return;
    const T = new Map(), I = new Map(), L = new Map();
    list.forEach(e => { if(!e || typeof e.from !== 'string' || typeof e.to !== 'string') return; (e.k === 'img' ? I : e.k === 'link' ? L : T).set(e.from, e.to); });
    if(T.size) textNodes(document.body).forEach(n => {
      const from = n._crtFrom !== undefined ? n._crtFrom : norm(n.nodeValue);
      if(T.has(from)){ n._crtFrom = from; if(norm(n.nodeValue) !== T.get(from)) setText(n, T.get(from)); }
    });
    if(I.size) document.querySelectorAll('img[src]').forEach(img => {
      const from = keyOfImg(img); if(!I.has(from) || !safe(I.get(from))) return;
      img._crtFrom = from; const to = resolve(I.get(from)); if(img.src !== to){ img.removeAttribute('srcset'); img.removeAttribute('sizes'); img.src = to; }
    });
    if(L.size) document.querySelectorAll('a[href]').forEach(a => {
      const from = keyOfLink(a); if(!L.has(from) || !safe(L.get(from))) return;
      a._crtFrom = from; a.href = resolve(L.get(from));
    });
  }
  const PHONE = {digits:'250796356035', shown:'+250 796 356 035'}, MAIL = 'hello@crt.rw';
  function applySettings(st){
    if(!st) return;
    const c = st.contact || {};
    const digits = String(c.phone || '').replace(/\D/g, '');
    if(digits.length >= 10 && digits !== PHONE.digits){
      const shown = norm(c.phone);
      CRT_WA = digits;
      document.querySelectorAll('a[href]').forEach(a => { const h = a.getAttribute('href'); if(h.indexOf(PHONE.digits) > -1) a.setAttribute('href', h.split(PHONE.digits).join(digits)); });
      textNodes(document.body).forEach(n => { if(n.nodeValue.indexOf(PHONE.shown) > -1) n.nodeValue = n.nodeValue.split(PHONE.shown).join(shown); });
    }
    const mail = norm(c.email);
    if(/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(mail) && mail !== MAIL){
      document.querySelectorAll('a[href^="mailto:' + MAIL + '"]').forEach(a => a.setAttribute('href', a.getAttribute('href').replace(MAIL, mail)));
      textNodes(document.body).forEach(n => { if(n.nodeValue.indexOf(MAIL) > -1) n.nodeValue = n.nodeValue.split(MAIL).join(mail); });
    }
    if(st.announcement) window.CRT_ANNOUNCE = st.announcement;
    if(st.showreel && st.showreel.mp4 && safe(st.showreel.mp4)) window.CRT_SHOWREEL = {mp4: resolve(st.showreel.mp4)};
  }
  let current = null;
  function run(c){
    if(!c) return;
    current = c;
    if(!EDIT){ const pe = c.page_edits || {}; applyEdits([].concat(pe['*'] || [], pe[page] || [])); }
    applySettings(c.site_settings);
    document.dispatchEvent(new CustomEvent('crt:content', {detail: c}));
  }
  if(EDIT){ stamp(); window.__CRT_EDITOR = {page, norm, rel, keyOfImg, keyOfLink, textNodes, setText, apply: applyEdits, stamp}; }
  let cached = null; try{ cached = JSON.parse(localStorage.getItem(KEY) || 'null'); }catch(e){}
  run(cached);
  // The menu, forms and other parts are built by script after this point: apply again once they exist.
  const again = () => run(current);
  document.addEventListener('DOMContentLoaded', () => setTimeout(again, 0));
  window.addEventListener('load', () => setTimeout(again, 1600));
  if(CFG.SUPABASE_URL && CFG.SUPABASE_ANON_KEY){
    fetch(CFG.SUPABASE_URL.replace(/\/$/, '') + '/rest/v1/site_content?select=key,value&key=in.(page_edits,site_settings)',
      {headers: {'apikey': CFG.SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + CFG.SUPABASE_ANON_KEY}})
      .then(r => r.ok ? r.json() : null)
      .then(rows => {
        if(!rows) return;
        const c = {}; rows.forEach(r => { c[r.key] = r.value; });
        const txt = JSON.stringify(c);
        try{ localStorage.setItem(KEY, txt); }catch(e){}
        if(txt !== JSON.stringify(cached || {})) run(c);
      }).catch(() => {});
  }
})();

document.addEventListener('click', e => {
  const a = e.target.closest && e.target.closest('a[href*="wa.me/"]'); if(!a || !crtIsDesktop()) return;
  try{ const u = new URL(a.href); const num = u.pathname.replace(/\D/g, '') || CRT_WA;
    a.href = 'https://web.whatsapp.com/send?phone=' + num + (u.searchParams.get('text') ? '&text=' + encodeURIComponent(u.searchParams.get('text')) : '');
    a.target = '_blank'; a.rel = 'noopener'; }catch(err){}
}, true);
(function(){
  // The site works straight from a folder (no server), so links are built relative
  // to the folder that holds this script. u('/contact#inquiry') -> .../contact/index.html#inquiry
  const ROOT = (document.currentScript && document.currentScript.src)
    ? new URL('.', document.currentScript.src).href : new URL('/', location.href).href;
  const u = p=>{
    if(!p || p[0] !== '/') return p;
    const m = p.match(/^([^?#]*)(.*)$/); let path = m[1];
    if(path === '/' || path.endsWith('/')) path += 'index.html';
    else if(!/\.[a-z0-9]+$/i.test(path.split('/').pop())) path += '/index.html';
    return new URL(path.slice(1) + m[2], ROOT).href;
  };
  // '.../business/index.html' -> '/business' (used to match menu entries)
  const pageKey = href=>{
    const h = new URL(href, location.href).href.split(/[?#]/)[0];
    if(!h.startsWith(ROOT)) return null;
    return '/' + h.slice(ROOT.length).replace(/(^|\/)index\.html$/, '').replace(/\/$/, '');
  };
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.nav-links');
  if(nav) nav.querySelectorAll(':scope > a').forEach(a=>{ if(pageKey(a.href) === '/about') a.classList.add('nav-about'); });
  if(toggle && nav){
    // Phone menu: Escape closes, focus moves into the menu and back to the button, Tab stays inside, page behind stops scrolling.
    const isOpenNav = ()=>nav.classList.contains('open');
    const focusables = ()=>[toggle, ...nav.querySelectorAll('a[href], button')].filter(el=>!el.hidden && el.offsetParent !== null);
    const setNav = (open, moveFocus)=>{
      nav.classList.toggle('open', open);
      toggle.setAttribute('aria-expanded', String(open));
      toggle.textContent = open ? 'Close' : 'Menu';
      document.documentElement.classList.toggle('nav-locked', open);
      if(moveFocus){ if(open){ const f = focusables()[1]; if(f) f.focus({preventScroll:true}); } else toggle.focus({preventScroll:true}); }
    };
    toggle.addEventListener('click', e=>setNav(!isOpenNav(), e.detail === 0));
    document.addEventListener('click', e=>{ if(isOpenNav() && !e.target.closest('.site-header')) setNav(false, false); });
    nav.addEventListener('click', e=>{ if(e.target.closest('a')) setNav(false, false); });
    document.addEventListener('keydown', e=>{
      if(!isOpenNav()) return;
      if(e.key === 'Escape'){ e.preventDefault(); setNav(false, true); return; }
      if(e.key !== 'Tab') return;
      const f = focusables(); if(!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if(e.shiftKey && document.activeElement === first){ e.preventDefault(); last.focus(); }
      else if(!e.shiftKey && document.activeElement === last){ e.preventDefault(); first.focus(); }
    });
    const navWide = window.matchMedia('(min-width: 761px)');
    navWide.addEventListener && navWide.addEventListener('change', ()=>{ if(navWide.matches && isOpenNav()) setNav(false, false); });
  }
  const params = new URLSearchParams(window.location.search);

  // Swap prices in visible text, e.g. {"600,000":"1,200,000"}. One pass, so a new
  // price is never swapped twice. Skips scripts, styles and form fields.
  function crtReplaceNumbers(root, map){
    const keys = Object.keys(map);
    if(!root || !keys.length) return;
    const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const re = new RegExp('(^|[^\\d,])(' + keys.map(esc).join('|') + ')(?![\\d,])', 'g');
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: n => (n.parentElement && n.parentElement.closest('script,style,textarea,input')) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT
    });
    const nodes = []; while(walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(n => { const t = n.nodeValue; if(re.test(t)){ re.lastIndex = 0; n.nodeValue = t.replace(re, (m, a, b) => a + map[b]); } re.lastIndex = 0; });
  }

  // ---------------------------------------------------------------
  // Analytics: paste your IDs here to switch tracking on.
  //   GA_ID         e.g. 'G-XXXXXXXXXX'   (Google Analytics 4)
  //   META_PIXEL_ID e.g. '123456789012345' (Meta / Facebook Pixel)
  // While they are empty, no tracking code loads at all.
  // ---------------------------------------------------------------
  // Where website enquiries are emailed (FormSubmit form-to-email service).
  const ENQUIRY_EMAIL = 'kigalimediaagency@gmail.com';
  window.CRT_FORM_EMAIL = ENQUIRY_EMAIL;   // used by the review form (v9.3)
  // Public address shown to visitors if sending fails.
  const PUBLIC_EMAIL = 'hello@crt.rw';
  const GA_ID = 'G-J6F328BM6H';
  const META_PIXEL_ID = '1506800021342255';
  // Tracking only loads after the visitor accepts the cookie notice (Rwanda data
  // protection law, Law No. 058/2021). With both IDs empty, no notice is shown.
  const CONSENT_KEY = 'crt_consent';
  const getConsent = ()=>{ try{ return localStorage.getItem(CONSENT_KEY); }catch(e){ return null; } };
  const setConsent = v=>{ try{ localStorage.setItem(CONSENT_KEY, v); }catch(e){} };
  function loadTracking(){
    if(GA_ID){
      const s=document.createElement('script'); s.async=true; s.src='https://www.googletagmanager.com/gtag/js?id='+GA_ID; document.head.appendChild(s);
      window.dataLayer=window.dataLayer||[]; window.gtag=function(){dataLayer.push(arguments);}; gtag('js', new Date()); gtag('config', GA_ID, {anonymize_ip:true});
    }
    if(META_PIXEL_ID){
      !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', META_PIXEL_ID); fbq('track','PageView');
    }
  }
  if((GA_ID || META_PIXEL_ID) && !window.__CRT_EDIT){
    const choice = getConsent();
    if(choice === 'yes') loadTracking();
    else if(choice !== 'no'){
      const bar = document.createElement('div');
      bar.className = 'consent'; bar.setAttribute('role','region'); bar.setAttribute('aria-label','Cookie notice');
      bar.innerHTML = '<p>We use cookies to see which pages and ads work. <a href="/privacy/#cookies">Privacy</a></p>'+
        '<div class="consent-actions"><button type="button" class="btn small ghost" data-c="no">Decline</button><button type="button" class="btn small" data-c="yes">Accept</button></div>';
      bar.addEventListener('click', e=>{
        const b = e.target.closest('[data-c]'); if(!b) return;
        setConsent(b.dataset.c); bar.remove();
        if(b.dataset.c === 'yes') loadTracking();
      });
      // The notice is a slim bar docked to the bottom edge. It lifts the floating buttons instead of covering them,
      // and on the home page it waits for the first scroll so it never sits over the three price cards on arrival.
      const root = document.documentElement;
      const dock = ()=>{ root.style.setProperty('--consent-h', bar.offsetHeight + 'px'); };
      const show = ()=>{ if(bar.isConnected || getConsent() !== null) return; document.body.appendChild(bar); root.classList.add('has-consent'); dock(); window.addEventListener('resize', dock); };
      bar.addEventListener('click', e=>{ if(e.target.closest('[data-c]')){ root.classList.remove('has-consent'); root.style.removeProperty('--consent-h'); window.removeEventListener('resize', dock); } });
      if(document.querySelector('.hero-paths')){
        const onScroll = ()=>{ if(window.scrollY > 200){ window.removeEventListener('scroll', onScroll); show(); } };
        window.addEventListener('scroll', onScroll, {passive:true}); onScroll();
      } else show();
    }
  }
  // Privacy page: "Choose again" clears the saved cookie choice and shows the notice again.
  document.addEventListener('click', e=>{
    if(!e.target.closest('[data-consent-reset]')) return;
    try{ localStorage.removeItem(CONSENT_KEY); }catch(err){}
    location.reload();
  });
  const trackLead = (label)=>{
    if(typeof window.gtag==='function') gtag('event','generate_lead',{form_location:location.pathname,label:label});
    if(typeof window.fbq==='function') fbq('track','Lead',{content_name:label});
  };

  // Where did this visitor come from? Remember the ad / campaign for the session.
  const SOURCE_KEY = 'crt_source';
  (function(){
    const utm = ['utm_source','utm_medium','utm_campaign'].map(k=>params.get(k)).filter(Boolean);
    let src = utm.length ? utm.join(' / ') : (params.get('fbclid') ? 'facebook / instagram ad' : (params.get('gclid') ? 'google ad' : ''));
    try{
      if(src) sessionStorage.setItem(SOURCE_KEY, src);
      else if(!sessionStorage.getItem(SOURCE_KEY)){
        const ref = document.referrer && new URL(document.referrer).hostname;
        sessionStorage.setItem(SOURCE_KEY, ref && ref !== location.hostname ? ref : 'direct');
      }
    }catch(e){}
  })();
  const getSource = ()=>{ try{ return sessionStorage.getItem(SOURCE_KEY) || 'direct'; }catch(e){ return 'unknown'; } };

  document.querySelectorAll('[data-booking-form]').forEach(form=>{
    const formService = form.dataset.service || params.get('service') || 'Creative project';
    const formOffer = form.dataset.offer || params.get('offer') || '';
    const serviceField = form.querySelector('[name="service"]');
    const offerField = form.querySelector('[name="offer"]');
    if(serviceField) serviceField.value = params.get('service') || formService;
    if(offerField) offerField.value = params.get('offer') || formOffer;
    if(params.get('date')) { const dateField=form.querySelector('[name="date"]'); if(dateField) dateField.value=params.get('date'); }
    // Contact form: tick the matching "What do you need?" chips from ?service=
    const pre = (params.get('service') || '').toLowerCase();
    if(pre) [['photo','Photography'],['video','Video'],['film','Video'],['event','Event coverage'],['brand','Branding & design'],['design','Branding & design'],['social','Social media'],['web','Website'],['wedding','Wedding']]
      .forEach(([k, v]) => { if(pre.includes(k)){ const c = form.querySelector('[name="need"][value="' + v + '"]'); if(c) c.checked = true; } });
    const status = form.querySelector('.form-status');
    const sendBtn = form.querySelector('button[type="submit"]');
    const waBtn = form.querySelector('[data-send-whatsapp]');
    const sendLabel = sendBtn ? sendBtn.textContent : '';
    const collect = ()=>{
      const set = (n,v)=>{ const f=form.querySelector('[name="'+n+'"]'); if(f) f.value=v; };
      set('page', location.pathname);
      set('source', getSource());
      const data = new FormData(form);
      const needs = data.getAll('need');
      return {data, service: needs.length ? needs.join(', ') : (data.get('service') || formService), offer: data.get('offer') || formOffer};
    };
    // A copy of every enquiry goes to the admin dashboard (Supabase), if connected.
    const saveLead = ({data, service, offer}, channel)=>{
      const CFG = window.CRT_CONFIG || {};
      if(!CFG.SUPABASE_URL || !CFG.SUPABASE_ANON_KEY || data.get('bot-field')) return Promise.resolve(false);
      const cut = (v,n)=> (v||'').toString().slice(0,n) || null;
      try{
        return fetch(CFG.SUPABASE_URL.replace(/\/$/,'') + '/rest/v1/leads', {
          method:'POST', keepalive:true,
          headers:{'apikey':CFG.SUPABASE_ANON_KEY,'Authorization':'Bearer '+CFG.SUPABASE_ANON_KEY,'Content-Type':'application/json','Prefer':'return=minimal'},
          body: JSON.stringify({
            name: cut(data.get('name'),120) || 'Unknown', contact: cut(data.get('contact'),160) || 'Unknown',
            service: cut(service,120), offer: cut(offer,120), event_date: cut(data.get('date'),120),
            details: cut([data.get('company') ? 'Company: ' + data.get('company') : '', data.get('budget') ? 'Budget: ' + data.get('budget') : '', data.get('details')].filter(Boolean).join('\n'),2000), page: cut(location.pathname,200),
            source: cut(getSource() + ' · via ' + channel, 200)
          })
        }).then(r => r.ok).catch(() => false);
      }catch(err){ return Promise.resolve(false); }
    };
    const show = (kind, html)=>{ if(!status) return; status.className = 'form-status is-' + kind; status.innerHTML = html; status.hidden = false; };
    const waLink = ({data, service, offer})=>{
      const lines = [
        'Hi CRT Media Agency, I would like to enquire about a project.',
        'Service: ' + service,
        offer ? 'Offer/package: ' + offer : '',
        data.get('name') ? 'Name: ' + data.get('name') : '',
        data.get('company') ? 'Company: ' + data.get('company') : '',
        data.get('budget') ? 'Budget: ' + data.get('budget') : '',
        data.get('contact') ? 'Email or phone: ' + data.get('contact') : '',
        data.get('date') ? 'Preferred date/timeline: ' + data.get('date') : '',
        data.get('details') ? 'Project details: ' + data.get('details') : '',
      ].filter(Boolean);
      return crtWaUrl(lines.join('\n'));
    };

    // Choice 1 (default): email the enquiry to our inbox.
    form.addEventListener('submit', function(e){
      e.preventDefault();
      const info = collect(), data = info.data;
      if(data.get('bot-field')) return;
      const leadSaved = saveLead(info, 'email');
      trackLead(info.offer || info.service);
      const contact = (data.get('contact') || '').toString();
      const payload = {
        _subject: 'New website enquiry: ' + (info.offer || info.service) + ' – ' + (data.get('name') || ''),
        _template: 'table', _captcha: 'false',
        Name: data.get('name') || '', Company: data.get('company') || '—', 'WhatsApp or email': contact, Budget: data.get('budget') || '—',
        Service: info.service, 'Offer / package': info.offer || '—',
        'Date / timeline': data.get('date') || '—', Details: data.get('details') || '—',
        Page: location.href.split('#')[0], Source: getSource()
      };
      if(/@/.test(contact)) payload._replyto = contact;
      if(sendBtn){ sendBtn.disabled = true; sendBtn.textContent = 'Sending…'; }
      if(status) status.hidden = true;
      // The email (FormSubmit) and the dashboard copy (Supabase) run together. If either one lands, the enquiry
      // has reached us, so the visitor sees the thank-you. The error shows only if both fail.
      const mailed = fetch('https://formsubmit.co/ajax/' + ENQUIRY_EMAIL, {
        method:'POST', headers:{'Content-Type':'application/json','Accept':'application/json'}, body: JSON.stringify(payload)
      }).then(r => r.json().then(j => ({ok: r.ok, j})).catch(() => ({ok: r.ok, j: {}})))
        .then(({ok, j}) => ok && String(j.success) !== 'false').catch(() => false);
      Promise.all([mailed, leadSaved])
        .then(([m, l]) => {
          if(!m && !l) throw new Error('not sent');
          const name = (data.get('name') || '').toString().split(' ')[0];
          show('ok', '<strong>Thank you' + (name ? ', ' + name.replace(/[<>&]/g,'') : '') + '!</strong> Your enquiry has reached us. We usually reply within 2 hours.');
          form.reset();
          const sf = form.querySelector('[name="service"]'), of = form.querySelector('[name="offer"]');
          if(sf) sf.value = info.service; if(of) of.value = info.offer;
        })
        .catch(() => {
          show('error', 'Sorry, we couldn’t send that just now. Please <a href="' + waLink(info) + '" target="_blank" rel="noopener">send it on WhatsApp</a> or write to <a href="mailto:' + PUBLIC_EMAIL + '">' + PUBLIC_EMAIL + '</a>.');
        })
        .finally(() => { if(sendBtn){ sendBtn.disabled = false; sendBtn.textContent = sendLabel; } });
    });

    // Choice 2: send the same details on WhatsApp instead.
    if(waBtn) waBtn.addEventListener('click', function(){
      if(!form.reportValidity()) return;
      const info = collect();
      if(info.data.get('bot-field')) return;
      saveLead(info, 'WhatsApp');
      trackLead(info.offer || info.service);
      const url = waLink(info);
      if(crtIsDesktop()){
        window.open(url, '_blank', 'noopener');
        show('ok', '<strong>WhatsApp is opening in a new tab</strong> with your message ready. Press send there. Didn’t open? Use <em>Send enquiry</em> instead, or message us on +250 796 356 035.');
      } else window.location.href = url;
    });
  });
  document.querySelectorAll('[data-prefill-service]').forEach(link=>{
    const target = new URL(link.href, window.location.href);
    target.searchParams.set('service', link.dataset.prefillService);
    if(link.dataset.prefillOffer) target.searchParams.set('offer', link.dataset.prefillOffer);
    link.href = target.toString();
  });
  // Bottom action bar on every page: "Ask a question" (WhatsApp) + the page's main action.
  // Replaces the old floating WA circle and phone-only enquiry button.
  (function(){
    if(document.querySelector('[data-builder]')){ const w = document.querySelector('.whatsapp-float'); if(w) w.hidden = true; return; } // the builder has its own summary bar with the booking action
    const oldMain = document.querySelector('.mobile-booking a');
    const oldWa = document.querySelector('.whatsapp-float');
    const hasForm = !!document.getElementById('inquiry');
    const bar = document.createElement('div');
    bar.className = 'action-bar' + (document.querySelector('.hero-paths,.wd-hero') ? ' is-hidden' : '');
    const ask = document.createElement('a');
    ask.className = 'action-ask';
    ask.href = oldWa ? oldWa.href : 'https://wa.me/250796356035';
    ask.target = '_blank'; ask.rel = 'noopener';
    ask.dataset.track = 'bar_whatsapp';
    ask.innerHTML = '<span class="action-dot"></span><span class="lbl-long">Ask a question</span><span class="lbl-short">Ask</span>';
    const main = document.createElement('a');
    main.className = 'btn action-main';
    main.href = hasForm ? '#inquiry' : u('/contact#inquiry');
    main.dataset.track = 'bar_main';
    main.textContent = oldMain ? oldMain.textContent.trim() : 'Get a quote';
    // "Book a call" (filled with BOOKING_URL below; stays hidden if there is no link)
    const CAL_ICON = '<svg class="cal-ico" viewBox="0 0 20 20" aria-hidden="true"><rect x="3" y="4.5" width="14" height="12.5" rx="2.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M3 8.5h14M7 2.8v3.4M13 2.8v3.4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>';
    const call = document.createElement('a');
    call.className = 'action-call';
    call.href = u('/contact'); call.hidden = true;
    call.setAttribute('data-booking-link','');
    call.dataset.track = 'bar_book_call';
    call.innerHTML = CAL_ICON + '<span class="lbl-long">Book a free call</span><span class="lbl-short">Call</span>';
    bar.append(ask, call, main);
    document.body.appendChild(bar);
    // Header: "Book a call" beside "Get a quote"
    const navCta = document.querySelector('.nav-links .nav-cta');
    if(navCta){
      const actions = document.createElement('div');
      actions.className = 'nav-actions';
      const navCall = document.createElement('a');
      navCall.className = 'nav-call';
      navCall.href = u('/contact'); navCall.hidden = true;
      navCall.setAttribute('data-booking-link','');
      navCall.dataset.track = 'nav_book_call';
      navCall.innerHTML = CAL_ICON + '<span>Book a call</span>';
      navCta.parentNode.insertBefore(actions, navCta);
      actions.append(navCall, navCta);
      const navShop = document.querySelector('.nav-links .nav-shop');
      if(navShop) actions.append(navShop); // Shop sits at the far right, after "Get a quote"
    }
    document.querySelectorAll('.mobile-booking,.whatsapp-float').forEach(el=>el.remove());
    document.body.classList.add('has-action-bar');
    // Get out of the way when the form, the footer or the home hero tiles are on screen.
    const targets = [document.getElementById('inquiry'), document.querySelector('footer'), document.querySelector('.hero-paths'), document.querySelector('.wd-hero .cta-row')].filter(Boolean);
    if('IntersectionObserver' in window && targets.length){
      const seen = new Set();
      const io = new IntersectionObserver(entries=>{
        entries.forEach(e=>e.isIntersecting ? seen.add(e.target) : seen.delete(e.target));
        bar.classList.toggle('is-hidden', seen.size > 0);
      }, {threshold: 0.15});
      targets.forEach(t=>io.observe(t));
    }
  })();

  // ---------------------------------------------------------------
  // "Book a call": paste your Cal.com / Calendly / Google Calendar
  // booking-page link here. While it is empty, every "Book a call"
  // button stays hidden, so nothing broken ever shows.
  // ---------------------------------------------------------------
  const BOOKING_URL = 'https://cal.com/crt-media-agency-djafrq/20-minutes-meeting-with-crt';
  document.querySelectorAll('[data-booking-link]').forEach(el=>{
    if(!BOOKING_URL) return;
    el.href = BOOKING_URL;
    el.target = '_blank'; el.rel = 'noopener';
    (el.closest('[data-booking]') || el).hidden = false;
  });

  // ---------------------------------------------------------------
  // Menu panels (desktop): every menu item opens a panel with photos
  // and quick links; the page is blurred behind it.
  // Footer call-to-action band (all pages)
  (function(){
    const f = document.querySelector('footer.footer');
    // Offer landing pages (ad traffic) stay focused on their own form: no extra call-to-action band
    if(!f || f.querySelector('.footer-cta') || document.body.classList.contains('lp')) return;
    const d = document.createElement('div');
    d.className = 'footer-cta';
    d.innerHTML = '<div><span class="kicker">Have a project in mind?</span>'+
      '<p class="footer-cta-title">Your next launch, event <br>or brand. Let’s make it.</p>'+
      '<a class="footer-cta-mail" href="mailto:hello@crt.rw" data-track="footer_cta_email">hello@crt.rw</a></div>'+
      '<div class="footer-cta-actions"><a class="btn" href="'+u('/contact')+'" data-track="footer_cta_quote">Get a quote →</a>'+
      '<a class="btn ghost" href="https://wa.me/250796356035?text=Hi%20CRT%20Media%20Agency%2C%20I%27d%20like%20to%20start%20a%20project." target="_blank" rel="noopener" data-track="footer_cta_whatsapp">Chat on WhatsApp ↗</a></div>';
    // A page-specific banner just above the footer becomes the footer CTA's lead-in
    const main = document.querySelector('main'), last = main && main.lastElementChild;
    if(last && last.classList.contains('cta-banner')){
      const h = last.querySelector('h2'), p = last.querySelector('p'), b = last.querySelector('.btn');
      if(h) d.querySelector('.kicker').textContent = h.textContent;
      if(p){ const n = document.createElement('p'); n.className = 'footer-cta-note'; n.textContent = p.textContent; d.firstElementChild.appendChild(n); }
      if(b){ const q = d.querySelector('.footer-cta-actions .btn'); q.href = b.href; q.textContent = b.textContent; }
      // keep any extra options from the page banner (e.g. "Build your project") as secondary buttons
      [...last.querySelectorAll('.btn')].slice(1).forEach(x => { const a = document.createElement('a'); a.className = 'btn ghost'; a.href = x.href; a.textContent = x.textContent; d.querySelector('.footer-cta-actions .btn').after(a); });
      last.remove();
    }
    f.prepend(d);
  })();

  // Footer: Kigali local time (helps clients abroad plan a call)
  (function(){
    const el = document.querySelector('[data-kigali-time]'); if(!el || !window.Intl) return;
    let fmt; try{ fmt = new Intl.DateTimeFormat('en-GB', {hour:'2-digit', minute:'2-digit', timeZone:'Africa/Kigali'}); }catch(e){ return; }
    const tick = () => { el.textContent = 'Kigali time ' + fmt.format(new Date()); };
    tick(); el.hidden = false; setInterval(tick, 30000);
  })();

  // ---------------------------------------------------------------
  // Main menu (v8.9): audience-led top bar, grouped panels with prices,
  // one proof card and one quote card per panel. To change a panel, edit PANELS.
  // Each item: [icon key or 'img:/path', name, one line, link]
  // ---------------------------------------------------------------
  (function(){
    const nav = document.querySelector('.nav-links'), header = document.querySelector('.site-header');
    if(!nav || !header) return;
  const I = {
      camera:'<path d="M4 8h3l2-2.5h6L17 8h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
      film:'<rect x="3.5" y="6" width="12" height="12" rx="2"/><path d="M15.5 10.5l5-3v9l-5-3"/>',
      event:'<rect x="4" y="5.5" width="16" height="14" rx="2"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/><path d="M9.5 14.5l2 2 3.5-3.5"/>',
      brand:'<path d="M12 3.5l2.4 5 5.4.6-4 3.7 1.1 5.4L12 15.5l-4.9 2.7 1.1-5.4-4-3.7 5.4-.6z"/>',
      design:'<path d="M4 20l4-1 10.5-10.5a2.1 2.1 0 0 0-3-3L5 16z"/><path d="M14 7l3 3"/>',
      web:'<rect x="3.5" y="5" width="17" height="12" rx="2"/><path d="M8.5 20h7M12 17v3"/><path d="M9.5 9.5L7.5 11l2 1.5M14.5 9.5l2 1.5-2 1.5"/>',
      social:'<path d="M5 18.5V12M10 18.5V8.5M15 18.5v-5M20 18.5V5"/>',
      rocket:'<path d="M14 4.5c3 0 5.5 2.5 5.5 5.5L13 16.5 7.5 11z"/><path d="M7.5 11l-3 .5 2-3.5h4M13 16.5l-.5 3 3.5-2v-4"/><circle cx="14.5" cy="9.5" r="1.3"/>',
      ring:'<circle cx="12" cy="14" r="5.5"/><path d="M9.5 4.5h5l1.5 2.5-4 2-4-2z"/>',
      grow:'<path d="M4 17l5-5 4 4 7-7"/><path d="M15 9h5v5"/>',
      hotel:'<path d="M4 20V6h10v14M14 10h6v10M7 9.5h1.5M10 9.5h1.5M7 13h1.5M10 13h1.5M8 20v-3h3v3"/>',
      food:'<path d="M7 3.5v7M5 3.5v4a2 2 0 0 0 4 0v-4M7 10.5v10M16.5 20.5V3.5c-2 1.5-3 4-3 7h3"/>',
      corp:'<rect x="4" y="7.5" width="16" height="11.5" rx="2"/><path d="M9 7.5V5.5h6v2M4 12.5h16"/>',
      well:'<path d="M12 20s-7-4.3-7-9.5A4 4 0 0 1 12 8a4 4 0 0 1 7 2.5C19 15.7 12 20 12 20z"/>'
    };
  const PANELS = {
      business: {
        label: 'For Businesses', all: ['All business services','/business/'], cta: ['Get a quote','/business/#inquiry'],
        groups: [
          ['Capture', [
            ['camera','Photography','Product, food and brand photos, from 400,000 RWF','/commercial-photography-video/'],
            ['film','Video & film','Brand films and reels for launches and ads','/commercial-photography-video/'] ]],
          ['Build your brand', [
            ['brand','Branding & identity','Logos, colours and brand kits, from 250,000 RWF','/branding-graphic-design/'],
            ['design','Graphic design','Posters, banners and social posts','/branding-graphic-design/'],
            ['web','Websites','Fast, mobile-first sites, from 600,000 RWF','/web-digital/'] ]],
          ['Grow', [
            ['social','Social media & content','Planned, shot and posted, from 500,000 RWF / month','/social-media-content/'],
            ['grow','Content session','One half-day shoot, a month of content, from 400,000 RWF','/offer-commercial-content-session/'],
            ['rocket','Fixed-price offers','Launch bundle, brand kit and more','/business/#offers'] ]]
        ],
        feature: ['/assets/work/cases/oryx-energies/cover-800.webp','Case study · ORYX Energies','Engine oil, shot like a premium product','/work-oryx-energies/']
      },
      events: {
        label: 'Event Coverage', all: ['Events overview','/events/'], cta: ['Check my date','/events/#inquiry'],
        groups: [
          ['Book coverage', [
            ['event','Event coverage','3 packages, from 200,000 RWF','/events/#packages'],
            ['social','Event + social bundle','Coverage plus ready-to-post content, from 200,000 RWF','/offer-event-social-bundle/'],
            ['brand','Event branding','Badges, banners, stage and roll-ups','/work-rwanda-mining-week/'] ]],
          ['Recent events', [
            ['corp','SanlamAllianz Agents Day','An appreciation day where every agent made the frame','/work-sanlam-allianz-agents-day/'],
            ['corp','Old Mutual year-end','A year-end party with the whole team in the frame','/work-old-mutual-year-end/'],
            ['film','All event case studies','Conferences, launches and workshops','/work/#for-corporate-events'] ]]
        ],
        feature: ['/assets/work/cases/rwanda-mining-week/cover-800.webp','Case study · Rwanda Mining Week','One visual system, from badge to main stage','/work-rwanda-mining-week/']
      },
      weddings: {
        label: 'Weddings', all: ['Weddings overview','/weddings/'], cta: ['Check my date','/weddings/#inquiry'],
        groups: [
          ['Packages', [
            ['img:/assets/work/wedding-sandra-mathias-800.webp','Basic','1,200,000 RWF · photos of all four days','/weddings/#packages'],
            ['img:/assets/work/reception-sandra-mathias-800.webp','Standard','2,000,000 RWF · photos and video','/weddings/#packages'],
            ['img:/assets/work/wedding-party-mirindi-ange-800.webp','Premium','3,000,000 RWF · the complete journey, with livestream','/weddings/#packages'],
            ['img:/assets/work/cases/wedding-mirindi-ange/06-800.webp','VIP','4,500,000 RWF · everything, plus a same-day edit','/weddings/#packages'] ]],
          ['More for your day', [
            ['event','Build your own','Only the days you need, from 200,000 RWF','/weddings/#days'],
            ['grow','Book early, save 30%','Packages from 840,000 RWF','/offer-wedding-early-booking/'],
            ['design','Albums & prints','Keep the day in print','/shop/#albums'] ]]
        ],
        feature: ['/assets/work/cases/wedding-mirindi-ange/06-800.webp','Wedding stories','See real couples and their full galleries','/work/#for-weddings']
      },
      work: {
        label: 'Our Work', all: ['All work','/work/'], cta: ['Get a quote','/contact/'],
        groups: [
          ['By service', [
            ['camera','Photography','Products, food, hotels and events','/work/#photography'],
            ['film','Video','Highlight films and reels','/work/#film'],
            ['brand','Branding','Logos and event identities','/work/#branding'],
            ['design','Graphic design','Posters, banners and social posts','/work/#graphic-design'] ]],
          ['By industry', [
            ['hotel','Hotels & hospitality','TR-5 Resort, Million Views, Zora Lounge','/work/#for-hospitality'],
            ['food','Food & drink brands','Inka Steak House, Phizer Wines, Terrassa Wines','/work/#for-food-drink'],
            ['corp','Corporate & finance','Old Mutual, SanlamAllianz, Rwanda Mining Week','/work/#for-corporate-events'],
            ['well','Beauty, sport & wellness',"L'OU Aesthetic Center, SportsPark",'/work/#for-beauty-wellness'] ]]
        ],
        feature: ['/assets/work/cases/inka-steak-house/cover-800.webp','Portfolio','See all our work','/work/']
      }
    };
    const esc = s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;');
    const ico = k=> k.startsWith('img:') ? `<span class="mm-ico mm-thumb" aria-hidden="true"><img src="${u(k.slice(4))}" alt="" loading="lazy" decoding="async"></span>` : `<span class="mm-ico" aria-hidden="true"><svg viewBox="0 0 24 24">${I[k]}</svg></span>`;
    const item = ([k,n,d,h])=>`<a class="mm-item" href="${u(h)}">${ico(k)}<span><strong>${esc(n)}</strong><small>${esc(d)}</small></span></a>`;
    const allRow = p=>`<a class="mm-all" href="${u(p.all[1])}">${esc(p.all[0])} <span aria-hidden="true">→</span></a>`;
    const quote = p=>`<a class="mm-quote" data-track="menu_quote_click" href="${u(p.cta[1])}"><strong>${esc(p.cta[0])} <span aria-hidden="true">→</span></strong><small>We usually reply within 2 hours.</small></a>`;
    const KEYS = {'/business':'business','/events':'events','/weddings':'weddings','/work':'work'};
    const here = pageKey(location.href) || '';
    const triggers = [];
    // Swap the four section links for menu buttons (the plain links stay in the HTML for no-JS and search engines)
    [...nav.querySelectorAll(':scope > a')].forEach(a=>{
      const key = KEYS[pageKey(a.href)], p = key && PANELS[key]; if(!p) return;
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'mm-trigger'; b.dataset.key = key;
      b.setAttribute('aria-expanded','false'); b.setAttribute('aria-controls','mm-' + key);
      b.innerHTML = `${esc(p.label)}<svg class="mm-chev" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 4.5l3 3 3-3"/></svg>`;
      const root = pageKey(a.href);
      if(here === root || here.startsWith(root + '/') || (key === 'work' && here.startsWith('/work-'))) b.classList.add('is-current');
      const sub = document.createElement('div');
      sub.className = 'mm-sub'; sub.id = 'mm-sub-' + key; sub.hidden = true;
      sub.innerHTML = allRow(p) + p.groups.map(([g, items])=>`<p class="mm-glabel">${esc(g)}</p>` + items.map(item).join('')).join('');
      a.replaceWith(b, sub); triggers.push(b);
    });
    if(!triggers.length) return;
    // Desktop: centre the menu in the free space between the logo and the buttons (their widths differ)
    const brand = header.querySelector('.brand');
    const balance = ()=>{
      const acts = nav.querySelector('.nav-actions'); if(!brand || !acts) return;
      const h = header.getBoundingClientRect(), b = brand.getBoundingClientRect(), a = acts.getBoundingClientRect();
      if(!a.width) return;
      nav.style.setProperty('--nav-l', Math.round(b.right - h.left + 24) + 'px');
      nav.style.setProperty('--nav-r', Math.round(h.right - a.left + 24) + 'px');
    };
    balance(); window.addEventListener('resize', balance, {passive:true}); window.addEventListener('load', balance);
    if(document.fonts && document.fonts.ready) document.fonts.ready.then(balance);
    new MutationObserver(balance).observe(nav, {subtree:true, attributes:true, attributeFilter:['hidden']});
    const panel = document.createElement('div');
    panel.className = 'mm-panel';
    panel.innerHTML = triggers.map(t=>{ const key = t.dataset.key, p = PANELS[key];
      return `<div class="mm-pane" id="mm-${key}" data-key="${key}" role="region" aria-label="${esc(p.label)}" hidden>` +
        `<div class="mm-groups" data-cols="${p.groups.length}" style="--cols:${p.groups.length}">` +
          p.groups.map(([g, items])=>`<div class="mm-group"><p class="mm-glabel">${esc(g)}</p>${items.map(item).join('')}</div>`).join('') + allRow(p) +
        `</div><div class="mm-side">` +
          `<a class="mm-feature" data-track="menu_feature_click" href="${u(p.feature[3])}"><span class="mm-fimg"><img src="${u(p.feature[0])}" alt="" loading="lazy" decoding="async"></span><em>${esc(p.feature[1])}</em><strong>${esc(p.feature[2])} <span aria-hidden="true">→</span></strong></a>` +
          quote(p) + `</div></div>`; }).join('');
    const scrim = document.createElement('div'); scrim.className = 'mm-scrim';
    // v9.7 Stripe-style morph: a caret that slides to the hovered item, and panes that slide
    // sideways (direction follows the menu order) while the panel eases to the new height.
    const caret = document.createElement('div'); caret.className = 'mm-caret'; caret.setAttribute('aria-hidden','true');
    document.body.append(scrim, panel, caret);
    if(window.__CRT_PRICE_MAP){ crtReplaceNumbers(panel, window.__CRT_PRICE_MAP); crtReplaceNumbers(nav, window.__CRT_PRICE_MAP); }

    const wide = window.matchMedia('(hover: hover) and (pointer: fine) and (min-width: 761px)');
    const desk = window.matchMedia('(min-width: 761px)');
    let current = null, openT, closeT;
    const mv = {x:0, y:0, px:0, py:0};
    document.addEventListener('pointermove', e=>{ if(!current) return; mv.px = mv.x; mv.py = mv.y; mv.x = e.clientX; mv.y = e.clientY; }, {passive:true});
    const place = ()=>{ panel.style.top = (header.getBoundingClientRect().bottom + 10) + 'px'; };
    const links = key=>[...panel.querySelectorAll('#mm-' + key + ' a')];
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
    const order = triggers.map(t=>t.dataset.key), EASE = 'cubic-bezier(.22,.8,.24,1)';
    let morphT;
    const aim = (key, instant)=>{
      const t = triggers.find(x=>x.dataset.key === key); if(!t) return;
      const r = t.getBoundingClientRect(), pl = panel.getBoundingClientRect().left, x = Math.round(r.left + r.width / 2);
      caret.classList.toggle('no-anim', !!instant);
      caret.style.left = x + 'px'; caret.style.top = panel.style.top;
      panel.style.transformOrigin = Math.round(x - pl) + 'px 0';
    };
    const settle = ()=>{
      clearTimeout(morphT); panel.classList.remove('mm-morph'); panel.style.height = '';
      panel.querySelectorAll('.mm-pane').forEach(p=>{
        if(p.getAnimations) p.getAnimations().forEach(a=>a.cancel());
        if(p.classList.contains('mm-leave')){ p.classList.remove('mm-leave'); p.style.cssText = ''; }
        p.hidden = p.dataset.key !== current;
      });
    };
    const show = key=>{
      clearTimeout(closeT); place();
      const wasOpen = document.body.classList.contains('mm-open') && !!current;
      if(wasOpen && current === key){ aim(key); return; }
      // Read the live height and opacity first, so a morph interrupted mid-way carries on without a snap
      const from = wasOpen && panel.querySelector('#mm-' + current), to = panel.querySelector('#mm-' + key);
      const h0 = panel.getBoundingClientRect().height, op0 = from ? +getComputedStyle(from).opacity : 1;
      settle();
      if(from && to && !reduce.matches && to.animate){
        const dir = order.indexOf(key) > order.indexOf(current) ? 1 : -1;
        from.style.cssText = `position:absolute;top:${from.offsetTop}px;left:${from.offsetLeft}px;width:${from.offsetWidth}px;margin:0;pointer-events:none`;
        from.classList.add('mm-leave'); to.hidden = false;
        const h1 = panel.offsetHeight;
        panel.classList.add('mm-morph'); panel.style.height = h0 + 'px'; void panel.offsetHeight; panel.style.height = h1 + 'px';
        from.animate([{opacity:op0, transform:'none'}, {opacity:0, transform:`translateX(${-dir * 56}px)`}], {duration:220, easing:EASE, fill:'forwards'});
        to.animate([{opacity:0, transform:`translateX(${dir * 56}px)`}, {opacity:1, transform:'none'}], {duration:340, easing:EASE});
        morphT = setTimeout(settle, 380);
      } else {
        panel.querySelectorAll('.mm-pane').forEach(p=>p.hidden = p.dataset.key !== key);
      }
      current = key; aim(key, !wasOpen);
      triggers.forEach(t=>t.setAttribute('aria-expanded', String(t.dataset.key === key)));
      document.body.classList.add('mm-open');
    };
    const hide = ()=>{ document.body.classList.remove('mm-open'); current = null; triggers.forEach(t=>t.setAttribute('aria-expanded','false')); };
    const close = d=>{ clearTimeout(openT); clearTimeout(closeT); closeT = setTimeout(hide, d == null ? 200 : d); };
    triggers.forEach(t=>{
      const key = t.dataset.key, sub = nav.querySelector('#mm-sub-' + key);
      t.addEventListener('pointerenter', ()=>{ if(!wide.matches) return; clearTimeout(closeT); clearTimeout(openT);
        if(!current){ openT = setTimeout(()=>show(key), 90); return; }
        // Stripe-style intent: a pointer heading down toward the open panel only grazes this item,
        // so wait a beat before switching; it switches at once when moving along the bar.
        const dx = mv.x - mv.px, dy = mv.y - mv.py;
        if(current !== key && dy > 1 && dy > Math.abs(dx) * .6) openT = setTimeout(()=>show(key), 140); else show(key); });
      t.addEventListener('pointerleave', ()=>{ if(wide.matches) close(); });
      t.addEventListener('click', e=>{
        if(desk.matches){
          if(e.detail && wide.matches){ clearTimeout(openT); show(key); return; }   // mouse: hover already opened it, a click keeps it open
          if(current === key){ hide(); return; }
          show(key); if(e.detail === 0){ const f = links(key)[0]; if(f) f.focus(); }
          return;
        }
        const open = sub.hidden; sub.hidden = !open; t.setAttribute('aria-expanded', String(open));
      });
    });
    nav.querySelectorAll(':scope > a, .nav-actions a').forEach(a=>a.addEventListener('pointerenter', ()=>{ if(wide.matches) close(60); }));
    panel.addEventListener('pointerenter', ()=>clearTimeout(closeT));
    panel.addEventListener('pointerleave', ()=>{ if(wide.matches) close(); });
    scrim.addEventListener('click', ()=>close(0));
    // Keyboard: Tab runs through the open panel, then on to the next item in the bar
    panel.addEventListener('keydown', e=>{
      if(e.key !== 'Tab' || !current) return;
      const l = links(current), t = triggers.find(x=>x.dataset.key === current);
      if(e.shiftKey && document.activeElement === l[0]){ e.preventDefault(); t.focus(); }
      else if(!e.shiftKey && document.activeElement === l[l.length - 1]){
        e.preventDefault(); const all = [...nav.querySelectorAll(':scope > button, :scope > a, .nav-actions a')].filter(el=>!el.hidden && el.offsetParent !== null);
        const nx = all[all.indexOf(t) + 1]; hide(); (nx || t).focus();
      }
    });
    document.addEventListener('keydown', e=>{ if(e.key === 'Escape' && current){ const t = triggers.find(x=>x.dataset.key === current); hide(); if(t) t.focus(); } });
    document.addEventListener('focusin', e=>{ if(!current || panel.contains(e.target)) return; const t = e.target.closest && e.target.closest('.mm-trigger'); if(!t || t.dataset.key !== current) hide(); });
    window.addEventListener('scroll', ()=>{ if(current){ place(); aim(current, true); } }, {passive:true});
    desk.addEventListener && desk.addEventListener('change', hide);
  })();

  // ---------------------------------------------------------------
  // Live prices + wedding package contents, edited in /admin.
  // The pages keep today's prices as a fallback; when the dashboard
  // has different values, every matching price on the page is swapped.
  // ---------------------------------------------------------------
  (function(){
    const CFG = window.CRT_CONFIG || {};
    if(!CFG.SUPABASE_URL || !CFG.SUPABASE_ANON_KEY) return;
    // Prices exactly as written in the pages today. Don't edit these here; edit them in /admin.
    const BASE = {basic:1200000, standard:2000000, premium:3000000, vip:4500000};
    const fmt = n => Number(n).toLocaleString('en-US');
    const url = CFG.SUPABASE_URL.replace(/\/$/,'') + '/rest/v1/site_content?select=key,value';
    fetch(url, {headers:{'apikey':CFG.SUPABASE_ANON_KEY,'Authorization':'Bearer '+CFG.SUPABASE_ANON_KEY}})
      .then(r => r.ok ? r.json() : [])
      .then(rows => {
        const c = {}; (rows||[]).forEach(r => { c[r.key] = r.value; });
        c.prices = c.prices_v2; c.packages = c.wedding_packages;
        if(c.prices){
          const map = {};
          for(const k in BASE){
            const v = Number(c.prices[k]);
            if(v > 0 && v !== BASE[k]) map[fmt(BASE[k])] = fmt(v);
          }
          ['basic','standard','premium','vip'].forEach(k => {          // early booking = 30% off
            const v = Number(c.prices[k]);
            if(v > 0 && v !== BASE[k]) map[fmt(Math.round(BASE[k]*0.7))] = fmt(Math.round(v*0.7/1000)*1000);
          });
          if(Object.keys(map).length){ window.__CRT_PRICE_MAP = map; crtReplaceNumbers(document.body, map); }
        }
        if(Array.isArray(c.testimonials) && c.testimonials.length){
          const sec = document.querySelector('[data-testimonials]'), list = sec && sec.querySelector('[data-testimonials-list]');
          if(list){
            list.querySelectorAll(':scope > :not([data-static])').forEach(n => n.remove());   // keep the hard-coded genuine quote
            c.testimonials.slice(0, 6).forEach(t => {
              if(!t || !t.quote || !t.name) return;
              const fig = document.createElement('figure'); fig.className = 't-card';
              const q = document.createElement('blockquote'); q.textContent = '“' + t.quote + '”';
              const cap = document.createElement('figcaption'); const b = document.createElement('strong'); b.textContent = t.name; cap.appendChild(b);
              if(t.role){ const r = document.createElement('span'); r.textContent = t.role; cap.appendChild(r); }
              fig.append(q, cap); list.appendChild(fig);
            });
            sec.hidden = !list.children.length;
          }
        }
        if(c.packages){
          document.querySelectorAll('[data-compare]').forEach(el => el.hidden = true);   // admin changed package contents: hide the fixed comparison table rather than show stale rows
          document.querySelectorAll('ul.package-list[data-package]').forEach(ul => {
            const items = c.packages[ul.dataset.package];
            if(!Array.isArray(items) || !items.length) return;
            const short = !!ul.querySelector('li.more');
            const shown = short ? items.slice(0,3) : items;
            ul.innerHTML = '';
            shown.forEach(t => { const li = document.createElement('li'); li.textContent = t; ul.appendChild(li); });
            if(short && items.length > 3){ const li = document.createElement('li'); li.className = 'more'; li.textContent = 'and ' + (items.length - 3) + ' more'; ul.appendChild(li); }
          });
        }
      }).catch(()=>{});
  })();

  // ---------------------------------------------------------------
  // Case study media (film + photos), uploaded in /admin → Case studies.
  // Visitors only see sections that have content. Add ?preview=1 to the
  // page address to see the empty slots as placeholders.
  // ---------------------------------------------------------------
  (function(){
    const page = document.querySelector('[data-case]');
    if(!page) return;
    const slug = page.dataset.case;
    const preview = params.has('preview');
    const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const safeUrl = u => { try{ const x = new URL(u, location.href); return (x.protocol === 'https:' || x.origin === location.origin) ? x.href : ''; }catch(e){ return ''; } };
    function filmHTML(v){
      const url = safeUrl(v.url); if(!url) return '';
      const yt = url.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)([\w-]{11})/);
      if(yt) return `<iframe src="https://www.youtube-nocookie.com/embed/${yt[1]}?rel=0" title="Highlight video" loading="lazy" allow="accelerometer; autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>`;
      const ig = url.match(/instagram\.com\/(?:[\w.]+\/)?(?:reel|reels|p|tv)\/([\w-]+)/);
      if(ig) return `<iframe class="film-ig" src="https://www.instagram.com/reel/${ig[1]}/embed/" title="Highlight video" loading="lazy" scrolling="no" allowtransparency="true" allow="autoplay; encrypted-media; picture-in-picture"></iframe>`;
      const gd = url.match(/drive\.google\.com\/(?:file\/d\/|open\?id=|uc\?(?:export=\w+&)?id=)([\w-]{20,})/);
      if(gd) return `<iframe src="https://drive.google.com/file/d/${gd[1]}/preview" title="Highlight video" loading="lazy" allow="autoplay; fullscreen" allowfullscreen></iframe>`;
      const vm = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
      if(vm) return `<iframe src="https://player.vimeo.com/video/${vm[1]}" title="Highlight video" loading="lazy" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>`;
      if(v.type === 'file' || /\.(mp4|webm|mov)(\?|$)/i.test(url)) return `<video src="${esc(url)}" controls preload="metadata" playsinline></video>`;
      return `<a class="btn" href="${esc(url)}" target="_blank" rel="noopener">Watch the highlight video ↗</a>`;
    }
    function render(entry){
      entry = entry || {};
      const filmSec = document.querySelector('[data-case-film]'), filmSlot = filmSec && filmSec.querySelector('[data-film-slot]');
      if(filmSlot){
        const html = entry.video && entry.video.url ? filmHTML(entry.video) : '';
        if(html){ filmSlot.innerHTML = html; filmSec.hidden = false; filmSlot.classList.toggle('is-vertical', /film-ig|\/shorts\//.test(html + (entry.video.url || ''))); }
        else if(preview){ filmSlot.innerHTML = '<div class="ph-box film-ph"><span>Highlight video placeholder</span><small>Add a YouTube, Instagram, Google Drive or Vimeo link, or upload the video, in /admin → Case studies</small></div>'; filmSec.hidden = false; }
      }
      // Client review (edited in /admin -> Case studies -> Client review). Only rendered when there is a quote, so no empty space otherwise.
      const rv = entry.review && entry.review.quote ? entry.review : (preview ? {quote:'Client review placeholder. Add the quote in /admin → Case studies → Client review.', name:'Client name', role:'Role, company'} : null);
      if(rv){
        const sec = document.createElement('section');
        sec.className = 'cs2-review'; sec.setAttribute('data-case-review', '');
        sec.innerHTML = `<div class="cs2-wrap"><figure class="cs2-review-in"><span class="cs2-label">What the client said</span><blockquote><p>${esc(rv.quote)}</p></blockquote>`
          + `<figcaption><strong>${esc(rv.name || '')}</strong>${rv.role ? `<span>${esc(rv.role)}</span>` : ''}</figcaption></figure></div>`;
        const after = document.querySelector('.cs2-why');
        const before = document.querySelector('.cs2-next');
        if(after) after.after(sec); else if(before) before.before(sec); else (document.querySelector('main') || document.body).appendChild(sec);
      }
      // Credits: who worked on the project (edited in /admin -> Case studies -> Credits)
      const credits = (entry.credits || []).filter(c => c && c.name && c.role);
      if(credits.length || preview){
        const sec = document.createElement('section');
        sec.className = 'cs2-credits'; sec.setAttribute('data-case-credits', '');
        const rows = credits.length ? credits.map(c => `<div><dt>${esc(c.role)}</dt><dd>${esc(c.name)}</dd></div>`).join('')
          : '<div><dt>Role</dt><dd>Credits placeholder · add names in /admin → Case studies → Credits</dd></div>';
        sec.innerHTML = `<div class="cs2-wrap"><div class="cs2-credits-in"><span class="cs2-label">Credits</span><dl class="cs2-credit-list">${rows}</dl></div></div>`;
        const next = document.querySelector('.cs2-next') || document.querySelector('main > section:last-of-type');
        if(next) next.before(sec); else (document.querySelector('main') || document.body).appendChild(sec);
      }
      // Photos uploaded in /admin -> Case studies -> Photos: added to the case study's own gallery (same grid, same lightbox).
      const photos = (entry.photos || []).filter(p => p && safeUrl(p.url));
      if(photos.length || preview){
        let gal = document.querySelector('[data-gallery-slot]') || document.querySelector('.cs2-story .cs-gallery');
        if(!gal){
          const sec = document.createElement('section');
          sec.className = 'cs2-story'; sec.setAttribute('data-case-gallery', '');
          sec.innerHTML = '<div class="cs2-wrap"><div class="cs2-sec-head"><span class="cs2-label">The work</span><h2>More from the project.</h2><p>Tap any photo to see it full screen.</p></div><div class="cs-gallery cs2-grid" data-gallery-slot></div></div>';
          const at = document.querySelector('.cs2-why') || document.querySelector('[data-case-review]') || document.querySelector('[data-case-credits]') || document.querySelector('.cs2-next');
          if(at) at.before(sec); else (document.querySelector('main') || document.body).appendChild(sec);
          gal = sec.querySelector('[data-gallery-slot]');
        }
        let html = photos.map(p => `<figure class="cs-tile cs2-t cs-up" tabindex="0" role="button" data-lb="1" aria-label="Open photo${p.caption ? ': ' + esc(p.caption) : ''}"><img src="${esc(safeUrl(p.url))}" alt="${esc(p.caption || '')}"${p.w && p.h ? ` width="${Number(p.w)}" height="${Number(p.h)}"` : ''} loading="lazy" decoding="async">${p.caption ? `<figcaption>${esc(p.caption)}</figcaption>` : ''}</figure>`).join('');
        if(preview && !photos.length) html = '<figure class="cs-tile cs2-t ph-tile"><div class="ph-box"><span>Your uploaded photos appear here</span><small>/admin → Case studies → Photos</small></div></figure>';
        gal.insertAdjacentHTML('beforeend', html);
        const sec = gal.closest('section'); if(sec) sec.hidden = false;
      }
    }
    const CFG = window.CRT_CONFIG || {};
    if(!CFG.SUPABASE_URL || !CFG.SUPABASE_ANON_KEY){ render(null); return; }
    fetch(CFG.SUPABASE_URL.replace(/\/$/,'') + '/rest/v1/site_content?select=value&key=eq.case_studies',
          {headers:{'apikey':CFG.SUPABASE_ANON_KEY,'Authorization':'Bearer '+CFG.SUPABASE_ANON_KEY}})
      .then(r => r.ok ? r.json() : [])
      .then(rows => render(rows && rows[0] && rows[0].value ? rows[0].value[slug] : null))
      .catch(() => render(null));
  })();

  // Click tracking (only active once GA_ID / META_PIXEL_ID are set above).
  document.querySelectorAll('[data-track]').forEach(el=>el.addEventListener('click',()=>{
    const eventName = el.dataset.track;
    if(typeof window.gtag === 'function') window.gtag('event', eventName);
    if(typeof window.fbq === 'function'){
      if(/book_call/.test(eventName)) fbq('track','Schedule');
      else if(/whatsapp/.test(eventName)) fbq('track','Contact');
    }
  }));
})();

// Footer: keep the copyright year current
document.querySelectorAll('[data-year]').forEach(el=>{ el.textContent = new Date().getFullYear(); });

// ---------------------------------------------------------------
// Photo framing: every photo cropped with object-fit:cover gets a
// focal point, so faces and subjects stay in frame at any shape.
// Add an entry here (file name without -800 / .webp) to fine-tune.
// ---------------------------------------------------------------
(function(){
  const FOCUS = {
    'workshop':'25% 35%',
    'wedding-mirindi-ange/cover':'50% 24%', 'wedding-mirindi-ange/06':'50% 26%', 'wedding-sandra-mathias/01':'50% 40%', 'eloge-alice/cover':'50% 38%', 'wedding-sandra-mathias/cover':'50% 34%',
    'zora-lounge/cover':'50% 45%', 'kings-memo/cover':'50% 50%', 'intore-dancers':'50% 40%', 'church-celebration':'50% 48%',
    'church-ceremony':'45% 38%', 'table-styling':'50% 55%', 'floral-centerpiece':'50% 55%',
    'decor-lounge':'50% 62%', 'decor-reception-lounge':'50% 62%', 'zora-lounge-poster':'50% 38%',
    'kings-memo-logo':'50% 50%', 'crt-website':'50% 45%', 'proposal-eloge-alice':'50% 40%',
    'wedding-sandra-mathias':'50% 32%', 'reception-sandra-mathias':'50% 48%',
    'wedding-party-mirindi-ange':'50% 72%',
    'alain-cedrick':'50% 22%', 'thierry-ziggy-nteziryayo':'50% 22%'
  };
  const key = src => { try{ return decodeURIComponent(new URL(src, location.href).pathname.split('/').pop()).replace(/(-800)?\.(webp|jpe?g|png)$/i,''); }catch(e){ return ''; } };
  const caseKey = src => { const m = String(src).match(/cases\/([^/]+)\/([^/.]+?)(-800)?\.webp/); return m ? m[1] + '/' + m[2] : ''; };
  function frame(img){
    if(img.dataset.framed || img.style.objectPosition) return;
    if(getComputedStyle(img).objectFit !== 'cover') return;
    const src = img.currentSrc || img.src, k = key(src), ck = caseKey(src);
    let pos = FOCUS[ck] || FOCUS[k] || (/^cover-/.test(k) ? '50% 50%' : '');
    if(!pos){
      const w = img.naturalWidth, h = img.naturalHeight;
      if(!w || !h) return;                       // try again once it has loaded
      pos = h > w * 1.05 ? '50% 30%' : '50% 42%'; // portraits: keep heads in; landscapes: slightly above centre
    }
    img.style.objectPosition = pos; img.dataset.framed = '1';
  }
  function scan(root){ (root || document).querySelectorAll('img').forEach(img=>{ frame(img); if(!img.dataset.framed && !img.complete) img.addEventListener('load', ()=>frame(img), {once:true}); }); }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ()=>scan()); else scan();
  window.addEventListener('load', ()=>scan());
  new MutationObserver(ms=>ms.forEach(m=>m.addedNodes.forEach(n=>{ if(n.nodeType===1){ if(n.tagName==='IMG') frame(n); else scan(n); } }))).observe(document.documentElement, {childList:true, subtree:true});
})();

// ---------------------------------------------------------------
// Portfolio pop-up: click any photo in a case-study gallery to see it
// large, then browse left/right (arrows, keyboard ← →, or swipe).
// ---------------------------------------------------------------
(function(){
  const SEL = '.cs-gallery .cs-tile:not(.ph-tile) img';
  let box, imgEl, countEl, capEl, list = [], idx = 0, lastFocus = null;
  const big = img => {
    const ss = img.getAttribute('srcset');
    if(ss){ const best = ss.split(',').map(s=>s.trim().split(/\s+/)).sort((a,b)=>parseInt(b[1])-parseInt(a[1]))[0]; if(best) return new URL(best[0], location.href).href; }
    return (img.currentSrc || img.src).replace(/-800(\.\w+)$/, '$1');
  };
  function build(){
    box = document.createElement('div');
    box.className = 'lightbox'; box.hidden = true;
    box.setAttribute('role','dialog'); box.setAttribute('aria-modal','true'); box.setAttribute('aria-label','Photo viewer');
    box.innerHTML = '<button class="lb-close" type="button" aria-label="Close">×</button>'+
      '<button class="lb-nav lb-prev" type="button" aria-label="Previous photo">‹</button>'+
      '<figure class="lb-stage"><img alt=""><figcaption class="lb-cap"></figcaption></figure>'+
      '<button class="lb-nav lb-next" type="button" aria-label="Next photo">›</button>'+
      '<div class="lb-count" aria-live="polite"></div>';
    document.body.appendChild(box);
    imgEl = box.querySelector('.lb-stage img'); countEl = box.querySelector('.lb-count'); capEl = box.querySelector('.lb-cap');
    box.querySelector('.lb-close').addEventListener('click', close);
    box.querySelector('.lb-prev').addEventListener('click', e=>{ e.stopPropagation(); go(-1); });
    box.querySelector('.lb-next').addEventListener('click', e=>{ e.stopPropagation(); go(1); });
    box.addEventListener('click', e=>{ if(e.target === box || e.target.classList.contains('lb-stage')) close(); });
    // swipe
    let x0 = null, y0 = null;
    box.addEventListener('touchstart', e=>{ x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; }, {passive:true});
    box.addEventListener('touchend', e=>{
      if(x0 === null) return;
      const dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0; x0 = null;
      if(Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy)) go(dx < 0 ? 1 : -1);
      else if(dy > 90 && Math.abs(dy) > Math.abs(dx)) close();
    });
    document.addEventListener('keydown', e=>{
      if(box.hidden) return;
      if(e.key === 'Escape') close();
      else if(e.key === 'ArrowRight') go(1);
      else if(e.key === 'ArrowLeft') go(-1);
      else if(e.key === 'Tab'){ // keep focus inside the viewer
        const f = [...box.querySelectorAll('button')]; const i = f.indexOf(document.activeElement);
        e.preventDefault(); f[(i + (e.shiftKey ? -1 : 1) + f.length) % f.length].focus();
      }
    });
  }
  function show(){
    const img = list[idx];
    box.classList.add('is-loading');
    imgEl.onload = ()=>box.classList.remove('is-loading');
    imgEl.src = big(img); imgEl.alt = img.alt || '';
    capEl.textContent = img.alt || ''; capEl.hidden = !img.alt;
    countEl.textContent = (idx + 1) + ' / ' + list.length;
    const multi = list.length > 1;
    box.querySelectorAll('.lb-nav').forEach(b=>b.hidden = !multi);
    [idx + 1, idx - 1].forEach(j=>{ const n = list[(j + list.length) % list.length]; if(n){ const p = new Image(); p.src = big(n); } });
  }
  function go(d){ if(list.length < 2) return; idx = (idx + d + list.length) % list.length; show(); }
  function open(img){
    if(!box) build();
    const gal = img.closest('.cs-gallery');
    list = [...gal.querySelectorAll('.cs-tile:not(.ph-tile) img')];
    idx = Math.max(0, list.indexOf(img));
    lastFocus = document.activeElement;
    box.hidden = false; document.documentElement.classList.add('lb-open');
    requestAnimationFrame(()=>box.classList.add('is-open'));
    show(); box.querySelector('.lb-close').focus();
  }
  function close(){
    box.classList.remove('is-open'); document.documentElement.classList.remove('lb-open');
    setTimeout(()=>{ box.hidden = true; imgEl.removeAttribute('src'); }, 200);
    if(lastFocus && lastFocus.focus) lastFocus.focus();
  }
  // Make gallery photos clickable and keyboard-reachable (also ones added later from the dashboard)
  function prep(root){ (root || document).querySelectorAll('.cs-gallery .cs-tile:not(.ph-tile)').forEach(t=>{ if(t.dataset.lb) return; t.dataset.lb = '1'; t.tabIndex = 0; t.setAttribute('role','button'); t.setAttribute('aria-label','Open photo' + (t.querySelector('img') && t.querySelector('img').alt ? ': ' + t.querySelector('img').alt : '')); }); }
  prep();
  new MutationObserver(()=>prep()).observe(document.body, {childList:true, subtree:true});
  document.addEventListener('click', e=>{ const t = e.target.closest('.cs-gallery .cs-tile:not(.ph-tile)'); if(t && t.querySelector('img')){ e.preventDefault(); open(t.querySelector('img')); } });
  document.addEventListener('keydown', e=>{ if((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('.cs-gallery .cs-tile[data-lb]')){ e.preventDefault(); open(e.target.querySelector('img')); } });
})();

// ---------------------------------------------------------------
// Offers page: filter tabs (All / Business / Events / Weddings).
// Links such as /deals#weddings open with that tab selected.
// ---------------------------------------------------------------
(function(){
  const root = document.querySelector('[data-offer-filter]');
  if(!root) return;
  const tabs = [...root.querySelectorAll('[data-filter]')];
  const items = [...root.querySelectorAll('[data-cat]')];
  const apply = (cat, scroll)=>{
    tabs.forEach(t => t.setAttribute('aria-selected', String(t.dataset.filter === cat)));
    items.forEach(el => { el.hidden = !(cat === 'all' || el.dataset.cat === cat); });
    root.classList.toggle('is-filtered', cat !== 'all');
    if(scroll) root.scrollIntoView({behavior:'smooth', block:'start'});
  };
  tabs.forEach(t => t.addEventListener('click', ()=>{
    apply(t.dataset.filter, false);
    try{ history.replaceState(null, '', t.dataset.filter === 'all' ? '#offers' : '#' + t.dataset.filter); }catch(e){}
  }));
  // keyboard: arrow keys move between tabs
  root.querySelector('[role="tablist"]').addEventListener('keydown', e=>{
    const i = tabs.indexOf(document.activeElement); if(i < 0) return;
    if(e.key === 'ArrowRight' || e.key === 'ArrowLeft'){
      e.preventDefault(); const n = tabs[(i + (e.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length]; n.focus(); n.click();
    }
  });
  const fromHash = ()=>{ const h = location.hash.slice(1); if(['business','events','weddings'].includes(h)) apply(h, true); };
  fromHash(); window.addEventListener('hashchange', fromHash);
})();

// Work page: "We make [what] for [who]" filter. Hash: #photography, #for-weddings, #film/for-corporate-events
(function(){
  const say = document.querySelector('.wk-say'); if(!say) return;
  const sel = {d: say.querySelector('select[data-dim="d"]'), s: say.querySelector('select[data-dim="s"]')};
  const cards = [...document.querySelectorAll('.wk-all .wk-card')];
  const countEl = document.querySelector('[data-wk-count]'), empty = document.querySelector('[data-wk-empty]');
  const resets = document.querySelectorAll('[data-wk-reset]'), topReset = document.querySelector('.wk-meta [data-wk-reset]');
  const ALIAS = {commercial:'photography', events:'for-corporate-events', weddings:'for-weddings', design:'graphic-design', all:''};
  const has = (c, dim, v) => !v || (c.dataset[dim] || '').split(' ').includes(v);
  function parse(h){
    h = decodeURIComponent(h || '').replace(/^#/, ''); h = ALIAS[h] !== undefined ? ALIAS[h] : h;
    let d = '', s = '';
    h.split('/').forEach(p => { if(p.startsWith('for-')) s = p.slice(4); else if(p) d = p; });
    const ok = (el, v) => [...el.options].some(o => o.value === v);
    return {d: ok(sel.d, d) ? d : '', s: ok(sel.s, s) ? s : ''};
  }
  function render(push){
    const d = sel.d.value, s = sel.s.value; let n = 0;
    cards.forEach(c => { const on = has(c, 'd', d) && has(c, 's', s); c.hidden = !on; if(on) n++; });
    // live counts in each list, and impossible pairs disabled
    [['d', 's'], ['s', 'd']].forEach(([dim, other]) => [...sel[dim].options].forEach(o => {
      const k = cards.filter(c => has(c, dim, o.value) && has(c, other, sel[other].value)).length;
      o.textContent = (o.dataset.name || o.dataset.say.replace(/^./, m => m.toUpperCase())) + ' (' + k + ')';
      o.disabled = k === 0 && o.value !== sel[dim].value;
    }));
    say.querySelectorAll('select').forEach(x => { const o = x.options[x.selectedIndex]; x.previousElementSibling.textContent = o.dataset.say; x.parentElement.classList.toggle('is-set', !!x.value); });
    document.querySelectorAll('[data-wk-chip]').forEach(b => { const on = b.dataset.wkChip === d; b.classList.toggle('is-on', on); b.setAttribute('aria-pressed', on);
      const k = cards.filter(c => has(c, 'd', b.dataset.wkChip) && has(c, 's', s)).length; b.querySelector('span').textContent = k; b.disabled = k === 0 && !on; });
    if(countEl) countEl.textContent = n === 1 ? '1 case study' : n + ' case studies';
    if(topReset) topReset.hidden = !d && !s;
    if(empty) empty.hidden = n > 0;
    if(push){ const h = [d, s && 'for-' + s].filter(Boolean).join('/'); history.replaceState(null, '', h ? '#' + h : location.pathname); }
  }
  function apply(h){ const v = parse(h); sel.d.value = v.d; sel.s.value = v.s; render(false); }
  Object.values(sel).forEach(x => x.addEventListener('change', () => render(true)));
  document.querySelectorAll('[data-wk-chip]').forEach(b => b.addEventListener('click', () => { sel.d.value = b.dataset.wkChip; render(true); }));
  resets.forEach(b => b.addEventListener('click', () => { sel.d.value = ''; sel.s.value = ''; render(true); }));
  window.addEventListener('hashchange', () => apply(location.hash));
  apply(location.hash);
})();

// Logo presentation: anatomy (take apart / put together), construction toggle, copy colour codes
(function(){
  const anat = document.querySelector('[data-lg-anatomy] .lg-anat-wrap');
  if(anat){
    const btn = anat.querySelector('[data-lg-assemble]');
    const set = whole => { anat.classList.toggle('is-whole', whole); if(btn){ btn.textContent = whole ? 'Take it apart' : 'Put it together'; btn.setAttribute('aria-pressed', whole); } };
    set(true);
    if('IntersectionObserver' in window && !matchMedia('(prefers-reduced-motion: reduce)').matches){
      const io = new IntersectionObserver(es => es.forEach(e => { if(e.isIntersecting){ setTimeout(() => set(false), 350); io.disconnect(); } }), {threshold:.55});
      io.observe(anat);
    } else set(false);
    if(btn) btn.addEventListener('click', () => set(!anat.classList.contains('is-whole')));
  }
  const tg = document.querySelector('[data-lg-construct]'), wrap = document.querySelector('[data-lg-wrap]');
  if(tg && wrap) tg.addEventListener('click', () => { const on = !wrap.classList.contains('is-on'); wrap.classList.toggle('is-on', on); tg.setAttribute('aria-pressed', on); tg.textContent = on ? 'Hide construction' : 'Show construction'; });
  document.querySelectorAll('.lg-sw[data-copy]').forEach(b => b.addEventListener('click', () => {
    const t = b.dataset.copy; (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).catch(()=>{}).finally(() => { b.classList.add('is-copied'); setTimeout(() => b.classList.remove('is-copied'), 1600); });
  }));
})();

// Build your project: drag services into a 3-stage pipeline, see an estimate, book the combination.
// Pointer events, so the same drag works with a mouse, a finger or a pen. Tap or Enter adds a service.
(function(){
  const root = document.querySelector('[data-builder]'); if(!root) return;
  const DATA = JSON.parse(document.getElementById('bx-data').textContent);
  const KEY = 'crt-builder';
  const lists = {1: root.querySelector('[data-lane-list="1"]'), 2: root.querySelector('[data-lane-list="2"]'), 3: root.querySelector('[data-lane-list="3"]')};
  const rwf = n => Number(n).toLocaleString('en-US');
  const escH = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  let pipe = {1:[], 2:[], 3:[]};

  // restore: link (#b=1:id.id|2:id) first, then this browser's last build
  function fromHash(){
    const m = location.hash.match(/^#b=(.+)$/); if(!m) return null;
    const p = {1:[], 2:[], 3:[]};
    decodeURIComponent(m[1]).split('|').forEach(part => { const [l, ids] = part.split(':'); if(p[l] && ids) p[l] = ids.split('.').filter(id => DATA[id]); });
    return p;
  }
  try{ pipe = fromHash() || JSON.parse(localStorage.getItem(KEY) || 'null') || pipe; }catch(e){}
  [1, 2, 3].forEach(l => { pipe[l] = (pipe[l] || []).filter(id => DATA[id]); });

  const all = () => [1, 2, 3].flatMap(l => pipe[l]);
  function save(){
    try{ localStorage.setItem(KEY, JSON.stringify(pipe)); }catch(e){}
    const h = [1, 2, 3].filter(l => pipe[l].length).map(l => l + ':' + pipe[l].join('.')).join('|');
    history.replaceState(null, '', h ? '#b=' + h : location.pathname);
  }
  function render(){
    [1, 2, 3].forEach(l => {
      lists[l].innerHTML = pipe[l].map((id, i) => {
        const s = DATA[id];
        return `<li class="bx-item" data-item="${id}" data-lane="${l}" data-i="${i}"><span class="bx-grip" aria-hidden="true"></span><span class="bx-item-t"><b>${escH(s.n)}</b><small>${s.p ? 'from ' + rwf(s.p) + ' RWF' : 'Priced on request'}</small></span>` +
          `<button type="button" class="bx-x" data-remove="${l}:${i}" aria-label="Remove ${escH(s.n)}">×</button></li>`;
      }).join('');
      lists[l].closest('.bx-lane').classList.toggle('is-empty', !pipe[l].length);
    });
    const ids = all(), known = ids.filter(id => DATA[id].p), unknown = ids.length - known.length, total = known.reduce((s, id) => s + DATA[id].p, 0);
    root.querySelectorAll('.bx-card').forEach(c => c.classList.toggle('is-in', ids.includes(c.dataset.svc)));
    root.querySelector('[data-bx-count]').textContent = ids.length ? ids.length + ' service' + (ids.length > 1 ? 's' : '') + ' in your pipeline' : 'No services yet';
    const tot = !ids.length ? 'Add a service to see an estimate' : known.length ? 'From ' + rwf(total) + ' RWF' + (unknown ? ' + ' + unknown + ' priced on request' : '') : 'Priced on request';
    root.querySelector('[data-bx-total]').textContent = tot;
    const book = root.querySelector('[data-bx-book]'); book.setAttribute('aria-disabled', String(!ids.length));
    root.querySelector('[data-bx-share]').hidden = !ids.length;
    root.querySelector('[data-bx-list]').innerHTML = [1, 2, 3].filter(l => pipe[l].length).map(l => `<li><span>${['', 'Before', 'On the day', 'After'][l]}</span>${pipe[l].map(id => escH(DATA[id].n)).join(', ')}</li>`).join('');
    root.querySelector('[data-bx-total2]').textContent = ids.length ? tot : '';
    // keep the booking form in sync
    const form = root.querySelector('[data-builder-form]');
    if(form){
      const lines = [1, 2, 3].filter(l => pipe[l].length).map(l => ['', 'Before', 'On the day', 'After'][l] + ': ' + pipe[l].map(id => DATA[id].n).join(', '));
      form.querySelector('[name="service"]').value = ids.map(id => DATA[id].n).join(', ').slice(0, 120) || 'Custom project';
      form.querySelector('[name="offer"]').value = ids.length ? 'Custom pipeline · ' + tot : '';
      const det = form.querySelector('[name="details"]');
      det.value = (ids.length ? 'My pipeline:\n' + lines.join('\n') + '\nEstimate: ' + tot + '\n\n' : '') + (det.dataset.own || '');
    }
    save();
  }
  function add(id, lane, index){
    if(!DATA[id]) return;
    [1, 2, 3].forEach(l => { pipe[l] = pipe[l].filter(x => x !== id); });
    lane = lane || DATA[id].s;
    const list = pipe[lane]; list.splice(index == null ? list.length : Math.min(index, list.length), 0, id);
    render();
    const el = root.querySelector(`.bx-item[data-item="${id}"]`); if(el){ el.classList.add('is-new'); setTimeout(() => el.classList.remove('is-new'), 600); }
  }

  // ---- drag (pointer events) ----
  let drag = null;
  function laneAt(x, y){
    const el = document.elementFromPoint(x, y); const lane = el && el.closest('.bx-lane');
    if(!lane) return null;
    const l = Number(lane.dataset.lane), items = [...lists[l].querySelectorAll('.bx-item:not(.is-ghosted)')];
    let index = items.length;
    for(let i = 0; i < items.length; i++){ const r = items[i].getBoundingClientRect(); if(y < r.top + r.height / 2){ index = i; break; } }
    return {l, index, lane};
  }
  root.addEventListener('pointerdown', e => {
    if(e.button !== 0 || e.target.closest('button')) return;
    const src = e.target.closest('.bx-card, .bx-item'); if(!src) return;
    drag = {src, id: src.dataset.svc || src.dataset.item, from: src.dataset.lane ? Number(src.dataset.lane) : null, x0: e.clientX, y0: e.clientY, moved: false};
    src.setPointerCapture(e.pointerId);
  });
  root.addEventListener('pointermove', e => {
    if(!drag) return;
    if(!drag.moved){
      if(Math.hypot(e.clientX - drag.x0, e.clientY - drag.y0) < 6) return;
      drag.moved = true;
      const r = drag.src.getBoundingClientRect();
      drag.ghost = drag.src.cloneNode(true); drag.ghost.className = 'bx-ghost'; drag.ghost.style.width = r.width + 'px';
      drag.dx = e.clientX - r.left; drag.dy = e.clientY - r.top;
      document.body.appendChild(drag.ghost); document.body.classList.add('bx-dragging');
      if(drag.from) drag.src.classList.add('is-ghosted');
      drag.marker = document.createElement('li'); drag.marker.className = 'bx-marker';
    }
    e.preventDefault();
    drag.ghost.style.transform = `translate(${e.clientX - drag.dx}px, ${e.clientY - drag.dy}px) rotate(-1.5deg)`;
    const t = laneAt(e.clientX, e.clientY);
    root.querySelectorAll('.bx-lane.is-over').forEach(x => x !== (t && t.lane) && x.classList.remove('is-over'));
    if(t){ t.lane.classList.add('is-over'); const items = [...lists[t.l].querySelectorAll('.bx-item:not(.is-ghosted)')]; if(items[t.index]) items[t.index].before(drag.marker); else lists[t.l].appendChild(drag.marker); }
    else drag.marker.remove();
  });
  function end(e, cancel){
    if(!drag) return;
    const d = drag; drag = null;
    document.body.classList.remove('bx-dragging');
    root.querySelectorAll('.bx-lane.is-over').forEach(x => x.classList.remove('is-over'));
    if(!d.moved){ if(!cancel && d.src.classList.contains('bx-card')) add(d.id); return; }
    d.ghost.remove(); d.marker.remove(); d.src.classList.remove('is-ghosted');
    if(cancel) return;
    const t = laneAt(e.clientX, e.clientY);
    if(t){
      let index = t.index;
      if(d.from === t.l){ const old = pipe[t.l].indexOf(d.id); if(old > -1 && old < index) index--; }
      add(d.id, t.l, index);
    } else if(d.from){ pipe[d.from] = pipe[d.from].filter(x => x !== d.id); render(); } // dragged out of the pipeline: remove
  }
  root.addEventListener('pointerup', e => end(e, false));
  root.addEventListener('pointercancel', e => end(e, true));
  root.addEventListener('keydown', e => { const c = e.target.closest('.bx-card'); if(c && (e.key === 'Enter' || e.key === ' ')){ e.preventDefault(); add(c.dataset.svc); } });

  root.addEventListener('click', e => {
    const rm = e.target.closest('[data-remove]');
    if(rm){ const [l, i] = rm.dataset.remove.split(':').map(Number); pipe[l].splice(i, 1); render(); return; }
    const tpl = e.target.closest('[data-tpl]');
    if(tpl){ pipe = {1:[], 2:[], 3:[]}; tpl.dataset.tpl.split(',').forEach(id => { if(DATA[id]) pipe[DATA[id].s].push(id); }); render(); return; }
    if(e.target.closest('[data-bx-clear]')){ pipe = {1:[], 2:[], 3:[]}; render(); return; }
    if(e.target.closest('[data-bx-share]')){
      const url = location.href;
      (navigator.share ? navigator.share({title: 'My CRT project', url}) : navigator.clipboard.writeText(url)).then(() => { const b = e.target.closest('[data-bx-share]'); const t = b.textContent; b.textContent = navigator.share ? 'Shared' : 'Link copied'; setTimeout(() => b.textContent = t, 1600); }).catch(() => {});
      return;
    }
    const book = e.target.closest('[data-bx-book]');
    if(book){
      e.preventDefault();
      if(!all().length){ root.querySelector('.bx-lib').scrollIntoView({behavior:'smooth', block:'start'}); return; }
      const b = root.querySelector('.bx-book'); b.hidden = false; b.scrollIntoView({behavior:'smooth', block:'start'});
      setTimeout(() => { const n = b.querySelector('[name="name"]'); if(n) n.focus({preventScroll:true}); }, 500);
      return;
    }
    if(e.target.closest('[data-bx-edit]')){ root.querySelector('.bx-board').scrollIntoView({behavior:'smooth', block:'start'}); }
  });
  const det = root.querySelector('[data-builder-form] [name="details"]');
  if(det) det.addEventListener('input', () => { const i = det.value.indexOf('\n\n'); det.dataset.own = det.value.startsWith('My pipeline:') && i > -1 ? det.value.slice(i + 2) : det.value; });
  render();
})();

// Home page: each collection shows one row; "See more" opens the rest in place. Rows are measured live,
// so one row is 4 tiles on a laptop and 1 card on a phone.
(function(){
  if(!document.querySelector('.hero-home')) return;
  const SEL = '.svc-grid, .deals-grid, .card-grid.four, [data-testimonials-list]'; // the work bento shows in full; its header links to all work
  // Collections with a full page of their own: "See more" goes there instead of expanding in place.
  const PAGE = {'bento': ['work/index.html', 'See all our work']};
  const state = new WeakMap();
  function apply(grid){
    const items = [...grid.children].filter(el => el.nodeType === 1);
    const page = Object.keys(PAGE).find(c => grid.classList.contains(c));
    const ownCta = grid.nextElementSibling && grid.nextElementSibling.classList.contains('cta-row'); // e.g. "See all offers"
    let st = state.get(grid);
    if(!st){
      st = {open: false};
      const row = document.createElement('div'); row.className = 'more-row';
      if(page){
        row.innerHTML = `<a class="btn secondary more-btn" href="${PAGE[page][0]}">${PAGE[page][1]} <span aria-hidden="true">→</span></a>`;
      } else {
        row.innerHTML = '<button type="button" class="btn secondary more-btn" aria-expanded="false"></button>';
        row.querySelector('button').addEventListener('click', () => { st.open = !st.open; apply(grid); if(!st.open) grid.scrollIntoView({block:'nearest'}); });
      }
      if(!ownCta) grid.after(row);
      st.row = row; st.btn = row.querySelector('button');
      state.set(grid, st);
    }
    items.forEach(el => el.classList.remove('is-more-hidden'));
    grid.classList.toggle('is-one-row', !st.open);
    if(!items.length){ st.row.hidden = true; return; }
    if(page || ownCta){
      // one row only; the link (ours or the section's own) opens the full page
      const top0 = Math.min(...items.map(el => el.offsetTop));
      items.filter(el => el.offsetTop > top0 + 4).forEach(el => el.classList.add('is-more-hidden'));
      st.row.hidden = false;
      return;
    }
    const top = Math.min(...items.map(el => el.offsetTop));
    const extra = items.filter(el => el.offsetTop > top + 4);
    const shown = items.length - extra.length;
    if(!st.open) extra.forEach(el => el.classList.add('is-more-hidden'));
    // when open, count what the collapsed row would hide
    let hidden = extra.length;
    if(st.open){ grid.classList.add('is-one-row'); const t2 = Math.min(...items.map(el => el.offsetTop)); hidden = items.filter(el => el.offsetTop > t2 + 4).length; grid.classList.remove('is-one-row'); }
    st.row.hidden = hidden === 0;
    st.btn.setAttribute('aria-expanded', String(st.open));
    st.btn.textContent = st.open ? 'See less' : 'See more (' + hidden + ')';
  }
  const run = () => document.querySelectorAll(SEL).forEach(apply);
  run();
  let t; window.addEventListener('resize', () => { clearTimeout(t); t = setTimeout(run, 120); });
  const tl = document.querySelector('[data-testimonials-list]');
  if(tl) new MutationObserver(() => apply(tl)).observe(tl, {childList: true});
  window.addEventListener('load', run);
})();

// Shop: category tabs, quick view with options, a request list that is sent through the normal enquiry form.
(function(){
  const root = document.querySelector('[data-shop]'); if(!root) return;
  const D = JSON.parse(document.getElementById('shop-data').textContent);
  const KEY = 'crt-shop-bag';
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const price = p => p ? Number(p).toLocaleString('en-US') + ' RWF' : 'Price on request';
  let bag = []; try{ bag = JSON.parse(localStorage.getItem(KEY) || '[]').filter(x => D[x.id]); }catch(e){}
  const qv = root.querySelector('[data-shop-qv]'), drawer = root.querySelector('[data-shop-drawer]'), scrim = root.querySelector('[data-shop-scrim]');
  const units = (id, q) => q + ' ' + (q === 1 ? D[id].u[0] : D[id].u[1]);
  const label = it => D[it.id].n + (Object.keys(it.o).length ? ' (' + Object.values(it.o).join(', ') + ')' : '') + ': ' + units(it.id, it.q);

  function filter(cat){
    root.querySelectorAll('.sp-tab').forEach(b => { const on = b.dataset.shopCat === cat; b.classList.toggle('is-on', on); b.setAttribute('aria-pressed', on); });
    root.querySelectorAll('.sp-tile').forEach(t => { t.hidden = !!cat && t.dataset.cat !== cat; });
    history.replaceState(null, '', cat ? '#' + cat : location.pathname);
  }
  function openQV(id){
    const p = D[id]; if(!p) return;
    const opts = Object.entries(p.o).map(([k, vals]) => `<fieldset class="sp-opt"><legend>${esc(k)}</legend><div>` +
      vals.map((v, i) => `<label><input type="radio" name="o-${esc(k)}" value="${esc(v)}"${i ? '' : ' checked'}><span>${esc(v)}</span></label>`).join('') + '</div></fieldset>').join('');
    qv.innerHTML = `<form method="dialog" class="sp-qv-in" data-qv-form data-id="${id}">
      <div class="sp-qv-stage">${p.m}</div>
      <div class="sp-qv-info"><button type="button" class="sp-x" data-qv-close aria-label="Close">×</button>
        <h2>${esc(p.n)}</h2><p class="sp-qv-price">${price(p.p)}</p><p class="sp-qv-line">${esc(p.l)}</p>${opts}
        <div class="sp-qty"><span>Number of ${esc(p.u[1])}</span><div class="sp-qty-ctl"><button type="button" data-qty="-1" aria-label="One fewer ${esc(p.u[0])}">−</button><output data-qty-val aria-live="polite">1</output><button type="button" data-qty="1" aria-label="One more ${esc(p.u[0])}">+</button><span class="sp-qty-unit" data-qty-unit>${esc(p.u[0])}</span></div></div>
        ${id === 'gift-card' ? '<label class="sp-gift-to">Who is it for? <small>(optional)</small><input type="text" name="recipient" maxlength="60" placeholder="Their name" autocomplete="off"></label>' : ''}
        <button class="btn sp-add" type="submit">Add to request list</button>
        ${p.c === 'albums' ? '<p class="sp-qv-note">Booked your wedding with us? Ask us about adding an album when you send your request.</p>' : ''}
        <p class="sp-qv-small">Made to order. We confirm the price and delivery with you first.</p></div></form>`;
    qv.showModal();
  }
  function save(){ try{ localStorage.setItem(KEY, JSON.stringify(bag)); }catch(e){} }
  function renderBag(){
    const n = bag.reduce((s, x) => s + x.q, 0);
    root.querySelectorAll('[data-bag-count]').forEach(el => { el.textContent = bag.length; el.hidden = !bag.length; el.setAttribute('aria-label', bag.length + (bag.length === 1 ? ' product' : ' products') + ' in your request list'); });
    root.querySelector('[data-bag-list]').innerHTML = bag.map((it, i) => `<li><div class="sp-bag-thumb">${D[it.id].m}</div><div class="sp-bag-txt"><b>${esc(D[it.id].n)}</b>` +
      `<small>${esc(Object.values(it.o).join(' · '))}</small><small><strong>Quantity: ${esc(units(it.id, it.q))}</strong> · ${price(D[it.id].p)}</small></div>` +
      `<button type="button" class="sp-x sm" data-bag-remove="${i}" aria-label="Remove ${esc(D[it.id].n)}">×</button></li>`).join('');
    root.querySelector('[data-bag-empty]').hidden = !!bag.length;
    root.querySelector('[data-bag-form]').hidden = !bag.length;
    const form = root.querySelector('[data-shop-form]');
    if(form){
      const lines = bag.map(it => '- ' + label(it));
      form.querySelector('[name="service"]').value = ('Shop: ' + bag.map(it => D[it.id].n).join(', ')).slice(0, 120);
      form.querySelector('[name="offer"]').value = bag.length ? bag.length + ' product' + (bag.length > 1 ? 's' : '') + ' from the shop' : '';
      const det = form.querySelector('[name="details"]');
      det.value = (bag.length ? 'Request list:\n' + lines.join('\n') + '\n\n' : '') + (det.dataset.own || '');
    }
    save();
    const sticky = root.querySelector('[data-shop-sticky]');
    if(sticky){ sticky.hidden = !bag.length; sticky.querySelector('[data-sticky-n]').textContent = bag.length + (bag.length === 1 ? ' item' : ' items'); }
    document.body.classList.toggle('sp-has-bar', !!bag.length);
    window.dispatchEvent(new CustomEvent('crt:bag', {detail: bag.length}));
  }
  const openBag = () => { drawer.hidden = false; scrim.hidden = false; requestAnimationFrame(() => drawer.classList.add('is-open')); };
  const closeBag = () => { drawer.classList.remove('is-open'); scrim.hidden = true; setTimeout(() => drawer.hidden = true, 250); };

  root.addEventListener('click', e => {
    const t = e.target;
    const tab = t.closest('[data-shop-cat]'); if(tab){ filter(tab.dataset.shopCat); return; }
    const jump = t.closest('[data-shop-jump]'); if(jump){ e.preventDefault(); filter(jump.dataset.shopJump); root.querySelector('.sp-tabs').scrollIntoView({behavior:'smooth'}); return; }
    const op = t.closest('[data-product]'); if(op){ openQV(op.dataset.product); return; }
    if(t.closest('[data-qv-close]')){ qv.close(); return; }
    const q = t.closest('[data-qty]'); if(q){ const o = qv.querySelector('[data-qty-val]'); o.textContent = Math.max(1, Math.min(50, Number(o.textContent) + Number(q.dataset.qty))); const id = qv.querySelector('[data-qv-form]').dataset.id; qv.querySelector('[data-qty-unit]').textContent = Number(o.textContent) === 1 ? D[id].u[0] : D[id].u[1]; return; }
    if(t.closest('[data-shop-bag]')){ openBag(); return; }
    if(t.closest('[data-shop-close]') || t.closest('[data-shop-scrim]')){ closeBag(); return; }
    const rm = t.closest('[data-bag-remove]'); if(rm){ bag.splice(Number(rm.dataset.bagRemove), 1); renderBag(); return; }
  });
  qv.addEventListener('click', e => { if(e.target === qv) qv.close(); });
  root.addEventListener('submit', e => {
    const f = e.target.closest('[data-qv-form]'); if(!f) return;
    e.preventDefault();
    const o = {}; f.querySelectorAll('.sp-opt').forEach(fs => { const c = fs.querySelector('input:checked'); if(c) o[fs.querySelector('legend').textContent] = c.value; });
    const rcp = f.querySelector('[name="recipient"]'); if(rcp && rcp.value.trim()) o['Name on card'] = rcp.value.trim().slice(0, 60);
    const it = {id: f.dataset.id, o, q: Number(f.querySelector('[data-qty-val]').textContent) || 1};
    const same = bag.find(x => x.id === it.id && JSON.stringify(x.o) === JSON.stringify(it.o));
    if(same) same.q += it.q; else bag.push(it);
    qv.close(); renderBag(); openBag();
  });
  const det = root.querySelector('[data-shop-form] [name="details"]');
  if(det) det.addEventListener('input', () => { const i = det.value.indexOf('\n\n'); det.dataset.own = det.value.startsWith('Request list:') && i > -1 ? det.value.slice(i + 2) : det.value; });
  document.addEventListener('keydown', e => { if(e.key === 'Escape' && !drawer.hidden) closeBag(); });
  const h = location.hash.slice(1); if(h && root.querySelector(`[data-shop-cat="${h}"]`)) filter(h);
  else if(/^[a-z-]+$/.test(h) && root.querySelector(`[data-product="${h}"]`)) openQV(h); // e.g. /shop#gift-card from the seasonal ribbon
  renderBag();
})();

// Legal pages: highlight the section being read in the "On this page" list.
(function(){
  const links = [...document.querySelectorAll('.legal-toc a[href^="#"]')];
  if(!links.length || !('IntersectionObserver' in window)) return;
  const byId = new Map(links.map(a => [a.getAttribute('href').slice(1), a]));
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => { if(e.isIntersecting){ links.forEach(a => a.classList.remove('is-current')); const a = byId.get(e.target.id); if(a) a.classList.add('is-current'); } });
  }, {rootMargin: '-30% 0px -60% 0px'});
  byId.forEach((a, id) => { const el = document.getElementById(id); if(el) io.observe(el); });
})();

/* Privacy policy pop-up: footer link opens the policy in a dialog (falls back to the page) */
(function(){
  if(typeof HTMLDialogElement === 'undefined' || /\/privacy(\/|$)/.test(location.pathname)) return;
  let dlg = null, cache = null;
  const build = () => {
    dlg = document.createElement('dialog');
    dlg.className = 'pv-modal';
    dlg.setAttribute('aria-labelledby', 'pv-title');
    dlg.innerHTML = '<div class="pv-head"><div class="pv-head-txt"><span class="pv-kicker">CRT Media Agency</span><h2 id="pv-title"></h2><p class="pv-date"></p></div>' +
      '<div class="pv-actions"><a class="pv-full" href="">Full page ↗</a><button type="button" class="pv-x" aria-label="Close privacy policy">×</button></div></div>' +
      '<div class="pv-body legal-content" tabindex="-1"></div>';
    document.body.appendChild(dlg);
    dlg.querySelector('.pv-x').addEventListener('click', () => dlg.close());
    dlg.addEventListener('click', e => { if(e.target === dlg) dlg.close(); });
    dlg.addEventListener('close', () => document.documentElement.classList.remove('pv-lock'));
    dlg.querySelector('.pv-body').addEventListener('click', e => {
      const a = e.target.closest('a[href^="#pv-"]'); if(!a) return;
      e.preventDefault(); const t = dlg.querySelector(a.getAttribute('href')); if(t) t.scrollIntoView({behavior:'smooth', block:'start'});
    });
  };
  const load = async url => {
    if(cache && cache.url === url) return cache;
    const r = await fetch(url, {credentials:'same-origin'}); if(!r.ok) throw new Error('fetch');
    const doc = new DOMParser().parseFromString(await r.text(), 'text/html');
    const c = doc.querySelector('.legal-content'); if(!c) throw new Error('content');
    const base = new URL(url, location.href);
    c.querySelectorAll('[id]').forEach(x => { x.id = 'pv-' + x.id; });
    c.querySelectorAll('a[href]').forEach(x => {
      const h = x.getAttribute('href');
      if(h.startsWith('#')) x.setAttribute('href', '#pv-' + h.slice(1)); else x.href = new URL(h, base).href;
    });
    c.querySelectorAll('script').forEach(s => s.remove());
    const txt = sel => { const n = doc.querySelector(sel); return n ? n.textContent.trim() : ''; };
    return cache = {url, title: txt('.legal-hero h1') || 'Privacy policy', date: txt('.legal-date'), html: c.innerHTML};
  };
  document.addEventListener('click', async e => {
    const a = e.target.closest('.footer-legal a[href*="privacy"], .site-footer a[href*="privacy"]');
    if(!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    e.preventDefault();
    let d; try { d = await load(a.href); } catch(err){ location.href = a.href; return; }
    if(!dlg) build();
    dlg.querySelector('#pv-title').textContent = d.title;
    dlg.querySelector('.pv-date').textContent = d.date;
    dlg.querySelector('.pv-full').href = a.href;
    const body = dlg.querySelector('.pv-body'); body.innerHTML = d.html; body.scrollTop = 0;
    document.documentElement.classList.add('pv-lock');
    dlg.showModal(); body.focus({preventScroll:true});
  });
})();

/* Selected work row: arrow buttons scroll one card at a time; disabled at either end */
(function(){
  const row = document.querySelector('[data-sw]'); if(!row) return;
  const sec = row.closest('section'), prev = sec.querySelector('[data-sw-prev]'), next = sec.querySelector('[data-sw-next]');
  const step = () => { const c = row.querySelector('li'); return c ? c.getBoundingClientRect().width + parseFloat(getComputedStyle(row).columnGap || 16) : row.clientWidth; };
  const sync = () => { const max = row.scrollWidth - row.clientWidth - 2; if(prev) prev.disabled = row.scrollLeft <= 2; if(next) next.disabled = row.scrollLeft >= max; };
  prev && prev.addEventListener('click', () => row.scrollBy({left: -step(), behavior: 'smooth'}));
  next && next.addEventListener('click', () => row.scrollBy({left: step(), behavior: 'smooth'}));
  row.addEventListener('scroll', () => requestAnimationFrame(sync), {passive: true});
  window.addEventListener('resize', sync); sync();
})();

// ---------------------------------------------------------------
// Reels pop-up (Car Biz and any .reel-row): click a reel to watch it large,
// browse with ‹ › / ← → / swipe, close with ×, Esc or a click outside. Same viewer feel as the photos.
// ---------------------------------------------------------------
(function(){
  const reels = [...document.querySelectorAll('.reel-row .reel')]; if(!reels.length) return;
  const items = reels.map((r, i) => { const f = r.querySelector('iframe'); return f ? {src: f.getAttribute('src'), title: f.title || ('Reel ' + (i + 1))} : null; }).filter(Boolean);
  let box, frame, countEl, idx = 0, lastFocus = null;
  function build(){
    box = document.createElement('div');
    box.className = 'lightbox reel-lb'; box.hidden = true;
    box.setAttribute('role','dialog'); box.setAttribute('aria-modal','true'); box.setAttribute('aria-label','Reel viewer');
    box.innerHTML = '<button class="lb-close" type="button" aria-label="Close">×</button>'+
      '<button class="lb-nav lb-prev" type="button" aria-label="Previous reel">‹</button>'+
      '<figure class="lb-stage"><div class="reel-frame reel-lb-frame"></div></figure>'+
      '<button class="lb-nav lb-next" type="button" aria-label="Next reel">›</button>'+
      '<div class="lb-count" aria-live="polite"></div>';
    document.body.appendChild(box);
    frame = box.querySelector('.reel-lb-frame'); countEl = box.querySelector('.lb-count');
    box.querySelector('.lb-close').addEventListener('click', close);
    box.querySelector('.lb-prev').addEventListener('click', e=>{ e.stopPropagation(); go(-1); });
    box.querySelector('.lb-next').addEventListener('click', e=>{ e.stopPropagation(); go(1); });
    box.addEventListener('click', e=>{ if(e.target === box || e.target.classList.contains('lb-stage')) close(); });
    let x0 = null, y0 = null;
    box.addEventListener('touchstart', e=>{ x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; }, {passive:true});
    box.addEventListener('touchend', e=>{ if(x0 === null) return; const dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0; x0 = null;
      if(Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy)) go(dx < 0 ? 1 : -1); else if(dy > 90 && Math.abs(dy) > Math.abs(dx)) close(); });
    document.addEventListener('keydown', e=>{
      if(box.hidden) return;
      if(e.key === 'Escape') close(); else if(e.key === 'ArrowRight') go(1); else if(e.key === 'ArrowLeft') go(-1);
      else if(e.key === 'Tab'){ const f = [...box.querySelectorAll('button')]; const i = f.indexOf(document.activeElement); e.preventDefault(); f[(i + (e.shiftKey ? -1 : 1) + f.length) % f.length].focus(); }
    });
  }
  function show(){
    const it = items[idx];
    frame.innerHTML = `<iframe src="${it.src}" title="${it.title.replace(/"/g,'&quot;')}" scrolling="no" frameborder="0" allowtransparency="true" allow="autoplay; encrypted-media; picture-in-picture"></iframe>`;
    countEl.textContent = (idx + 1) + ' / ' + items.length;
    box.querySelectorAll('.lb-nav').forEach(b=>b.hidden = items.length < 2);
  }
  function go(d){ idx = (idx + d + items.length) % items.length; show(); }
  function open(i){
    if(!box) build();
    idx = i; lastFocus = document.activeElement;
    box.hidden = false; document.documentElement.classList.add('lb-open');
    requestAnimationFrame(()=>box.classList.add('is-open'));
    show(); box.querySelector('.lb-close').focus();
  }
  function close(){
    box.classList.remove('is-open'); document.documentElement.classList.remove('lb-open');
    setTimeout(()=>{ box.hidden = true; frame.innerHTML = ''; }, 200);   // stops playback
    if(lastFocus && lastFocus.focus) lastFocus.focus();
  }
  reels.forEach((r, i) => {
    const fr = r.querySelector('.reel-frame'); if(!fr) return;
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'reel-open'; b.setAttribute('aria-label', 'Play ' + (items[i] ? items[i].title : 'reel'));
    b.innerHTML = '<span class="reel-play" aria-hidden="true"></span>';
    b.addEventListener('click', () => open(i));
    fr.appendChild(b);
  });
  const hint = document.querySelector('.reel-head p'); if(hint && /Tap a reel/i.test(hint.textContent)) hint.textContent = 'Tap a reel to watch it full screen.';
})();


// Header Shop link: label for phones, and a count of items in the request list (shown only when > 0).
(function(){
  const links = [...document.querySelectorAll('.nav-shop')]; if(!links.length) return;
  links.forEach(a => {
    if(!a.querySelector('.nav-shop-sub')){ const sub = document.createElement('span'); sub.className = 'nav-shop-sub'; sub.textContent = 'Albums, prints & gifts'; a.appendChild(sub); }
    if(!a.querySelector('.nav-shop-count')){ const c = document.createElement('em'); c.className = 'nav-shop-count'; c.hidden = true; c.setAttribute('aria-hidden', 'true'); a.appendChild(c); }
  });
  const read = () => { try{ const b = JSON.parse(localStorage.getItem('crt-shop-bag') || '[]'); return Array.isArray(b) ? b.length : 0; }catch(e){ return 0; } };
  let last = null;
  const paint = n => links.forEach(a => {
    const c = a.querySelector('.nav-shop-count'); c.textContent = n; c.hidden = !n;
    a.setAttribute('aria-label', n ? `Shop, ${n} ${n === 1 ? 'item' : 'items'} in your request list` : 'Shop');
    if(last !== null && n > last){ a.classList.remove('is-bump'); void a.offsetWidth; a.classList.add('is-bump'); }
  });
  const update = n => { n = typeof n === 'number' ? n : read(); paint(n); last = n; };
  window.addEventListener('crt:bag', e => update(e.detail));
  window.addEventListener('storage', e => { if(e.key === 'crt-shop-bag') update(); });
  update();
})();

// Seasonal ribbon (home page only), like apple.com's timely top line. Add a season to SEASONS
// with month/day start and end; it shows only inside its window, and a visitor can dismiss it.
(function(){
  if(!document.querySelector('.hero-home')) return;
  const SEASONS = [
    {id:'gifts-2026', from:[11,1], to:[12,31], text:'Holiday gifting: give a photo session.', link:'Choose a gift card', href:'shop/index.html#gift-card'}
  ];
  const esc = v => String(v == null ? '' : v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function build(){
    const old = document.querySelector('.season-bar'); if(old) old.remove();
    const now = new Date(), md = (now.getMonth()+1)*100 + now.getDate();
    let s = SEASONS.find(x => md >= x.from[0]*100 + x.from[1] && md <= x.to[0]*100 + x.to[1]);
    // The admin's announcement (Content → Announcement bar) replaces the seasonal one, or switches the bar off.
    const A = window.CRT_ANNOUNCE;
    if(A){
      if(A.on === false || !String(A.text || '').trim()) return;
      const t = String(A.text).trim().slice(0, 120);
      let id = 0; for(let i = 0; i < t.length; i++) id = (id * 31 + t.charCodeAt(i)) >>> 0;
      let href = String(A.href || '').trim(); if(href && !/^(https?:\/\/|\/|[a-z0-9_-]+\/)/i.test(href)) href = '';
      if(href[0] === '/') href = href.slice(1) || 'index.html';
      s = {id: 'a' + id, text: t, link: href ? String(A.link || 'See more').trim().slice(0, 40) : '', href};
    }
    if(!s) return;
    const key = 'crt-season-' + s.id;
    try{ if(localStorage.getItem(key) === 'x') return; }catch(e){}
    const header = document.querySelector('.site-header'); if(!header) return;
    const bar = document.createElement('div');
    bar.className = 'season-bar';
    bar.setAttribute('role', 'region'); bar.setAttribute('aria-label', 'Announcement');
    bar.innerHTML = `<p><span>${esc(s.text)}</span>${s.link ? ` <a href="${esc(s.href)}" data-track="season_${esc(s.id)}">${esc(s.link)} <i aria-hidden="true">›</i></a>` : ''}</p><button type="button" class="season-x" aria-label="Hide this message">×</button>`;
    header.before(bar);
    bar.querySelector('.season-x').addEventListener('click', () => { bar.remove(); const b = header.querySelector('.brand'); if(b) b.focus(); try{ localStorage.setItem(key, 'x'); }catch(e){} });
  }
  build();
  document.addEventListener('crt:content', e => { if(e.detail && e.detail.site_settings && e.detail.site_settings.announcement) build(); });
})();


// v9.1 Section links bar (apple.com product pages): highlight the section on screen.
(function(){
  const bar = document.querySelector('[data-subnav]'); if(!bar || !('IntersectionObserver' in window)) return;
  const links = [...bar.querySelectorAll('.subnav-links a')];
  const secs = links.map(a => document.getElementById(a.hash.slice(1))).filter(Boolean);
  const seen = new Map();
  const io = new IntersectionObserver(es => {
    es.forEach(e => seen.set(e.target.id, e.isIntersecting ? e.intersectionRatio : 0));
    let best = null, top = 0;
    secs.forEach(s => { const r = seen.get(s.id) || 0; if(r > top){ top = r; best = s.id; } });
    links.forEach(a => {
      const on = a.hash.slice(1) === best; a.classList.toggle('is-on', on);
      if(on){ a.setAttribute('aria-current', 'true'); const box = a.parentElement;
        if(a.offsetLeft < box.scrollLeft || a.offsetLeft + a.offsetWidth > box.scrollLeft + box.clientWidth) box.scrollTo({left: a.offsetLeft - 12, behavior: 'smooth'}); }
      else a.removeAttribute('aria-current');
    });
  }, {rootMargin: '-140px 0px -45% 0px', threshold: [0, .1, .25, .5]});
  secs.forEach(s => io.observe(s));
  // The comparison table opens when someone jumps to it
  links.forEach(a => a.addEventListener('click', () => { const t = document.getElementById(a.hash.slice(1)); if(t && t.tagName === 'DETAILS') t.open = true; }));
})();

// v9.1 Contact form in two steps (stripe.com sales form): what you need + how to reach you, then the details.
(function(){
  document.querySelectorAll('form[data-booking-form]').forEach(form => {
    const needs = form.querySelector('.need-set'), grid = form.querySelector('.form-grid');
    const name = form.querySelector('[name="name"]'), contact = form.querySelector('[name="contact"]');
    if(!needs || !grid || !name || !contact) return;
    const sub = form.querySelector('.form-subtitle');
    const steps = document.createElement('p'); steps.className = 'form-steps'; steps.setAttribute('aria-hidden', 'true');
    steps.innerHTML = '<span class="is-on">You</span><span>Your project</span>';
    (sub || needs).insertAdjacentElement(sub ? 'afterend' : 'beforebegin', steps);
    const live = document.createElement('p'); live.className = 'sr-only'; live.setAttribute('aria-live', 'polite'); steps.after(live);
    // Step 1: chips + name + contact + Continue
    const grid1 = document.createElement('div'); grid1.className = 'form-grid'; grid1.dataset.step = '1';
    grid1.append(name.closest('.field'), contact.closest('.field'));
    needs.dataset.step = '1'; needs.after(grid1);
    const act1 = document.createElement('div'); act1.className = 'form-actions'; act1.dataset.step = '1';
    act1.innerHTML = '<button class="btn" type="button" data-track="form_step1_continue">Continue →</button>';
    grid1.after(act1);
    // Step 2: everything else
    const back = document.createElement('button'); back.type = 'button'; back.className = 'form-step-back'; back.dataset.step = '2'; back.textContent = '← Back';
    const rest = [grid, form.querySelector('.form-actions:not([data-step])'), form.querySelector('.form-disclaimer')].filter(Boolean);
    grid.before(back);
    [back, ...rest].forEach(el => { el.dataset.step = '2'; el.hidden = true; });
    const req2 = [...grid.querySelectorAll('[required]')]; req2.forEach(el => el.required = false);
    let step = 1;
    const go = n => {
      step = n;
      form.querySelectorAll('[data-step]').forEach(el => el.hidden = el.dataset.step !== String(n));
      req2.forEach(el => el.required = n === 2);
      steps.children[1].classList.toggle('is-on', n === 2); steps.children[0].classList.toggle('is-on', n === 1);
      live.textContent = n === 2 ? 'Step 2 of 2: your project' : 'Step 1 of 2: about you';
      const f = n === 2 ? grid.querySelector('input,select,textarea') : name;
      if(f) f.focus({preventScroll: true});
      const top = form.getBoundingClientRect().top; if(top < 90) window.scrollBy({top: top - 110, behavior: 'smooth'});
    };
    const next = () => { if(!name.reportValidity() || !contact.reportValidity()) return; go(2); };
    act1.querySelector('button').addEventListener('click', next);
    back.addEventListener('click', () => go(1));
    // After a successful send the form resets: start again at step 1, so name and contact are visible.
    form.addEventListener('reset', () => setTimeout(() => go(1), 0));
    // Enter on step 1 means "Continue", never a half-filled send
    form.addEventListener('submit', e => { if(step === 1){ e.preventDefault(); e.stopImmediatePropagation(); next(); } }, true);
    // Arriving from a package or service link with the chips already ticked: start at step 1 all the same (name + contact first).
  });
})();

// v9.2 "Skip to content" for keyboard and screen-reader users (apple.com, gov.uk)
(function(){
  const main = document.querySelector('main'); if(!main || document.querySelector('.skip-link')) return;
  if(!main.id) main.id = 'main';
  if(!main.hasAttribute('tabindex')) main.setAttribute('tabindex', '-1');
  const a = document.createElement('a'); a.className = 'skip-link'; a.href = '#' + main.id; a.textContent = 'Skip to content';
  document.body.insertBefore(a, document.body.firstChild);
})();


// v9.3 Review form (/review/): emails the client's review to CRT. Nothing is published automatically.
(function(){
  const form = document.querySelector('[data-review-form]'); if(!form) return;
  const status = form.querySelector('.form-status'), btn = form.querySelector('button[type="submit"]'), label = btn.textContent;
  const show = (k, h)=>{ status.className = 'form-status is-' + k; status.innerHTML = h; status.hidden = false; };
  form.addEventListener('submit', e=>{
    e.preventDefault();
    const d = new FormData(form); if(d.get('bot-field')) return;
    const payload = {_subject: 'New client review: ' + (d.get('name') || ''), _template: 'table', _captcha: 'false',
      Name: d.get('name') || '', 'Role and organisation': d.get('role') || '—', Project: d.get('project') || '',
      Review: d.get('review') || '', 'Can we publish it?': d.get('publish') || '', Page: location.href.split('#')[0]};
    btn.disabled = true; btn.textContent = 'Sending…'; status.hidden = true;
    fetch('https://formsubmit.co/ajax/' + (window.CRT_FORM_EMAIL || 'kigalimediaagency@gmail.com'), {method: 'POST', headers: {'Content-Type': 'application/json', 'Accept': 'application/json'}, body: JSON.stringify(payload)})
      .then(r => r.json().then(j => ({ok: r.ok, j})).catch(() => ({ok: r.ok, j: {}})))
      .then(({ok, j}) => { if(!ok || String(j.success) === 'false') throw new Error('not sent');
        const n = (d.get('name') || '').toString().split(' ')[0].replace(/[<>&]/g, '');
        show('ok', '<strong>Thank you' + (n ? ', ' + n : '') + '!</strong> Your review is with us.'); form.reset();
        if(typeof window.gtag === 'function') window.gtag('event', 'review_submitted'); })
      .catch(() => show('error', 'Sorry, that didn’t send. Please email your review to <a href="mailto:hello@crt.rw">hello@crt.rw</a> or send it on <a href="https://wa.me/250796356035" target="_blank" rel="noopener">WhatsApp</a>.'))
      .finally(() => { btn.disabled = false; btn.textContent = label; });
  });
})();

// v9.6 Home hero reel.
// 1) If a showreel file is set (data-video on .showreel, or window.CRT_SHOWREEL = {mp4, webm}), it plays muted and looped
//    behind the headline once the page has loaded; the photo stays as the poster and the fallback.
// 2) Until then, real photos drift slowly and cross-fade like cuts in a reel.
// The first photo is the page's own <img>, so first paint is unchanged. Off for reduced motion and data-saver.
(function(){
  const box = document.querySelector('.hero-home .showreel'); if(!box || box.querySelector('video')) return;
  if(window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const con = navigator.connection || {};
  if(con.saveData || /(^|-)2g$/.test(con.effectiveType || '')) return;
  const small = window.matchMedia('(max-width: 760px)').matches;
  const whenLoaded = fn => { if(document.readyState === 'complete') setTimeout(fn, 1200); else window.addEventListener('load', () => setTimeout(fn, 1200)); };

  const video = () => { const cfg = window.CRT_SHOWREEL || {}; return {mp4: box.dataset.video || cfg.mp4, webm: box.dataset.videoWebm || cfg.webm}; };
  whenLoaded(() => {
    const {mp4, webm} = video();
    if(mp4 || webm){
      const v = document.createElement('video');
      v.muted = true; v.loop = true; v.playsInline = true; v.autoplay = true; v.preload = 'auto';
      v.setAttribute('muted', ''); v.setAttribute('playsinline', ''); v.setAttribute('aria-hidden', 'true'); v.tabIndex = -1;
      v.className = 'hero-video';
      if(webm){ const a = document.createElement('source'); a.src = webm; a.type = 'video/webm'; v.appendChild(a); }
      if(mp4){ const b = document.createElement('source'); b.src = mp4; b.type = 'video/mp4'; v.appendChild(b); }
      v.addEventListener('playing', () => v.classList.add('is-on'), {once: true});
      box.appendChild(v);
      const p = v.play(); if(p && p.catch) p.catch(() => v.remove());   // autoplay refused: the photo stays
      if('IntersectionObserver' in window) new IntersectionObserver(es => es.forEach(e => { if(e.isIntersecting) v.play().catch(() => {}); else v.pause(); }), {threshold: .05}).observe(box);
      document.addEventListener('visibilitychange', () => { if(document.hidden) v.pause(); else v.play().catch(() => {}); });
      return;
    }
    photoReel();
  });

  // [file, alt, focus on wide screens, focus on phones]. Wide frames only, so no face sits behind the headline.
  const SHOTS = [
    ['assets/work/cases/phizer-wines/08', 'Wine poured beside a pool, product shoot for Phizer Wines by CRT', '50% 40%', '50% 40%'],
    ['assets/work/cases/sportspark/04', 'A crowd warming up on the pitch at a SportsPark community day, photographed by CRT', '50% 45%', '50% 45%'],
    ['assets/work/cases/old-mutual/01', 'Guests at round tables at the Old Mutual end-of-year dinner, photographed by CRT', '50% 55%', '50% 55%']
  ];
  function photoReel(){
    const base = box.querySelector('img'); if(base) base.classList.add('hero-drift');
    const imgs = [];
    const make = i => {
      if(imgs[i] || !SHOTS[i]) return;
      const [src, alt, pos, posSmall] = SHOTS[i];
      const im = new Image(); im.className = 'hero-slide'; im.alt = alt; im.decoding = 'async'; im.style.objectPosition = small ? posSmall : pos;
      im.src = src + (small ? '-800.webp' : '.webp'); box.appendChild(im); imgs[i] = im;
    };
    make(0);
    let k = 0;   // 0 = the page's own photo, 1..n = the added shots
    const ready = im => im && im.complete && im.naturalWidth > 0;
    setInterval(() => {
      if(document.hidden) return;
      const next = (k + 1) % (SHOTS.length + 1);
      if(next){
        const im = imgs[next - 1]; if(!ready(im)) return;
        im.classList.remove('hero-drift'); void im.offsetWidth; im.classList.add('hero-drift', 'is-on');   // restart the drift with the cut
        make(next);   // fetch the following shot one cut ahead
      } else {
        // back to the first photo: drop the hidden lower layers at once, then fade the top one out
        imgs.slice(0, -1).forEach(im => { im.classList.add('is-cut'); im.classList.remove('is-on'); void im.offsetWidth; im.classList.remove('is-cut'); });
        imgs[imgs.length - 1].classList.remove('is-on');
      }
      k = next;
    }, 5000);
  }
})();
