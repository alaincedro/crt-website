-- CRT admin: sign-in codes from an authenticator app on the phone (Google Authenticator, Microsoft Authenticator,
-- iPhone Passwords). Free, no SMS account needed. Run once in Supabase → SQL Editor. Safe to run again.
create table if not exists public.member_mfa (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  secret     text,                 -- active key (base32), never sent to the website after setup
  pending    text,                 -- key shown as a QR code, until its first code is confirmed
  active     boolean not null default false,
  last_step  bigint not null default 0,   -- stops the same code being used twice
  updated_at timestamptz not null default now()
);
alter table public.member_mfa enable row level security;   -- no rules: only the "team" server function reads it
select count(*) as members_with_app from public.member_mfa where active;
