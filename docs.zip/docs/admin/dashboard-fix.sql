-- CRT admin: one-time fix so everything in the dashboard can save.  Supabase → SQL Editor → New query → paste → Run.
-- Safe to run more than once. Nothing you saved is changed.

-- 1) Content menu: allow every kind of content (page edits, contact details, logos, prices, every CMS section).
alter table public.site_content drop constraint if exists site_content_key_check;
alter table public.site_content add constraint site_content_key_check check (key ~ '^[a-z0-9_]{1,40}$');

-- 2) Let admins remove content rows too (the first setup only allowed adding and changing them),
--    and remove the test row left by the dashboard check on 21 Nov 2026.
drop policy if exists "admins delete content" on public.site_content;
create policy "admins delete content" on public.site_content for delete to authenticated using (public.is_admin());
delete from public.site_content where key = 'cms_check_tmp';

-- 3) Photo storage ("media" bucket): admins read, upload, replace and delete. Read was the missing rule that made
--    uploads fail with "new row violates row-level security policy". (Applied 21 Nov 2026.)
drop policy if exists "admins read media" on storage.objects;
create policy "admins read media" on storage.objects for select to authenticated using (bucket_id = 'media' and public.is_admin());
