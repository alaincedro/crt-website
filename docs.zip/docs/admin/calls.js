/* CRT admin: Settings → Call booking (2026-11-25, replaced cal.com).
   When people can book a call on crt.rw/call/ (site_content.call_settings), the days you are closed,
   and the calls coming up (public.calls, see admin/calls-setup.sql). */
(function(){
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const DAYS = [['1', 'Monday'], ['2', 'Tuesday'], ['3', 'Wednesday'], ['4', 'Thursday'], ['5', 'Friday'], ['6', 'Saturday'], ['7', 'Sunday']];
  const DEF = {minutes: 20, notice_min: 120, days_ahead: 21, blocked: [], hours: {1: [['09:00', '17:00']], 2: [['09:00', '17:00']], 3: [['09:00', '17:00']], 4: [['09:00', '17:00']], 5: [['09:00', '17:00']], 6: [['10:00', '13:00']], 7: []}};
  const DEMO = 'crt-calls-demo';
  let A = null, esc = s => String(s == null ? '' : s), S = null, calls = [], built = false;
  const ro = () => !A.isAdmin();
  const clone = o => JSON.parse(JSON.stringify(o));
  async function load(){
    S = clone(DEF);
    if(A.LIVE){
      const {data} = await A.sb.from('site_content').select('value').eq('key', 'call_settings').maybeSingle();
      if(data && data.value) S = Object.assign(clone(DEF), data.value);
      const {data: c, error} = await A.sb.from('calls').select('*').gte('starts_at', new Date(Date.now() - 36e5).toISOString()).order('starts_at').limit(100);
      calls = error ? null : (c || []);
    } else { try{ const d = JSON.parse(sessionStorage.getItem(DEMO) || 'null'); if(d) S = Object.assign(clone(DEF), d); }catch(e){} calls = []; }
  }
  const when = iso => new Date(iso).toLocaleString('en-GB', {weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', timeZone: 'Africa/Kigali'});
  const wa = c => { let d = String(c || '').replace(/\D/g, ''); if(d.startsWith('0')) d = '250' + d.slice(1); return d.length >= 10 ? d : ''; };
  function paint(){
    const box = $('#set-calls'); if(!box) return;
    const dis = ro() ? ' disabled' : '', H = S.hours || {};
    const howTxt = {whatsapp: 'WhatsApp call', phone: 'Phone call', video: 'Video link'};
    const list = calls === null ? '<p class="notice small">Run <code>admin/calls-setup.sql</code> once in Supabase (SQL Editor) to turn on call booking.</p>'
      : !A.LIVE ? '<p class="muted small">Booked calls show here in the live dashboard.</p>'
      : calls.filter(c => c.status === 'booked').length ? '<ul class="cb-list">' + calls.filter(c => c.status === 'booked').map(c => `<li data-call="${c.id}">
          <div class="cb-when"><b>${esc(when(c.starts_at))}</b><small>${esc(c.minutes)} min · ${esc(howTxt[c.how] || c.how)}</small></div>
          <div class="cb-who"><b>${esc(c.name)}</b><small>${esc(c.contact)}${c.email ? ' · ' + esc(c.email) : ''}</small>${c.topic ? `<p>${esc(c.topic)}</p>` : ''}${c.video_link ? `<a href="${esc(c.video_link)}" target="_blank" rel="noopener">${esc(c.video_link.replace('https://', ''))}</a>` : ''}</div>
          <div class="cb-act">${wa(c.contact) ? `<a class="btn secondary small" href="https://wa.me/${wa(c.contact)}" target="_blank" rel="noopener">WhatsApp</a>` : ''}${ro() ? '' : `<button type="button" class="btn secondary small" data-cb="done">Done</button><button type="button" class="link danger small" data-cb="cancel">Cancel</button>`}</div></li>`).join('') + '</ul>'
      : '<p class="muted small">No calls booked yet. Share <b>crt.rw/call</b>, or use any “Book a call” button on the website.</p>';
    box.innerHTML = `<h2>Call booking</h2>
      <p class="muted small">Visitors book a free call on <a href="../call/index.html" target="_blank" rel="noopener">crt.rw/call ↗</a>. Each booking appears below and in Leads, and arrives in the hello@ mailbox. All times are Kigali time.</p>
      <h3 class="cb-h">Coming up</h3>${list}
      <h3 class="cb-h">When people can book</h3>
      <div class="cb-hours">${DAYS.map(([k, n]) => { const w = (H[k] || [])[0]; return `<div class="cb-day${w ? '' : ' is-off'}" data-d="${k}"><label class="cb-on"><input type="checkbox" data-cb="open"${w ? ' checked' : ''}${dis}> ${n}</label>
        <input type="time" data-cb="from" value="${esc(w ? w[0] : '09:00')}" step="900"${w ? '' : ' disabled'}${dis} aria-label="${n} from"><span>to</span><input type="time" data-cb="to" value="${esc(w ? w[1] : '17:00')}" step="900"${w ? '' : ' disabled'}${dis} aria-label="${n} to"></div>`; }).join('')}</div>
      <div class="cb-opts">
        <label>Call length<select data-cb="minutes"${dis}>${[15, 20, 30, 45, 60].map(m => `<option value="${m}"${+S.minutes === m ? ' selected' : ''}>${m} minutes</option>`).join('')}</select></label>
        <label>Earliest booking<select data-cb="notice"${dis}>${[[60, '1 hour from now'], [120, '2 hours from now'], [240, '4 hours from now'], [1440, 'Tomorrow at the earliest'], [2880, 'In 2 days']].map(([m, t]) => `<option value="${m}"${+S.notice_min === m ? ' selected' : ''}>${t}</option>`).join('')}</select></label>
        <label>Book up to<select data-cb="ahead"${dis}>${[7, 14, 21, 30, 60].map(d => `<option value="${d}"${+S.days_ahead === d ? ' selected' : ''}>${d} days ahead</option>`).join('')}</select></label>
      </div>
      <h3 class="cb-h">Closed days</h3>
      <p class="muted small">Holidays, shoot days or travel: nobody can book these dates.</p>
      <div class="cb-blocked">${(S.blocked || []).slice().sort().map(d => `<span class="cb-chip">${esc(new Date(d + 'T12:00:00').toLocaleDateString('en-GB', {weekday: 'short', day: 'numeric', month: 'short', year: 'numeric'}))}${ro() ? '' : `<button type="button" data-cb="unblock" data-date="${esc(d)}" aria-label="Open this day again">×</button>`}</span>`).join('') || '<span class="muted small">None.</span>'}
        ${ro() ? '' : '<input type="date" data-cb="block-date" aria-label="Date to close"><button type="button" class="btn secondary small" data-cb="block">Close this day</button>'}</div>
      ${ro() ? '<p class="muted small">Only admins can change these settings.</p>' : '<div class="row-end"><button type="button" class="btn" data-cb="save">Save call settings</button></div>'}`;
  }
  function read(){
    const box = $('#set-calls'), hours = {};
    box.querySelectorAll('.cb-day').forEach(r => { const on = r.querySelector('[data-cb="open"]').checked, a = r.querySelector('[data-cb="from"]').value, b = r.querySelector('[data-cb="to"]').value; hours[r.dataset.d] = on && a && b && a < b ? [[a, b]] : []; });
    S.hours = hours; S.minutes = +box.querySelector('[data-cb="minutes"]').value; S.notice_min = +box.querySelector('[data-cb="notice"]').value; S.days_ahead = +box.querySelector('[data-cb="ahead"]').value;
  }
  async function save(){
    read();
    if(!Object.values(S.hours).some(h => h.length)){ A.toast('Open at least one day, or people cannot book.'); return; }
    try{
      if(A.LIVE){ const {error} = await A.sb.from('site_content').upsert({key: 'call_settings', value: S, updated_by: A.me.user_id}); if(error) throw error; }
      else sessionStorage.setItem(DEMO, JSON.stringify(S));
      A.toast(A.LIVE ? 'Call settings saved. Live on crt.rw/call.' : 'Saved in this demo. Nothing was published.');
    }catch(e){ A.fail(e); }
  }
  async function onClick(e){
    const b = e.target.closest('[data-cb]'); if(!b || ro()) return;
    const a = b.dataset.cb;
    if(a === 'save') return save();
    if(a === 'block'){ const d = $('#set-calls [data-cb="block-date"]').value; if(!d){ A.toast('Pick the date first'); return; } read(); S.blocked = [...new Set([...(S.blocked || []), d])]; paint(); A.toast('Press Save call settings to publish.'); return; }
    if(a === 'unblock'){ read(); S.blocked = (S.blocked || []).filter(x => x !== b.dataset.date); paint(); return; }
    if(a === 'done' || a === 'cancel'){
      const li = b.closest('[data-call]'), id = +li.dataset.call;
      if(a === 'cancel' && !confirm('Cancel this call? Tell the client on WhatsApp too.')) return;
      const {error} = await A.sb.from('calls').update({status: a === 'done' ? 'done' : 'cancelled'}).eq('id', id);
      if(error){ A.fail(error); return; } const c = calls.find(x => x.id === id); if(c) c.status = a === 'done' ? 'done' : 'cancelled'; paint(); A.toast(a === 'done' ? 'Marked as done' : 'Call cancelled. The time is free again.');
    }
  }
  function onChange(e){ const t = e.target; if(t.dataset.cb === 'open'){ const r = t.closest('.cb-day'); r.classList.toggle('is-off', !t.checked); r.querySelectorAll('input[type=time]').forEach(i => i.disabled = !t.checked); } }
  async function mount(){
    const box = $('#set-calls'); if(!box || !A) return;
    if(!built){ built = true; box.addEventListener('click', onClick); box.addEventListener('change', onChange); }
    box.innerHTML = '<h2>Call booking</h2><p class="muted">Loading…</p>';
    try{ await load(); }catch(e){ calls = null; }
    paint();
  }
  document.addEventListener('crt:settings', e => { if(e.detail === 'calls') mount(); });
  const ready = () => { A = window.CRT_ADMIN; esc = A.esc; };
  if(window.CRT_ADMIN) ready(); else document.addEventListener('crt:ready', ready);
})();
