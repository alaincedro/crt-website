/* CRT admin: Mail. Your @crt.rw mailboxes (alain@, hello@, any you add) inside the dashboard.
   Reads public.mail_messages directly (the database only shows people the mailboxes they belong to; the main admin sees all).
   Sends and opens attachments through the "mail" server function. Mail settings (main admin): mailboxes, who reads them,
   forwarding to Gmail or any app, the sending key and the receiving worker for Cloudflare. */
(function(){
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const DOMAIN = 'crt.rw', PAGE = 60, FOLDERS = [['inbox', 'Inbox'], ['sent', 'Sent'], ['archive', 'Archive'], ['trash', 'Trash']];
  let A = null, esc = s => String(s == null ? '' : s), boxes = [], box = null, folder = 'inbox', list = [], open = null, q = '', counts = {}, team = [], setup = null, started = false, timer = 0;
  const when = t => { const d = new Date(t), now = new Date(); return d.toDateString() === now.toDateString() ? d.toLocaleTimeString('en-GB', {hour: '2-digit', minute: '2-digit'}) : d.toLocaleDateString('en-GB', {day: 'numeric', month: 'short'}); };
  const who = m => m.direction === 'out' ? 'To: ' + (m.to_addrs || []).join(', ') : (m.from_name || m.from_addr);
  async function fn(body){
    const {data, error} = await A.sb.functions.invoke('mail', {body});
    if(error){ let d = {}; try{ d = await error.context.json(); }catch(e){} const err = new Error(d.error || error.message); err.code = d.error; err.info = d; throw err; }
    return data;
  }
  const ERR = {no_sender: 'Sending isn’t connected yet. Add the Resend key in Mail settings.', no_recipient: 'Add who it goes to.', no_access: 'You don’t have access to that mailbox.', too_big: 'Attachments are over 20 MB together.', verify_first: 'Enter your sign-in code first.', owner_only: 'Only the main admin can do that.'};
  const err = e => ERR[e && e.code] || ('Something went wrong: ' + ((e && e.info && e.info.detail) || (e && e.message) || 'try again'));

  // ------------------------------------------------------------------ shell
  function shell(){
    const tab = $('#tab-inbox');
    tab.innerHTML = `<div class="page-head"><div><h1>Mail</h1><p class="muted" id="mail-sub">Your @${DOMAIN} mailboxes.</p></div>
      <div class="head-actions"><button class="btn secondary small" data-mail="refresh">Refresh</button>${A.isAdmin() && A.me.role === 'owner' ? '<button class="btn secondary small" data-mail="settings">Mail settings</button>' : ''}<button class="btn small" data-mail="compose">Write</button></div></div>
      <div class="mail" id="mail"><nav class="mail-nav panel" id="mail-nav" aria-label="Mailboxes"></nav>
        <section class="mail-list panel flush"><div class="mail-tools"><input type="search" id="mail-q" placeholder="Search this folder…" aria-label="Search mail"></div><ul id="mail-items"></ul><p class="mail-none" id="mail-none" hidden></p><button class="link" id="mail-more" data-mail="more" hidden>Load older</button></section>
        <section class="mail-read panel" id="mail-read"><p class="muted small">Choose an email to read it here.</p></section></div>
      <dialog class="mail-dlg" id="mail-compose"></dialog><dialog class="mail-dlg wide" id="mail-settings"></dialog>`;
    tab.addEventListener('click', onClick);
    $('#mail-q').addEventListener('input', e => { q = e.target.value; clearTimeout(timer); timer = setTimeout(() => load(), 250); });
  }
  async function start(){
    if(started) return; started = true; shell();
    if(!A.LIVE){ $('#mail-read').innerHTML = '<p class="muted">Mail needs the live dashboard. Nothing to show in demo mode.</p>'; return; }
    await loadBoxes();
    setInterval(() => { if(!document.hidden && !$('#tab-inbox').hidden) load(true); }, 60000);
  }
  async function loadBoxes(){
    const {data, error} = await A.sb.from('mailboxes').select('local,display_name,members,catch_all,forward_to').order('local');
    if(error){ $('#mail-nav').innerHTML = `<p class="muted small">${/does not exist|relation/i.test(error.message) ? 'Mail isn’t set up yet: run <code>admin/mail-setup.sql</code> once.' : esc(error.message)}</p>`; return; }
    boxes = data || []; if(!box || !boxes.some(b => b.local === box)) box = (boxes[0] || {}).local || null;
    await countUnread(); paintNav(); load();
  }
  async function countUnread(){
    counts = {};
    const {data} = await A.sb.from('mail_messages').select('mailbox').eq('folder', 'inbox').eq('unread', true).limit(1000);
    (data || []).forEach(r => { counts[r.mailbox] = (counts[r.mailbox] || 0) + 1; });
    const total = Object.values(counts).reduce((a, b) => a + b, 0), c = $('#inbox-count'); if(c){ c.hidden = !total; c.textContent = total; }
  }
  function paintNav(){
    $('#mail-nav').innerHTML = boxes.length ? boxes.map(b => `<div class="mail-box${b.local === box ? ' is-on' : ''}"><button type="button" data-box="${esc(b.local)}"><b>${esc(b.local)}@${DOMAIN}</b>${counts[b.local] ? `<em>${counts[b.local]}</em>` : ''}</button>
      ${b.local === box ? FOLDERS.map(([k, l]) => `<button type="button" class="mail-folder${k === folder ? ' is-on' : ''}" data-folder="${k}">${l}${k === 'inbox' && counts[b.local] ? ` <em>${counts[b.local]}</em>` : ''}</button>`).join('') : ''}</div>`).join('')
      : '<p class="muted small">No mailbox yet.</p>';
    $('#mail-sub').textContent = box ? `${box}@${DOMAIN} · ${FOLDERS.find(f => f[0] === folder)[1]}` : `Your @${DOMAIN} mailboxes.`;
  }

  // ------------------------------------------------------------------ list and reader
  async function load(keep, more){
    if(!box) { list = []; paintList(); return; }
    let qy = A.sb.from('mail_messages').select('id,created_at,folder,direction,from_addr,from_name,to_addrs,subject,text_body,unread,attachments').eq('mailbox', box).eq('folder', folder).order('created_at', {ascending: false}).range(more ? list.length : 0, (more ? list.length : 0) + PAGE - 1);
    if(q.trim()){ const t = q.trim().replace(/[%,()]/g, ' '); qy = qy.or(`subject.ilike.%${t}%,from_addr.ilike.%${t}%,from_name.ilike.%${t}%,text_body.ilike.%${t}%`); }
    const {data, error} = await qy; if(error){ A.toast(err(error)); return; }
    list = more ? list.concat(data || []) : (data || []);
    $('#mail-more').hidden = (data || []).length < PAGE;
    paintList();
    if(keep) countUnread().then(paintNav);
  }
  function paintList(){
    $('#mail-items').innerHTML = list.map(m => `<li class="${m.unread ? 'unread' : ''}${open && open.id === m.id ? ' is-open' : ''}" data-id="${m.id}"><div class="m-top"><span class="m-from">${esc(who(m))}</span><span class="m-when">${when(m.created_at)}</span></div>
      <div class="m-subject">${(m.attachments || []).length ? '📎 ' : ''}${esc(m.subject)}</div><div class="m-sum">${esc((m.text_body || '').replace(/\s+/g, ' ').slice(0, 110))}</div></li>`).join('');
    const none = $('#mail-none'); none.hidden = !!list.length; none.textContent = q ? 'Nothing matches.' : (folder === 'inbox' ? 'No mail here yet.' : 'Nothing in ' + folder + '.');
  }
  async function read(id){
    const {data: m, error} = await A.sb.from('mail_messages').select('*').eq('id', id).maybeSingle(); if(error || !m) return;
    open = m;
    if(m.unread){ await A.sb.from('mail_messages').update({unread: false}).eq('id', id); const it = list.find(x => x.id === id); if(it) it.unread = false; countUnread().then(paintNav); }
    paintList();
    const r = $('#mail-read'), atts = m.attachments || [];
    r.innerHTML = `<div class="mr-head"><h2>${esc(m.subject)}</h2><div class="mr-acts">
        ${m.direction === 'in' ? '<button class="btn small" data-mail="reply">Reply</button><button class="btn secondary small" data-mail="reply-all">Reply all</button>' : ''}<button class="btn secondary small" data-mail="forward">Forward</button>
        ${m.folder === 'trash' ? '<button class="btn secondary small" data-mail="move" data-to="inbox">Restore</button><button class="link danger" data-mail="delete">Delete forever</button>' : `${m.folder === 'archive' ? '<button class="btn secondary small" data-mail="move" data-to="inbox">Move to Inbox</button>' : (m.folder === 'inbox' ? '<button class="btn secondary small" data-mail="move" data-to="archive">Archive</button>' : '')}<button class="link danger" data-mail="move" data-to="trash">Trash</button>`}</div></div>
      <p class="mr-meta"><b>${esc(m.from_name || m.from_addr)}</b> &lt;${esc(m.from_addr)}&gt;<br><span class="muted small">To ${esc((m.to_addrs || []).join(', '))}${(m.cc_addrs || []).length ? ' · Cc ' + esc(m.cc_addrs.join(', ')) : ''} · ${new Date(m.created_at).toLocaleString('en-GB', {weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit'})}</span></p>
      ${atts.length ? `<div class="mr-atts">${atts.map((a, i) => `<button type="button" class="mr-att" data-att="${i}">📎 ${esc(a.name)} <small>${Math.max(1, Math.round((a.size || 0) / 1024))} KB</small></button>`).join('')}</div>` : ''}
      <iframe class="mr-body" sandbox="allow-popups allow-popups-to-escape-sandbox" title="Email"></iframe>`;
    const f = $('.mr-body', r), base = '<base target="_blank"><meta http-equiv="Content-Security-Policy" content="script-src \'none\'"><style>body{font:15px/1.55 -apple-system,Segoe UI,Helvetica,Arial,sans-serif;color:#1d1d1f;margin:0;padding:4px 2px;word-wrap:break-word}img{max-width:100%;height:auto}pre{white-space:pre-wrap}</style>';
    f.srcdoc = base + (m.html_body || `<pre>${esc(m.text_body)}</pre>`);
    f.onload = () => { try{ f.style.height = Math.min(4000, f.contentDocument.documentElement.scrollHeight + 20) + 'px'; }catch(e){} };
  }

  // ------------------------------------------------------------------ compose
  function compose(mode){
    const m = open, d = $('#mail-compose'), mine = boxes.map(b => b.local);
    let to = '', cc = '', subject = '', text = '', reply = null, from = box;
    if(m && mode){
      const quote = `\n\n\nOn ${new Date(m.created_at).toLocaleString('en-GB')}, ${m.from_name || m.from_addr} wrote:\n` + (m.text_body || '').split('\n').map(l => '> ' + l).join('\n');
      if(mode === 'forward'){ subject = (/^fwd?:/i.test(m.subject) ? '' : 'Fwd: ') + m.subject; text = quote.replace('wrote:', 'wrote (forwarded):'); }
      else {
        to = m.from_addr; subject = (/^re:/i.test(m.subject) ? '' : 'Re: ') + m.subject; text = quote; reply = m.message_id;
        if(mode === 'reply-all') cc = [...(m.to_addrs || []), ...(m.cc_addrs || [])].filter(a => !a.endsWith('@' + DOMAIN) && a !== m.from_addr).join(', ');
        const hit = (m.to_addrs || []).map(a => a.split('@')).find(([l, dmn]) => dmn === DOMAIN && mine.includes(l)); if(hit) from = hit[0];
      }
    }
    d.innerHTML = `<form method="dialog" class="mail-form" id="mail-form"><header><h2>${mode === 'forward' ? 'Forward' : mode ? 'Reply' : 'New email'}</h2><button type="button" class="link" data-mail="close" aria-label="Close">×</button></header>
      <label>From<select name="mailbox">${boxes.map(b => `<option value="${esc(b.local)}"${b.local === from ? ' selected' : ''}>${esc(b.display_name || b.local)} &lt;${esc(b.local)}@${DOMAIN}&gt;</option>`).join('')}</select></label>
      <label>To<input name="to" value="${esc(to)}" placeholder="name@example.com, …" required autocomplete="off"></label>
      <label>Cc<input name="cc" value="${esc(cc)}" autocomplete="off"></label>
      <label>Subject<input name="subject" value="${esc(subject)}"></label>
      <textarea name="text" rows="12" placeholder="Write your email…">${esc(text)}</textarea>
      <div class="mail-files"><label class="btn secondary small">Attach files<input type="file" multiple hidden id="mail-files"></label><span id="mail-file-list" class="muted small"></span></div>
      <footer><span class="muted small">Sent from ${DOMAIN}. A copy is kept in Sent.</span><button class="btn" type="submit">Send</button></footer></form>`;
    d.showModal();
    let files = [];
    $('#mail-files').onchange = e => { files = files.concat([...e.target.files]); $('#mail-file-list').textContent = files.map(f => f.name).join(', '); };
    $('#mail-form').onsubmit = async e => {
      e.preventDefault(); const f = e.target, btn = f.querySelector('[type=submit]'); btn.disabled = true; btn.textContent = 'Sending…';
      try{
        const attachments = await Promise.all(files.map(file => new Promise((res, rej) => { const rd = new FileReader(); rd.onload = () => res({name: file.name, type: file.type, base64: String(rd.result).split(',')[1]}); rd.onerror = rej; rd.readAsDataURL(file); })));
        await fn({action: 'send', mailbox: f.mailbox.value, to: f.to.value, cc: f.cc.value, subject: f.subject.value, text: f.text.value, in_reply_to: reply, attachments});
        d.close(); A.toast('Sent'); if(folder === 'sent') load();
      }catch(x){ A.toast(err(x)); btn.disabled = false; btn.textContent = 'Send'; }
    };
  }

  // ------------------------------------------------------------------ mail settings (main admin)
  async function settings(){
    const d = $('#mail-settings'); d.innerHTML = '<div class="mail-form"><p class="muted">Loading…</p></div>'; d.showModal();
    try{ setup = await fn({action: 'setup'}); }catch(e){ setup = null; }
    if(!team.length){ const {data} = await A.sb.from('team').select('user_id,name,role').order('name'); team = data || []; }
    paintSettings();
  }
  function paintSettings(){
    const d = $('#mail-settings'), s = setup || {}, cfg = window.CRT_CONFIG || {};
    const worker = s.receiving_key ? `// paste into Cloudflare → Workers → your email worker\n` + WORKER.replace('PASTE_ENDPOINT', s.endpoint).replace('PASTE_KEY', s.receiving_key).replace('PASTE_PUBLIC_KEY', cfg.SUPABASE_ANON_KEY || '') : '';
    const dom = {verified: '<span class="role-chip is-on">Verified</span>', pending: '<span class="role-chip is-off">Waiting for DNS</span>', not_started: '<span class="role-chip is-off">Waiting for DNS</span>', not_added: '<span class="role-chip is-off">Add crt.rw in Resend</span>', bad_key: '<span class="role-chip is-off">Key not accepted</span>'}[s.domain] || '';
    d.innerHTML = `<div class="mail-form"><header><h2>Mail settings</h2><button type="button" class="link" data-mail="close" aria-label="Close">×</button></header>
      <h3>Mailboxes</h3><p class="muted small">Each address at ${DOMAIN}. Tick who reads it (you read every mailbox). “Forward a copy to” also delivers each email to Gmail or any other app.</p>
      <div class="mb-list">${boxes.map(b => `<div class="mb-row" data-local="${esc(b.local)}"><div class="mb-top"><b>${esc(b.local)}@${DOMAIN}</b><input class="mb-name" value="${esc(b.display_name)}" placeholder="Name shown when sending" aria-label="Name for ${esc(b.local)}">
          <label class="mb-ca"><input type="radio" name="catch" ${b.catch_all ? 'checked' : ''} data-catch> Gets mail for unknown addresses</label></div>
        <div class="mb-mem">${team.filter(t => t.role !== 'owner').map(t => `<label><input type="checkbox" data-mem="${esc(t.user_id)}" ${(b.members || []).includes(t.user_id) ? 'checked' : ''}> ${esc(t.name)}</label>`).join('') || '<span class="muted small">Add team members in Team to share this mailbox.</span>'}</div>
        <input class="mb-fwd" value="${esc((b.forward_to || []).join(', '))}" placeholder="Forward a copy to (e.g. you@gmail.com)" aria-label="Forward ${esc(b.local)} to">
        <div class="row-end"><button type="button" class="btn secondary small" data-mail="mb-save">Save</button>${b.catch_all ? '' : '<button type="button" class="link danger" data-mail="mb-del">Delete mailbox</button>'}</div></div>`).join('')}</div>
      <form class="mb-add" id="mb-add"><input name="local" placeholder="new address, e.g. bookings" pattern="[a-z0-9][a-z0-9._-]{0,40}" required><span>@${DOMAIN}</span><input name="name" placeholder="Name shown when sending"><button class="btn small">Add mailbox</button></form>
      <h3>Sending ${s.sender ? '<span class="role-chip is-on">Connected</span>' : '<span class="role-chip is-off">Not connected</span>'} ${dom}</h3>
      <p class="muted small">Through Resend (free for 3,000 emails a month). Paste the API key once; it stays locked on the server.</p>
      <form class="mb-add" id="mb-key"><input name="key" type="password" placeholder="${s.sender ? '•••••••• saved (type to replace)' : 're_…'}" autocomplete="off"><button class="btn small">Save key</button></form>
      <h3>Receiving ${s.received ? `<span class="role-chip is-on">${s.received} received</span>` : (s.webhook ? '<span class="role-chip is-on">Ready, nothing received yet</span>' : '<span class="role-chip is-off">Not connected</span>')}</h3>
      <p class="muted small">Also through Resend (free). In Resend: Domains → ${DOMAIN} → turn on <b>Receiving</b> and add the MX record it shows at your DNS. Then Webhooks → Add endpoint → paste this address, choose the event <b>email.received</b>, and paste the endpoint's <b>Signing secret</b> below. Full steps: <code>admin/MAIL-SETUP.txt</code>.</p>
      ${s.endpoint ? `<label class="mb-url">Webhook address<input readonly value="${esc(s.endpoint)}" onclick="this.select()"></label>` : ''}
      <form class="mb-add" id="mb-hook"><input name="secret" type="password" placeholder="${s.webhook ? '•••••••• saved (type to replace)' : 'whsec_…'}" autocomplete="off"><button class="btn small">Save signing secret</button></form>
      ${worker ? `<details class="mb-alt"><summary>Prefer Cloudflare for receiving? (also free)</summary><p class="muted small">In Cloudflare → Workers &amp; Pages → Create → Worker, paste this code, then Email Routing → Catch-all → Send to Worker.</p><pre class="code mb-code" id="mb-worker">${esc(worker)}</pre><div class="row-end"><button type="button" class="btn secondary small" data-mail="copy-worker">Copy worker code</button><button type="button" class="link" data-mail="new-key">Make a new receiving key</button></div></details>` : ''}
      <h3>Use it in Gmail or any mail app</h3><ul class="tips"><li><b>Receive:</b> put the app’s address in “Forward a copy to” above. Each email arrives there too, and Reply goes straight to the sender.</li>
      <li><b>Send as ${esc((boxes[0] || {}).local || 'hello')}@${DOMAIN}:</b> Gmail → Settings → Accounts → “Send mail as” → Add. SMTP server <code>smtp.resend.com</code>, port <code>465</code>, username <code>resend</code>, password: your Resend API key. Apple Mail and Outlook use the same settings.</li></ul></div>`;
    $('#mb-add').onsubmit = async e => { e.preventDefault(); const f = e.target; const {error} = await A.sb.from('mailboxes').insert({local: f.local.value.trim().toLowerCase(), display_name: f.name.value.trim(), members: []}); if(error){ A.toast(/duplicate/i.test(error.message) ? 'That address already exists.' : err(error)); return; } A.toast('Mailbox added'); await loadBoxes(); paintSettings(); };
    $('#mb-hook').onsubmit = async e => { e.preventDefault(); const k = e.target.secret.value.trim(); if(!k) return; try{ setup = await fn({action: 'setup', webhook_secret: k}); A.toast('Signing secret saved. Receiving is ready.'); paintSettings(); }catch(x){ A.toast(err(x)); } };
    $('#mb-key').onsubmit = async e => { e.preventDefault(); const k = e.target.key.value.trim(); if(!k) return; try{ setup = await fn({action: 'setup', resend_key: k}); A.toast('Sending key saved'); paintSettings(); }catch(x){ A.toast(err(x)); } };
  }
  const WORKER = `const ENDPOINT = "PASTE_ENDPOINT";
const RECEIVING_KEY = "PASTE_KEY";
const PUBLIC_KEY = "PASTE_PUBLIC_KEY";
export default {
  async email(message, env, ctx) {
    const raw = new Uint8Array(await new Response(message.raw).arrayBuffer());
    let s = ""; for (let i = 0; i < raw.length; i += 0x8000) s += String.fromCharCode(...raw.subarray(i, i + 0x8000));
    const r = await fetch(ENDPOINT, { method: "POST",
      headers: { "Content-Type": "application/json", "x-crt-mail-secret": RECEIVING_KEY, Authorization: "Bearer " + PUBLIC_KEY, apikey: PUBLIC_KEY },
      body: JSON.stringify({ to: message.to, from: message.from, raw: btoa(s) }) });
    if (r.status === 404) return message.setReject("No such mailbox at crt.rw");
    if (!r.ok) throw new Error("CRT mail store failed: " + r.status);
    const d = await r.json().catch(() => ({}));
    for (const to of d.forward || []) { try { await message.forward(to); } catch (e) { console.log("forward failed", to, String(e)); } }
  },
};`;

  // ------------------------------------------------------------------ events
  async function onClick(e){
    const t = e.target.closest('button,li[data-id]'); if(!t) return;
    if(t.matches('li[data-id]')){ read(+t.dataset.id); return; }
    if(t.dataset.box){ box = t.dataset.box; folder = 'inbox'; open = null; $('#mail-read').innerHTML = '<p class="muted small">Choose an email to read it here.</p>'; paintNav(); load(); return; }
    if(t.dataset.folder){ folder = t.dataset.folder; open = null; $('#mail-read').innerHTML = '<p class="muted small">Choose an email to read it here.</p>'; paintNav(); load(); return; }
    if(t.dataset.att != null && open){ const a = open.attachments[+t.dataset.att]; try{ const r = await fn({action: 'file', path: a.path}); window.open(r.url, '_blank', 'noopener'); }catch(x){ A.toast(err(x)); } return; }
    const a = t.dataset.mail; if(!a) return;
    if(a === 'refresh'){ await loadBoxes(); A.toast('Mail up to date'); }
    else if(a === 'more') load(false, true);
    else if(a === 'compose') compose(null);
    else if(a === 'reply' || a === 'reply-all' || a === 'forward') compose(a);
    else if(a === 'close') t.closest('dialog').close();
    else if(a === 'move' && open){ const {error} = await A.sb.from('mail_messages').update({folder: t.dataset.to}).eq('id', open.id); if(error){ A.toast(err(error)); return; } A.toast(t.dataset.to === 'trash' ? 'Moved to Trash' : t.dataset.to === 'archive' ? 'Archived' : 'Moved'); open = null; $('#mail-read').innerHTML = '<p class="muted small">Choose an email to read it here.</p>'; load(true); }
    else if(a === 'delete' && open){ if(!confirm('Delete this email forever?')) return; await A.sb.from('mail_messages').delete().eq('id', open.id); open = null; $('#mail-read').innerHTML = ''; load(); }
    else if(a === 'settings') settings();
    else if(a === 'copy-worker'){ try{ await navigator.clipboard.writeText($('#mb-worker').textContent); A.toast('Worker code copied'); }catch(x){ A.toast('Select the code and copy it'); } }
    else if(a === 'new-key'){ if(!confirm('Make a new receiving key? The worker in Cloudflare must then be updated with the new code.')) return; try{ setup = await fn({action: 'setup', new_key: true}); paintSettings(); A.toast('New key made. Update the worker in Cloudflare.'); }catch(x){ A.toast(err(x)); } }
    else if(a === 'mb-save' || a === 'mb-del'){
      const row = t.closest('.mb-row'), local = row.dataset.local;
      if(a === 'mb-del'){ if(!confirm(`Delete ${local}@${DOMAIN} and all its mail?`)) return; const {error} = await A.sb.from('mailboxes').delete().eq('local', local); if(error){ A.toast(err(error)); return; } A.toast('Mailbox deleted'); await loadBoxes(); paintSettings(); return; }
      const fwd = row.querySelector('.mb-fwd').value.split(/[,;\s]+/).map(x => x.trim().toLowerCase()).filter(x => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x) && !x.endsWith('@' + DOMAIN)).slice(0, 5);
      const patch = {display_name: row.querySelector('.mb-name').value.trim(), members: $$('[data-mem]:checked', row).map(c => c.dataset.mem), forward_to: fwd};
      if(row.querySelector('[data-catch]').checked){ await A.sb.from('mailboxes').update({catch_all: false}).neq('local', local); patch.catch_all = true; }
      const {error} = await A.sb.from('mailboxes').update(patch).eq('local', local);
      if(error){ A.toast(err(error)); return; } A.toast('Saved'); await loadBoxes(); paintSettings();
    }
  }

  window.CRT_MAIL = {open: () => { if(A) start(); }};
  const ready = () => { A = window.CRT_ADMIN; esc = A.esc; if(!$('#tab-inbox').hidden) start(); };
  if(window.CRT_ADMIN) ready(); else document.addEventListener('crt:ready', ready);
})();
