/* CRT admin: Mail. Your @crt.rw mailboxes (alain@, hello@, any you add) inside the dashboard.
   Reads public.mail_messages directly (the database only shows people the mailboxes they belong to; the main admin sees all).
   Sends and opens attachments through the "mail" server function. Mail settings (main admin): mailboxes, who reads them,
   forwarding to Gmail or any app, the sending key and the receiving worker for Cloudflare. */
(function(){
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const DOMAIN = 'crt.rw', PAGE = 60, FOLDERS = [['inbox', 'Inbox'], ['sent', 'Sent'], ['archive', 'Archive'], ['trash', 'Trash']];
  let setHost = null;   // Settings → Mail (settings.js), where the mail settings now live
  let A = null, esc = s => String(s == null ? '' : s), boxes = [], box = null, folder = 'inbox', list = [], open = null, q = '', counts = {}, team = [], setup = null, started = false, timer = 0;
  const when = t => { const d = new Date(t), now = new Date(); return d.toDateString() === now.toDateString() ? d.toLocaleTimeString('en-GB', {hour: '2-digit', minute: '2-digit'}) : d.toLocaleDateString('en-GB', {day: 'numeric', month: 'short'}); };
  const who = m => m.direction === 'out' ? 'To: ' + (m.to_addrs || []).join(', ') : (m.from_name || m.from_addr);
  async function fn(body){
    const {data, error} = await A.sb.functions.invoke('mail', {body});
    if(error){ let d = {}; try{ d = await error.context.json(); }catch(e){} const err = new Error(d.error || error.message); err.code = d.error; err.info = d; throw err; }
    return data;
  }
  const ERR = {no_sender: 'Sending isn’t connected yet. Add the Resend key in Mail settings.', no_recipient: 'Add who it goes to.', no_access: 'You don’t have access to that mailbox.', too_big: 'Attachments are over 20 MB together.', verify_first: 'Enter your sign-in code first.', owner_only: 'Only the main admin can do that.', bad_secret: 'That isn’t the signing secret. In Resend → Webhooks → your endpoint, click the eye, then copy the text that starts with whsec_.'};
  const err = e => ERR[e && e.code] || ('Something went wrong: ' + ((e && e.info && e.info.detail) || (e && e.message) || 'try again'));

  // ------------------------------------------------------------------ shell (laid out like Gmail)
  const I = {
    search: '<path d="M10.5 4a6.5 6.5 0 1 0 4 11.6l4.2 4.2 1.4-1.4-4.2-4.2A6.5 6.5 0 0 0 10.5 4Zm0 2a4.5 4.5 0 1 1 0 9 4.5 4.5 0 0 1 0-9Z"/>',
    refresh: '<path d="M17.7 6.3A8 8 0 1 0 20 12h-2a6 6 0 1 1-1.8-4.2L13 11h7V4l-2.3 2.3Z"/>',
    gear: '<path d="M19.4 13a7.6 7.6 0 0 0 0-2l2.1-1.6-2-3.5-2.5 1a7.4 7.4 0 0 0-1.7-1L15 3h-4l-.4 2.9a7.4 7.4 0 0 0-1.7 1l-2.5-1-2 3.5L6.6 11a7.6 7.6 0 0 0 0 2l-2.1 1.6 2 3.5 2.5-1a7.4 7.4 0 0 0 1.7 1L11 21h4l.4-2.9a7.4 7.4 0 0 0 1.7-1l2.5 1 2-3.5-2.2-1.6ZM13 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7Z"/>',
    pen: '<path d="M3 17.3V21h3.7L17.8 9.9l-3.7-3.7L3 17.3Zm17.7-10.2a1 1 0 0 0 0-1.4l-2.4-2.4a1 1 0 0 0-1.4 0l-1.8 1.8 3.7 3.7 1.9-1.7Z"/>',
    inbox: '<path d="M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2Zm0 12h-4a3 3 0 0 1-6 0H5V5h14v10Z"/>',
    sent: '<path d="M2 21 23 12 2 3v7l15 2-15 2v7Z"/>',
    archive: '<path d="M20.5 5.2 19.1 3.5A1.5 1.5 0 0 0 18 3H6c-.5 0-.9.2-1.2.5L3.5 5.2A2 2 0 0 0 3 6.5V19a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6.5c0-.5-.2-1-.5-1.3ZM12 17.5 6.5 12H10v-2h4v2h3.5L12 17.5ZM5.1 5l.8-1h12l.9 1H5.1Z"/>',
    trash: '<path d="M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6v12ZM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4Z"/>',
    back: '<path d="M20 11H7.8l5.6-5.6L12 4l-8 8 8 8 1.4-1.4L7.8 13H20v-2Z"/>',
    unread: '<path d="M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2Zm0 4-8 5-8-5V6l8 5 8-5v2Z"/>',
    reply: '<path d="M10 9V5l-7 7 7 7v-4.1c5 0 8.5 1.6 11 5.1-1-5-4-10-11-11Z"/>',
    fwd: '<path d="M14 9V5l7 7-7 7v-4.1c-5 0-8.5 1.6-11 5.1 1-5 4-10 11-11Z"/>',
    clip: '<path d="M16.5 6v11.5a4 4 0 0 1-8 0V5a2.5 2.5 0 0 1 5 0v10.5a1 1 0 0 1-2 0V6H10v9.5a2.5 2.5 0 0 0 5 0V5a4 4 0 0 0-8 0v12.5a5.5 5.5 0 0 0 11 0V6h-1.5Z"/>',
    x: '<path d="M19 6.4 17.6 5 12 10.6 6.4 5 5 6.4 10.6 12 5 17.6 6.4 19 12 13.4 17.6 19 19 17.6 13.4 12 19 6.4Z"/>',
    min: '<path d="M5 18h14v2H5z"/>'
  };
  const ico = k => `<svg viewBox="0 0 24 24" aria-hidden="true" class="gi">${I[k]}</svg>`;
  const iconBtn = (k, label, attrs) => `<button type="button" class="gm-ib" aria-label="${label}" title="${label}" ${attrs}>${ico(k)}</button>`;
  const FI = {inbox: 'inbox', sent: 'sent', archive: 'archive', trash: 'trash'};
  function shell(){
    const tab = $('#tab-inbox');
    tab.innerHTML = `<div class="gm" id="mail">
        <aside class="gm-rail" id="mail-nav" aria-label="Mail folders"></aside>
        <section class="gm-main">
          <div class="gm-top"><label class="gm-search">${ico('search')}<input type="search" id="mail-q" placeholder="Search mail" aria-label="Search mail"></label>
            ${iconBtn('refresh', 'Refresh', 'data-mail="refresh"')}${A.isAdmin() && A.me.role === 'owner' ? iconBtn('gear', 'Mail settings', 'data-mail="settings"') : ''}</div>
          <div class="gm-view" id="mail-view">
            <div class="gm-listbar"><span class="gm-where" id="mail-sub"></span><span class="muted small" id="mail-range"></span></div>
            <ul class="gm-list" id="mail-items"></ul><p class="mail-none" id="mail-none" hidden></p><button class="link" id="mail-more" data-mail="more" hidden>Load older</button>
          </div>
          <div class="gm-read" id="mail-read" hidden></div>
        </section></div>
      <dialog class="gm-compose" id="mail-compose"></dialog>`;
    tab.addEventListener('click', onClick);
    tab.addEventListener('keydown', e => { const li = e.target.closest && e.target.closest('li[data-id]'); if(li && e.key === 'Enter') read(+li.dataset.id); });
    $('#mail-q').addEventListener('input', e => { q = e.target.value; clearTimeout(timer); timer = setTimeout(() => load(), 250); });
  }
  async function start(){
    if(started) return; started = true; shell();
    if(!A.LIVE){ $('#mail-items').innerHTML = ''; const n = $('#mail-none'); n.hidden = false; n.textContent = 'Mail needs the live dashboard. Nothing to show in demo mode.'; return; }
    await loadBoxes();
    setInterval(() => { if(!document.hidden && !$('#tab-inbox').hidden) load(true); }, 60000);
  }
  async function loadBoxes(){
    const {data, error} = await A.sb.from('mailboxes').select('local,display_name,members,catch_all,forward_to').order('local');
    if(error){ $('#mail-nav').innerHTML = `<p class="muted small">${/does not exist|relation/i.test(error.message) ? 'Mail isn’t set up yet: run <code>admin/mail-setup.sql</code> once.' : esc(error.message)}</p>`; return; }
    boxes = data || []; if(!box || !boxes.some(b => b.local === box)) box = (boxes[0] || {}).local || null;
    await countUnread(); paintNav(); load();
  }
  async function countUnread(){
    counts = {};
    const {data} = await A.sb.from('mail_messages').select('mailbox').eq('folder', 'inbox').eq('unread', true).limit(1000);
    (data || []).forEach(r => { counts[r.mailbox] = (counts[r.mailbox] || 0) + 1; });
    const total = Object.values(counts).reduce((a, b) => a + b, 0), c = $('#inbox-count'); if(c){ c.hidden = !total; c.textContent = total; }
  }
  // Left rail: Compose, the folders of the open mailbox, then the mailboxes (like Gmail's labels)
  function paintNav(){
    $('#mail-nav').innerHTML = `<button type="button" class="gm-compose-btn" data-mail="compose">${ico('pen')}<span>Compose</span></button>`
      + `<nav class="gm-folders">${FOLDERS.map(([k, l]) => `<button type="button" class="gm-f${k === folder ? ' is-on' : ''}" data-folder="${k}"${k === folder ? ' aria-current="true"' : ''}>${ico(FI[k])}<span>${l}</span>${k === 'inbox' && counts[box] ? `<em>${counts[box]}</em>` : ''}</button>`).join('')}</nav>`
      + (boxes.length > 1 ? `<p class="gm-lab">Mailboxes</p>${boxes.map(b => `<button type="button" class="gm-f gm-box${b.local === box ? ' is-on' : ''}" data-box="${esc(b.local)}" title="${esc(b.local)}@${DOMAIN}"><span class="gm-dot" aria-hidden="true"></span><span>${esc(b.local)}@${DOMAIN}</span>${counts[b.local] ? `<em>${counts[b.local]}</em>` : ''}</button>`).join('')}` : '')
      + (!boxes.length ? '<p class="muted small">No mailbox yet.</p>' : '');
    $('#mail-sub').textContent = box ? `${FOLDERS.find(f => f[0] === folder)[1]}${boxes.length > 1 ? ' · ' + box + '@' + DOMAIN : ''}` : '';
  }

  // ------------------------------------------------------------------ list and reader
  async function load(keep, more){
    if(!box) { list = []; paintList(); return; }
    let qy = A.sb.from('mail_messages').select('id,created_at,folder,direction,from_addr,from_name,to_addrs,subject,text_body,unread,attachments').eq('mailbox', box).eq('folder', folder).order('created_at', {ascending: false}).range(more ? list.length : 0, (more ? list.length : 0) + PAGE - 1);
    if(q.trim()){ const t = q.trim().replace(/[%,()]/g, ' '); qy = qy.or(`subject.ilike.%${t}%,from_addr.ilike.%${t}%,from_name.ilike.%${t}%,text_body.ilike.%${t}%`); }
    const {data, error} = await qy; if(error){ A.toast(err(error)); return; }
    list = more ? list.concat(data || []) : (data || []);
    $('#mail-more').hidden = (data || []).length < PAGE;
    paintList();
    if(keep) countUnread().then(paintNav);
  }
  function paintList(){
    $('#mail-items').innerHTML = list.map(m => `<li class="gm-row${m.unread ? ' unread' : ''}" data-id="${m.id}" tabindex="0">
      <span class="gm-from">${esc(who(m))}</span>
      <span class="gm-text"><span class="gm-subj">${esc(m.subject || '(no subject)')}</span><span class="gm-snip"> — ${esc((m.text_body || '').replace(/\s+/g, ' ').slice(0, 140))}</span></span>
      ${(m.attachments || []).length ? `<span class="gm-clip" title="Attachment">${ico('clip')}</span>` : '<span></span>'}
      <span class="gm-when">${when(m.created_at)}</span>
      <span class="gm-hover">${m.folder === 'inbox' ? iconBtn('archive', 'Archive', `data-mail="row-move" data-to="archive" data-row="${m.id}"`) : ''}${m.folder !== 'trash' ? iconBtn('trash', 'Delete', `data-mail="row-move" data-to="trash" data-row="${m.id}"`) : ''}</span></li>`).join('');
    const none = $('#mail-none'); none.hidden = !!list.length; none.textContent = q ? 'No messages matched your search.' : (folder === 'inbox' ? 'Your inbox is empty.' : 'No messages in ' + FOLDERS.find(f => f[0] === folder)[1] + '.');
    $('#mail-range').textContent = list.length ? '1–' + list.length : '';
  }
  const showList = () => { open = null; $('#mail-read').hidden = true; $('#mail-read').innerHTML = ''; $('#mail-view').hidden = false; };
  const initial = m => (String(m.from_name || m.from_addr || '?').trim()[0] || '?').toUpperCase();
  async function read(id){
    const {data: m, error} = await A.sb.from('mail_messages').select('*').eq('id', id).maybeSingle(); if(error || !m) return;
    open = m;
    if(m.unread){ await A.sb.from('mail_messages').update({unread: false}).eq('id', id); const it = list.find(x => x.id === id); if(it) it.unread = false; countUnread().then(paintNav); paintList(); }
    const r = $('#mail-read'), atts = m.attachments || [];
    const others = [...(m.to_addrs || []), ...(m.cc_addrs || [])].filter(a => !a.endsWith('@' + DOMAIN) && a !== m.from_addr);
    r.innerHTML = `<div class="gm-rbar">${iconBtn('back', 'Back to ' + FOLDERS.find(f => f[0] === folder)[1], 'data-mail="back"')}
        ${m.folder === 'trash' ? iconBtn('inbox', 'Move to Inbox', 'data-mail="move" data-to="inbox"') + `<button type="button" class="link danger small" data-mail="delete">Delete forever</button>`
          : (m.folder === 'archive' ? iconBtn('inbox', 'Move to Inbox', 'data-mail="move" data-to="inbox"') : m.folder === 'inbox' ? iconBtn('archive', 'Archive', 'data-mail="move" data-to="archive"') : '') + iconBtn('trash', 'Delete', 'data-mail="move" data-to="trash"')}
        ${m.direction === 'in' ? iconBtn('unread', 'Mark as unread', 'data-mail="unread"') : ''}</div>
      <h2 class="gm-subject">${esc(m.subject || '(no subject)')}</h2>
      <div class="gm-sender"><span class="gm-av" aria-hidden="true">${esc(initial(m))}</span><div class="gm-who"><b>${esc(m.from_name || m.from_addr)}</b> <span class="muted small">&lt;${esc(m.from_addr)}&gt;</span><br><span class="muted small">to ${esc((m.to_addrs || []).join(', '))}${(m.cc_addrs || []).length ? ', cc ' + esc(m.cc_addrs.join(', ')) : ''}</span></div>
        <span class="gm-date muted small">${new Date(m.created_at).toLocaleString('en-GB', {day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'})}</span></div>
      <iframe class="mr-body" sandbox="allow-popups allow-popups-to-escape-sandbox" title="Email"></iframe>
      ${atts.length ? `<div class="mr-atts">${atts.map((a, i) => `<button type="button" class="mr-att" data-att="${i}">${ico('clip')}<span>${esc(a.name)}</span><small>${Math.max(1, Math.round((a.size || 0) / 1024))} KB</small></button>`).join('')}</div>` : ''}
      <div class="gm-replies">${m.direction === 'in' ? `<button type="button" class="gm-pill" data-mail="reply">${ico('reply')}Reply</button>${others.length ? `<button type="button" class="gm-pill" data-mail="reply-all">${ico('reply')}Reply all</button>` : ''}` : ''}<button type="button" class="gm-pill" data-mail="forward">${ico('fwd')}Forward</button></div>`;
    $('#mail-view').hidden = true; r.hidden = false; window.scrollTo({top: 0});
    const f = $('.mr-body', r), base = '<base target="_blank"><meta http-equiv="Content-Security-Policy" content="script-src \'none\'"><style>body{font:14px/1.55 Arial,Helvetica,sans-serif;color:#222;margin:0;padding:4px 2px;word-wrap:break-word}img{max-width:100%;height:auto}pre{white-space:pre-wrap;font:inherit}</style>';
    f.srcdoc = base + (m.html_body || `<pre>${esc(m.text_body)}</pre>`);
    f.onload = () => { try{ f.style.height = Math.min(4000, f.contentDocument.documentElement.scrollHeight + 20) + 'px'; }catch(e){} };
  }

  // ------------------------------------------------------------------ compose
  function compose(mode){
    const m = open, d = $('#mail-compose'), mine = boxes.map(b => b.local);
    let to = '', cc = '', subject = '', text = '', reply = null, from = box;
    if(m && mode){
      const quote = `\n\n\nOn ${new Date(m.created_at).toLocaleString('en-GB')}, ${m.from_name || m.from_addr} wrote:\n` + (m.text_body || '').split('\n').map(l => '> ' + l).join('\n');
      if(mode === 'forward'){ subject = (/^fwd?:/i.test(m.subject) ? '' : 'Fwd: ') + m.subject; text = quote.replace('wrote:', 'wrote (forwarded):'); }
      else {
        to = m.from_addr; subject = (/^re:/i.test(m.subject) ? '' : 'Re: ') + m.subject; text = quote; reply = m.message_id;
        if(mode === 'reply-all') cc = [...(m.to_addrs || []), ...(m.cc_addrs || [])].filter(a => !a.endsWith('@' + DOMAIN) && a !== m.from_addr).join(', ');
        const hit = (m.to_addrs || []).map(a => a.split('@')).find(([l, dmn]) => dmn === DOMAIN && mine.includes(l)); if(hit) from = hit[0];
      }
    }
    const title = mode === 'forward' ? 'Forward' : mode ? 'Reply' : 'New message';
    d.innerHTML = `<form method="dialog" class="gm-cform" id="mail-form"><header><b>${title}</b><span>${iconBtn('min', 'Minimise', 'data-mail="min"')}${iconBtn('x', 'Close', 'data-mail="close"')}</span></header>
      <div class="gm-cbody">
      ${boxes.length > 1 ? `<label class="gm-line"><span>From</span><select name="mailbox">${boxes.map(b => `<option value="${esc(b.local)}"${b.local === from ? ' selected' : ''}>${esc(b.display_name || b.local)} &lt;${esc(b.local)}@${DOMAIN}&gt;</option>`).join('')}</select></label>` : `<input type="hidden" name="mailbox" value="${esc(from || '')}">`}
      <label class="gm-line"><span>To</span><input name="to" value="${esc(to)}" required autocomplete="off"><button type="button" class="link small" data-mail="show-cc"${cc ? ' hidden' : ''}>Cc</button></label>
      <label class="gm-line" id="mail-cc"${cc ? '' : ' hidden'}><span>Cc</span><input name="cc" value="${esc(cc)}" autocomplete="off"></label>
      <label class="gm-line"><input name="subject" value="${esc(subject)}" placeholder="Subject" aria-label="Subject"></label>
      <textarea name="text" aria-label="Message">${esc(text)}</textarea>
      <p id="mail-file-list" class="gm-files"></p></div>
      <footer><button class="gm-send" type="submit">Send</button><label class="gm-ib" title="Attach files" aria-label="Attach files">${ico('clip')}<input type="file" multiple hidden id="mail-files"></label></footer></form>`;
    d.classList.remove('is-min'); if(!d.open) d.show();
    const first = mode && mode !== 'forward' ? d.querySelector('textarea') : d.querySelector('[name=to]'); first.focus(); if(first.tagName === 'TEXTAREA') first.setSelectionRange(0, 0);
    let files = [];
    $('#mail-files').onchange = e => { files = files.concat([...e.target.files]); $('#mail-file-list').innerHTML = files.map(f => `<span>${ico('clip')}${esc(f.name)}</span>`).join(''); };
    $('#mail-form').onsubmit = async e => {
      e.preventDefault(); const f = e.target, btn = f.querySelector('[type=submit]'); btn.disabled = true; btn.textContent = 'Sending…';
      try{
        const attachments = await Promise.all(files.map(file => new Promise((res, rej) => { const rd = new FileReader(); rd.onload = () => res({name: file.name, type: file.type, base64: String(rd.result).split(',')[1]}); rd.onerror = rej; rd.readAsDataURL(file); })));
        await fn({action: 'send', mailbox: f.mailbox.value, to: f.to.value, cc: f.cc.value, subject: f.subject.value, text: f.text.value, in_reply_to: reply, attachments});
        d.close(); A.toast('Message sent'); if(folder === 'sent') load();
      }catch(x){ A.toast(err(x)); btn.disabled = false; btn.textContent = 'Send'; }
    };
  }

  // ------------------------------------------------------------------ mail settings (main admin)
  async function settings(){ if(window.CRT_SETTINGS) window.CRT_SETTINGS.open('mail'); }
  async function settingsIn(host){
    if(!host || !A) return;
    if(!setHost){ setHost = host; host.addEventListener('click', onClick); }
    if(!A.LIVE){ host.innerHTML = '<h2>Mail</h2><p class="muted small">Mailboxes, sending and receiving are set up in the live dashboard. Nothing to show in demo mode.</p>'; return; }
    host.innerHTML = '<h2>Mail</h2><p class="muted">Loading…</p>';
    try{ setup = await fn({action: 'setup'}); }catch(e){ setup = null; }
    if(!team.length){ const {data} = await A.sb.from('team').select('user_id,name,role').order('name'); team = data || []; }
    await reloadBoxes();
    paintSettings();
  }
  // the mailbox list for Settings, without redrawing the Mail screen when it isn't open
  async function reloadBoxes(){
    if(started) return loadBoxes();
    const {data} = await A.sb.from('mailboxes').select('local,display_name,members,catch_all,forward_to').order('local'); boxes = data || [];
  }
  function paintSettings(){
    const d = setHost, s = setup || {}, cfg = window.CRT_CONFIG || {}; if(!d) return;
    const worker = s.receiving_key ? `// paste into Cloudflare → Workers → your email worker\n` + WORKER.replace('PASTE_ENDPOINT', s.endpoint).replace('PASTE_KEY', s.receiving_key).replace('PASTE_PUBLIC_KEY', cfg.SUPABASE_ANON_KEY || '') : '';
    const dom = {verified: '<span class="role-chip is-on">Verified</span>', pending: '<span class="role-chip is-off">Waiting for DNS</span>', not_started: '<span class="role-chip is-off">Waiting for DNS</span>', not_added: '<span class="role-chip is-off">Add crt.rw in Resend</span>', bad_key: '<span class="role-chip is-off">Key not accepted</span>'}[s.domain] || '';
    d.innerHTML = `<div class="mail-form set-mailform"><h2>Mail</h2>
      <h3>Mailboxes</h3><p class="muted small">Each address at ${DOMAIN}. Tick who reads it (you read every mailbox). “Forward a copy to” also delivers each email to Gmail or any other app.</p>
      <div class="mb-list">${boxes.map(b => `<div class="mb-row" data-local="${esc(b.local)}"><div class="mb-top"><b>${esc(b.local)}@${DOMAIN}</b><input class="mb-name" value="${esc(b.display_name)}" placeholder="Name shown when sending" aria-label="Name for ${esc(b.local)}">
          <label class="mb-ca"><input type="radio" name="catch" ${b.catch_all ? 'checked' : ''} data-catch> Gets mail for unknown addresses</label></div>
        <div class="mb-mem">${team.filter(t => t.role !== 'owner').map(t => `<label><input type="checkbox" data-mem="${esc(t.user_id)}" ${(b.members || []).includes(t.user_id) ? 'checked' : ''}> ${esc(t.name)}</label>`).join('') || '<span class="muted small">Add team members in Team to share this mailbox.</span>'}</div>
        <input class="mb-fwd" value="${esc((b.forward_to || []).join(', '))}" placeholder="Forward a copy to (e.g. you@gmail.com)" aria-label="Forward ${esc(b.local)} to">
        <div class="row-end"><button type="button" class="btn secondary small" data-mail="mb-save">Save</button>${b.catch_all ? '' : '<button type="button" class="link danger" data-mail="mb-del">Delete mailbox</button>'}</div></div>`).join('')}</div>
      <form class="mb-add" id="mb-add"><input name="local" placeholder="new address, e.g. bookings" pattern="[a-z0-9][a-z0-9._-]{0,40}" required><span>@${DOMAIN}</span><input name="name" placeholder="Name shown when sending"><button class="btn small">Add mailbox</button></form>
      <h3>Sending ${s.sender ? '<span class="role-chip is-on">Connected</span>' : '<span class="role-chip is-off">Not connected</span>'} ${dom}</h3>
      <p class="muted small">Through Resend (free for 3,000 emails a month). Paste the API key once; it stays locked on the server.</p>
      <form class="mb-add" id="mb-key"><input name="key" type="password" placeholder="${s.sender ? '•••••••• saved (type to replace)' : 're_…'}" autocomplete="off"><button class="btn small">Save key</button></form>
      <h3>Receiving ${s.received ? `<span class="role-chip is-on">${s.received} received</span>` : (s.webhook ? '<span class="role-chip is-on">Ready, nothing received yet</span>' : '<span class="role-chip is-off">Not connected</span>')}</h3>
      <p class="muted small">Also through Resend (free). In Resend: Domains → ${DOMAIN} → turn on <b>Receiving</b> and add the MX record it shows at your DNS. Then Webhooks → Add endpoint → paste this address, choose the event <b>email.received</b>, and paste the endpoint's <b>Signing secret</b> below. Full steps: <code>admin/MAIL-SETUP.txt</code>.</p>
      ${s.endpoint ? `<label class="mb-url">Webhook address<input readonly value="${esc(s.endpoint)}" onclick="this.select()"></label>` : ''}
      <form class="mb-add" id="mb-hook"><input name="secret" type="password" placeholder="${s.webhook ? '•••••••• saved (type to replace)' : 'whsec_…'}" autocomplete="off"><button class="btn small">Save signing secret</button></form>
      ${worker ? `<details class="mb-alt"><summary>Prefer Cloudflare for receiving? (also free)</summary><p class="muted small">In Cloudflare → Workers &amp; Pages → Create → Worker, paste this code, then Email Routing → Catch-all → Send to Worker.</p><pre class="code mb-code" id="mb-worker">${esc(worker)}</pre><div class="row-end"><button type="button" class="btn secondary small" data-mail="copy-worker">Copy worker code</button><button type="button" class="link" data-mail="new-key">Make a new receiving key</button></div></details>` : ''}
      <h3>Use it in Gmail or any mail app</h3><ul class="tips"><li><b>Receive:</b> put the app’s address in “Forward a copy to” above. Each email arrives there too, and Reply goes straight to the sender.</li>
      <li><b>Send as ${esc((boxes[0] || {}).local || 'hello')}@${DOMAIN}:</b> Gmail → Settings → Accounts → “Send mail as” → Add. SMTP server <code>smtp.resend.com</code>, port <code>465</code>, username <code>resend</code>, password: your Resend API key. Apple Mail and Outlook use the same settings.</li></ul></div>`;
    $('#mb-add').onsubmit = async e => { e.preventDefault(); const f = e.target; const {error} = await A.sb.from('mailboxes').insert({local: f.local.value.trim().toLowerCase(), display_name: f.name.value.trim(), members: []}); if(error){ A.toast(/duplicate/i.test(error.message) ? 'That address already exists.' : err(error)); return; } A.toast('Mailbox added'); await loadBoxes(); paintSettings(); };
    $('#mb-hook').onsubmit = async e => { e.preventDefault(); const k = e.target.secret.value.trim(); if(!k) return; try{ setup = await fn({action: 'setup', webhook_secret: k}); A.toast('Signing secret saved. Receiving is ready.'); paintSettings(); }catch(x){ A.toast(err(x)); } };
    $('#mb-key').onsubmit = async e => { e.preventDefault(); const k = e.target.key.value.trim(); if(!k) return; try{ setup = await fn({action: 'setup', resend_key: k}); A.toast('Sending key saved'); paintSettings(); }catch(x){ A.toast(err(x)); } };
  }
  const WORKER = `const ENDPOINT = "PASTE_ENDPOINT";
const RECEIVING_KEY = "PASTE_KEY";
const PUBLIC_KEY = "PASTE_PUBLIC_KEY";
export default {
  async email(message, env, ctx) {
    const raw = new Uint8Array(await new Response(message.raw).arrayBuffer());
    let s = ""; for (let i = 0; i < raw.length; i += 0x8000) s += String.fromCharCode(...raw.subarray(i, i + 0x8000));
    const r = await fetch(ENDPOINT, { method: "POST",
      headers: { "Content-Type": "application/json", "x-crt-mail-secret": RECEIVING_KEY, Authorization: "Bearer " + PUBLIC_KEY, apikey: PUBLIC_KEY },
      body: JSON.stringify({ to: message.to, from: message.from, raw: btoa(s) }) });
    if (r.status === 404) return message.setReject("No such mailbox at crt.rw");
    if (!r.ok) throw new Error("CRT mail store failed: " + r.status);
    const d = await r.json().catch(() => ({}));
    for (const to of d.forward || []) { try { await message.forward(to); } catch (e) { console.log("forward failed", to, String(e)); } }
  },
};`;

  // ------------------------------------------------------------------ events
  async function onClick(e){
    const t = e.target.closest('button,li[data-id]'); if(!t) return;
    if(t.matches('li[data-id]')){ read(+t.dataset.id); return; }
    if(t.dataset.box){ box = t.dataset.box; folder = 'inbox'; showList(); paintNav(); load(); return; }
    if(t.dataset.folder){ folder = t.dataset.folder; showList(); paintNav(); load(); return; }
    if(t.dataset.att != null && open){ const a = open.attachments[+t.dataset.att]; try{ const r = await fn({action: 'file', path: a.path}); window.open(r.url, '_blank', 'noopener'); }catch(x){ A.toast(err(x)); } return; }
    const a = t.dataset.mail; if(!a) return;
    if(a === 'refresh'){ await loadBoxes(); A.toast('Mail up to date'); }
    else if(a === 'more') load(false, true);
    else if(a === 'compose') compose(null);
    else if(a === 'reply' || a === 'reply-all' || a === 'forward') compose(a);
    else if(a === 'close'){ const dl = t.closest('dialog'); if(dl.id === 'mail-compose' && (dl.querySelector('textarea') || {}).value && dl.querySelector('textarea').value.trim().length > 20 && !confirm('Discard this message?')) return; dl.close(); }
    else if(a === 'min') t.closest('dialog').classList.toggle('is-min');
    else if(a === 'show-cc'){ $('#mail-cc').hidden = false; t.hidden = true; $('#mail-cc input').focus(); }
    else if(a === 'back') showList();
    else if(a === 'unread' && open){ await A.sb.from('mail_messages').update({unread: true}).eq('id', open.id); const it = list.find(x => x.id === open.id); if(it) it.unread = true; showList(); paintList(); countUnread().then(paintNav); }
    else if(a === 'row-move'){ e.stopPropagation(); const id = +t.dataset.row, to = t.dataset.to; const {error} = await A.sb.from('mail_messages').update({folder: to}).eq('id', id); if(error){ A.toast(err(error)); return; } list = list.filter(x => x.id !== id); paintList(); A.toast(to === 'trash' ? 'Moved to Trash' : 'Archived'); countUnread().then(paintNav); }
    else if(a === 'move' && open){ const {error} = await A.sb.from('mail_messages').update({folder: t.dataset.to}).eq('id', open.id); if(error){ A.toast(err(error)); return; } A.toast(t.dataset.to === 'trash' ? 'Moved to Trash' : t.dataset.to === 'archive' ? 'Archived' : 'Moved to Inbox'); showList(); load(true); }
    else if(a === 'delete' && open){ if(!confirm('Delete this email forever?')) return; await A.sb.from('mail_messages').delete().eq('id', open.id); showList(); load(); }
    else if(a === 'settings') settings();
    else if(a === 'copy-worker'){ try{ await navigator.clipboard.writeText($('#mb-worker').textContent); A.toast('Worker code copied'); }catch(x){ A.toast('Select the code and copy it'); } }
    else if(a === 'new-key'){ if(!confirm('Make a new receiving key? The worker in Cloudflare must then be updated with the new code.')) return; try{ setup = await fn({action: 'setup', new_key: true}); paintSettings(); A.toast('New key made. Update the worker in Cloudflare.'); }catch(x){ A.toast(err(x)); } }
    else if(a === 'mb-save' || a === 'mb-del'){
      const row = t.closest('.mb-row'), local = row.dataset.local;
      if(a === 'mb-del'){ if(!confirm(`Delete ${local}@${DOMAIN} and all its mail?`)) return; const {error} = await A.sb.from('mailboxes').delete().eq('local', local); if(error){ A.toast(err(error)); return; } A.toast('Mailbox deleted'); await reloadBoxes(); paintSettings(); return; }
      const fwd = row.querySelector('.mb-fwd').value.split(/[,;\s]+/).map(x => x.trim().toLowerCase()).filter(x => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x) && !x.endsWith('@' + DOMAIN)).slice(0, 5);
      const patch = {display_name: row.querySelector('.mb-name').value.trim(), members: $$('[data-mem]:checked', row).map(c => c.dataset.mem), forward_to: fwd};
      if(row.querySelector('[data-catch]').checked){ await A.sb.from('mailboxes').update({catch_all: false}).neq('local', local); patch.catch_all = true; }
      const {error} = await A.sb.from('mailboxes').update(patch).eq('local', local);
      if(error){ A.toast(err(error)); return; } A.toast('Saved'); await reloadBoxes(); paintSettings();
    }
  }

  // Mail has its own search bar: the dashboard's lead search and "+ New lead" step aside here (as on Content)
  document.addEventListener('crt:tab', e => document.body.classList.toggle('on-mail', e.detail === 'inbox'));
  // From Leads: open Mail with a new message to the lead, from hello@ when it exists
  async function write(o){
    const t = document.querySelector('.tab[data-tab="inbox"]'); if(t) t.click();
    await start(); if(!document.querySelector('#mail-compose')) return;
    const keep = open; open = null; const was = box; if(boxes.some(b => b.local === 'hello')) box = 'hello';
    compose(null); open = keep; box = was;
    const f = document.querySelector('#mail-form'); if(!f) return;
    f.to.value = o.to || ''; f.subject.value = o.subject || ''; f.text.value = o.text || ''; f.text.focus(); f.text.setSelectionRange(f.text.value.length, f.text.value.length);
  }
  window.CRT_MAIL = {open: () => { if(A) start(); }, settingsIn, write};
  document.addEventListener('crt:settings', e => { if(e.detail === 'mail' && A) settingsIn($('#set-mail')); });
  const ready = () => { A = window.CRT_ADMIN; esc = A.esc; document.body.classList.toggle('on-mail', !$('#tab-inbox').hidden); if(!$('#tab-inbox').hidden) start(); };
  if(window.CRT_ADMIN) ready(); else document.addEventListener('crt:ready', ready);
})();
