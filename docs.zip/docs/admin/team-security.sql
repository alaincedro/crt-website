-- CRT admin: team accounts made from the dashboard + a phone code at sign-in.  Run once: Supabase → SQL Editor → Run.
-- Safe to run again. Nothing changes for visitors. The phone code stays OFF until the main admin switches it on
-- from Team → Sign-in security (only after their own phone has received a code), so nobody can be locked out.

-- 1) Team: phone and email, and the main admin ("owner"), who alone adds, changes and removes people.
alter table public.team add column if not exists phone text;
alter table public.team add column if not exists email text;
alter table public.team drop constraint if exists team_phone_check;
alter table public.team add constraint team_phone_check check (phone is null or phone ~ '^\+[1-9][0-9]{7,14}$');
alter table public.team drop constraint if exists team_role_check;
alter table public.team add constraint team_role_check check (role in ('owner','admin','staff'));
-- the first admin becomes the main admin
update public.team set role = 'owner'
where user_id = (select user_id from public.team where role = 'admin' order by created_at limit 1)
  and not exists (select 1 from public.team where role = 'owner');
update public.team t set email = u.email from auth.users u where u.id = t.user_id and t.email is null;

-- 2) Sign-in codes: one per sign-in session. Only the "team" server function reads or writes this table.
create table if not exists public.login_codes (
  user_id     uuid not null references auth.users(id) on delete cascade,
  session_id  uuid not null,
  code_hash   text not null,
  sent_at     timestamptz not null default now(),
  expires_at  timestamptz not null,
  attempts    int not null default 0,
  verified_at timestamptz,
  primary key (user_id, session_id)
);
alter table public.login_codes enable row level security;   -- no policies: the website itself can't touch it

create table if not exists public.security_settings (
  id           int primary key default 1 check (id = 1),
  require_code boolean not null default false,
  updated_at   timestamptz not null default now()
);
insert into public.security_settings (id) values (1) on conflict (id) do nothing;
alter table public.security_settings enable row level security;
drop policy if exists "team reads security" on public.security_settings;
create policy "team reads security" on public.security_settings for select to authenticated using (true);

-- 3) A session counts only after its code was entered (when the code is switched on). Every dashboard rule
--    already goes through is_team() / is_admin(), so this one change protects leads, content, finance and photos.
create or replace function public.session_verified() returns boolean
language sql stable security definer set search_path = public as $$
  select not coalesce((select require_code from public.security_settings where id = 1), false)
      or exists (select 1 from public.login_codes
                 where user_id = auth.uid()
                   and session_id = nullif(auth.jwt() ->> 'session_id', '')::uuid
                   and verified_at is not null and verified_at > now() - interval '30 days')
$$;
create or replace function public.is_team() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.team where user_id = auth.uid()) and public.session_verified()
$$;
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.team where user_id = auth.uid() and role in ('owner','admin')) and public.session_verified()
$$;
create or replace function public.is_owner() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.team where user_id = auth.uid() and role = 'owner') and public.session_verified()
$$;

-- 4) Only the main admin changes or removes team members (admins can no longer promote themselves).
drop policy if exists "admins update team" on public.team;
drop policy if exists "owner updates team" on public.team;
create policy "owner updates team" on public.team for update to authenticated using (public.is_owner()) with check (public.is_owner());
drop policy if exists "admins remove team" on public.team;
drop policy if exists "owner removes team" on public.team;
create policy "owner removes team" on public.team for delete to authenticated using (public.is_owner() and user_id <> auth.uid());

-- 5) Connection keys (text messages, mailbox) entered by the main admin in the dashboard, so nobody needs Supabase.
--    No rules at all: only the server functions can read it, and the dashboard only learns whether a key is set.
create table if not exists public.app_secrets (
  name       text primary key check (name ~ '^[A-Z0-9_]{2,40}$'),
  value      text not null,
  updated_at timestamptz not null default now()
);
alter table public.app_secrets enable row level security;

-- check
select name, role, email, phone from public.team order by created_at;
