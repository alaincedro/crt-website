-- CRT: every website enquiry and review also lands in the hello@ mailbox (Dashboard → Mail). Replaces FormSubmit.
-- Run once in Supabase → SQL Editor. Safe to run again. If anything here fails, the enquiry is still saved as a lead.
create extension if not exists pg_net;

create or replace function public.lead_to_mail() returns trigger
language plpgsql security definer set search_path = public as $$
declare box text; mid bigint; key text; reply text;
begin
  select local into box from public.mailboxes where catch_all order by local limit 1;
  if box is null then select local into box from public.mailboxes where local = 'hello'; end if;
  if box is null then return new; end if;
  reply := case when new.contact ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then lower(new.contact) else '' end;
  insert into public.mail_messages (mailbox, folder, direction, from_addr, from_name, to_addrs, subject, text_body, unread)
  values (box, 'inbox', 'in', coalesce(nullif(reply, ''), 'website@crt.rw'), coalesce(nullif(new.name, ''), 'Website visitor'), array[box || '@crt.rw'],
    left((case when new.service = 'Client review' then 'New client review: ' else 'New enquiry: ' end)
         || coalesce(nullif(new.offer, ''), nullif(new.service, ''), 'Website') || ' – ' || coalesce(new.name, ''), 300),
    concat_ws(E'\n',
      'Name: ' || new.name,
      case when new.service = 'Client review' then null else 'WhatsApp or email: ' || new.contact end,
      'Service: ' || coalesce(new.service, '—'),
      case when coalesce(new.offer, '') <> '' then 'Offer / package: ' || new.offer end,
      case when coalesce(new.event_date, '') <> '' then 'Date / timeline: ' || new.event_date end,
      'Page: ' || coalesce(new.page, '—'), 'Source: ' || coalesce(new.source, '—'), '', coalesce(new.details, ''),
      '', case when reply = '' then 'They gave a phone number: reply on WhatsApp.' else 'Press Reply to answer them by email.' end),
    true)
  returning id into mid;
  -- a copy to the mailbox's "Forward a copy to" addresses (e.g. Gmail), through the "mail" function, when set up
  select value into key from public.app_secrets where name = 'MAIL_INBOUND_SECRET';
  if key is not null and exists (select 1 from public.mailboxes where local = box and cardinality(forward_to) > 0) then
    perform net.http_post(url := 'https://xwymonxbaokdjhywqydu.supabase.co/functions/v1/mail',
      headers := jsonb_build_object('Content-Type', 'application/json', 'x-crt-mail-secret', key, 'Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh3eW1vbnhiYW9rZGpoeXdxeWR1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTQwOTA5MDEsImV4cCI6MjEwOTY2NjkwMX0.dKuVjQSx8FcxjdIbF2DQAGsWT0ThhG_x1uOPAKgDxK4'),   -- the site's public key
      body := jsonb_build_object('forward_id', mid));
  end if;
  return new;
exception when others then
  return new;   -- never lose an enquiry because of the mail copy
end $$;

drop trigger if exists lead_to_mail on public.leads;
create trigger lead_to_mail after insert on public.leads for each row execute function public.lead_to_mail();
