-- CRT Finance: books for the admin dashboard, WhatsApp and the Google Sheets backup.
-- Run once, after supabase-setup.sql: Supabase → SQL Editor → New query → paste all of this → Run.
-- Safe to run again.
--
-- One ledger table holds every movement of money. Everything else (profit & loss,
-- cash flow, balances, what clients owe) is calculated from it, so the dashboard,
-- WhatsApp and the Sheet always agree.

-- ---------------------------------------------------------------- tables
create table if not exists public.fin_accounts (
  id         text primary key check (id ~ '^[a-z0-9-]{2,30}$'),
  name       text not null check (char_length(name) between 1 and 60),
  kind       text not null default 'bank' check (kind in ('bank','mobile_money','cash')),
  opening_rwf bigint not null default 0,
  archived   boolean not null default false,
  sort       int not null default 0
);

create table if not exists public.fin_categories (
  id         text primary key check (id ~ '^[a-z0-9-]{2,40}$'),
  name       text not null check (char_length(name) between 1 and 60),
  type       text not null check (type in ('income','expense')),
  keywords   text not null default '',          -- words that map a WhatsApp message to this category
  sort       int not null default 0
);

create table if not exists public.fin_invoices (
  id          bigint generated always as identity primary key,
  number      text not null unique check (char_length(number) between 1 and 30),
  client      text not null check (char_length(client) between 1 and 120),
  description text check (char_length(description) <= 500),
  amount_rwf  bigint not null check (amount_rwf > 0),
  issued_on   date not null default current_date,
  due_on      date,
  status      text not null default 'sent' check (status in ('draft','sent','paid','void')),
  lead_id     bigint references public.leads(id) on delete set null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists public.fin_entries (
  id           bigint generated always as identity primary key,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  happened_on  date not null default current_date,
  type         text not null check (type in ('income','expense','transfer')),
  amount_rwf   bigint not null check (amount_rwf > 0),
  account_id   text not null references public.fin_accounts(id),
  to_account_id text references public.fin_accounts(id),          -- transfers only
  category_id  text references public.fin_categories(id),
  party        text check (char_length(party) <= 120),            -- client or supplier
  note         text check (char_length(note) <= 500),
  invoice_id   bigint references public.fin_invoices(id) on delete set null,
  source       text not null default 'dashboard' check (source in ('dashboard','whatsapp','sheet','import')),
  raw_message  text check (char_length(raw_message) <= 1000),     -- the WhatsApp text it came from
  created_by   uuid references auth.users(id) on delete set null,
  created_by_name text check (char_length(created_by_name) <= 80),
  check ((type = 'transfer') = (to_account_id is not null)),
  check (type = 'transfer' or category_id is not null)
);
create index if not exists fin_entries_day_idx on public.fin_entries (happened_on desc, id desc);

-- WhatsApp numbers allowed to record money (international format, digits only, e.g. 250788123456)
create table if not exists public.fin_whatsapp_senders (
  phone   text primary key check (phone ~ '^[0-9]{8,15}$'),
  name    text not null check (char_length(name) between 1 and 80),
  user_id uuid references auth.users(id) on delete set null
);

drop trigger if exists fin_entries_touch on public.fin_entries;
create trigger fin_entries_touch before update on public.fin_entries for each row execute function public.touch_updated_at();
drop trigger if exists fin_invoices_touch on public.fin_invoices;
create trigger fin_invoices_touch before update on public.fin_invoices for each row execute function public.touch_updated_at();

-- ---------------------------------------------------------------- starting accounts and categories (edit freely)
insert into public.fin_accounts (id, name, kind, sort) values
  ('momo',  'MTN MoMo',       'mobile_money', 1),
  ('bank',  'Bank account',   'bank',         2),
  ('cash',  'Cash',           'cash',         3)
on conflict (id) do nothing;

insert into public.fin_categories (id, name, type, keywords, sort) values
  ('weddings',      'Weddings',                 'income',  'wedding,gusaba,dowry,bride,couple,proposal,shower', 1),
  ('events',        'Events',                   'income',  'event,conference,launch,party,gala,defense,graduation,workshop', 2),
  ('commercial',    'Commercial shoots',        'income',  'product,food,menu,shoot,commercial,hotel,restaurant', 3),
  ('branding',      'Branding & design',        'income',  'logo,brand,design,poster,flyer,banner', 4),
  ('social',        'Social media & content',   'income',  'social,content,reels,instagram,tiktok,retainer,monthly', 5),
  ('web',           'Websites',                 'income',  'website,web,site,domain,hosting', 6),
  ('other-income',  'Other income',             'income',  '', 9),
  ('crew',          'Crew & freelancers',       'expense', 'crew,freelancer,freelance,assistant,second shooter,editor,videographer,photographer,salary,pay', 11),
  ('transport',     'Transport & fuel',         'expense', 'transport,fuel,moto,taxi,uber,yego,bus,car,petrol,diesel', 12),
  ('equipment',     'Equipment & repairs',      'expense', 'camera,lens,battery,card,sd,drone,light,tripod,repair,gimbal,mic,equipment', 13),
  ('printing',      'Printing & albums',        'expense', 'print,album,photobook,frame,canvas', 14),
  ('software',      'Software & subscriptions', 'expense', 'adobe,lightroom,premiere,subscription,software,google,storage,icloud,dropbox,canva,cal', 15),
  ('internet',      'Internet & airtime',       'expense', 'internet,data,airtime,bundle,wifi,mtn,airtel', 16),
  ('marketing',     'Marketing & ads',          'expense', 'ads,ad,boost,promotion,marketing,sponsored', 17),
  ('rent',          'Rent & utilities',         'expense', 'rent,electricity,water,cashpower,office', 18),
  ('food',          'Meals on shoots',          'expense', 'food,lunch,dinner,meal,snacks,water bottle', 19),
  ('fees',          'Bank & MoMo fees',         'expense', 'fee,fees,charges,commission,withdraw', 20),
  ('tax',           'Taxes & RRA',              'expense', 'tax,rra,vat,paye,patente', 21),
  ('other-expense', 'Other expenses',           'expense', '', 29)
on conflict (id) do nothing;

-- ---------------------------------------------------------------- statements (read by the dashboard and WhatsApp)
create or replace view public.fin_balances with (security_invoker = true) as
  select a.id, a.name, a.kind, a.sort,
         a.opening_rwf
         + coalesce(sum(case when e.type = 'income' and e.account_id = a.id then e.amount_rwf end), 0)
         - coalesce(sum(case when e.type = 'expense' and e.account_id = a.id then e.amount_rwf end), 0)
         - coalesce(sum(case when e.type = 'transfer' and e.account_id = a.id then e.amount_rwf end), 0)
         + coalesce(sum(case when e.type = 'transfer' and e.to_account_id = a.id then e.amount_rwf end), 0) as balance_rwf
  from public.fin_accounts a
  left join public.fin_entries e on e.account_id = a.id or e.to_account_id = a.id
  where not a.archived
  group by a.id;

-- ---------------------------------------------------------------- access: admins only
alter table public.fin_accounts enable row level security;
alter table public.fin_categories enable row level security;
alter table public.fin_entries enable row level security;
alter table public.fin_invoices enable row level security;
alter table public.fin_whatsapp_senders enable row level security;

do $$ declare t text; begin
  foreach t in array array['fin_accounts','fin_categories','fin_entries','fin_invoices','fin_whatsapp_senders'] loop
    execute format('drop policy if exists "admins read %1$s" on public.%1$s', t);
    execute format('drop policy if exists "admins write %1$s" on public.%1$s', t);
    execute format('create policy "admins read %1$s" on public.%1$s for select to authenticated using (public.is_admin())', t);
    execute format('create policy "admins write %1$s" on public.%1$s for all to authenticated using (public.is_admin()) with check (public.is_admin())', t);
  end loop;
end $$;

-- ---------------------------------------------------------------- live updates in the dashboard
do $$ begin
  begin alter publication supabase_realtime add table public.fin_entries; exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.fin_invoices; exception when duplicate_object then null; end;
end $$;
