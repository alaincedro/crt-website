-- CRT dashboard · Leads v2 (2026-11-25): follow-up dates, first-reply time and a history per lead.
-- Run once in Supabase → SQL Editor. Safe to run again. Free tier.
alter table public.leads add column if not exists follow_up date;
alter table public.leads add column if not exists replied_at timestamptz;
alter table public.leads add column if not exists activity jsonb not null default '[]'::jsonb;
create index if not exists leads_follow_up_idx on public.leads (follow_up) where follow_up is not null;
