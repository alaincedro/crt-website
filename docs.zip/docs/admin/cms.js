/* CRT admin: the content management system (Content tab).
   Collections: offers, packages and extras, availability, print products, home hero campaigns, questions, search & sharing.
   Every collection works the same way: edit → your changes are kept as a draft in this browser → Publish puts them live.
   Each publish keeps the previous 10 versions (History → Restore). Live preview shows drafts on the real page as you type.
   Storage: Supabase site_content, key cms_<name>, value {items, at, by, history}. Starting content: ../data/cms.json
   (made by tools/cms_export.py). The site reads it in site.js ("v19 CMS"). Demo mode keeps everything in this tab. */
(function(){
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const clone = o => JSON.parse(JSON.stringify(o == null ? null : o));
  const DRAFT = 'crt-cms-draft', DEMO = 'crt-demo-cms';
  const day = (d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'))(new Date());
  const rwf = n => n == null || n === '' ? 'On request' : Number(n).toLocaleString('en-US') + ' RWF';
  const slug = s => String(s || '').toLowerCase().normalize('NFKD').replace(/[^\w\s-]/g, '').trim().replace(/[\s_]+/g, '-').slice(0, 48) || 'item';
  const ago = t => { if(!t) return ''; const s = (Date.now() - new Date(t)) / 1000; return s < 60 ? 'just now' : s < 3600 ? Math.round(s / 60) + ' min ago' : s < 86400 ? Math.round(s / 3600) + ' h ago' : new Date(t).toLocaleDateString('en-GB', {day: 'numeric', month: 'short'}); };
  let A = null, esc = s => String(s == null ? '' : s), ro = true, host = null;
  let defaults = {}, store = {}, drafts = {}, col = 'overview', sel = null, find = '', show = 'all', preview = false, pushT = 0;
  try{ drafts = JSON.parse(localStorage.getItem(DRAFT) || '{}') || {}; }catch(e){}

  const CAT = [['business', 'Business'], ['events', 'Events'], ['weddings', 'Weddings']];
  const SVC = [['weddings', 'Weddings'], ['events', 'Events'], ['business', 'Business']];
  const name = (list, v) => (list.find(x => x[0] === v) || [v, v])[1];

  // ------------------------------------------------------------------ the collections
  // field: [key, label, type, extra]. types: text area money number select toggle date image list options page readonly
  const C = {
    offers: {
      title: 'Offers', one: 'offer', group: 'Sell', icon: 'tag', dated: true,
      where: 'The Offers page, the Offers menu, the bar above the header (if chosen) and each offer’s own page. Deleting, hiding or ending an offer removes it from all of them.',
      page: it => it && it.title ? (/^\/offer-[a-z0-9-]+\/?$/i.test(it.link || '') ? it.link : '/offer/?o=' + encodeURIComponent(it.id || '')) : '/offers/',
      label: it => it.title || 'Untitled offer', meta: it => name(CAT, it.cat) + ' · ' + (it.price ? rwf(it.price) : 'Price on request') + (it.spotlight ? ' · Featured' : '') + (it.bar ? ' · In the bar' : ''),
      fields: [
        ['Offer'], ['title', 'Name', 'text', {req: 1, max: 60}], ['cat', 'Category', 'select', {opts: CAT}],
        ['label', 'Small label above the name', 'text', {hint: 'For example “Business bundle”. Empty shows the category.'}],
        ['badge', 'Badge', 'text', {hint: 'Optional, for example “Best value” or “New”.', max: 20}],
        ['hook', 'One line that sells it', 'area', {max: 140}], ['incl', 'What’s included', 'list', {hint: 'One per line. Three reads best.'}],
        ['Price'], ['price_label', 'Before the price', 'text', {hint: 'For example “From”, “Bundle” or “Kit from”.'}], ['price', 'Price', 'money'],
        ['per', 'Charged', 'select', {opts: [['', 'Once'], ['month', 'Every month']]}],
        ['was', 'Old price, crossed out', 'money', {hint: 'Optional. Shows the saving next to the price.'}], ['price_note', 'Note under the price', 'text'],
        ['Look and links'], ['cover', 'Cover picture', 'image', {hint: 'On the Offers page card.'}],
        ['cta', 'Button words', 'text', {max: 28}],
        ['The offer’s page'], ['hero', 'Page photo', 'image', {hint: 'The big photo at the top of the offer’s page. Empty uses the category’s photo.'}],
        ['page_incl', 'Everything included', 'list', {hint: 'One per line, “Name: what it is”. For example “Brand kit: logo, colours and fonts”. Empty uses “What’s included” above.'}],
        ['book', 'Book button goes to', 'text', {hint: 'For example /book/?s=business&p=launch. Empty opens the Book page for this category.'}],
        ['link', 'Page address', 'text', {hint: 'Empty: the page is made for you at /offer/?o=… The next upload gives it a clean address if you set one here, like /offer-year-end/.'}],
        ['Proof (optional)'], ['proof_text', 'Proof line', 'text', {hint: 'For example “The brand-kit part, done: King’s Memo”.'}], ['proof_link', 'Proof link', 'text'], ['proof_img', 'Proof picture', 'image'],
        ['When it shows'], ['live', 'Show on the website', 'toggle', {hint: 'Off, or deleted and published, removes it everywhere: the Offers page, the menu, the bar, cards and links. Its own page then says the offer has ended.'}],
        ['spotlight', 'Feature it at the top of the Offers page', 'toggle'], ['menu', 'Show in the Offers menu', 'toggle', {def: true}],
        ['bar', 'Show in the bar above the header', 'toggle', {hint: 'The thin bar at the top of most pages. If several offers are on, each section shows its own (events, weddings, business), otherwise the first in the list.'}],
        ['bar_text', 'Words in the bar', 'text', {max: 60, when: it => !!it.bar, hint: 'For example “Planning an event?”. Empty shows the offer’s name. The price and link are added for you.'}],
        ['start', 'Starts', 'date'], ['end', 'Ends', 'date', {hint: 'Leave empty to keep it running.'}]],
      blank: () => ({title: '', cat: 'business', label: '', badge: 'New', hook: '', incl: [], price_label: 'From', price: null, was: null, per: '', price_note: '', cover: '/assets/icons/cover-launch-bundle.svg', link: '', cta: 'See the offer', hero: '', page_incl: [], book: '', proof_text: '', proof_link: '', proof_img: '', spotlight: false, menu: true, bar: false, bar_text: '', live: false, start: '', end: ''})
    },
    packages: {
      title: 'Packages & extras', one: 'package', group: 'Sell', icon: 'box',
      where: 'The Book page: packages, extras and the live price estimate.', page: it => '/book/' + (it && it.service ? '?s=' + it.service + (it.kind === 'package' ? '&p=' + it.id.split(':').pop() : '') : ''),
      label: it => it.name || 'Untitled', meta: it => (it.kind === 'extra' ? 'Extra' : 'Package') + ' · ' + rwf(it.price) + (it.per ? ' / ' + it.per : ''),
      groupOf: it => name(SVC, it.service) + ' · ' + (it.kind === 'extra' ? 'Extras' : 'Packages'),
      fields: [
        ['Package'], ['service', 'Service', 'select', {opts: SVC}], ['kind', 'Type', 'select', {opts: [['package', 'Package'], ['extra', 'Extra']]}],
        ['name', 'Name', 'text', {req: 1, max: 60}], ['line', 'What’s in it, in one line', 'area', {max: 120, when: it => it.kind === 'package'}],
        ['price', 'Price', 'money', {hint: 'Leave empty for “Priced on request”. 0 shows “Included” or “Free”.'}],
        ['per', 'Charged', 'select', {opts: [['', 'Once'], ['month', 'Every month']], when: it => it.kind === 'package'}],
        ['days', 'Only with “Only some days”', 'toggle', {when: it => it.kind === 'extra' && it.service === 'weddings', hint: 'For single wedding days chosen one by one.'}],
        ['live', 'Show on the Book page', 'toggle']],
      blank: () => ({service: 'weddings', kind: 'package', name: '', line: '', price: null, per: '', days: false, live: true})
    },
    availability: {title: 'Availability', one: 'date', group: 'Sell', icon: 'cal', custom: true, where: 'A date check on the Book page and on every “Check your date” section. Visitors see free, almost full or booked, nothing more.', page: () => '/book/?s=weddings'},
    print: {
      title: 'Print products', one: 'product', group: 'Sell', icon: 'print',
      where: 'The Print page: product tiles, the quick view and its options.', page: () => '/print/',
      label: it => it.name || 'Untitled product', meta: it => name([...CAT, ['custom', 'Custom']], it.cat) + ' print · ' + (it.price ? 'From ' + rwf(it.price) : 'On request'),
      groupOf: it => name([...CAT, ['custom', 'Custom']], it.cat) + ' print',
      fields: [
        ['Product'], ['name', 'Name', 'text', {req: 1, max: 50}], ['cat', 'Category', 'select', {opts: [['business', 'Business print'], ['events', 'Event print'], ['weddings', 'Wedding print'], ['custom', 'Custom print']]}],
        ['line', 'One line about it', 'area', {max: 120}], ['image', 'Picture', 'image', {hint: 'Products with a drawn mock-up (like business cards) keep it until you add a picture.'}],
        ['Price and options'], ['price', 'Starting price', 'money', {hint: 'Empty shows “Price on request”.'}],
        ['options', 'Options', 'options', {hint: 'One option per line: Name: choice, choice, choice'}],
        ['unit_one', 'Counted as (one)', 'text', {hint: 'For example “box”.'}], ['unit_many', 'Counted as (many)', 'text', {hint: 'For example “boxes”.'}],
        ['live', 'Show on the Print page', 'toggle']],
      blank: () => ({name: '', cat: 'business', line: '', image: '', mock: '', price: null, options: [{name: 'Service', values: ['Design and print', 'Print only (your design)']}], unit_one: 'item', unit_many: 'items', live: true})
    },
    hero: {
      title: 'Home hero', one: 'campaign', group: 'Pages', icon: 'star', dated: true,
      where: 'The top of the home page. Every live campaign whose dates include today takes a turn: the main one first for 8 seconds, the others 5 seconds each; drag to set their order.', page: () => '/',
      label: it => it.name || it.title || 'Untitled campaign', meta: it => (it.main ? 'Main · ' : '') + it.title + (it.title_sub ? ' ' + it.title_sub : ''),
      fields: [
        ['Campaign'], ['name', 'Campaign name (only you see it)', 'text', {req: 1}],
        ['title', 'Headline', 'text', {req: 1, max: 60}], ['title_sub', 'Headline, second line', 'text', {max: 60}], ['lead', 'Line under the headline', 'text', {max: 110}],
        ['cta', 'Button words', 'text', {max: 24}], ['cta_link', 'Button goes to', 'text', {hint: 'For example /book/?s=weddings or /offers/#weddings.'}],
        ['image', 'Background picture', 'image', {hint: 'Landscape, at least 1600px wide. Keep faces away from the middle-left, where the words sit.'}], ['image_alt', 'Picture description', 'text', {hint: 'What the picture shows, for screen readers and Google.'}],
        ['When it shows'], ['main', 'Main campaign: shows first, for 8 seconds', 'toggle', {hint: 'Only one campaign can be the main one; turning this on turns it off on the others. The rest show 5 seconds each.'}], ['live', 'Show on the website', 'toggle'], ['start', 'Starts', 'date'], ['end', 'Ends', 'date', {hint: 'After it ends it leaves the rotation by itself. With none live, the built-in headline shows.'}]],
      blank: () => ({name: '', title: '', title_sub: '', lead: '', cta: 'Book', cta_link: '/book/', image: '', image_alt: '', main: false, live: false, start: '', end: ''})
    },
    faq: {
      title: 'Questions', one: 'question', group: 'Pages', icon: 'q',
      where: 'The “Before you book” questions on each page. Add questions to any page; the section appears by itself.', page: it => it && it.page || '/',
      label: it => it.q || 'New question', meta: it => (it.a || '').slice(0, 70), groupOf: it => pageName(it.page),
      fields: [['page', 'Page', 'page'], ['q', 'Question', 'text', {req: 1, max: 100}], ['a', 'Answer', 'area', {req: 1, max: 400}], ['live', 'Show on the page', 'toggle']],
      blank: () => ({page: '/', q: '', a: '', live: true})
    },
    seo: {
      title: 'Search & sharing', one: 'page', group: 'Pages', icon: 'globe', fixed: true,
      where: 'How each page looks on Google and when shared on WhatsApp. Changes show at once and are written into the pages at the next upload.', page: it => it && it.path || '/',
      label: it => pageName(it.path), meta: it => it.title,
      fields: [['path', 'Page', 'readonly'], ['title', 'Title', 'text', {req: 1, max: 60, soft: 1}], ['desc', 'Description', 'area', {max: 155, soft: 1}], ['image', 'Share picture', 'image', {hint: '1200×630. Shown when the link is shared on WhatsApp, Facebook or LinkedIn.'}], ['__seo']]
    }
  };
  const ORDER = ['offers', 'packages', 'availability', 'print', 'hero', 'seo'];   // questions removed from the website (2026-11-24)
  const ICON = {
    tag: '<path d="M3 12V4a1 1 0 0 1 1-1h8l9 9-9 9-9-9z"/><circle cx="8" cy="8" r="1.6"/>', box: '<path d="M3 7l9-4 9 4v10l-9 4-9-4z"/><path d="M3 7l9 4 9-4M12 11v10"/>',
    cal: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>', print: '<path d="M7 9V3h10v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M7 14h10v7H7z"/>',
    star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>', q: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6V14M12 17.5v.01"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.7 2.5 15.3 0 18M12 3c-2.5 2.7-2.5 15.3 0 18"/>', search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-5-5"/>', home: '<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>'};
  const icon = k => `<svg viewBox="0 0 24 24" aria-hidden="true">${ICON[k] || ''}</svg>`;

  // ------------------------------------------------------------------ data
  const pageList = () => (defaults.seo || []).map(x => x.path);
  function pageName(p){
    const s = (published('seo') || defaults.seo || []).find(x => x.path === p);
    if(p === '/') return 'Home';
    const t = s && s.title ? s.title.split(/[|:–—]/)[0].trim() : '';
    return t && t.length < 42 ? t : String(p || '').replace(/^\/|\/$/g, '').replace(/-/g, ' ').replace(/^./, c => c.toUpperCase());
  }
  const published = c => store[c] && Array.isArray(store[c].items) ? store[c].items : null;
  const current = c => drafts[c] || published(c) || defaults[c] || [];
  const dirty = c => !!drafts[c] && JSON.stringify(drafts[c]) !== JSON.stringify(published(c) || defaults[c] || []);
  const isLive = c => !!published(c);
  function status(it, c){
    if(!C[c] || C[c].fixed) return ['', ''];
    if(it.live === false) return ['Hidden', 'off'];
    if(it.start && day < it.start) return ['From ' + fdate(it.start), 'soon'];
    if(it.end && day > it.end) return ['Ended', 'off'];
    if(it.end) return ['Until ' + fdate(it.end), 'on'];
    return ['Live', 'on'];
  }
  const fdate = d => d ? new Date(d + 'T12:00').toLocaleDateString('en-GB', {day: 'numeric', month: 'short'}) : '';

  async function load(){
    try{ defaults = await fetch('../data/cms.json', {cache: 'no-cache'}).then(r => r.json()); }catch(e){ defaults = {}; }
    ORDER.forEach(c => { if(!Array.isArray(defaults[c])) defaults[c] = []; });
    if(A.LIVE){
      const {data, error} = await A.sb.from('site_content').select('key,value').in('key', ORDER.map(c => 'cms_' + c));
      if(error) throw error;
      (data || []).forEach(r => { store[r.key.slice(4)] = r.value || {}; });
    } else { try{ store = JSON.parse(sessionStorage.getItem(DEMO) || '{}') || {}; }catch(e){} }
    ORDER.forEach(c => { if(drafts[c] && !dirty(c)) delete drafts[c]; });
    keepDrafts();
  }
  function keepDrafts(){ try{ localStorage.setItem(DRAFT, JSON.stringify(drafts)); }catch(e){} }
  function edit(c, fn){
    if(ro) return;
    const list = clone(current(c)); fn(list); drafts[c] = list;
    if(!dirty(c)) delete drafts[c];
    keepDrafts(); paintHead(); paintNavDot(); schedulePush();
  }
  async function publish(c){
    if(ro || !drafts[c]) return;
    const bad = check(c); if(bad){ A.toast(bad); return; }
    const prev = store[c] && store[c].items ? {at: store[c].at, by: store[c].by, items: store[c].items} : null;
    const value = {items: drafts[c], at: new Date().toISOString(), by: (A.me && (A.me.name || A.me.email)) || 'Team', history: [prev, ...((store[c] && store[c].history) || [])].filter(Boolean).slice(0, 10)};
    try{
      if(A.LIVE){ const {error} = await A.sb.from('site_content').upsert({key: 'cms_' + c, value, updated_by: A.me.user_id}); if(error) throw error; }
      store[c] = value; delete drafts[c]; keepDrafts();
      if(!A.LIVE) sessionStorage.setItem(DEMO, JSON.stringify(store));
      try{ const k = 'crt-cms-v1', cache = JSON.parse(localStorage.getItem(k) || '{}') || {}; cache[c] = {items: value.items}; localStorage.setItem(k, JSON.stringify(cache)); }catch(e){}
      A.toast(C[c].title + ' published. Live on the website now.');
      if(c === 'packages') syncPrices(prev ? prev.items : defaults.packages, value.items);
      paint();
    }catch(e){ A.fail(e); }
  }
  // A package price changed here also changes that amount on the rest of the site (menus, pages, guides),
  // but only when no other package uses the same amount; otherwise the dashboard says where to change it.
  async function syncPrices(before, after){
    const map = {}, shared = [];
    after.forEach(x => {
      const b = (before || []).find(y => y.id === x.id); if(!b || !b.price || !x.price || +b.price === +x.price) return;
      const same = (defaults.packages || []).filter(y => +y.price === +b.price).length + (defaults.offers || []).filter(y => +y.price === +b.price && y.cat !== x.service).length;
      if(same > 1) shared.push(rwf(b.price)); else map[+b.price] = +x.price;
    });
    if(Object.keys(map).length && A.LIVE){
      try{
        const {data} = await A.sb.from('site_content').select('value').eq('key', 'price_map').maybeSingle();
        const m = Object.assign({}, (data && data.value) || {}, map);
        await A.sb.from('site_content').upsert({key: 'price_map', value: m, updated_by: A.me.user_id});
        try{ localStorage.setItem('crt-price-map', JSON.stringify(m)); }catch(e){}
      }catch(e){ console.warn(e); }
    }
    if(shared.length) setTimeout(() => A.toast(shared.join(', ') + ' is used by more than one package. Change it on other pages in Prices.'), 2400);
  }
  function check(c){
    const sch = C[c]; if(!sch || !sch.fields) return '';
    for(const it of current(c)){
      for(const f of sch.fields){
        if(!f[1] || !f[3]) continue;
        if(f[3].when && !f[3].when(it)) continue;
        if(f[3].req && !String(it[f[0]] == null ? '' : it[f[0]]).trim()) return `“${sch.label(it)}” needs a ${f[1].toLowerCase()}.`;
      }
      if(it.start && it.end && it.end < it.start) return `“${sch.label(it)}” ends before it starts.`;
    }
    return '';
  }

  // ------------------------------------------------------------------ shell
  function mount(el){
    host = el;
    host.innerHTML = '<div class="cm" id="cm"></div><div class="cm-k" id="cm-k" hidden></div><dialog class="cm-hist" id="cm-hist"></dialog>';
    host.addEventListener('input', onInput); host.addEventListener('change', onChange); host.addEventListener('click', onClick);
    host.addEventListener('dragstart', onDrag); host.addEventListener('dragover', onDrag); host.addEventListener('drop', onDrag); host.addEventListener('dragend', onDrag);
    document.addEventListener('keydown', onKey);
  }
  function open(c){
    col = c || 'overview'; sel = null; find = ''; show = 'all';
    if(col !== 'overview' && C[col] && !C[col].custom){ const l = visibleItems(); sel = l.length ? l[0].id : null; }
    paint();
  }
  function paint(){
    const el = $('#cm'); if(!el) return;
    if(col === 'overview'){ el.className = 'cm cm-over'; el.innerHTML = overview(); focus(false); return; }
    const sch = C[col]; if(!sch) return;
    el.className = 'cm' + (preview ? ' has-prev' : '') + (sch.custom ? ' is-custom' : '');
    el.innerHTML = `<header class="cm-head" id="cm-head"></header><div class="cm-body">${sch.custom ? '<section class="cm-cal" id="cm-cal"></section>' : '<section class="cm-list" id="cm-list"></section><section class="cm-edit" id="cm-edit"></section>'}<section class="cm-prev" id="cm-prev"${preview ? '' : ' hidden'}><div class="cm-prev-bar"><span>Live preview · drafts included</span><a id="cm-prev-open" target="_blank" rel="noopener">Open ↗</a></div><iframe id="cm-frame" title="Live preview"></iframe></section></div>`;
    paintHead();
    if(sch.custom) paintCal(); else { paintList(); paintEdit(); }
    focus(preview);
    if(preview){ loadPreview(true); fitPrev(); }
  }
  // Live preview: the side menu steps aside, and the page is drawn at a real desktop width (1280px) scaled to fit.
  function focus(on){ const ct = $('.ct'); if(ct) ct.classList.toggle('cm-focus', !!on); }
  let ro2 = null;
  function fitPrev(){
    const box = $('#cm-prev'), f = $('#cm-frame'); if(!box || !f) return;
    const go = () => { const w = box.clientWidth, h = box.clientHeight - 38, s = Math.min(1, w / 1280); f.style.width = '1280px'; f.style.height = Math.round(h / s) + 'px'; f.style.transform = 'scale(' + s + ')'; };
    go(); if('ResizeObserver' in window){ if(ro2) ro2.disconnect(); ro2 = new ResizeObserver(go); ro2.observe(box); }
  }
  function paintHead(){
    const h = $('#cm-head'); if(!h) return; const sch = C[col], s = store[col], d = dirty(col);
    const state = d ? `<span class="cm-state is-dirty">● Unpublished changes</span>` : (s && s.at ? `<span class="cm-state">Published ${ago(s.at)}${s.by ? ' by ' + esc(s.by) : ''}</span>` : `<span class="cm-state is-built">Showing the built-in version</span>`);
    h.innerHTML = `<div class="cm-title"><span class="cm-ico">${icon(sch.icon)}</span><div><h2>${esc(sch.title)}</h2><p>${esc(sch.where)}</p></div></div>
      <div class="cm-actions">${state}
        ${s && s.history && s.history.length ? '<button type="button" class="btn secondary small" data-cm="history">History</button>' : ''}
        <button type="button" class="btn secondary small${preview ? ' is-on' : ''}" data-cm="preview" aria-pressed="${preview}">Live preview</button>
        ${d ? '<button type="button" class="btn secondary small" data-cm="discard">Discard</button>' : ''}
        <button type="button" class="btn small" data-cm="publish"${d && !ro ? '' : ' disabled'} title="${d ? 'Put your changes live (⌘S)' : 'No changes to publish'}">Publish</button></div>`;
  }
  function paintNavDot(){ if(window.CRT_CONTENT_NAV) window.CRT_CONTENT_NAV(); }

  // ------------------------------------------------------------------ list
  function visibleItems(){
    const q = find.trim().toLowerCase(), sch = C[col];
    return current(col).filter(it => {
      if(q && JSON.stringify(it).toLowerCase().indexOf(q) < 0) return false;
      if(show === 'all') return true;
      const st = status(it, col)[1];
      return show === 'live' ? st === 'on' : show === 'off' ? st === 'off' : st === 'soon';
    }).filter(it => sch.fields);
  }
  function paintList(){
    const el = $('#cm-list'); if(!el) return; const sch = C[col], list = visibleItems();
    let html = `<div class="cm-tools"><input type="search" id="cm-find" placeholder="Search ${esc(sch.title.toLowerCase())}…" value="${esc(find)}" aria-label="Search">`
      + (sch.fixed ? '' : `<div class="cm-filter" role="group" aria-label="Show">${[['all', 'All'], ['live', 'Live'], ...(sch.dated ? [['soon', 'Scheduled']] : []), ['off', 'Hidden']].map(([k, l]) => `<button type="button" data-show="${k}" class="${show === k ? 'is-on' : ''}" aria-pressed="${show === k}">${l}</button>`).join('')}</div>`)
      + '</div><ul class="cm-rows" id="cm-rows">';
    let g = null;
    list.forEach(it => {
      const grp = sch.groupOf ? sch.groupOf(it) : null;
      if(grp && grp !== g){ g = grp; html += `<li class="cm-grp">${esc(grp)}</li>`; }
      const [st, cls] = status(it, col), img = it.cover || it.image;
      html += `<li class="cm-row${it.id === sel ? ' is-on' : ''}" data-id="${esc(it.id)}"${!find && !sch.fixed && !ro ? ' draggable="true"' : ''}><button type="button" data-pick="${esc(it.id)}">`
        + (img ? `<img src="${esc(src(img))}" alt="" loading="lazy">` : '') + `<span class="cm-row-t"><b>${esc(sch.label(it))}</b><small>${esc(sch.meta(it) || '')}</small></span>`
        + (st ? `<em class="cm-chip is-${cls}">${esc(st)}</em>` : '') + '</button></li>';
    });
    html += '</ul>' + (list.length ? '' : `<p class="cm-none">${find ? 'Nothing matches “' + esc(find) + '”.' : 'Nothing here yet.'}</p>`);
    if(!sch.fixed && !ro) html += `<button type="button" class="cm-add" data-cm="add">+ New ${esc(sch.one)}</button>`;
    el.innerHTML = html;
  }
  const src = u => /^(https?:|data:|blob:)/.test(u || '') ? u : '..' + (String(u || '').startsWith('/') ? '' : '/') + u;

  // ------------------------------------------------------------------ editor
  function paintEdit(){
    const el = $('#cm-edit'); if(!el) return; const sch = C[col], it = current(col).find(x => x.id === sel);
    if(!it){ el.innerHTML = `<div class="cm-empty"><span class="cm-ico">${icon(sch.icon)}</span><p>Choose ${esc(sch.one === 'offer' ? 'an offer' : 'a ' + sch.one)} to edit it${sch.fixed || ro ? '' : ', or add a new one'}.</p></div>`; return; }
    const dis = ro ? ' disabled' : '';
    let html = `<div class="cm-edit-head"><h3>${esc(sch.label(it))}</h3><div>${sch.fixed || ro ? '' : `<button type="button" class="link" data-cm="dup">Duplicate</button><button type="button" class="link danger" data-cm="del">Delete</button>`}</div></div>`;
    sch.fields.forEach(f => {
      const [k, label, type, x = {}] = f;
      if(k === '__seo'){ html += seoPreview(it); return; }
      if(!label){ html += `<p class="cm-sec">${esc(k)}</p>`; return; }
      if(x.when && !x.when(it)) return;
      const id = 'cmf-' + k, v = it[k], hint = x.hint ? `<small>${esc(x.hint)}</small>` : '';
      const count = x.max ? `<i class="cm-count${String(v || '').length > x.max ? ' is-over' : ''}" data-count="${k}">${String(v || '').length}/${x.max}</i>` : '';
      let input = '';
      if(type === 'text') input = `<input id="${id}" data-f="${k}" value="${esc(v || '')}"${x.max && !x.soft ? ` maxlength="${x.max + 40}"` : ''}${dis}>`;
      else if(type === 'area') input = `<textarea id="${id}" data-f="${k}" rows="3"${dis}>${esc(v || '')}</textarea>`;
      else if(type === 'money' || type === 'number') input = `<div class="cm-money"><input id="${id}" data-f="${k}" data-num inputmode="numeric" value="${v == null || v === '' ? '' : Number(v).toLocaleString('en-US')}" placeholder="On request"${dis}><span>RWF</span></div>`;
      else if(type === 'select') input = `<select id="${id}" data-f="${k}"${dis}>${x.opts.map(([a, b]) => `<option value="${esc(a)}"${a === (v || '') ? ' selected' : ''}>${esc(b)}</option>`).join('')}</select>`;
      else if(type === 'page') input = `<select id="${id}" data-f="${k}"${dis}>${pageList().map(p => `<option value="${esc(p)}"${p === v ? ' selected' : ''}>${esc(pageName(p))} · ${esc(p)}</option>`).join('')}</select>`;
      else if(type === 'toggle'){ html += `<label class="cm-toggle"><input type="checkbox" data-f="${k}"${(v == null ? x.def : v) ? ' checked' : ''}${dis}><span>${esc(label)}</span></label>${hint}`; return; }
      else if(type === 'date') input = `<input id="${id}" type="date" data-f="${k}" value="${esc(v || '')}"${dis}>`;
      else if(type === 'list') input = `<textarea id="${id}" data-f="${k}" data-list rows="4"${dis}>${esc((v || []).join('\n'))}</textarea>`;
      else if(type === 'options') input = `<textarea id="${id}" data-f="${k}" data-opts rows="4"${dis}>${esc((v || []).map(g => g.name + ': ' + (g.values || []).join(', ')).join('\n'))}</textarea>`;
      else if(type === 'readonly') input = `<p class="cm-ro"><a href="..${esc(v)}" target="_blank" rel="noopener">crt.rw${esc(v)} ↗</a></p>`;
      else if(type === 'image') input = `<div class="cm-img">${v ? `<img src="${esc(src(v))}" alt="">` : '<span class="cm-img-none">No picture</span>'}<div><input id="${id}" data-f="${k}" value="${esc(v || '')}" placeholder="/assets/… or https://…"${dis}><label class="btn secondary small">Upload<input type="file" accept="image/*" data-up="${k}" hidden${dis}></label>${v && label !== 'Share picture' ? `<button type="button" class="btn secondary small" data-crop="${esc(v)}">Adjust crop</button>` : ''}</div></div>`;
      html += `<div class="cm-field${type === 'date' ? ' is-half' : ''}"><label for="${id}">${esc(label)}${count}</label>${input}${hint}</div>`;
    });
    el.innerHTML = html;
  }
  function seoPreview(it){
    const t = it.title || '', d = it.desc || '', img = it.image || '/assets/og/crt-og.jpg', url = 'crt.rw' + (it.path || '/');
    return `<div id="cm-seo-prev"><p class="cm-sec">On Google</p><div class="cm-serp"><small>${esc(url)}</small><b>${esc(t.length > 62 ? t.slice(0, 60) + '…' : t)}</b><p>${esc(d.length > 158 ? d.slice(0, 156) + '…' : d)}</p></div>
      <p class="cm-sec">Shared on WhatsApp</p><div class="cm-wa"><img src="${esc(src(img))}" alt=""><div><b>${esc(t)}</b><p>${esc(d)}</p><small>crt.rw</small></div></div></div>`;
  }

  // ------------------------------------------------------------------ availability calendar
  let calMonth = day.slice(0, 7), calSvc = 'all';
  function paintCal(){
    const el = $('#cm-cal'); if(!el) return;
    const list = current('availability'), [y, m] = calMonth.split('-').map(Number);
    const month = (yy, mm) => {
      const first = new Date(yy, mm - 1, 1), days = new Date(yy, mm, 0).getDate(), pad = (first.getDay() + 6) % 7;
      let h = `<div class="cm-month"><h3>${first.toLocaleDateString('en-GB', {month: 'long', year: 'numeric'})}</h3><div class="cm-dow">${['M', 'T', 'W', 'T', 'F', 'S', 'S'].map(d => `<span>${d}</span>`).join('')}</div><div class="cm-days">` + '<span></span>'.repeat(pad);
      for(let d = 1; d <= days; d++){
        const iso = `${yy}-${String(mm).padStart(2, '0')}-${String(d).padStart(2, '0')}`, hit = list.filter(x => x.date === iso && (calSvc === 'all' || !x.service || x.service === 'all' || x.service === calSvc));
        const st = hit.some(x => x.status === 'booked') ? 'booked' : hit.length ? 'limited' : '', past = iso < day;
        h += `<button type="button" class="cm-day${st ? ' is-' + st : ''}${past ? ' is-past' : ''}${iso === day ? ' is-today' : ''}" data-day="${iso}"${past || ro ? ' disabled' : ''} title="${st ? (st === 'booked' ? 'Booked' : 'Almost full') + (hit[0].service && hit[0].service !== 'all' ? ' · ' + name(SVC, hit[0].service) : '') : 'Free'}">${d}</button>`;
      }
      return h + '</div></div>';
    };
    const nm = m === 12 ? [y + 1, 1] : [y, m + 1];
    const up = list.filter(x => x.date >= day).sort((a, b) => a.date < b.date ? -1 : 1);
    el.innerHTML = `<div class="cm-cal-main"><div class="cm-cal-bar"><button type="button" class="btn secondary small" data-cal="-1" aria-label="Earlier months">‹</button><button type="button" class="btn secondary small" data-cal="0">Today</button><button type="button" class="btn secondary small" data-cal="1" aria-label="Later months">›</button>
        <label class="cm-cal-svc">Marking for <select id="cm-cal-svc">${[['all', 'All services'], ...SVC].map(([a, b]) => `<option value="${a}"${a === calSvc ? ' selected' : ''}>${b}</option>`).join('')}</select></label></div>
      <div class="cm-months">${month(y, m)}${month(nm[0], nm[1])}</div>
      <p class="cm-legend"><span class="is-free">Free</span><span class="is-limited">Almost full</span><span class="is-booked">Booked</span> Click a day to switch it: free → booked → almost full → free.</p></div>
      <aside class="cm-cal-side"><h3>Coming up <em>${up.length}</em></h3>${up.length ? '<ul>' + up.map(x => `<li><b>${new Date(x.date + 'T12:00').toLocaleDateString('en-GB', {weekday: 'short', day: 'numeric', month: 'short', year: 'numeric'})}</b><span class="cm-chip is-${x.status === 'booked' ? 'off' : 'soon'}">${x.status === 'booked' ? 'Booked' : 'Almost full'}</span><small>${x.service && x.service !== 'all' ? name(SVC, x.service) : 'All services'}</small>${ro ? '' : `<button type="button" class="link danger" data-unday="${esc(x.id)}" aria-label="Free this date">×</button>`}</li>`).join('') + '</ul>' : '<p class="muted small">No dates marked. Every date shows as free.</p>'}
      <p class="muted small">Only free, almost full or booked is shown to visitors. Never put client names here: it is public.</p></aside>`;
  }

  // ------------------------------------------------------------------ overview
  function overview(){
    const offers = current('offers'), liveOffers = offers.filter(o => status(o, 'offers')[1] === 'on'), ending = liveOffers.filter(o => o.end).sort((a, b) => a.end < b.end ? -1 : 1);
    const soon = current('availability').filter(x => x.date >= day).sort((a, b) => a.date < b.date ? -1 : 1).slice(0, 5);
    const pending = ORDER.filter(dirty), heroes = current('hero').filter(h => status(h, 'hero')[1] === 'on').sort((a, b) => !!b.main - !!a.main), hero = heroes[0];
    const recent = ORDER.filter(c => store[c] && store[c].at).sort((a, b) => store[a].at < store[b].at ? 1 : -1).slice(0, 5);
    const card = (c, body, act) => `<article class="cm-card"><header><span class="cm-ico">${icon(C[c].icon)}</span><h3>${esc(C[c].title)}</h3><button type="button" class="link" data-open="${c}">Open ›</button></header>${body}${act || ''}</article>`;
    return `
      ${pending.length ? `<div class="cm-pending"><b>${pending.length} unpublished ${pending.length > 1 ? 'collections' : 'collection'}:</b> ${pending.map(c => `<button type="button" class="link" data-open="${c}">${esc(C[c].title)}</button>`).join(' · ')}${ro ? '' : ' <button type="button" class="btn small" data-cm="publish-all">Publish all</button>'}</div>` : ''}
      <div class="cm-cards">
        ${card('offers', `<p class="cm-big">${liveOffers.length}<small> live</small></p><ul class="cm-mini">${(ending.length ? ending : liveOffers).slice(0, 3).map(o => `<li><span>${esc(o.title)}</span><em>${o.end ? 'ends ' + fdate(o.end) : 'running'}</em></li>`).join('')}</ul>`, ro ? '' : '<button type="button" class="btn secondary small" data-quick="offers">+ New offer</button>')}
        ${card('availability', soon.length ? `<ul class="cm-mini">${soon.map(x => `<li><span>${new Date(x.date + 'T12:00').toLocaleDateString('en-GB', {weekday: 'short', day: 'numeric', month: 'short'})}</span><em>${x.status === 'booked' ? 'Booked' : 'Almost full'}</em></li>`).join('')}</ul>` : '<p class="muted small">No dates marked yet. Mark booked days so visitors can check theirs.</p>', ro ? '' : '<button type="button" class="btn secondary small" data-open="availability">Mark a date</button>')}
        ${card('hero', `<p class="cm-hero-now"><small>${heroes.length > 1 ? heroes.length + ' campaigns taking turns' + (hero.main ? ' · main 8 s, others 5 s' : ', 5 s each') : 'Showing now'}</small><b>${esc(hero ? hero.title + (hero.title_sub ? ' ' + hero.title_sub : '') : 'The built-in headline')}</b>${hero && hero.end ? `<em>until ${fdate(hero.end)}</em>` : ''}</p>`, ro ? '' : '<button type="button" class="btn secondary small" data-quick="hero">+ New campaign</button>')}
        ${card('packages', `<p class="cm-big">${current('packages').filter(x => x.kind === 'package' && x.live !== false).length}<small> packages · ${current('packages').filter(x => x.kind === 'extra' && x.live !== false).length} extras</small></p>`)}
        ${card('print', `<p class="cm-big">${current('print').filter(x => x.live !== false).length}<small> products</small></p>`)}
      </div>
      <section class="cm-recent"><h3>Recently published</h3>${recent.length ? '<ul>' + recent.map(c => `<li><button type="button" class="link" data-open="${c}">${esc(C[c].title)}</button><span>${ago(store[c].at)}${store[c].by ? ' · ' + esc(store[c].by) : ''}</span></li>`).join('') + '</ul>' : '<p class="muted small">Nothing published from here yet. The website shows its built-in content until you publish.</p>'}</section>`;
  }

  // ------------------------------------------------------------------ live preview
  function previewData(){ const d = {}; ORDER.forEach(c => { if(drafts[c] || published(c)) d[c] = current(c); }); return d; }
  function previewUrl(){ const it = current(col).find(x => x.id === sel), p = (C[col].page && C[col].page(it)) || '/'; return '..' + p + (p.indexOf('?') > -1 ? '&' : '?') + 'cms_preview=1'; }
  function loadPreview(force){
    const f = $('#cm-frame'); if(!f) return; const u = previewUrl(), o = $('#cm-prev-open');
    if(o) o.href = u;
    if(force || f.dataset.u !== u){ f.dataset.u = u; f.src = u; f.onload = () => push(); }
  }
  function schedulePush(){ clearTimeout(pushT); pushT = setTimeout(push, 120); }
  function push(){
    const f = $('#cm-frame'); if(!f || !f.contentWindow) return;
    try{ f.contentWindow.postMessage({crtCms: previewData()}, location.origin); }catch(e){}
    if(col === 'packages' || col === 'print') loadPreview();   // these pages redraw best from a fresh load when the item changes
  }

  // ------------------------------------------------------------------ events
  function selected(){ return current(col).find(x => x.id === sel); }
  function setField(k, v){ edit(col, list => { const it = list.find(x => x.id === sel); if(it) it[k] = v; if(k === 'main' && v) list.forEach(x => { if(x !== it) x.main = false; }); }); const row = $(`.cm-row[data-id="${CSS.escape(sel)}"] .cm-row-t`); const it = selected(); if(row && it){ row.querySelector('b').textContent = C[col].label(it); row.querySelector('small').textContent = C[col].meta(it) || ''; } }
  function onInput(e){
    const t = e.target;
    if(t.id === 'cm-find'){ find = t.value; paintList(); const f = $('#cm-find'); f.focus(); f.setSelectionRange(find.length, find.length); return; }
    if(t.id === 'cm-k-in'){ paintK(t.value); return; }
    const k = t.dataset.f; if(!k || t.type === 'checkbox' || t.tagName === 'SELECT' || t.type === 'date') return;
    let v = t.value;
    if(t.hasAttribute('data-num')){ const n = v.replace(/\D/g, ''); v = n ? +n : null; }
    else if(t.hasAttribute('data-list')) v = t.value.split('\n').map(s => s.trim()).filter(Boolean);
    else if(t.hasAttribute('data-opts')) v = t.value.split('\n').map(l => { const i = l.indexOf(':'); return i < 0 ? null : {name: l.slice(0, i).trim(), values: l.slice(i + 1).split(',').map(s => s.trim()).filter(Boolean)}; }).filter(g => g && g.name && g.values.length);
    setField(k, v);
    const c = $(`[data-count="${k}"]`), max = c && +c.textContent.split('/')[1]; if(c){ c.textContent = t.value.length + '/' + max; c.classList.toggle('is-over', t.value.length > max); }
    if(col === 'seo'){ const p = $('#cm-seo-prev'); if(p) p.outerHTML = seoPreview(selected()); }
  }
  function onChange(e){
    const t = e.target;
    if(t.id === 'cm-cal-svc'){ calSvc = t.value; paintCal(); return; }
    if(t.dataset.up){ upload(t.files[0], t.dataset.up); return; }
    const k = t.dataset.f; if(!k) return;
    if(t.type === 'checkbox') setField(k, t.checked);
    else if(t.tagName === 'SELECT' || t.type === 'date') setField(k, t.value);
    else if(t.hasAttribute('data-num')){ const v = selected() && selected()[k]; t.value = v == null ? '' : Number(v).toLocaleString('en-US'); }
    else if(k === 'cover' || k === 'image' || k === 'proof_img' || k === 'hero'){ paintEdit(); }
    if(['kind', 'service', 'cat', 'live', 'start', 'end', 'spotlight', 'main', 'page', 'bar', 'menu'].includes(k)){ paintList(); paintEdit(); if(preview) loadPreview(); }
  }
  function onClick(e){
    const t = e.target.closest('button,a,[data-pick]'); if(!t) return;
    if(t.dataset.crop){ if(window.CRT_FOCUS) window.CRT_FOCUS.open(src(t.dataset.crop), {readOnly: !A.isAdmin()}); return; }
    if(t.dataset.pick){ sel = t.dataset.pick; $$('.cm-row').forEach(r => r.classList.toggle('is-on', r.dataset.id === sel)); paintEdit(); if(preview) loadPreview(); return; }
    if(t.dataset.open){ if(window.CRT_CONTENT_GO) window.CRT_CONTENT_GO('cms:' + t.dataset.open); else open(t.dataset.open); return; }
    if(t.dataset.quick){ if(window.CRT_CONTENT_GO) window.CRT_CONTENT_GO('cms:' + t.dataset.quick); else open(t.dataset.quick); add(); return; }
    if(t.dataset.show){ show = t.dataset.show; paintList(); return; }
    if(t.dataset.day){ cycleDay(t.dataset.day); return; }
    if(t.dataset.unday){ edit('availability', l => { const i = l.findIndex(x => x.id === t.dataset.unday); if(i > -1) l.splice(i, 1); }); paintCal(); return; }
    if(t.dataset.cal){ const n = +t.dataset.cal; if(!n) calMonth = day.slice(0, 7); else { const [y, m] = calMonth.split('-').map(Number), d = new Date(y, m - 1 + n, 1); calMonth = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); } paintCal(); return; }
    if(t.dataset.restore != null){ restore(+t.dataset.restore); return; }
    if(t.dataset.kgo){ closeK(); const [c, id] = t.dataset.kgo.split('|'); if(c === 'contact' && window.CRT_SETTINGS){ window.CRT_SETTINGS.open('business'); return; } if(c.indexOf('page:') === 0 || ['testimonials', 'logos', 'announcement', 'contact', 'prices', 'changes'].includes(c)){ window.CRT_CONTENT_GO && window.CRT_CONTENT_GO(c); return; } if(window.CRT_CONTENT_GO) window.CRT_CONTENT_GO('cms:' + c); if(id){ sel = id; paint(); } return; }
    const a = t.dataset.cm; if(!a) return;
    if(a === 'publish') publish(col);
    else if(a === 'publish-all') ORDER.filter(dirty).reduce((p, c) => p.then(() => publish(c)), Promise.resolve()).then(() => { col = 'overview'; paint(); });
    else if(a === 'discard'){ if(confirm('Discard your unpublished changes to ' + C[col].title + '?')){ delete drafts[col]; keepDrafts(); paint(); paintNavDot(); schedulePush(); } }
    else if(a === 'preview'){ preview = !preview; paint(); }
    else if(a === 'add') add();
    else if(a === 'dup'){ const it = selected(); if(!it) return; const n = Object.assign(clone(it), {id: uid(it), live: false}); if(n.title) n.title += ' (copy)'; if(n.name) n.name += ' (copy)'; if(n.q) n.q += ' (copy)'; edit(col, l => l.splice(l.findIndex(x => x.id === sel) + 1, 0, n)); sel = n.id; paintList(); paintEdit(); }
    else if(a === 'del'){ const it = selected(); if(!it || !confirm('Delete “' + C[col].label(it) + '”? You can bring it back with Discard until you publish.')) return; const i = current(col).findIndex(x => x.id === sel); edit(col, l => l.splice(i, 1)); const l = visibleItems(); sel = l.length ? l[Math.max(0, i - 1)].id : null; paintList(); paintEdit(); }
    else if(a === 'history') history();
    else if(a === 'k') openK();
    else if(a === 'close-hist') $('#cm-hist').close();
  }
  function uid(it){ const base = col === 'packages' ? (it.service || 'weddings') + ':' + slug(it.name || 'new') : slug(it.title || it.name || it.q || 'new'); let id = base, n = 2; const ids = current(col).map(x => x.id); while(ids.includes(id)) id = base + '-' + n++; return id; }
  function add(){
    const sch = C[col]; if(!sch || !sch.blank || ro) return;
    const it = sch.blank(); if(col === 'faq'){ const cur = selected(); if(cur) it.page = cur.page; }
    if(col === 'packages'){ const cur = selected(); if(cur){ it.service = cur.service; it.kind = cur.kind; } }
    it.id = uid(it) + '-' + Date.now().toString(36).slice(-4);
    edit(col, l => { if(col === 'packages' || col === 'faq'){ let i = -1; l.forEach((x, j) => { if(x.service === it.service && x.kind === it.kind || (col === 'faq' && x.page === it.page)) i = j; }); l.splice(i + 1 || l.length, 0, it); } else l.unshift(it); });
    sel = it.id; find = ''; show = 'all'; paintList(); paintEdit();
    const first = $('#cm-edit input[data-f], #cm-edit textarea[data-f]'); if(first) first.focus();
  }
  function cycleDay(iso){
    edit('availability', l => {
      const svc = calSvc, i = l.findIndex(x => x.date === iso && (x.service || 'all') === svc);
      if(i < 0) l.push({id: iso + ':' + svc, date: iso, service: svc, status: 'booked'});
      else if(l[i].status === 'booked') l[i].status = 'limited';
      else l.splice(i, 1);
      l.sort((a, b) => a.date < b.date ? -1 : 1);
    });
    paintCal();
  }
  async function upload(file, k){
    if(!file || ro) return;
    try{
      A.toast('Uploading the picture…');
      const f = await shrink(file); let url;
      if(!A.LIVE) url = URL.createObjectURL(f);
      else {
        const ext = f.type === 'image/webp' ? '.webp' : ((file.name.match(/\.[a-z0-9]+$/i) || ['.jpg'])[0].toLowerCase());
        const p = 'site/cms/' + col + '/' + Date.now() + '-' + Math.random().toString(36).slice(2, 7) + ext;
        const {error} = await A.sb.storage.from('media').upload(p, f, {upsert: false, contentType: f.type || 'application/octet-stream', cacheControl: '31536000'});
        if(error) throw error;
        url = A.sb.storage.from('media').getPublicUrl(p).data.publicUrl;
      }
      setField(k, url); paintEdit(); paintList(); A.toast('Picture added. Publish to put it live.');
    }catch(e){ A.fail(e); }
  }
  function shrink(file){
    return new Promise(res => {
      if(!/^image\/(jpeg|png|webp)$/.test(file.type)) return res(file);
      const img = new Image(), u = URL.createObjectURL(file);
      img.onload = () => { const k = Math.min(1, 2000 / Math.max(img.naturalWidth, img.naturalHeight)), c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(u); c.toBlob(b => res(b && b.size < file.size ? new File([b], file.name.replace(/\.[a-z0-9]+$/i, '') + '.webp', {type: 'image/webp'}) : file), 'image/webp', .84); };
      img.onerror = () => { URL.revokeObjectURL(u); res(file); }; img.src = u;
    });
  }
  // drag to reorder
  let dragId = null;
  function onDrag(e){
    const row = e.target.closest && e.target.closest('.cm-row');
    if(e.type === 'dragstart' && row){ dragId = row.dataset.id; row.classList.add('is-drag'); e.dataTransfer.effectAllowed = 'move'; try{ e.dataTransfer.setData('text/plain', dragId); }catch(x){} }
    else if(e.type === 'dragover' && dragId && row){ e.preventDefault(); $$('.cm-row.is-over').forEach(r => r.classList.remove('is-over')); row.classList.add('is-over'); }
    else if(e.type === 'drop' && dragId && row){ e.preventDefault(); const to = row.dataset.id; if(to !== dragId) edit(col, l => { const i = l.findIndex(x => x.id === dragId), it = l.splice(i, 1)[0]; l.splice(l.findIndex(x => x.id === to), 0, it); }); dragId = null; paintList(); }
    else if(e.type === 'dragend'){ dragId = null; $$('.cm-row.is-drag,.cm-row.is-over').forEach(r => r.classList.remove('is-drag', 'is-over')); }
  }
  function history(){
    const d = $('#cm-hist'), s = store[col]; if(!d || !s) return;
    d.innerHTML = `<div class="cm-hist-in"><header><h3>${esc(C[col].title)}: history</h3><button type="button" class="link" data-cm="close-hist" aria-label="Close">×</button></header><p class="muted small">Restoring loads that version as a draft. Nothing changes on the website until you publish.</p><ul>
      <li><b>Live now</b><span>${ago(s.at)}${s.by ? ' · ' + esc(s.by) : ''} · ${s.items.length} items</span></li>
      ${(s.history || []).map((h, i) => `<li><b>${new Date(h.at).toLocaleString('en-GB', {day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit'})}</b><span>${h.by ? esc(h.by) + ' · ' : ''}${h.items.length} items</span>${ro ? '' : `<button type="button" class="btn secondary small" data-restore="${i}">Restore</button>`}</li>`).join('')}</ul></div>`;
    d.showModal();
  }
  function restore(i){ const h = store[col].history[i]; if(!h) return; drafts[col] = clone(h.items); keepDrafts(); $('#cm-hist').close(); paint(); paintNavDot(); A.toast('Older version loaded as a draft. Publish to put it live.'); }

  // ------------------------------------------------------------------ ⌘K: find anything
  function openK(){ const k = $('#cm-k'); if(!k) return; k.hidden = false; k.innerHTML = '<div class="cm-k-in" role="dialog" aria-label="Find anything"><input id="cm-k-in" type="search" placeholder="Find an offer, package, product, question, page or setting…" autocomplete="off"><ul id="cm-k-list"></ul><p class="cm-k-foot"><kbd>↑</kbd><kbd>↓</kbd> to move · <kbd>↵</kbd> to open · <kbd>esc</kbd> to close</p></div>'; paintK(''); $('#cm-k-in').focus(); }
  function closeK(){ const k = $('#cm-k'); if(k) k.hidden = true; }
  function paintK(q){
    q = q.trim().toLowerCase(); const out = [];
    [['overview', 'Overview'], ...ORDER.map(c => [c, C[c].title])].forEach(([c, t]) => out.push([c, '', t, 'Section']));
    [['testimonials', 'Reviews'], ['logos', 'Client logos'], ['announcement', 'Announcement bar'], ['prices', 'Prices (amounts across the site)'], ['contact', 'Contact details'], ['changes', 'All page edits']].forEach(([c, t]) => out.push([c, '', t, 'Section']));
    (window.CRT_CONTENT_PAGES || []).forEach(([k, l]) => out.push(['page:' + k, '', 'Edit page: ' + l, 'crt.rw' + (k === '/' ? '/' : k + '/')]));
    if(q) ORDER.forEach(c => { if(C[c].custom) return; current(c).forEach(it => out.push([c, it.id, C[c].label(it), C[c].title])); });
    const hits = (q ? out.filter(r => (r[2] + ' ' + r[3]).toLowerCase().indexOf(q) > -1) : out.slice(0, 12)).slice(0, 14);
    $('#cm-k-list').innerHTML = hits.map((r, i) => `<li><button type="button" data-kgo="${esc(r[0] + '|' + r[1])}"${i ? '' : ' class="is-on"'}><b>${esc(r[2])}</b><small>${esc(r[3])}</small></button></li>`).join('') || '<li class="cm-none">Nothing found.</li>';
  }
  function onKey(e){
    const tab = $('#tab-content'); if(!tab || tab.hidden) return;
    if((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k'){ e.preventDefault(); openK(); return; }
    const k = $('#cm-k');
    if(k && !k.hidden){
      if(e.key === 'Escape'){ closeK(); return; }
      const bs = $$('#cm-k-list button'), i = bs.findIndex(b => b.classList.contains('is-on'));
      if(e.key === 'ArrowDown' || e.key === 'ArrowUp'){ e.preventDefault(); const n = bs[(i + (e.key === 'ArrowDown' ? 1 : -1) + bs.length) % bs.length]; bs.forEach(b => b.classList.toggle('is-on', b === n)); if(n) n.scrollIntoView({block: 'nearest'}); }
      if(e.key === 'Enter' && bs[i]){ e.preventDefault(); bs[i].click(); }
      return;
    }
    if(col !== 'overview' && $('#cm') && $('#cm').offsetParent && (e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 's'){ e.preventDefault(); if(dirty(col)) publish(col); }
  }

  // ------------------------------------------------------------------ API for content.js (the Content tab shell)
  window.CRT_CMS = {
    C, ORDER, icon,
    async start(a){ A = a; esc = a.esc; ro = !a.isAdmin(); try{ await load(); }catch(e){ A.fail(e); } if(host) open(col); },
    mount, open, paint,
    count: c => c === 'availability' ? current(c).filter(x => x.date >= day).length : current(c).filter(it => it.live !== false && status(it, c)[1] !== 'off').length,
    dirty, isLive, openK
  };
})();
