/**
 * CRT Finance → Google Sheets backup (Apps Script).
 * A live copy of the books: every entry made in the dashboard or on WhatsApp appears here
 * within seconds, edits update the same row, deletions remove it.
 *
 * Setup (once, about 10 minutes; full steps in admin/FINANCE-SETUP.txt):
 *  1. Create a Google Sheet called "CRT Books" in the Google Drive folder you want.
 *  2. Extensions → Apps Script → paste this whole file → Save.
 *  3. Project Settings → Script properties → add:
 *       SECRET                any long random text (also used in the Supabase webhook URL)
 *       SUPABASE_URL          https://YOUR-PROJECT.supabase.co
 *       SUPABASE_SERVICE_KEY  Supabase → Project Settings → API → service_role key
 *     (Script properties are visible only to you, the owner of the script.)
 *  4. Run the function "setup" once (accept Google's permission screen). It creates the tabs
 *     and copies everything already in the books.
 *  5. Deploy → New deployment → Web app → Execute as: Me, Who has access: Anyone → Deploy.
 *     Copy the Web app URL and add ?key=YOUR_SECRET to the end of it.
 *  6. In Supabase → Database → Webhooks, create two webhooks (fin_entries and fin_invoices,
 *     events Insert, Update, Delete, type HTTP Request, method POST) pointing at that URL.
 *
 * The Sheet is a read-only mirror: make changes in the dashboard or on WhatsApp, not here,
 * so the three never disagree. Run "resync" any time to rebuild it from the books.
 */

var LEDGER = 'Ledger', INVOICES = 'Invoices', SUMMARY = 'Summary';
var LEDGER_HEAD = ['ID', 'Date', 'Type', 'Amount (RWF)', 'Signed (RWF)', 'Account', 'To account', 'Category', 'Who', 'Note', 'Source', 'By', 'Month', 'Updated'];
var INV_HEAD = ['ID', 'Number', 'Client', 'What it covers', 'Amount (RWF)', 'Issued', 'Due', 'Status', 'Updated'];
var TYPE = {income: 'Money in', expense: 'Money out', transfer: 'Transfer'};
var SOURCE = {dashboard: 'Dashboard', whatsapp: 'WhatsApp', sheet: 'Sheet', 'import': 'Import'};

function props_() { return PropertiesService.getScriptProperties(); }

function api_(path) {
  var p = props_();
  var res = UrlFetchApp.fetch(p.getProperty('SUPABASE_URL').replace(/\/$/, '') + '/rest/v1/' + path, {
    headers: {apikey: p.getProperty('SUPABASE_SERVICE_KEY'), Authorization: 'Bearer ' + p.getProperty('SUPABASE_SERVICE_KEY')},
    muteHttpExceptions: true
  });
  if (res.getResponseCode() >= 300) throw new Error('Supabase ' + res.getResponseCode() + ': ' + res.getContentText());
  return JSON.parse(res.getContentText());
}

// Names for accounts and categories, cached for 6 hours
function names_() {
  var cache = CacheService.getScriptCache(), hit = cache.get('names');
  if (hit) return JSON.parse(hit);
  var n = {acc: {}, cat: {}};
  api_('fin_accounts?select=id,name').forEach(function (a) { n.acc[a.id] = a.name; });
  api_('fin_categories?select=id,name').forEach(function (c) { n.cat[c.id] = c.name; });
  cache.put('names', JSON.stringify(n), 21600);
  return n;
}

function sheet_(name, head) {
  var ss = SpreadsheetApp.getActive(), sh = ss.getSheetByName(name) || ss.insertSheet(name);
  if (sh.getLastRow() === 0) {
    sh.appendRow(head);
    sh.getRange(1, 1, 1, head.length).setFontWeight('bold').setBackground('#141a2e').setFontColor('#ffffff');
    sh.setFrozenRows(1);
  }
  return sh;
}

function ledgerRow_(e, n) {
  var amt = Number(e.amount_rwf) || 0;
  return [e.id, e.happened_on, TYPE[e.type] || e.type, amt, e.type === 'income' ? amt : e.type === 'expense' ? -amt : 0,
    n.acc[e.account_id] || e.account_id || '', e.to_account_id ? (n.acc[e.to_account_id] || e.to_account_id) : '',
    e.category_id ? (n.cat[e.category_id] || e.category_id) : (e.type === 'transfer' ? 'Transfer' : ''),
    e.party || '', e.note || '', SOURCE[e.source] || e.source || '', e.created_by_name || '',
    String(e.happened_on || '').slice(0, 7), new Date()];
}
function invoiceRow_(i) {
  return [i.id, i.number, i.client, i.description || '', Number(i.amount_rwf) || 0, i.issued_on || '', i.due_on || '',
    {draft: 'Draft', sent: 'Unpaid', paid: 'Paid', 'void': 'Void'}[i.status] || i.status, new Date()];
}

function findRow_(sh, id) {
  if (sh.getLastRow() < 2) return 0;
  var hit = sh.getRange(2, 1, sh.getLastRow() - 1, 1).createTextFinder(String(id)).matchEntireCell(true).findNext();
  return hit ? hit.getRow() : 0;
}

function upsert_(sh, id, row) {
  var r = findRow_(sh, id);
  if (r) sh.getRange(r, 1, 1, row.length).setValues([row]);
  else sh.appendRow(row);
}

// Called by the Supabase database webhooks
function doPost(e) {
  if (!e || !e.parameter || e.parameter.key !== props_().getProperty('SECRET')) return out_({ok: false, error: 'bad key'});
  var lock = LockService.getScriptLock(); lock.waitLock(20000);
  try {
    var p = JSON.parse(e.postData.contents), rec = p.record, old = p.old_record;
    if (p.table === 'fin_entries') {
      var sh = sheet_(LEDGER, LEDGER_HEAD);
      if (p.type === 'DELETE') { var r = findRow_(sh, old.id); if (r) sh.deleteRow(r); }
      else upsert_(sh, rec.id, ledgerRow_(rec, names_()));
    } else if (p.table === 'fin_invoices') {
      var si = sheet_(INVOICES, INV_HEAD);
      if (p.type === 'DELETE') { var r2 = findRow_(si, old.id); if (r2) si.deleteRow(r2); }
      else upsert_(si, rec.id, invoiceRow_(rec));
    } else if (p.table === 'fin_accounts' || p.table === 'fin_categories') {
      CacheService.getScriptCache().remove('names');
    }
    return out_({ok: true});
  } catch (err) {
    console.error(err);
    return out_({ok: false, error: String(err)});
  } finally { lock.releaseLock(); }
}
function out_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }

// Run once after pasting the script
function setup() {
  var p = props_();
  ['SECRET', 'SUPABASE_URL', 'SUPABASE_SERVICE_KEY'].forEach(function (k) {
    if (!p.getProperty(k)) throw new Error('Add the script property ' + k + ' first (Project Settings → Script properties).');
  });
  resync();
  var ss = SpreadsheetApp.getActive(), s = ss.getSheetByName(SUMMARY) || ss.insertSheet(SUMMARY, 0);
  s.clear();
  s.getRange('A1').setValue('CRT books: profit by month').setFontWeight('bold').setFontSize(14);
  s.getRange('A2').setValue('Live copy of the dashboard. Edit entries in the dashboard or on WhatsApp, not in this file.').setFontColor('#67625b');
  s.getRange('A4').setFormula("=QUERY({Ledger!M2:M, Ledger!C2:C, Ledger!E2:E}, \"select Col1, sum(Col3) where Col2 <> 'Transfer' and Col1 is not null group by Col1 pivot Col2 order by Col1 desc label Col1 'Month'\", 0)");
  s.getRange('E4').setValue('Profit').setFontWeight('bold');
  s.getRange('E5').setFormula('=ARRAYFORMULA(IF(A5:A="",,N(B5:B)+N(C5:C)))');
  s.getRange('B5:E200').setNumberFormat('#,##0;-#,##0');
  [LEDGER, INVOICES].forEach(function (n) {
    var sh = ss.getSheetByName(n);
    sh.protect().setWarningOnly(true).setDescription('Mirror of the CRT books. Change entries in the dashboard or on WhatsApp.');
  });
  ss.getSheetByName(LEDGER).getRange('D:E').setNumberFormat('#,##0;-#,##0');
  ss.getSheetByName(INVOICES).getRange('E:E').setNumberFormat('#,##0');
}

// Rebuild both tabs from the books (safe to run any time)
function resync() {
  CacheService.getScriptCache().remove('names');
  var n = names_(), ss = SpreadsheetApp.getActive();
  var entries = api_('fin_entries?select=*&order=happened_on.desc,id.desc&limit=100000');
  var sh = sheet_(LEDGER, LEDGER_HEAD);
  if (sh.getLastRow() > 1) sh.getRange(2, 1, sh.getLastRow() - 1, sh.getLastColumn()).clearContent();
  if (entries.length) sh.getRange(2, 1, entries.length, LEDGER_HEAD.length).setValues(entries.map(function (e) { return ledgerRow_(e, n); }));
  var inv = api_('fin_invoices?select=*&order=issued_on.desc&limit=10000');
  var si = sheet_(INVOICES, INV_HEAD);
  if (si.getLastRow() > 1) si.getRange(2, 1, si.getLastRow() - 1, si.getLastColumn()).clearContent();
  if (inv.length) si.getRange(2, 1, inv.length, INV_HEAD.length).setValues(inv.map(invoiceRow_));
  ss.toast('Synced ' + entries.length + ' entries and ' + inv.length + ' invoices.');
}
