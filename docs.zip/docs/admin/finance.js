/* CRT Finance tab: ledger, quick entry (same language as WhatsApp), statements, invoices.
   Data lives in Supabase (finance-setup.sql). Without Supabase it runs on sample data. */
(function(){
  'use strict';
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];
  const rwf = n => (Number(n) || 0).toLocaleString('en-US');
  const TYPE = {income:'Money in', expense:'Money out', transfer:'Transfer'};
  const SRC = {dashboard:'Dashboard', whatsapp:'WhatsApp', sheet:'Sheet', import:'Import'};
  let A = null, accounts = [], categories = [], entries = [], invoices = [], loaded = false, channel = null;
  let period = 'month', fType = '', fAcc = '', fCat = '', q = '', editing = null;

  // ---------------------------------------------------------------- sample data (demo mode)
  function demoData(){
    const d = n => { const x = new Date(); x.setDate(x.getDate() - n); return x.toISOString().slice(0, 10); };
    accounts = [{id:'momo',name:'MTN MoMo',kind:'mobile_money',opening_rwf:350000,sort:1},{id:'bank',name:'Bank account',kind:'bank',opening_rwf:1200000,sort:2},{id:'cash',name:'Cash',kind:'cash',opening_rwf:80000,sort:3}];
    categories = [['weddings','Weddings','income','wedding,gusaba,bride'],['events','Events','income','event,gala,defense,conference'],['commercial','Commercial shoots','income','product,food,menu,shoot'],['branding','Branding & design','income','logo,brand,design'],['social','Social media & content','income','social,content,monthly'],['other-income','Other income','income',''],
      ['crew','Crew & freelancers','expense','crew,freelancer,editor,editing,assistant,second shooter,second shooting,shooter,wages'],['transport','Transport & fuel','expense','transport,fuel,moto,taxi'],['equipment','Equipment & repairs','expense','camera,lens,battery,sd,repair'],['software','Software & subscriptions','expense','adobe,subscription,software'],['internet','Internet & airtime','expense','internet,data,airtime'],['food','Meals on shoots','expense','food,lunch,meal'],['fees','Bank & MoMo fees','expense','fee,fees,charges'],['other-expense','Other expenses','expense','']]
      .map(([id,name,type,keywords], i) => ({id,name,type,keywords,sort:i}));
    let id = 20;
    const e = (days, type, amt, acc, cat, party, note, src) => ({id:id--, happened_on:d(days), type, amount_rwf:amt, account_id:acc, to_account_id:null, category_id:cat, party, note, source:src||'dashboard', created_by_name:'Alain', created_at:new Date(Date.now()-days*864e5).toISOString()});
    entries = [e(0,'expense',50000,'momo','transport','','paid 50k fuel momo','whatsapp'), e(1,'income',400000,'bank','commercial','Inka Steak House','Menu shoot balance'),
      e(2,'expense',150000,'momo','crew','Jean','Editor, Old Mutual gala','whatsapp'), e(3,'income',800000,'bank','events','Old Mutual','Year-end party coverage'),
      e(5,'expense',35000,'cash','equipment','','SD card 128GB'), e(6,'income',1200000,'momo','weddings','Grace & Eric','Wedding deposit','whatsapp'),
      e(9,'expense',68000,'bank','software','Adobe','Creative Cloud'), e(12,'expense',20000,'momo','internet','MTN','Data bundle','whatsapp'),
      e(38,'income',500000,'bank','social','Car Biz','Monthly content'), e(40,'expense',90000,'momo','crew','Eric','Second shooter'),
      e(70,'income',600000,'bank','branding','King’s Memo','Logo design'), e(72,'expense',45000,'cash','food','','Lunch on shoots')];
    entries.push({id:1, happened_on:d(15), type:'transfer', amount_rwf:300000, account_id:'momo', to_account_id:'bank', category_id:null, party:'', note:'Moved to bank', source:'dashboard', created_by_name:'Alain'});
    invoices = [{id:3, number:'CRT-2026-014', client:'Old Mutual', description:'Year-end party photos', amount_rwf:800000, issued_on:d(10), due_on:d(-4), status:'paid'},
      {id:2, number:'CRT-2026-015', client:'Digital Axis', description:'Product photography', amount_rwf:350000, issued_on:d(8), due_on:d(-6), status:'sent'},
      {id:1, number:'CRT-2026-013', client:'SportsPark', description:'Aerobics event coverage', amount_rwf:250000, issued_on:d(30), due_on:d(16), status:'sent'}];
  }

  // ---------------------------------------------------------------- data
  const db = {
    async load(){
      if(!A.LIVE){ demoData(); return; }
      const [a, c, e, i] = await Promise.all([
        A.sb.from('fin_accounts').select('*').eq('archived', false).order('sort'),
        A.sb.from('fin_categories').select('*').order('sort'),
        A.sb.from('fin_entries').select('*').order('happened_on', {ascending:false}).order('id', {ascending:false}).limit(5000),
        A.sb.from('fin_invoices').select('*').order('issued_on', {ascending:false}).limit(1000)]);
      for(const r of [a, c, e, i]) if(r.error) throw r.error;
      accounts = a.data; categories = c.data; entries = e.data; invoices = i.data;
    },
    async save(row){
      if(!A.LIVE){ if(row.id){ Object.assign(entries.find(x => x.id === row.id), row); } else { row.id = Date.now(); row.created_by_name = A.me.name; entries.unshift(row); } return row; }
      const me = A.me;
      if(row.id){ const {id, ...patch} = row; const r = await A.sb.from('fin_entries').update(patch).eq('id', id).select('*').single(); if(r.error) throw r.error; return r.data; }
      const r = await A.sb.from('fin_entries').insert({...row, created_by: me.user_id, created_by_name: me.name}).select('*').single(); if(r.error) throw r.error; return r.data;
    },
    async remove(id){ if(!A.LIVE){ entries = entries.filter(x => x.id !== id); return; } const r = await A.sb.from('fin_entries').delete().eq('id', id); if(r.error) throw r.error; },
    async saveInvoice(row){
      if(!A.LIVE){ if(row.id) Object.assign(invoices.find(x => x.id === row.id), row); else { row.id = Date.now(); invoices.unshift(row); } return row; }
      if(row.id){ const {id, ...patch} = row; const r = await A.sb.from('fin_invoices').update(patch).eq('id', id).select('*').single(); if(r.error) throw r.error; return r.data; }
      const r = await A.sb.from('fin_invoices').insert(row).select('*').single(); if(r.error) throw r.error; return r.data;
    },
    live(){
      if(!A.LIVE || channel) return;
      // Anything recorded on WhatsApp (or by a teammate) appears here within a second.
      channel = A.sb.channel('fin').on('postgres_changes', {event:'*', schema:'public', table:'fin_entries'}, p => {
        if(p.eventType === 'DELETE') entries = entries.filter(x => x.id !== p.old.id);
        else { const i = entries.findIndex(x => x.id === p.new.id); if(i >= 0) entries[i] = p.new; else { entries.unshift(p.new); if(p.new.source === 'whatsapp') A.toast('New from WhatsApp: ' + TYPE[p.new.type] + ' ' + rwf(p.new.amount_rwf) + ' RWF'); } }
        sortEntries(); render();
      }).on('postgres_changes', {event:'*', schema:'public', table:'fin_invoices'}, p => {
        if(p.eventType === 'DELETE') invoices = invoices.filter(x => x.id !== p.old.id);
        else { const i = invoices.findIndex(x => x.id === p.new.id); if(i >= 0) invoices[i] = p.new; else invoices.unshift(p.new); }
        render();
      }).subscribe();
    }
  };
  const sortEntries = () => entries.sort((a, b) => (b.happened_on || '').localeCompare(a.happened_on || '') || b.id - a.id);

  // ---------------------------------------------------------------- calculations
  const accName = id => (accounts.find(a => a.id === id) || {name:id || '—'}).name;
  const cat = id => categories.find(c => c.id === id) || {name:'—', type:''};
  function range(p){
    const now = new Date(), y = now.getFullYear(), m = now.getMonth(), f = d => d.toISOString().slice(0, 10);
    const day = (yy, mm, dd) => f(new Date(Date.UTC(yy, mm, dd)));
    if(p === 'month') return [day(y, m, 1), day(y, m + 1, 0), now.toLocaleDateString('en-GB', {month:'long', year:'numeric'})];
    if(p === 'last') return [day(y, m - 1, 1), day(y, m, 0), new Date(y, m - 1, 1).toLocaleDateString('en-GB', {month:'long', year:'numeric'})];
    if(p === 'quarter'){ const qs = Math.floor(m / 3) * 3; return [day(y, qs, 1), day(y, qs + 3, 0), 'Q' + (qs / 3 + 1) + ' ' + y]; }
    if(p === 'year') return [day(y, 0, 1), day(y, 11, 31), String(y)];
    return ['0000-01-01', '9999-12-31', 'All time'];
  }
  const inRange = (e, r) => e.happened_on >= r[0] && e.happened_on <= r[1];
  function pnl(r){
    const inc = {}, exp = {}; let ti = 0, te = 0;
    entries.filter(e => inRange(e, r)).forEach(e => {
      if(e.type === 'income'){ inc[e.category_id] = (inc[e.category_id] || 0) + Number(e.amount_rwf); ti += Number(e.amount_rwf); }
      if(e.type === 'expense'){ exp[e.category_id] = (exp[e.category_id] || 0) + Number(e.amount_rwf); te += Number(e.amount_rwf); }
    });
    return {inc, exp, ti, te, net: ti - te};
  }
  function balances(){
    return accounts.map(a => {
      let b = Number(a.opening_rwf) || 0;
      entries.forEach(e => {
        const v = Number(e.amount_rwf);
        if(e.type === 'income' && e.account_id === a.id) b += v;
        if(e.type === 'expense' && e.account_id === a.id) b -= v;
        if(e.type === 'transfer'){ if(e.account_id === a.id) b -= v; if(e.to_account_id === a.id) b += v; }
      });
      return {...a, balance: b};
    });
  }
  function months(n){
    const out = [], now = new Date();
    for(let i = n - 1; i >= 0; i--){
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1), key = d.toISOString().slice(0, 7);
      let inc = 0, exp = 0;
      entries.forEach(e => { if((e.happened_on || '').slice(0, 7) !== key) return; if(e.type === 'income') inc += Number(e.amount_rwf); if(e.type === 'expense') exp += Number(e.amount_rwf); });
      out.push({label: d.toLocaleDateString('en-GB', {month:'short'}), inc, exp});
    }
    return out;
  }
  const owed = () => invoices.filter(i => i.status === 'sent');
  const overdue = i => i.status === 'sent' && i.due_on && i.due_on < new Date().toISOString().slice(0, 10);

  // ---------------------------------------------------------------- render
  function shell(){
    $('#tab-finance').innerHTML = `
      <div class="page-head"><div><h1>Finance</h1><p class="muted">Every franc in and out. Record here or by WhatsApp; it lands in the books, the statements and the Google Sheet at once.</p></div>
        <div class="head-actions"><div class="seg" role="group" aria-label="Period" id="fin-period">${[['month','This month'],['last','Last month'],['quarter','Quarter'],['year','Year'],['all','All']].map(([k, l]) => `<button class="seg-btn" data-fin-period="${k}">${l}</button>`).join('')}</div>
        <button class="btn secondary small" data-fin="export">Export CSV</button></div></div>
      <div class="fin-quick panel">
        <form id="fin-quick-form" autocomplete="off"><label class="sr-only" for="fin-quick">Record money</label>
          <input id="fin-quick" type="text" placeholder="Type it like a WhatsApp message: paid 50k fuel momo · received 400k from Inka bank · moved 200k momo to bank">
          <button class="btn" type="submit">Record</button></form>
        <div id="fin-quick-preview" class="fin-preview" hidden></div>
        <p class="muted small fin-quick-help">Prefer a form? <button type="button" class="link" data-fin="new">Add with all fields</button></p>
      </div>
      <div class="kpis fin-kpis" id="fin-kpis"></div>
      <div class="fin-grid">
        <div class="panel"><h2>Profit &amp; loss <span class="muted small" id="fin-pnl-label"></span></h2><div id="fin-pnl"></div></div>
        <div class="fin-side">
          <div class="panel"><h2>Cash flow, last 6 months</h2><div id="fin-flow" class="fin-flow"></div><p class="fin-legend small muted"><i class="in"></i>Money in <i class="out"></i>Money out</p></div>
          <div class="panel"><h2>Balances</h2><div id="fin-bal"></div></div>
        </div>
      </div>
      <div class="panel flush">
        <div class="fin-ledger-head"><h2>Ledger</h2>
          <div class="fin-filters">
            <select id="fin-f-type" aria-label="Type"><option value="">All types</option><option value="income">Money in</option><option value="expense">Money out</option><option value="transfer">Transfers</option></select>
            <select id="fin-f-acc" aria-label="Account"></select><select id="fin-f-cat" aria-label="Category"></select>
            <input id="fin-f-q" type="search" placeholder="Search who or what" aria-label="Search ledger"></div></div>
        <div class="fin-table-wrap"><table class="leads-table fin-table"><thead><tr><th>Date</th><th>What</th><th>Category</th><th>Account</th><th class="num">Amount (RWF)</th></tr></thead><tbody id="fin-rows"></tbody></table></div>
        <div class="empty" id="fin-empty" hidden>Nothing recorded for this period.</div>
      </div>
      <div class="panel flush">
        <div class="fin-ledger-head"><h2>Invoices</h2><button class="btn secondary small" data-fin="new-invoice">+ New invoice</button></div>
        <div class="fin-table-wrap"><table class="leads-table fin-table"><thead><tr><th>Number</th><th>Client</th><th>Issued</th><th>Due</th><th>Status</th><th class="num">Amount (RWF)</th><th></th></tr></thead><tbody id="fin-inv"></tbody></table></div>
      </div>
      <dialog id="fin-dialog" class="fin-dialog"></dialog>`;
  }
  function render(){
    if(!loaded) return;
    const r = range(period), p = pnl(r), bal = balances(), cash = bal.reduce((s, a) => s + a.balance, 0), due = owed();
    $$('[data-fin-period]').forEach(b => b.classList.toggle('is-active', b.dataset.finPeriod === period));
    const margin = p.ti ? Math.round(p.net / p.ti * 100) : 0;
    $('#fin-kpis').innerHTML = [
      ['Money in', rwf(p.ti), r[2]], ['Money out', rwf(p.te), r[2]],
      ['Profit', (p.net < 0 ? '−' : '') + rwf(Math.abs(p.net)), p.ti ? margin + '% margin' : '—', p.net < 0 ? 'neg' : 'pos'],
      ['Cash on hand', rwf(cash), 'All accounts'],
      ['Clients owe', rwf(due.reduce((s, i) => s + Number(i.amount_rwf), 0)), due.length + ' unpaid' + (due.filter(overdue).length ? ', ' + due.filter(overdue).length + ' overdue' : '')]
    ].map(([k, v, s, cls]) => `<div class="kpi ${cls || ''}"><span>${k}</span><strong>${v}</strong><small>${A.esc(s)}</small></div>`).join('');
    $('#fin-pnl-label').textContent = '· ' + r[2];
    const lines = (obj, type) => categories.filter(c => c.type === type && obj[c.id]).sort((a, b) => obj[b.id] - obj[a.id]).map(c => `<div class="fin-line"><span>${A.esc(c.name)}</span><span class="num">${rwf(obj[c.id])}</span></div>`).join('') || '<div class="fin-line muted"><span>Nothing yet</span><span></span></div>';
    $('#fin-pnl').innerHTML = `<div class="fin-block"><h3>Income</h3>${lines(p.inc, 'income')}<div class="fin-line total"><span>Total income</span><span class="num">${rwf(p.ti)}</span></div></div>
      <div class="fin-block"><h3>Expenses</h3>${lines(p.exp, 'expense')}<div class="fin-line total"><span>Total expenses</span><span class="num">${rwf(p.te)}</span></div></div>
      <div class="fin-line net ${p.net < 0 ? 'neg' : 'pos'}"><span>Net profit</span><span class="num">${p.net < 0 ? '−' : ''}${rwf(Math.abs(p.net))}</span></div>`;
    const ms = months(6), max = Math.max(1, ...ms.map(m => Math.max(m.inc, m.exp)));
    $('#fin-flow').innerHTML = ms.map(m => `<div class="fin-col" title="${m.label}: in ${rwf(m.inc)}, out ${rwf(m.exp)}"><div class="fin-bars"><i class="in" style="height:${m.inc / max * 100}%"></i><i class="out" style="height:${m.exp / max * 100}%"></i></div><span>${m.label}</span></div>`).join('');
    $('#fin-bal').innerHTML = bal.map(a => `<div class="fin-line"><span>${A.esc(a.name)}</span><span class="num ${a.balance < 0 ? 'neg' : ''}">${rwf(a.balance)}</span></div>`).join('') + `<div class="fin-line total"><span>Total</span><span class="num">${rwf(cash)}</span></div>`;
    // filters
    const fa = $('#fin-f-acc'), fc = $('#fin-f-cat');
    if(!fa.options.length){ fa.innerHTML = '<option value="">All accounts</option>' + accounts.map(a => `<option value="${a.id}">${A.esc(a.name)}</option>`).join(''); fc.innerHTML = '<option value="">All categories</option>' + categories.map(c => `<option value="${c.id}">${A.esc(c.name)}</option>`).join(''); }
    const ql = q.toLowerCase();
    const rows = entries.filter(e => inRange(e, r) && (!fType || e.type === fType) && (!fAcc || e.account_id === fAcc || e.to_account_id === fAcc) && (!fCat || e.category_id === fCat)
      && (!ql || [e.party, e.note, cat(e.category_id).name].join(' ').toLowerCase().includes(ql)));
    $('#fin-rows').innerHTML = rows.map(e => `<tr data-fin-id="${e.id}"><td>${new Date(e.happened_on + 'T00:00').toLocaleDateString('en-GB', {day:'numeric', month:'short'})}</td>
      <td><b>${A.esc(e.party || e.note || TYPE[e.type])}</b>${e.party && e.note ? `<small>${A.esc(e.note)}</small>` : ''}<em class="fin-src fin-src-${e.source}">${SRC[e.source] || e.source}${e.created_by_name ? ' · ' + A.esc(e.created_by_name) : ''}</em></td>
      <td>${e.type === 'transfer' ? 'Transfer' : A.esc(cat(e.category_id).name)}</td>
      <td>${A.esc(accName(e.account_id))}${e.type === 'transfer' ? ' → ' + A.esc(accName(e.to_account_id)) : ''}</td>
      <td class="num fin-amt ${e.type}">${e.type === 'income' ? '+' : e.type === 'expense' ? '−' : ''}${rwf(e.amount_rwf)}</td></tr>`).join('');
    $('#fin-empty').hidden = rows.length > 0;
    $('#fin-inv').innerHTML = invoices.map(i => `<tr><td><b>${A.esc(i.number)}</b></td><td>${A.esc(i.client)}<small>${A.esc(i.description || '')}</small></td><td>${A.esc(i.issued_on || '')}</td><td>${A.esc(i.due_on || '—')}</td>
      <td><span class="badge fin-inv-${overdue(i) ? 'overdue' : i.status}">${overdue(i) ? 'Overdue' : {draft:'Draft', sent:'Unpaid', paid:'Paid', void:'Void'}[i.status]}</span></td>
      <td class="num">${rwf(i.amount_rwf)}</td><td class="num">${i.status === 'sent' ? `<button class="btn small" data-fin="paid" data-inv="${i.id}">Mark paid</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="7" class="muted">No invoices yet.</td></tr>';
  }

  // ---------------------------------------------------------------- forms
  const today = () => new Date().toISOString().slice(0, 10);
  function entryForm(e){
    editing = e && e.id ? e : null; e = e || {type:'expense', happened_on: today(), account_id: accounts[0] && accounts[0].id};
    const opts = (list, v) => list.map(x => `<option value="${x.id}"${x.id === v ? ' selected' : ''}>${A.esc(x.name)}</option>`).join('');
    const d = $('#fin-dialog');
    d.innerHTML = `<form method="dialog" class="fin-form" id="fin-form"><h2>${e.id ? 'Edit entry' : 'Record money'}</h2>
      <div class="seg fin-type" role="group" aria-label="Type">${Object.entries(TYPE).map(([k, l]) => `<button type="button" class="seg-btn${e.type === k ? ' is-active' : ''}" data-fin-type="${k}">${l}</button>`).join('')}</div>
      <input type="hidden" name="type" value="${e.type}">
      <label>Amount (RWF)<input name="amount_rwf" inputmode="numeric" required value="${e.amount_rwf ? rwf(e.amount_rwf) : ''}" placeholder="50,000"></label>
      <label>Date<input name="happened_on" type="date" required value="${e.happened_on}"></label>
      <label>${e.type === 'transfer' ? 'From account' : 'Account'}<select name="account_id">${opts(accounts, e.account_id)}</select></label>
      <label class="fin-to"${e.type === 'transfer' ? '' : ' hidden'}>To account<select name="to_account_id">${opts(accounts, e.to_account_id || (accounts[1] || {}).id)}</select></label>
      <label class="fin-cat"${e.type === 'transfer' ? ' hidden' : ''}>Category<select name="category_id">${opts(categories.filter(c => c.type === (e.type === 'income' ? 'income' : 'expense')), e.category_id)}</select></label>
      <label class="fin-party"${e.type === 'transfer' ? ' hidden' : ''}>${e.type === 'income' ? 'From (client)' : 'Paid to'}<input name="party" maxlength="120" value="${A.esc(e.party || '')}" list="fin-parties"></label>
      <label class="fin-wide">Note<input name="note" maxlength="500" value="${A.esc(e.note || '')}"></label>
      <datalist id="fin-parties">${[...new Set(entries.map(x => x.party).filter(Boolean))].slice(0, 200).map(p => `<option>${A.esc(p)}</option>`).join('')}</datalist>
      <div class="fin-actions">${e.id ? '<button type="button" class="link danger" data-fin="delete">Delete</button>' : ''}<span></span><button type="button" class="btn secondary" data-fin="close">Cancel</button><button class="btn" type="submit">${e.id ? 'Save' : 'Record'}</button></div></form>`;
    d.showModal(); d.querySelector('[name=amount_rwf]').focus();
  }
  function setType(t){
    const f = $('#fin-form'); f.type.value = t;
    $$('[data-fin-type]', f).forEach(b => b.classList.toggle('is-active', b.dataset.finType === t));
    f.querySelector('.fin-to').hidden = t !== 'transfer'; f.querySelector('.fin-cat').hidden = t === 'transfer'; f.querySelector('.fin-party').hidden = t === 'transfer';
    f.category_id.innerHTML = categories.filter(c => c.type === (t === 'income' ? 'income' : 'expense')).map(c => `<option value="${c.id}">${A.esc(c.name)}</option>`).join('');
    f.querySelector('.fin-party').firstChild.textContent = t === 'income' ? 'From (client)' : 'Paid to';
  }
  async function submitForm(){
    const f = $('#fin-form'), t = f.type.value, amt = Number(String(f.amount_rwf.value).replace(/[^\d]/g, ''));
    if(!(amt > 0)){ A.toast('Enter an amount'); return; }
    if(t === 'transfer' && f.account_id.value === f.to_account_id.value){ A.toast('Pick two different accounts'); return; }
    const row = {type:t, amount_rwf:amt, happened_on:f.happened_on.value, account_id:f.account_id.value, to_account_id: t === 'transfer' ? f.to_account_id.value : null,
      category_id: t === 'transfer' ? null : f.category_id.value, party: t === 'transfer' ? null : f.party.value.trim() || null, note: f.note.value.trim() || null};
    if(editing) row.id = editing.id; else row.source = 'dashboard';
    try{ const saved = await db.save(row); upsert(saved); $('#fin-dialog').close(); A.toast(editing ? 'Saved' : 'Recorded'); }catch(err){ A.fail(err); }
  }
  function upsert(row){ const i = entries.findIndex(x => x.id === row.id); if(i >= 0) entries[i] = row; else entries.unshift(row); sortEntries(); render(); }
  function invoiceForm(){
    const n = 'CRT-' + new Date().getFullYear() + '-' + String(invoices.length + 1).padStart(3, '0'), due = new Date(Date.now() + 14 * 864e5).toISOString().slice(0, 10);
    const d = $('#fin-dialog');
    d.innerHTML = `<form method="dialog" class="fin-form" id="fin-inv-form"><h2>New invoice</h2>
      <label>Number<input name="number" required maxlength="30" value="${n}"></label><label>Client<input name="client" required maxlength="120" list="fin-clients"></label>
      <label>Amount (RWF)<input name="amount_rwf" inputmode="numeric" required placeholder="400,000"></label><label>Due<input name="due_on" type="date" value="${due}"></label>
      <label class="fin-wide">What it covers<input name="description" maxlength="500"></label>
      <datalist id="fin-clients">${[...new Set((A.leads() || []).map(l => l.name).concat(entries.filter(e => e.type === 'income').map(e => e.party)).filter(Boolean))].slice(0, 300).map(p => `<option>${A.esc(p)}</option>`).join('')}</datalist>
      <p class="muted small fin-wide">Records what a client owes, so it shows under "Clients owe". When they pay, press Mark paid: the money is added to the books automatically.</p>
      <div class="fin-actions"><span></span><button type="button" class="btn secondary" data-fin="close">Cancel</button><button class="btn" type="submit">Save invoice</button></div></form>`;
    d.showModal();
  }
  function markPaid(id){
    const inv = invoices.find(i => i.id === id); if(!inv) return;
    const d = $('#fin-dialog');
    d.innerHTML = `<form method="dialog" class="fin-form" id="fin-paid-form" data-inv="${inv.id}"><h2>${A.esc(inv.number)} paid</h2>
      <p class="muted fin-wide">${A.esc(inv.client)} · ${rwf(inv.amount_rwf)} RWF. This adds the payment to the books.</p>
      <label>Paid into<select name="account_id">${accounts.map(a => `<option value="${a.id}">${A.esc(a.name)}</option>`).join('')}</select></label>
      <label>Date<input type="date" name="happened_on" value="${today()}"></label>
      <label class="fin-wide">Category<select name="category_id">${categories.filter(c => c.type === 'income').map(c => `<option value="${c.id}">${A.esc(c.name)}</option>`).join('')}</select></label>
      <div class="fin-actions"><span></span><button type="button" class="btn secondary" data-fin="close">Cancel</button><button class="btn" type="submit">Record payment</button></div></form>`;
    d.showModal();
  }
  async function paidSubmit(f){
    const inv = invoices.find(i => i.id === Number(f.dataset.inv)); if(!inv) return;
    try{
      upsert(await db.save({type:'income', amount_rwf:inv.amount_rwf, happened_on:f.happened_on.value, account_id:f.account_id.value, category_id:f.category_id.value, party:inv.client, note:'Invoice ' + inv.number + (inv.description ? ': ' + inv.description : ''), invoice_id:inv.id, source:'dashboard'}));
      Object.assign(inv, await db.saveInvoice({id:inv.id, status:'paid'})); $('#fin-dialog').close(); render(); A.toast(inv.number + ' marked paid and added to the books');
    }catch(err){ A.fail(err); }
  }
  function exportCsv(){
    const r = range(period), cell = v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
    const lines = [['Date','Type','Amount RWF','Account','To account','Category','Who','Note','Source','By'].join(',')].concat(
      entries.filter(e => inRange(e, r)).map(e => [e.happened_on, TYPE[e.type], e.amount_rwf, accName(e.account_id), e.to_account_id ? accName(e.to_account_id) : '', e.category_id ? cat(e.category_id).name : '', e.party, e.note, SRC[e.source], e.created_by_name].map(cell).join(',')));
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + lines.join('\n')], {type:'text/csv'})); a.download = 'crt-books-' + r[2].replace(/\s+/g, '-').toLowerCase() + '.csv'; a.click();
  }

  // ---------------------------------------------------------------- quick entry (same parser as WhatsApp)
  let pending = null;
  function preview(){
    const v = $('#fin-quick').value.trim(), box = $('#fin-quick-preview');
    if(!v){ box.hidden = true; pending = null; return; }
    const p = window.crtParseMoney(v, {categories, defaultAccount: accounts[0] && accounts[0].id});
    pending = p.missing.length ? null : p;
    box.hidden = false;
    box.innerHTML = p.missing.length ? `<span class="muted">Add ${p.missing.map(m => m === 'type' ? 'whether money came in or went out (e.g. "paid" or "received")' : 'an amount').join(' and ')}.</span>`
      : `<b class="fin-amt ${p.type}">${TYPE[p.type]} ${rwf(p.amount_rwf)} RWF</b> · ${p.type === 'transfer' ? A.esc(accName(p.account_id)) + ' → ' + A.esc(accName(p.to_account_id)) : A.esc(cat(p.category_id).name) + ' · ' + A.esc(accName(p.account_id))}${p.party ? ' · ' + A.esc(p.party) : ''} · ${new Date(p.happened_on + 'T00:00').toLocaleDateString('en-GB', {day:'numeric', month:'short'})} <button type="button" class="link" data-fin="adjust">Adjust</button>`;
  }
  async function quickSave(){
    if(!pending){ preview(); A.toast('Not sure what to record yet; see the hint'); return; }
    const row = {type:pending.type, amount_rwf:pending.amount_rwf, happened_on:pending.happened_on, account_id:pending.account_id, to_account_id:pending.to_account_id,
      category_id:pending.category_id, party:pending.party || null, note:pending.note, raw_message:$('#fin-quick').value.trim().slice(0, 1000), source:'dashboard'};
    try{ upsert(await db.save(row)); $('#fin-quick').value = ''; preview(); A.toast('Recorded'); }catch(err){ A.fail(err); }
  }

  // ---------------------------------------------------------------- events
  async function open(){
    if(!A) return;
    if(!A.isAdmin()){ $('#tab-finance').innerHTML = '<div class="page-head"><div><h1>Finance</h1><p class="muted">Only admins can see the books.</p></div></div>'; return; }
    if(!loaded){
      shell();
      try{ await db.load(); loaded = true; sortEntries(); render(); db.live(); }
      catch(err){ $('#tab-finance').insertAdjacentHTML('beforeend', '<div class="panel"><p><b>The books are not set up yet.</b> Run <code>admin/finance-setup.sql</code> in Supabase (see FINANCE-SETUP.txt).</p></div>'); A.fail(err); }
    }
  }
  const ready = () => { A = window.CRT_ADMIN; if(!A.isAdmin()) $$('[data-admin-only]').forEach(el => el.hidden = true); };
  if(window.CRT_ADMIN) ready(); else document.addEventListener('crt:ready', ready);
  document.addEventListener('crt:tab', e => { if(e.detail === 'finance') open(); });
  document.addEventListener('input', e => {
    if(e.target.id === 'fin-quick') preview();
    if(e.target.id === 'fin-f-q'){ q = e.target.value; render(); }
  });
  document.addEventListener('change', e => {
    if(e.target.id === 'fin-f-type'){ fType = e.target.value; render(); }
    if(e.target.id === 'fin-f-acc'){ fAcc = e.target.value; render(); }
    if(e.target.id === 'fin-f-cat'){ fCat = e.target.value; render(); }
  });
  document.addEventListener('submit', async e => {
    if(e.target.id === 'fin-quick-form'){ e.preventDefault(); quickSave(); }
    if(e.target.id === 'fin-form'){ e.preventDefault(); submitForm(); }
    if(e.target.id === 'fin-paid-form'){ e.preventDefault(); paidSubmit(e.target); }
    if(e.target.id === 'fin-inv-form'){
      e.preventDefault(); const f = e.target, amt = Number(String(f.amount_rwf.value).replace(/[^\d]/g, ''));
      if(!(amt > 0)){ A.toast('Enter an amount'); return; }
      try{ const row = await db.saveInvoice({number:f.number.value.trim(), client:f.client.value.trim(), amount_rwf:amt, due_on:f.due_on.value || null, description:f.description.value.trim() || null, status:'sent', issued_on:today()});
        if(!invoices.some(i => i.id === row.id)) invoices.unshift(row); $('#fin-dialog').close(); render(); A.toast('Invoice saved'); }catch(err){ A.fail(err); }
    }
  });
  document.addEventListener('click', async e => {
    const per = e.target.closest('[data-fin-period]'); if(per){ period = per.dataset.finPeriod; render(); return; }
    const ty = e.target.closest('[data-fin-type]'); if(ty){ setType(ty.dataset.finType); return; }
    const row = e.target.closest('tr[data-fin-id]'); if(row){ entryForm(entries.find(x => String(x.id) === row.dataset.finId)); return; }
    const t = e.target.closest('[data-fin]'); if(!t) return;
    const a = t.dataset.fin;
    if(a === 'new') entryForm();
    else if(a === 'adjust' && pending) entryForm({...pending, id: undefined});
    else if(a === 'close') $('#fin-dialog').close();
    else if(a === 'export') exportCsv();
    else if(a === 'new-invoice') invoiceForm();
    else if(a === 'paid') markPaid(Number(t.dataset.inv));
    else if(a === 'delete' && editing){ if(!confirm('Delete this entry? It is also removed from the Google Sheet.')) return; try{ await db.remove(editing.id); entries = entries.filter(x => x.id !== editing.id); $('#fin-dialog').close(); render(); A.toast('Deleted'); }catch(err){ A.fail(err); } }
  });
})();
