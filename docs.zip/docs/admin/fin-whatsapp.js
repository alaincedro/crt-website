/* CRT admin: Finance → WhatsApp. Who may record money by WhatsApp, the evening reminder, the keys (main admin),
   and the webhook details to paste into Meta. Talks to the "finance-whatsapp" server function and the
   fin_whatsapp_senders table (admins only). Receipts in the ledger open through short-lived links. */
(function(){
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  let A = null, esc = s => String(s == null ? '' : s), senders = [], team = [], cfg = null, built = false;
  async function fn(body){
    const {data, error} = await A.sb.functions.invoke('finance-whatsapp', {body});
    if(error){ let d = {}; try{ d = await error.context.json(); }catch(e){} const x = new Error(d.error || error.message); x.code = d.error; x.info = d; throw x; }
    return data;
  }
  const owner = () => A && A.me && A.me.role === 'owner';
  async function load(){
    const [s, t] = await Promise.all([A.sb.from('fin_whatsapp_senders').select('*').order('name'), A.sb.from('team').select('user_id,name,phone').order('name')]);
    senders = s.data || []; team = t.data || [];
    if(owner()){ try{ cfg = await fn({action: 'status'}); }catch(e){ cfg = {error: e.code || e.message}; } }
    paint();
  }
  function paint(){
    const box = $('#fin-wa'); if(!box) return;
    const set = (cfg && cfg.set) || {}, ready = set.WHATSAPP_TOKEN && set.WHATSAPP_PHONE_NUMBER_ID && set.WHATSAPP_APP_SECRET;
    box.innerHTML = `<div class="fin-ledger-head"><h2>WhatsApp books ${ready ? '<span class="role-chip is-on">Connected</span>' : '<span class="role-chip is-off">Not connected</span>'}</h2></div>
      <p class="muted small">People on this list can record money by sending a WhatsApp message to the CRT business number: “paid 50k fuel momo”, a receipt photo, a forwarded MoMo message, “Inka owes 400k”. Send <b>help</b> there for everything it understands.</p>
      <table class="leads-table fin-table"><thead><tr><th>Name</th><th>WhatsApp number</th><th>Evening reminder</th><th></th></tr></thead><tbody>
      ${senders.map(s => `<tr data-phone="${esc(s.phone)}"><td>${esc(s.name)}</td><td>+${esc(s.phone)}</td><td><label class="cm-toggle"><input type="checkbox" data-wa="remind" ${s.remind !== false ? 'checked' : ''}><span>19:00 if nothing recorded</span></label></td><td class="num"><button class="link danger" data-wa="del">Remove</button></td></tr>`).join('') || '<tr><td colspan="4" class="muted small">Nobody yet. Add yourself below.</td></tr>'}
      </tbody></table>
      <form class="mb-add fin-wa-add" id="fin-wa-add"><select name="who" aria-label="Team member"><option value="">Team member…</option>${team.map(t => `<option value="${esc(t.user_id)}" data-phone="${esc((t.phone || '').replace(/\D/g, ''))}">${esc(t.name)}</option>`).join('')}</select>
        <input name="phone" inputmode="tel" placeholder="WhatsApp number, e.g. +250 788 123 456" required><button class="btn small">Add</button></form>
      ${owner() ? keys(set) : ''}`;
    $('#fin-wa-add').onsubmit = add;
    const sel = $('#fin-wa-add [name=who]'); sel.onchange = () => { const o = sel.selectedOptions[0]; if(o && o.dataset.phone) $('#fin-wa-add [name=phone]').value = '+' + o.dataset.phone; };
    const kf = $('#fin-wa-keys'); if(kf) kf.onsubmit = saveKeys;
  }
  function keys(set){
    const c = cfg || {};
    const row = (k, label, secret, hint) => `<div class="field"><label for="w-${k}">${label} ${set[k] ? '<span class="role-chip is-on">Saved</span>' : ''}</label><input id="w-${k}" name="${k}" ${secret ? 'type="password"' : ''} autocomplete="off" spellcheck="false" placeholder="${set[k] ? '•••••••• (saved, type to replace)' : ''}">${hint ? `<small class="muted">${hint}</small>` : ''}</div>`;
    return `<h3 class="fin-wa-h">Connection (main admin)</h3>
      <form id="fin-wa-keys" class="conn-set">
        ${row('WHATSAPP_PHONE_NUMBER_ID', 'Phone number ID', false, 'Meta → your app → WhatsApp → API setup.')}
        ${row('WHATSAPP_TOKEN', 'Permanent access token', true, 'Meta Business settings → System users → Generate token (whatsapp_business_messaging).')}
        ${row('WHATSAPP_APP_SECRET', 'App secret', true, 'Meta → your app → Settings → Basic. Proves messages really come from WhatsApp.')}
        ${row('GEMINI_API_KEY', 'Gemini key (FREE): reads receipt photos and messy messages', true, 'aistudio.google.com → Get API key (no card needed). Free tier: Google may use these messages to improve its models.')}
        ${row('ANTHROPIC_API_KEY', 'Claude key (optional, PAID per use): used instead of Gemini if set', true, 'Leave empty to stay free.')}
        <div class="row-end"><button class="btn small">Save keys</button></div></form>
      ${c.webhook ? `<div class="fin-wa-hook"><p class="muted small">Then in Meta → your app → WhatsApp → Configuration → Webhook, paste these two and subscribe to <b>messages</b>:</p>
        <label>Callback URL<input readonly value="${esc(c.webhook)}" onclick="this.select()"></label><label>Verify token<input readonly value="${esc(c.verify_token)}" onclick="this.select()"></label></div>` : `<p class="muted small">Couldn’t reach the WhatsApp function${c.error ? ' (' + esc(c.error) + ')' : ''}.</p>`}`;
  }
  async function add(e){
    e.preventDefault(); const f = e.target, who = f.who.value, phone = f.phone.value.replace(/\D/g, '');
    const name = who ? (team.find(t => t.user_id === who) || {}).name : '';
    if(!who){ A.toast('Choose the team member'); return; }
    if(phone.length < 10){ A.toast('Write the full number with the country code, like +250 788 123 456'); return; }
    const {error} = await A.sb.from('fin_whatsapp_senders').upsert({phone, name: name || 'Team member', user_id: who, remind: true});
    if(error){ A.toast(error.message); return; } A.toast(name + ' can now record money by WhatsApp'); load();
  }
  async function saveKeys(e){
    e.preventDefault(); const values = {}; [...e.target.querySelectorAll('input')].forEach(i => { if(i.value.trim()) values[i.name] = i.value.trim(); });
    if(!Object.keys(values).length){ A.toast('Nothing new to save'); return; }
    try{ cfg = await fn({action: 'save', values}); A.toast('Keys saved'); paint(); }catch(x){ A.toast('Couldn’t save: ' + (x.code || x.message)); }
  }
  document.addEventListener('click', async e => {
    const r = e.target.closest('[data-receipt]');
    if(r){ e.preventDefault(); try{ const d = await fn({action: 'receipt', path: r.dataset.receipt}); window.open(d.url, '_blank', 'noopener'); }catch(x){ A.toast('Only the main admin can open receipts for now'); } return; }
    const d = e.target.closest('[data-wa="del"]');
    if(d){ const phone = d.closest('tr').dataset.phone; if(!confirm('Remove +' + phone + ' from WhatsApp books?')) return; await A.sb.from('fin_whatsapp_senders').delete().eq('phone', phone); load(); }
  });
  document.addEventListener('change', async e => {
    const t = e.target.closest('[data-wa="remind"]'); if(!t) return;
    const phone = t.closest('tr').dataset.phone; const {error} = await A.sb.from('fin_whatsapp_senders').update({remind: t.checked}).eq('phone', phone);
    A.toast(error ? error.message : (t.checked ? 'Evening reminder on' : 'Evening reminder off'));
  });
  function mount(){
    if(built || !A || !A.isAdmin()) return;
    const anchor = document.querySelector('#tab-finance #fin-dialog'); if(!anchor) return;
    built = true; anchor.insertAdjacentHTML('beforebegin', '<div class="panel" id="fin-wa"></div>');
    if(A.LIVE) load(); else $('#fin-wa').innerHTML = '<h2>WhatsApp books</h2><p class="muted small">Not available in demo mode.</p>';
  }
  const ready = () => { A = window.CRT_ADMIN; esc = A.esc; mount(); };
  document.addEventListener('crt:tab', e => { if(e.detail === 'finance') setTimeout(mount, 300); });
  if(window.CRT_ADMIN) ready(); else document.addEventListener('crt:ready', ready);
})();
