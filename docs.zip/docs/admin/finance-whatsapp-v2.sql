-- CRT finance on WhatsApp, version 2: receipts, debts, reminders, managed from the dashboard.
-- Run once in Supabase → SQL Editor. Safe to run again. Needs finance-setup.sql (already run).
create extension if not exists pg_net;
create extension if not exists pg_cron;

-- receipts sent as photos or PDFs are kept with their entry (private; opened through short-lived links)
alter table public.fin_entries add column if not exists receipt_path text;
insert into storage.buckets (id, name, public, file_size_limit) values ('receipts', 'receipts', false, 15728640)
on conflict (id) do update set public = false;

-- who may record, and the evening reminder
alter table public.fin_whatsapp_senders add column if not exists remind boolean not null default true;
alter table public.fin_whatsapp_senders add column if not exists last_message_at timestamptz;

-- the reminders run inside Supabase (no outside scheduler): 19:00 Kigali every day, and Monday 08:00 for the week's summary
create or replace function public.fin_whatsapp_task(task text) returns void
language plpgsql security definer set search_path = public as $$
declare key text;
begin
  select value into key from public.app_secrets where name = 'FIN_CRON_SECRET';
  if key is null then return; end if;
  perform net.http_post(url := 'https://xwymonxbaokdjhywqydu.supabase.co/functions/v1/finance-whatsapp',
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-crt-cron', key),
    body := jsonb_build_object('task', task));
end $$;
revoke all on function public.fin_whatsapp_task(text) from public, anon, authenticated;

select cron.unschedule(jobid) from cron.job where jobname in ('crt-fin-reminder', 'crt-fin-weekly');
select cron.schedule('crt-fin-reminder', '0 17 * * *', $$select public.fin_whatsapp_task('reminder')$$);   -- 17:00 UTC = 19:00 Kigali
select cron.schedule('crt-fin-weekly', '0 6 * * 1', $$select public.fin_whatsapp_task('weekly')$$);       -- Monday 08:00 Kigali

select jobname, schedule from cron.job where jobname like 'crt-fin-%';
