// @ts-nocheck
// Supabase Edge Function "finance-whatsapp": record CRT money by sending a WhatsApp message.
//
// It talks back in plain words and understands what a message means, not one exact keyword:
//   "paid 50k for fuel"                          → records it, says what it recorded and which account it assumed
//   "got 200,000 from RMB for the shoot"         → money in, matched to RMB's open invoice if there is one
//   "how much did we spend this week?"           → answers from the books
//   "200k Inka"                                  → asks "did it come in or go out?", then books the answer
//   "no, it was cash" · "make it 60k" · "undo"   → fixes or removes the last entry
// Free rules handle most messages; the free Gemini key (or Claude, if its paid key is set) reads the rest.
// Needs the column added by admin/finance-whatsapp-v3.sql to remember the question it asked.
//
// The entry lands in Supabase (so the dashboard shows it within a second), and the
// database webhook copies it to the Google Sheet. Full setup: admin/FINANCE-SETUP.txt
//
// Keys: entered by the main admin in the dashboard (Finance → WhatsApp), kept in the locked table app_secrets.
// (Supabase → Edge Functions → Secrets with the same names also work.)
//   WHATSAPP_TOKEN            permanent access token of the Meta app (System user token)
//   WHATSAPP_PHONE_NUMBER_ID  the phone number ID from Meta → WhatsApp → API setup
//   WHATSAPP_VERIFY_TOKEN     any long random text; paste the same text in Meta's webhook settings
//   WHATSAPP_APP_SECRET       Meta app → Settings → Basic → App secret (proves messages come from Meta)
//   GEMINI_API_KEY            optional, FREE (Google AI Studio free tier): reads receipt photos and messages the rules don't understand
//   ANTHROPIC_API_KEY         optional, paid per use: used instead of Gemini when set (claude-haiku-5-5 for text, claude-sonnet-5-5 for receipts)
// SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are provided by Supabase automatically.
// Deploy with "Verify JWT" switched OFF (Meta cannot send a Supabase login).
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

let SECRETS = {};
const env = (k) => Deno.env.get(k) || SECRETS[k] || "";
const sb = createClient(Deno.env.get("SUPABASE_URL"), Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"), { auth: { persistSession: false } });
const FIN_KEYS = ["WHATSAPP_TOKEN", "WHATSAPP_PHONE_NUMBER_ID", "WHATSAPP_APP_SECRET", "WHATSAPP_VERIFY_TOKEN", "ANTHROPIC_API_KEY", "GEMINI_API_KEY", "FIN_CRON_SECRET"];
async function loadSecrets() {
  const { data } = await sb.from("app_secrets").select("name,value").in("name", FIN_KEYS);
  SECRETS = Object.fromEntries((data || []).map((r) => [r.name, r.value]));
}
const rwf = (n) => Number(n || 0).toLocaleString("en-US");
const TYPE = { income: "Money in", expense: "Money out", transfer: "Transfer" };
const tz = "Africa/Kigali";
const todayKigali = () => new Date(new Date().toLocaleString("en-US", { timeZone: tz }));

// ---------------------------------------------------------------- parser (same as admin/fin-parse.js)
const parse = (() => {
  const MONTHS = {jan:0,feb:1,mar:2,apr:3,may:4,jun:5,jul:6,aug:7,sep:8,sept:8,oct:9,nov:10,dec:11};
  const ACCOUNT_WORDS = [
    ['momo', /\b(momo|mtn|mobile money|airtel( money)?)\b/i],
    ['bank', /\b(bank|bk|equity|i&m|im bank|access bank|ecobank|cogebanque|bpr|kcb|ncba|visa)\b/i],
    ['cash', /\b(cash|hand|in hand)\b/i],
  ];
  const INCOME = /^\s*\+|\b(received|receive|got|income|deposit from|payment from|paid by|client paid|sold|invoice paid|advance from|deposit for)\b/i;
  const EXPENSE = /^\s*-|\b(paid|pay|spent|spend|bought|buy|expense|cost|costs|purchase|purchased|gave|sent to|salary)\b/i;
  const TRANSFER = /\b(moved|move|transfer|transferred|withdraw|withdrew|withdrawal|topped up|top up)\b/i;

  const iso = d => new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())).toISOString().slice(0, 10);

  function amountOf(text){
    // 50k, 1.2m, 400,000, 400 000, 25000rwf, rwf 25,000
    const m = text.match(/(?:rwf|frw|rf)?\s*(\d{1,3}(?:[ ,.]\d{3})+|\d+(?:\.\d+)?)\s*(k|m|million|thousand|rwf|frw|rf)?\b/i);
    if(!m) return null;
    let raw = m[1], unit = (m[2] || '').toLowerCase();
    let n = /^\d{1,3}([ ,.]\d{3})+$/.test(raw) && !(unit === 'k' || unit === 'm') ? Number(raw.replace(/[ ,.]/g, '')) : Number(raw.replace(/[ ,]/g, ''));
    if(unit === 'k' || unit === 'thousand') n *= 1e3;
    if(unit === 'm' || unit === 'million') n *= 1e6;
    n = Math.round(n);
    return n > 0 ? {value: n, text: m[0]} : null;
  }

  function dateOf(text, now){
    now = now || new Date();
    const t = text.toLowerCase();
    if(/\byesterday\b/.test(t)){ const d = new Date(now); d.setDate(d.getDate() - 1); return iso(d); }
    let m = t.match(/\b(\d{1,2})[\/\-](\d{1,2})(?:[\/\-](\d{2,4}))?\b/);
    if(m){ const y = m[3] ? (m[3].length === 2 ? 2000 + Number(m[3]) : Number(m[3])) : now.getFullYear(); const d = new Date(y, Number(m[2]) - 1, Number(m[1])); if(!isNaN(d)) return iso(d); }
    m = t.match(/\b(\d{1,2})(?:st|nd|rd|th)?\s+(jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*\b/) || t.match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*\s+(\d{1,2})\b/);
    if(m){ const day = Number(/\d/.test(m[1]) ? m[1] : m[2]), mon = MONTHS[(/\d/.test(m[1]) ? m[2] : m[1]).slice(0, 4).replace(/t$/, 't')] ?? MONTHS[(/\d/.test(m[1]) ? m[2] : m[1]).slice(0, 3)];
      const d = new Date(now.getFullYear(), mon, day); if(d > now){ if(d - now < 60 * 864e5) return iso(now); d.setFullYear(d.getFullYear() - 1); } return iso(d); }
    return iso(now);
  }

  function accountsIn(text){
    const hits = [];
    ACCOUNT_WORDS.forEach(([id, re]) => { const m = text.match(re); if(m) hits.push({id, at: m.index}); });
    return hits.sort((a, b) => a.at - b.at).map(h => h.id);
  }

  function categoryOf(text, type, categories){
    const t = ' ' + text.toLowerCase().replace(/[^a-z0-9&' ]+/g, ' ') + ' ';
    let best = null, bestLen = 0;
    (categories || []).forEach(c => {
      if(type && c.type !== type) return;
      String(c.keywords || '').split(',').map(k => k.trim().toLowerCase()).filter(Boolean).forEach(k => {
        if(t.includes(' ' + k + ' ') || t.includes(' ' + k + 's ')){ if(k.length > bestLen){ best = c; bestLen = k.length; } }
      });
    });
    return best;
  }

  function partyOf(text, type){
    const re = type === 'income' ? /\b(?:from|by)\s+(.+?)(?=\s+(?:for|via|on|to|in|into|momo|mtn|bank|cash|yesterday|today)\b|[.,;]|$)/i
                                 : /\b(?:to|at)\s+(.+?)(?=\s+(?:for|via|on|from|momo|mtn|bank|cash|yesterday|today)\b|[.,;]|$)/i;
    let m = text.match(re);
    // "gave Eric 90k", "paid Aline 50k for editing": a capitalised name straight after the verb
    if(!m && type === 'expense') m = text.match(/\b(?:gave|paid|pay|sent|send)\s+([A-Z][\w'’-]+(?:\s+[A-Z][\w'’-]+)?)(?=\s)/);
    if(!m) return '';
    const p = m[1].trim();
    if(/^(momo|mtn|bank|cash|the bank|my|our)\b/i.test(p) || /^\d/.test(p)) return '';
    return p.slice(0, 120);
  }

  function parse(text, opts){
    opts = opts || {};
    const cats = opts.categories || [], now = opts.now || new Date(), defAcc = opts.defaultAccount || 'momo';
    const clean = String(text || '').trim().replace(/\s+/g, ' ');
    const out = {type: null, amount_rwf: null, account_id: null, to_account_id: null, category_id: null, party: '', happened_on: dateOf(clean, now), note: clean.slice(0, 500), missing: []};
    const amt = amountOf(clean.replace(/\b\d{1,2}[\/\-]\d{1,2}([\/\-]\d{2,4})?\b/g, ' '));
    if(amt) out.amount_rwf = amt.value; else out.missing.push('amount');
    const accs = accountsIn(clean);
    if(TRANSFER.test(clean) && accs.length >= 2){
      out.type = 'transfer'; out.account_id = accs[0]; out.to_account_id = accs[1];
      if(/\bfrom\b/i.test(clean) && /\bto\b/i.test(clean)){
        const f = clean.toLowerCase().search(/\bfrom\b/), tIdx = clean.toLowerCase().search(/\bto\b/);
        if(tIdx < f){ out.account_id = accs[1]; out.to_account_id = accs[0]; }
      }
      return out;
    }
    if(TRANSFER.test(clean) && accs.length === 1 && /withdr/i.test(clean)){ out.type = 'transfer'; out.account_id = accs[0]; out.to_account_id = accs[0] === 'cash' ? defAcc : 'cash'; return out; }
    if(INCOME.test(clean)) out.type = 'income';
    else if(EXPENSE.test(clean)) out.type = 'expense';
    const cat = categoryOf(clean, out.type, cats);
    if(!out.type && cat) out.type = cat.type;
    if(!out.type) out.missing.push('type');
    if(out.type){
      const c = cat && cat.type === out.type ? cat : null;
      out.category_id = c ? c.id : (out.type === 'income' ? 'other-income' : 'other-expense');
      out.party = partyOf(clean, out.type);
    }
    out.account_id = accs[0] || defAcc;
    return out;
  }
  return parse;
})();

// ---------------------------------------------------------------- helpers
async function hmacOk(req, body) {
  const secret = env("WHATSAPP_APP_SECRET");
  if (!secret) return false; // fail closed: without the app secret we cannot prove a message came from Meta
  const sig = (req.headers.get("x-hub-signature-256") || "").replace("sha256=", "");
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const mac = new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(body)));
  const hex = [...mac].map((b) => b.toString(16).padStart(2, "0")).join("");
  if (hex.length !== sig.length) return false;
  let diff = 0; for (let i = 0; i < hex.length; i++) diff |= hex.charCodeAt(i) ^ sig.charCodeAt(i);
  return diff === 0;
}

async function reply(to, text) {
  await fetch(`https://graph.facebook.com/v21.0/${env("WHATSAPP_PHONE_NUMBER_ID")}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${env("WHATSAPP_TOKEN")}`, "Content-Type": "application/json" },
    body: JSON.stringify({ messaging_product: "whatsapp", to, type: "text", text: { body: text.slice(0, 4000) } }),
  });
}

// Free first: Gemini (Google AI Studio free tier). Claude is used instead only if its paid key is set.
function readerPrompt(accounts, categories) {
  const today = todayKigali().toISOString().slice(0, 10);
  return "You turn one bookkeeping message from a Rwandan creative agency into JSON. It may be English, Kinyarwanda or French, or a forwarded MTN MoMo / Airtel Money / bank SMS, or a photo/PDF of a receipt or invoice. Amounts are in RWF (50k = 50000, 1.2m = 1200000). For a forwarded MoMo message, money received is income and money sent or paid is expense; the account is momo. A receipt is an expense unless it clearly shows money paid to us. " +
    "Reply with JSON only: {\"type\":\"income|expense|transfer|unknown\",\"amount_rwf\":number|null,\"account_id\":string,\"to_account_id\":string|null,\"category_id\":string|null,\"party\":string|null,\"happened_on\":\"YYYY-MM-DD\"}. " +
    `Today is ${today}. Accounts: ${accounts.map((a) => a.id + " (" + a.name + ")").join(", ")}. ` +
    `Categories: ${categories.map((c) => c.id + " (" + c.type + ": " + c.name + ")").join(", ")}. ` +
    "If it is not about money moving, use type unknown. Never invent an amount.";
}
function tidy(j, accounts, categories) {
  const today = todayKigali().toISOString().slice(0, 10);
  if (!j || !["income", "expense", "transfer"].includes(j.type) || !(j.amount_rwf > 0)) return null;
  if (!accounts.some((a) => a.id === j.account_id)) j.account_id = accounts[0].id;
  if (j.type === "transfer" && !accounts.some((a) => a.id === j.to_account_id)) return null;
  if (j.type !== "transfer" && !categories.some((c) => c.id === j.category_id && c.type === j.type)) j.category_id = j.type === "income" ? "other-income" : "other-expense";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(j.happened_on || "")) j.happened_on = today;
  return { ...j, amount_rwf: Math.round(j.amount_rwf), to_account_id: j.type === "transfer" ? j.to_account_id : null, category_id: j.type === "transfer" ? null : j.category_id, party: j.party || "", missing: [] };
}
async function askGemini(text, accounts, categories, img) {
  const key = env("GEMINI_API_KEY"); if (!key) return null;
  const model = Deno.env.get("GEMINI_MODEL") || "gemini-2.5-flash";
  const parts = [{ text: readerPrompt(accounts, categories) + "\n\nMessage: " + (text || (img ? "(receipt attached)" : "")) }];
  if (img) parts.push({ inline_data: { mime_type: img.mime, data: img.data } });
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ contents: [{ role: "user", parts }], generationConfig: { responseMimeType: "application/json", temperature: 0 } }),
  });
  if (!r.ok) { console.error("gemini", r.status, (await r.text()).slice(0, 300)); return null; }
  const d = await r.json();
  try { return tidy(JSON.parse((d.candidates?.[0]?.content?.parts?.[0]?.text || "").replace(/^```(json)?|```$/g, "").trim()), accounts, categories); } catch { return null; }
}
const canRead = () => !!(env("ANTHROPIC_API_KEY") || env("GEMINI_API_KEY"));
async function askReader(text, accounts, categories, img) {
  if (env("ANTHROPIC_API_KEY")) return askClaude(text, accounts, categories, img);
  return askGemini(text, accounts, categories, img);
}

async function askClaude(text, accounts, categories, img) {
  const key = env("ANTHROPIC_API_KEY");
  if (!key) return null;
  const image = img ? (/pdf/.test(img.mime) ? { type: "document", source: { type: "base64", media_type: "application/pdf", data: img.data } } : { type: "image", source: { type: "base64", media_type: img.mime, data: img.data } }) : null;
  const today = todayKigali().toISOString().slice(0, 10);
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({
      model: image ? "claude-sonnet-5-5" : "claude-haiku-5-5",
      max_tokens: 300,
      system: readerPrompt(accounts, categories),
      messages: [{ role: "user", content: image ? [image, { type: "text", text: "This is a receipt, invoice or payment screenshot. Book it. " + (text || "") }] : text }],
    }),
  });
  if (!r.ok) return null;
  const d = await r.json();
  try { return tidy(JSON.parse((d.content?.[0]?.text || "").replace(/^```(json)?|```$/g, "").trim()), accounts, categories); } catch { return null; }
}

// ---------------------------------------------------------------- the assistant: understand a message, act, reply in plain words
// 1. If the bot asked a question last time (missing amount, money in or out…), the message is read as the answer.
// 2. Local rules understand most messages for free and instantly: records, questions, corrections, debts, small talk.
// 3. When the rules aren't sure, the free Gemini key (or Claude, if its paid key is set) reads the message.
//    The AI only classifies; every number in a reply comes from the books, and an amount the message doesn't contain is never booked.
const HELP = "Hi! I'm the CRT books assistant 👋 Just talk to me in your own words (English, Kinyarwanda or French).\n\n" +
  "*Record money*\n• paid 50k for fuel\n• got 200,000 from RMB for the shoot, bank\n• moved 100k from momo to cash\n📷 Or send a receipt photo, or forward a MoMo SMS.\n\n" +
  "*Ask me*\n• how much did we spend this week?\n• what did RMB pay us this month?\n• balance · who owes us? · profit last month\n\n" +
  "*Fix things*\n• make it 60k · it was cash · it was yesterday · undo\n\n" +
  "*Debts*\n• Inka owes 400k for the menu shoot\n• remind Inka";

const dayIso = (d) => d.toISOString().slice(0, 10);
function kigaliYMD() { const d = todayKigali(); return [d.getFullYear(), d.getMonth(), d.getDate()]; }
const U = (y, m, d) => new Date(Date.UTC(y, m, d));
const MONTH_RE = /\b(january|february|march|april|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sept?|oct|nov|dec|(?:in|for|of)\s+may)\b/;
const MONTH_IX = { jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5, jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11 };

// "this week", "last month", "in October", "last 7 days", "yesterday" → {from, to, label, now}
function periodOf(text, def = "this_month") {
  const k = " " + String(text || "").toLowerCase() + " ";
  const [y, m, d] = kigaliYMD(), wd = (U(y, m, d).getUTCDay() + 6) % 7;
  const P = (a, b, label, now = false) => ({ from: dayIso(a), to: dayIso(b), label, now });
  let x;
  if (/\b(today|uyu munsi|leo|aujourd'?hui)\b/.test(k)) return P(U(y, m, d), U(y, m, d), "today", true);
  if (/\b(yesterday|ejo|hier)\b/.test(k)) return P(U(y, m, d - 1), U(y, m, d - 1), "yesterday");
  if ((x = k.match(/\b(?:last|past|previous)\s+(\d{1,3})\s+days?\b/))) return P(U(y, m, d - Number(x[1]) + 1), U(y, m, d), `in the last ${x[1]} days`, true);
  if (/\b(last|previous|past)\s+week\b|\bicyumweru gishize\b/.test(k)) return P(U(y, m, d - wd - 7), U(y, m, d - wd - 1), "last week");
  if (/\bweek\b|\bicyumweru\b|\bsemaine\b/.test(k)) return P(U(y, m, d - wd), U(y, m, d), "this week", true);
  if (/\b(last|previous|past)\s+month\b|\bukwezi gushize\b|\bmois dernier\b/.test(k)) return P(U(y, m - 1, 1), U(y, m, 0), "last month (" + U(y, m - 1, 1).toLocaleDateString("en-GB", { month: "long", timeZone: "UTC" }) + ")");
  if (/\b(last|previous)\s+year\b/.test(k)) return P(U(y - 1, 0, 1), U(y - 1, 11, 31), `in ${y - 1}`);
  if (/\b(this\s+year|so far this year|year to date|ytd)\b/.test(k)) return P(U(y, 0, 1), U(y, m, d), `this year`, true);
  if (/\b(all time|ever|since (we )?start(ed)?|in total|overall)\b/.test(k)) return P(U(2000, 0, 1), U(y, m, d), "so far", true);
  if ((x = k.match(MONTH_RE))) {
    const mi = MONTH_IX[x[1].replace(/^(in|for|of)\s+/, "").slice(0, 3)];
    const yy = mi > m ? y - 1 : y;
    return P(U(yy, mi, 1), mi === m && yy === y ? U(y, m, d) : U(yy, mi + 1, 0), "in " + U(yy, mi, 1).toLocaleDateString("en-GB", { month: "long", year: yy === y ? undefined : "numeric", timeZone: "UTC" }), mi === m && yy === y);
  }
  if (/\b(this\s+)?month\b|\bukwezi\b|\bce mois\b/.test(k) || def === "this_month") return P(U(y, m, 1), U(y, m, d), "this month", true);
  if (def === "this_week") return P(U(y, m, d - wd), U(y, m, d), "this week", true);
  return P(U(y, m, d), U(y, m, d), "today", true);
}
// the same, from the AI's period word
function periodFromWord(w) {
  w = String(w || "").toLowerCase().replace(/_/g, " ");
  if (/^\d{4}-\d{2}$/.test(w)) { const [yy, mm] = w.split("-").map(Number); const [y, m, d] = kigaliYMD(); const cur = yy === y && mm - 1 === m;
    return { from: dayIso(U(yy, mm - 1, 1)), to: dayIso(cur ? U(y, m, d) : U(yy, mm, 0)), label: "in " + U(yy, mm - 1, 1).toLocaleDateString("en-GB", { month: "long", year: yy === y ? undefined : "numeric", timeZone: "UTC" }), now: cur }; }
  if (w === "all") w = "all time";
  return periodOf(w, "this_month");
}

const dateWord = (iso) => {
  const [y, m, d] = kigaliYMD();
  if (iso === dayIso(U(y, m, d))) return "today";
  if (iso === dayIso(U(y, m, d - 1))) return "yesterday";
  return "on " + new Date(iso + "T00:00:00Z").toLocaleDateString("en-GB", { day: "numeric", month: "short", timeZone: "UTC" });
};
const hasDateWords = (t) => /\b(today|yesterday|ejo|hier|\d{1,2}[\/\-]\d{1,2}([\/\-]\d{2,4})?|\d{1,2}(st|nd|rd|th)?\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)|(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+\d{1,2})\b/i.test(t);
const first = (n) => String(n || "").trim().split(/\s+/)[0] || "";

// every amount written in a message (to check the AI never books a number that isn't there)
function amountsIn(text) {
  const out = []; let s = String(text || "").replace(/\b\d{1,2}[\/\-]\d{1,2}([\/\-]\d{2,4})?\b/g, " ");
  for (let i = 0; i < 6; i++) { const p = parse(s, { categories: [] }); if (!p.amount_rwf) break; out.push(p.amount_rwf);
    const m = s.match(/(?:rwf|frw|rf)?\s*(\d{1,3}(?:[ ,.]\d{3})+|\d+(?:\.\d+)?)\s*(k|m|million|thousand|rwf|frw|rf)?\b/i); if (!m) break; s = s.slice(0, m.index) + " " + s.slice(m.index + m[0].length); }
  return out;
}
// "ibihumbi 60" (Kinyarwanda) = 60k, "miliyoni 1.2" = 1.2m, "60 mille" (French) = 60k
const normAmounts = (t) => String(t || "").replace(/\b(20\d\d)-(\d{2})-(\d{2})(?:[ T]\d{1,2}:\d{2}(?::\d{2})?)?\b/g, "$3/$2/$1")   // MoMo SMS dates
.replace(/\b(?:ibihumbi|igihumbi)\s+(\d+(?:[.,]\d+)?)\b/gi, "$1k").replace(/\b(?:miliyoni|miriyoni)\s+(\d+(?:[.,]\d+)?)\b/gi, "$1m")
  .replace(/\b(\d+(?:[.,]\d+)?)\s*(?:mille|milles)\b/gi, "$1k").replace(/\b(\d+(?:[.,]\d+)?)\s*(?:millions?)\b/gi, "$1m");
const NUMBER_WORDS = /\b(thousand|million|hundred|ibihumbi|igihumbi|miliyoni|mille|millions?|cent)\b/i;

// ---- conversation memory: what the bot asked last, and the entry it booked last (column fin_whatsapp_senders.state)
let STATE_OK = true;
async function getState(phone) {
  if (!STATE_OK) return {};
  const { data, error } = await sb.from("fin_whatsapp_senders").select("state").eq("phone", phone).maybeSingle();
  if (error) { STATE_OK = false; console.error("state column missing: run finance-whatsapp-v3.sql", error.message); return {}; }
  const s = (data && data.state) || {};
  if (s.pending && Date.now() - (s.pending.at || 0) > 30 * 60e3) delete s.pending;   // a question left unanswered for 30 min is dropped
  return s;
}
async function setState(phone, s) {
  if (!STATE_OK) return;
  const { error } = await sb.from("fin_whatsapp_senders").update({ state: s }).eq("phone", phone);
  if (error) STATE_OK = false;
}

// ---- local understanding (free, instant)
const QUESTION = /\?\s*$|^(how|what|what'?s|whats|which|who|when|where|did|do|does|have|has|is|are|was|were|can you (show|tell|give)|could you (show|tell)|show|list|tell me|give me|send me|check|angahe|combien|ni angahe)\b|\b(angahe|combien)\b/i;
const BARE_QUERY = /^(balance|balances|bal|report|summary|today|week|this week|month|this month|last week|last month|yesterday|owed|owe|unpaid|invoices|debts|profit|p&l|pnl|leo|uyu munsi|icyumweru|ukwezi|status|numbers|books)$/i;
const GREET = /^(hi|hello|hey|hiya|yo|muraho|mwiriwe|mwaramutse|bite|amakuru|bonjour|bonsoir|salut|good (morning|afternoon|evening))\b[\s!.,]*\w*[\s!.]*$/i;
const THANKS = /^(thanks?|thank you|thx|murakoze|merci|ok|okay|okey|cool|great|nice|perfect|good|sawa|ni byiza|👍|🙏|👌|✅)[\s!.]*(so much|a lot|cyane|beaucoup)?[\s!.]*$/i;
const HELPQ = /^(help|menu|start|commands|\?|options)$|\bwhat can you do\b|\bhow (do i|does this|to use)\b|\bhelp me\b/i;
const UNDO = /^(undo|siba|annule[rz]?)\b|\b(undo|delete (that|it|the last( one| entry)?|last entry)|remove (that|it|the last( one| entry)?)|cancel (that|it|the last( one| entry)?)|scrap (that|it)|that was a mistake|ignore (that|the last))\b/i;
const CORRECTION = /^(no|nope|nah|oops|sorry|actually|correction|wait|wrong|oya|non|pardon)\b|\b(make it|change (it|that|the amount|the account|the date|category)( to)?|should (be|have been)|it was|it's|it is|that was|was actually|instead|not \d|fix (it|that|the last))\b/i;
const NEW_RECORD_START = /^\s*(\+|-|paid|pay|spent|bought|received|got|moved|transfer|withdrew|gave|sent)\b/i;
const IN_WORDS = /^\+|\b(in|came in|money in|income|incoming|received|receive|we got|got|they paid( us)?|paid us|deposit|ninjiye|byinjiye|yinjiye|entr[ée]e|reçu)\b/i;
const OUT_WORDS = /^-|\b(out|went out|money out|expense|outgoing|we paid|i paid|paid|spent|cost|bought|yasohotse|byasohotse|sortie|dépense)\b/i;

function categoryLoose(text, type, categories) {
  const strip = String(text || "").toLowerCase().replace(/\b(spen[dt]|spending|paid|pay|paying|payments?|received|receive|got|earned|income|costs?|expenses?|money|salary|how|much|did|we|us|our)\b/g, " ");
  const byKw = (categories || []).filter((x) => !type || x.type === type);
  let best = null, bestLen = 0;
  const t = " " + strip.replace(/[^a-z0-9&' ]+/g, " ") + " ";
  for (const cat of byKw) {
    const words = String(cat.keywords || "").split(",").map((k) => k.trim().toLowerCase()).filter(Boolean)
      .concat(String(cat.name || "").toLowerCase().split(/[^a-z]+/).filter((w) => w.length > 3 && !/^(other|and|media|content)$/.test(w)));
    for (const k of words) if ((t.includes(" " + k + " ") || t.includes(" " + k + "s ") || (k.length > 4 && t.includes(" " + k.slice(0, -1)))) && k.length > bestLen) { best = cat; bestLen = k.length; }
  }
  return best;
}
function accountLoose(text) {
  const t = String(text || "").toLowerCase();
  if (/\b(momo|mtn|mobile money|airtel)\b/.test(t)) return "momo";
  if (/\b(bank|bk|equity|i&m|im bank|access bank|ecobank|cogebanque|bpr|kcb|ncba|visa|card)\b/.test(t)) return "bank";
  if (/\b(cash|in hand|hand)\b/.test(t)) return "cash";
  return null;
}
function partyInQuestion(t) {
  const STOP = /^(us|we|me|the|our|my|this|last|today|yesterday|week|month|year|momo|mtn|bank|cash|fuel|transport|equipment|crew|clients?|everyone|anyone|all|them|it|so far)$/i;
  const tries = [
    /\b(?:did|has|have)\s+(?!we\b|i\b|you\b)(.+?)\s+(?:pay|paid|send|sent|transfer)/i,
    /\bdoes\s+(?!we\b|i\b)(.+?)\s+owe\b/i,
    /\b(?:from|by)\s+(.+?)(?=\s+(?:this|last|today|yesterday|in|on|for|since|so far|so|until|to|via)\b|[?,.!]|$)/i,
    /\b(?:to|for)\s+([A-Z][\w&'’.-]*(?:\s+[A-Z][\w&'’.-]*)*)/,
    /\b(?:pay|paid|paying|gave|give|sent|send)\s+([A-Z][\w&'’.-]*(?:\s+[A-Z][\w&'’.-]*)*)/,
  ];
  for (const re of tries) {
    const m = t.match(re); if (!m) continue;
    const p = m[1].replace(/^(the|a)\s+/i, "").trim();
    if (!p || STOP.test(p) || /^(this|last|the last|past)\b/i.test(p) || MONTH_RE.test(" " + p.toLowerCase() + " ") || /^\d/.test(p)) continue;
    if (!/[A-Z]/.test(p) && p.split(/\s+/).length > 2) continue;   // long lower-case phrase: not a name
    return p.slice(0, 60);
  }
  return "";
}

function queryOf(t, ctx, strict = false) {
  const k = t.toLowerCase();
  let metric = null;
  const moneyVerb = /(spen[dt]|receiv|earn|paid|pay\b|income|cost|bought)/.test(k);
  if (/\bbal(ance)?s?\b/.test(k) || (!moneyVerb && (/\bhow much (money )?(do we have|have we got|is (there|left)|is (on|in))\b/.test(k) || /\b(left|available)\b/.test(k) || /\bhow much\b.*\b(on|in)\s+(the\s+)?(momo|mtn|bank|cash)\b/.test(k)))) metric = "balance";
  else if (/\b(owed?|owes|owing|unpaid|outstanding|invoices?|debts?|hasn'?t paid|not paid( yet)?|still to pay|pending)\b/.test(k)) metric = "owed";
  else if (/\b(profit|net|p&?l|pnl|loss|margin|ma(ke|de)|how (are|did|were|is) (we|it|things|business) (doing|do|going|go))\b/.test(k)) metric = "net";
  else if (/\b(paid us|pay us|paid you|pay you)\b|\b(did|has|have)\s+(?!we\b|i\b|you\b)\S+(\s+\S+)?\s+pa(y|id)\b/.test(k) || /\b(receiv|earn|income|revenue|sales|money in|came in|brought in|turnover)\w*/.test(k)) metric = "income";
  else if (/\b(spen[dt]|spending|expenses?|costs?|money out|went out|bought|buy|pa(y|id)|paying)\w*/.test(k)) metric = "expense";
  else if (/\b(list|entries|transactions|recent|last \d+|what did we (record|book)|records?|history)\b/.test(k)) metric = "list";
  else if (!strict && categoryLoose(t, null, ctx.categories)) metric = categoryLoose(t, null, ctx.categories).type;   // "how much on fuel this month?"
  else if (/\b(report|summary|overview|how are things|numbers|books|status)\b/.test(k) || (!strict && /\b(today|week|month|year|yesterday|leo|icyumweru|ukwezi)\b/.test(k))) metric = "summary";
  if (!metric) return null;
  const type = metric === "income" ? "income" : metric === "expense" ? "expense" : null;
  const cat = (metric === "income" || metric === "expense") ? categoryLoose(t, type, ctx.categories) : null;
  const party = metric === "balance" ? "" : partyInQuestion(t);
  return { intent: "query", sure: true, metric, period: periodOf(t, metric === "list" ? "this_week" : "this_month"), category_id: cat ? cat.id : null,
    party, account_id: accountLoose(t), periodGiven: /\b(today|yesterday|week|month|year|days|ever|all time|so far|ytd|ejo|leo|icyumweru|ukwezi)\b/i.test(t) || MONTH_RE.test(" " + k + " ") };
}

function recordOf(t, ctx) {
  const p = parse(t, { categories: ctx.categories, defaultAccount: ctx.accounts[0]?.id, now: todayKigali() });
  const accountGiven = accountsGiven(t);
  // several numbers ("printed 2 frames 300 rwf", "paid 3 crew 90k"): the one with a unit is the amount, else the largest
  const all = amountsIn(t);
  if (all.length > 1) {
    const u = t.replace(/\b\d{1,2}[\/\-]\d{1,2}([\/\-]\d{2,4})?\b/g, " ").match(/(?:rwf|frw|rf)\s*\d[\d,. ]*\d|\d[\d,.]*\s*(?:k|m|rwf|frw|rf|million|thousand)\b/i);
    const pickAmt = u ? parse(u[0], { categories: [] }).amount_rwf : Math.max(...all);
    if (pickAmt) p.amount_rwf = pickAmt;
  }
  // "Kigali Heights paid 400k", "Inka has paid": someone else paid, so the money came to us
  const payer = (t.match(/^(.+?)\s+(?:paid|has paid|have paid|sent|yishyuye)\b/i) || [])[1];
  if (payer && p.amount_rwf && !/^(i|i've|we|we've|me|us|our|my|you|you've|y'ello|nous|je|j'ai|on|nti|twe|njye|twebwe|just|already|today|yesterday|also|then|and|so|finally|have|has)\b/i.test(payer.trim()) && payer.trim().split(/\s+/).length <= 5 && !/\d/.test(payer) && p.type !== "transfer") {
    p.type = "income"; p.party = payer.trim().slice(0, 120); p.missing = p.missing.filter((m) => m !== "type");
    const c = categoryLoose(t.slice(payer.length), "income", ctx.categories); p.category_id = c ? c.id : "other-income";
  }
  if (p.party) p.party = p.party.replace(/\s*\(?\+?\d{6,}\)?/g, "").replace(/\s+(?:at|on)\s+.*$/i, "").trim();   // "JOHN DOE (2507…)", "ABC LTD at 24/11/2026"
  if (p.type && p.type !== "transfer" && /^other-/.test(p.category_id || "")) { const c = categoryLoose(t, p.type, ctx.categories); if (c) p.category_id = c.id; }
  return { intent: "record", sure: !p.missing.length, draft: { type: p.type, amount_rwf: p.amount_rwf, account_id: p.account_id, to_account_id: p.to_account_id, category_id: p.category_id,
    party: p.party, happened_on: p.happened_on, raw: t.slice(0, 500), accountGiven } };
}
const accountsGiven = (t) => /\b(momo|mtn|mobile money|airtel|bank|bk|equity|i&m|access bank|ecobank|cogebanque|bpr|kcb|ncba|visa|cash|in hand)\b/i.test(t);

function editOf(t, ctx, last) {
  const f = {};
  const amt = parse(t, { categories: [] }).amount_rwf; if (amt) f.amount_rwf = amt;
  const acc = accountLoose(t); if (acc) f.account_id = acc;
  if (hasDateWords(t)) f.happened_on = parse(t, { categories: [], now: todayKigali() }).happened_on;
  if (/\b(income|money in|came in|it was in|received)\b/i.test(t)) f.type = "income";
  else if (/\b(expense|money out|went out|it was out|spent)\b/i.test(t)) f.type = "expense";
  const ty = f.type || last?.type;
  if (ty && ty !== "transfer") { const c = categoryLoose(t.replace(/\b(make it|change|it was|should be|actually|no|category|to)\b/gi, " "), ty, ctx.categories); if (c) f.category_id = c.id; }
  const pm = t.match(/\b(?:from|to|client (?:is|was)|it was for|for)\s+([A-Z][\w&'’.-]*(?:\s+[A-Z][\w&'’.-]*)*)/);
  if (pm && !accountLoose(pm[1])) f.party = pm[1].slice(0, 120);
  return { intent: "edit", sure: Object.keys(f).length > 0, fields: f };
}

function localUnderstand(t, ctx) {
  t = t.trim().replace(/^(please|pls|plz|hey|ok|okay|so|and)[,\s]+/i, "").trim();
  const k = t.toLowerCase();
  if (!k || HELPQ.test(k)) return { intent: "help", sure: true };
  if (/\b(stop|turn off|disable|pause|no more)\b.*\breminders?\b/i.test(k)) return { intent: "reminders", on: false, sure: true };
  if (/\b(start|turn on|enable|resume)\b.*\breminders?\b/i.test(k)) return { intent: "reminders", on: true, sure: true };
  if (GREET.test(k)) return { intent: "greet", sure: true };
  if (THANKS.test(k)) return { intent: "thanks", sure: true };
  if (UNDO.test(k) && !parse(k, { categories: [] }).amount_rwf) return { intent: "undo", sure: true };
  if (BARE_QUERY.test(k) || (QUESTION.test(k) && !NEW_RECORD_START.test(k))) {
    const q = queryOf(t, ctx); if (q) return q;
    return { intent: "unclear", sure: false, question: true };
  }
  const rem = k.match(/^(?:remind|chase|nudge|follow up with)\s+(.+)$/i);
  if (rem && !/reminders?/.test(k)) return { intent: "remind", client: t.trim().replace(/^\S+\s+(up with\s+)?/i, "").trim(), sure: true };
  const owes = t.trim().match(/^(.+?)\s+(?:still\s+)?(?:owes?|is owing|has to pay|needs to pay|will pay)\s+(?:us\s+)?(.+)$/i) || t.trim().match(/^invoice\s+(.+?)\s+((?:rwf\s*)?\d.*)$/i);
  if (owes) {
    const amt = parse(owes[2], { categories: [] }).amount_rwf;
    return { intent: "owe", sure: !!amt, client: owes[1].replace(/^(please|pls)\s+/i, "").trim().slice(0, 120), amount_rwf: amt, description: ((owes[2].match(/\bfor\s+(.+)$/i) || [])[1] || "").slice(0, 500) };
  }
  if (ctx.last && CORRECTION.test(k) && !NEW_RECORD_START.test(k)) { const e = editOf(t, ctx, ctx.last); if (e.sure) return e; }
  const r = recordOf(t, ctx);
  if (!r.draft.amount_rwf && !NEW_RECORD_START.test(k)) { const q = queryOf(t, ctx, true); if (q) return q; }   // "profit last month", "spending on fuel this week"
  if (!r.draft.amount_rwf && !r.draft.type) return { intent: "unclear", sure: false, draft: r.draft };
  return r;
}

// ---- the AI reader (only when the rules above aren't sure)
function brainPrompt(ctx) {
  const today = dayIso(U(...kigaliYMD()));
  return "You are the WhatsApp bookkeeping assistant of CRT Media Agency, a photo/video/branding studio in Kigali, Rwanda. " +
    "Read the team member's message (English, Kinyarwanda, French or a mix; it may be a forwarded MTN MoMo / Airtel / bank SMS) and decide what they want. " +
    "Reply with ONE JSON object only, no prose, no code fences:\n" +
    '{"intent":"record|query|edit|undo|owe|remind|help|chat|clarify",' +
    '"record":{"type":"income|expense|transfer|null","amount_rwf":number|null,"account_id":string|null,"to_account_id":string|null,"category_id":string|null,"party":string|null,"happened_on":"YYYY-MM-DD"|null},' +
    '"query":{"metric":"expense|income|net|summary|balance|owed|list","period":"today|yesterday|this_week|last_week|this_month|last_month|this_year|last_year|last_7_days|last_30_days|all|YYYY-MM","category_id":string|null,"party":string|null,"account_id":string|null},' +
    '"edit":{"amount_rwf":number|null,"account_id":string|null,"category_id":string|null,"type":"income|expense"|null,"happened_on":"YYYY-MM-DD"|null,"party":string|null},' +
    '"owe":{"client":string,"amount_rwf":number|null,"description":string|null},"client":string|null,' +
    '"question":string|null,"reply":string|null}\n' +
    "Only fill the part that matches the intent. Rules:\n" +
    "- record = money already moved (paid, spent, bought, received, got, a client paid, moved between our accounts). income = money came to CRT; expense = CRT paid; transfer = between our own accounts.\n" +
    "- Amounts are RWF: 50k = 50000, 1.2m = 1200000, 'ibihumbi 50' = 50000. NEVER invent an amount. If the amount is missing, use intent clarify with record filled as far as known and a short question.\n" +
    "- If you can't tell whether money came in or went out, use clarify and ask exactly that. Don't guess an account: leave account_id null if not said.\n" +
    "- query = any question about the books (totals, spending, income, profit, balances, who owes, list of entries). Pick the period the message implies; default this_month.\n" +
    "- edit = a correction of the entry just booked (\"no, it was cash\", \"make it 60k\", \"it was yesterday\"). undo = delete it.\n" +
    "- owe = someone owes CRT money not yet paid (\"Inka owes 400k for menu shoot\", \"invoice Kigali Heights 300k\"). remind = they want a payment reminder for a client.\n" +
    "- chat = greetings, thanks, or anything not about the books: put a short, warm reply (max 2 sentences) in reply, steering back to the books.\n" +
    `Today is ${today} (Kigali). Accounts: ${ctx.accounts.map((a) => a.id + " = " + a.name).join(", ")}. ` +
    `Categories: ${ctx.categories.map((c) => c.id + " = " + c.type + " " + c.name).join(", ")}.` +
    (ctx.state?.pending ? `\nThe assistant just asked: "${ctx.state.pending.ask}" about this draft: ${JSON.stringify(ctx.state.pending.draft || {})}. The message may be the answer.` : "") +
    (ctx.last ? `\nThe last entry this person booked: ${JSON.stringify({ type: ctx.last.type, amount_rwf: ctx.last.amount_rwf, account_id: ctx.last.account_id, category_id: ctx.last.category_id, party: ctx.last.party, happened_on: ctx.last.happened_on })}.` : "");
}
const jsonIn = (s) => { try { const a = s.indexOf("{"), b = s.lastIndexOf("}"); return a < 0 ? null : JSON.parse(s.slice(a, b + 1)); } catch { return null; } };
async function askBrain(text, ctx) {
  const sys = brainPrompt(ctx);
  try {
    if (env("ANTHROPIC_API_KEY")) {
      const r = await fetch("https://api.anthropic.com/v1/messages", { method: "POST", signal: AbortSignal.timeout(15000),
        headers: { "x-api-key": env("ANTHROPIC_API_KEY"), "anthropic-version": "2023-06-01", "content-type": "application/json" },
        body: JSON.stringify({ model: Deno.env.get("CLAUDE_TEXT_MODEL") || "claude-haiku-5-5", max_tokens: 500, system: sys, messages: [{ role: "user", content: text }] }) });
      if (!r.ok) { console.error("claude", r.status, (await r.text()).slice(0, 300)); return null; }
      const d = await r.json(); return jsonIn(d.content?.find((c) => c.type === "text")?.text || "");
    }
    if (env("GEMINI_API_KEY")) {
      const model = Deno.env.get("GEMINI_MODEL") || "gemini-2.5-flash";
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(env("GEMINI_API_KEY"))}`, {
        method: "POST", signal: AbortSignal.timeout(15000), headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ systemInstruction: { parts: [{ text: sys }] }, contents: [{ role: "user", parts: [{ text }] }], generationConfig: { responseMimeType: "application/json", temperature: 0 } }) });
      if (!r.ok) { console.error("gemini", r.status, (await r.text()).slice(0, 300)); return null; }
      const d = await r.json(); return jsonIn(d.candidates?.[0]?.content?.parts?.[0]?.text || "");
    }
  } catch (e) { console.error("reader", e?.message || e); }
  return null;
}
// turn the AI's JSON into the same shape the local rules produce, checking every field against the books and the message
function fromBrain(j, t, ctx) {
  if (!j || typeof j !== "object") return null;
  const accOk = (id) => ctx.accounts.some((a) => a.id === id) ? id : null;
  const catOk = (id, ty) => ctx.categories.some((c) => c.id === id && (!ty || c.type === ty)) ? id : null;
  const seen = amountsIn(t), pendAmt = ctx.state?.pending?.draft?.amount_rwf;
  const amtOk = (n) => { n = Math.round(Number(n)); if (!(n > 0)) return null; if (seen.includes(n) || n === pendAmt) return n; if (!seen.length && NUMBER_WORDS.test(t)) return n; return seen.length === 1 ? seen[0] : null; };
  const isoOk = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s || "") && s <= dayIso(U(...kigaliYMD())) ? s : null;
  const it = String(j.intent || "");
  if (it === "record" || it === "clarify") {
    const r = j.record || {}, type = ["income", "expense", "transfer"].includes(r.type) ? r.type : null;
    const draft = { type, amount_rwf: amtOk(r.amount_rwf), account_id: accOk(r.account_id), to_account_id: type === "transfer" ? accOk(r.to_account_id) : null,
      category_id: type && type !== "transfer" ? (catOk(r.category_id, type) || (type === "income" ? "other-income" : "other-expense")) : null,
      party: String(r.party || "").slice(0, 120), happened_on: isoOk(r.happened_on) || parse(t, { categories: [], now: todayKigali() }).happened_on, raw: t.slice(0, 500), accountGiven: !!accOk(r.account_id) && accountsGiven(t) };
    if (!draft.account_id) draft.account_id = ctx.accounts[0]?.id;
    if (!draft.amount_rwf && !draft.type && it === "clarify" && j.question) return { intent: "clarify", question: String(j.question).slice(0, 300), draft };
    return { intent: "record", draft, ask: it === "clarify" && j.question ? String(j.question).slice(0, 300) : null };
  }
  if (it === "query") {
    const q = j.query || {}, metric = ["expense", "income", "net", "summary", "balance", "owed", "list"].includes(q.metric) ? q.metric : "summary";
    const ty = metric === "income" ? "income" : metric === "expense" ? "expense" : null;
    return { intent: "query", metric, period: periodFromWord(q.period || (metric === "list" ? "this_week" : "this_month")), category_id: catOk(q.category_id, ty), party: String(q.party || "").slice(0, 60), account_id: accOk(q.account_id), periodGiven: !!q.period };
  }
  if (it === "edit") {
    const e = j.edit || {}, f = {};
    const a = amtOk(e.amount_rwf); if (a) f.amount_rwf = a;
    if (accOk(e.account_id)) f.account_id = e.account_id;
    if (["income", "expense"].includes(e.type)) f.type = e.type;
    if (catOk(e.category_id, f.type || ctx.last?.type)) f.category_id = e.category_id;
    if (isoOk(e.happened_on)) f.happened_on = e.happened_on;
    if (e.party) f.party = String(e.party).slice(0, 120);
    return { intent: "edit", fields: f };
  }
  if (it === "undo") return { intent: "undo" };
  if (it === "owe" && j.owe?.client) return { intent: "owe", client: String(j.owe.client).slice(0, 120), amount_rwf: amtOk(j.owe.amount_rwf), description: String(j.owe.description || "").slice(0, 500) };
  if (it === "remind" && (j.client || j.owe?.client)) return { intent: "remind", client: String(j.client || j.owe.client).slice(0, 120) };
  if (it === "help") return { intent: "help" };
  if (it === "chat") return { intent: "chat", reply: String(j.reply || "").slice(0, 400) };
  return null;
}

// ---- doing it
async function lastEntry(sender, st) {
  const since = new Date(Date.now() - 12 * 3600e3).toISOString();
  let q = sb.from("fin_entries").select("id,type,amount_rwf,account_id,to_account_id,category_id,party,happened_on,note,created_at").eq("source", "whatsapp").eq("created_by_name", sender.name).gte("created_at", since);
  q = st?.last_entry_id ? q.eq("id", st.last_entry_id) : q.order("id", { ascending: false }).limit(1);
  const { data } = await q;
  return (data && data[0]) || null;
}

function describe(e, ctx) {
  const amt = `*${rwf(e.amount_rwf)} RWF*`, acc = ctx.accName(e.account_id), when = dateWord(e.happened_on);
  if (e.type === "transfer") return `${amt} moved from ${acc} to ${ctx.accName(e.to_account_id)} ${when}`;
  if (e.type === "income") return `${amt} in${e.party ? " from " + e.party : ""} (${ctx.catName(e.category_id)}), into ${acc} ${when}`;
  return `${amt} out for ${ctx.catName(e.category_id)}${e.party ? " to " + e.party : ""}, paid from ${acc} ${when}`;
}

async function ask(from, ctx, need, draft, question) {
  ctx.state.pending = { need, draft, ask: question, at: Date.now() };
  await setState(from, ctx.state);
  return reply(from, question + (STATE_OK ? "" : "\n\n(Send it again as one message, e.g. \"paid 50k fuel momo\".)"));
}

async function record(from, sender, ctx, draft) {
  const d = { ...draft };
  if (!d.amount_rwf) {
    const what = d.type === "income" ? `How much came in${d.party ? " from " + d.party : ""}?` : d.type === "expense" ? `How much was it${d.category_id && !/^other-/.test(d.category_id) ? " for " + ctx.catName(d.category_id).toLowerCase() : ""}?` : "How much was it?";
    return ask(from, ctx, "amount", d, `Sure, I can record that. ${what}`);
  }
  if (d.amount_rwf < 500 && !/\b(rwf|frw|rf|francs?)\b/i.test(d.raw || "") && !d.small_ok) {
    const g = d.amount_rwf; d.amount_rwf = null; d.guess = g;
    return ask(from, ctx, "amount", d, `Just to check: *${rwf(g)} RWF*, or *${rwf(g * 1000)} RWF* (${g}k)?`);
  }
  if (!d.type) return ask(from, ctx, "type", d, `Got *${rwf(d.amount_rwf)} RWF*${d.party ? " with " + d.party : ""}. Did it come *in* (we were paid) or go *out* (we paid)?`);
  if (d.type === "transfer" && (!d.to_account_id || d.to_account_id === d.account_id)) return ask(from, ctx, "to_account", d, `Moving *${rwf(d.amount_rwf)} RWF* from ${ctx.accName(d.account_id)} to which account? (${ctx.accounts.filter((a) => a.id !== d.account_id).map((a) => a.name).join(", ")})`);
  if (!d.account_id) d.account_id = ctx.accounts[0]?.id;
  if (d.type !== "transfer" && !ctx.categories.some((c) => c.id === d.category_id && c.type === d.type)) d.category_id = d.type === "income" ? "other-income" : "other-expense";
  // a client paying an open invoice: "Inka paid 400k", "got 400k from Inka"
  let invoice = null;
  const payer = d.type === "income" ? (d.party || ((d.raw || "").match(/^(.+?)\s+(?:paid|has paid|yishyuye)\b/i) || [])[1] || "").trim() : "";
  if (payer.length >= 3 && !/^(i|we|me|us|our|my|nous|je|nti|twe|njye|client)$/i.test(payer)) {
    const { data: inv } = await sb.from("fin_invoices").select("id,number,client,amount_rwf").eq("status", "sent").ilike("client", `${payer}%`).order("due_on").limit(1).maybeSingle();
    if (inv) { invoice = inv; d.party = inv.client; }
  }
  const row = { type: d.type, amount_rwf: d.amount_rwf, happened_on: d.happened_on || dayIso(U(...kigaliYMD())), account_id: d.account_id, to_account_id: d.type === "transfer" ? d.to_account_id : null,
    category_id: d.type === "transfer" ? null : d.category_id, party: d.party || null, note: (d.raw || "").slice(0, 500), raw_message: (d.raw || "").slice(0, 1000),
    source: "whatsapp", created_by: sender.user_id || null, created_by_name: sender.name, invoice_id: invoice?.id ?? null };
  const { data: ins, error } = await sb.from("fin_entries").insert(row).select("id").single();
  if (error) return reply(from, "Sorry, I couldn't save that: " + error.message + "\nPlease add it in the dashboard.");
  if (invoice && d.amount_rwf >= Number(invoice.amount_rwf)) await sb.from("fin_invoices").update({ status: "paid" }).eq("id", invoice.id);
  ctx.state.pending = null; ctx.state.last_entry_id = ins?.id ?? null; await setState(from, ctx.state);
  const open = d.type === "income" ? pick(["Nice one 🎉", "Great 💪", "Lovely 🙌"]) : d.type === "expense" ? pick(["Done ✅", "Noted ✅", "Recorded ✅"]) : "Done ✅";
  let msg = `${open} I've recorded ${describe(row, ctx)}.`;
  if (invoice) msg += `\n🧾 That ${d.amount_rwf >= Number(invoice.amount_rwf) ? "settles" : "part-pays"} invoice ${invoice.number}${d.amount_rwf < Number(invoice.amount_rwf) ? ` (${rwf(Number(invoice.amount_rwf) - d.amount_rwf)} RWF still open)` : ""}.`;
  if (d.type !== "transfer" && !d.accountGiven) msg += `\nI put it on ${ctx.accName(d.account_id)}; tell me if it was ${ctx.accounts.filter((a) => a.id !== d.account_id).map((a) => a.name.replace(/ account$/i, "")).join(" or ")}.`;
  else msg += `\nAnything off? Just say so ("make it 60k", "it was yesterday") or *undo*.`;
  return reply(from, msg);
}
let PICK = 0; const pick = (a) => a[(PICK++) % a.length];

async function resumePending(from, sender, ctx, t) {
  const p = ctx.state.pending; if (!p) return false;
  const k = t.toLowerCase().trim();
  if (/^(cancel|never ?mind|nevermind|forget it|leave it|skip|no thanks|nothing|reka|oya reka)\b/.test(k)) { ctx.state.pending = null; await setState(from, ctx.state); await reply(from, "No problem, I've dropped that. Nothing was recorded."); return true; }
  const fresh = parse(t, { categories: ctx.categories, now: todayKigali() });
  const d = { ...p.draft };
  if (p.need === "amount") {
    if (d.guess && /^(yes|yeah|yep|yego|correct|right|exactly|just|only|oui)\b/i.test(k) && !/\d/.test(k)) { d.amount_rwf = d.guess; d.small_ok = true; await record(from, sender, ctx, d); return true; }
    if (d.guess && fresh.amount_rwf === d.guess) { d.amount_rwf = d.guess; d.small_ok = true; await record(from, sender, ctx, d); return true; }
    if (fresh.amount_rwf && fresh.type && fresh.missing.length === 0 && t.split(/\s+/).length > 2) return false;   // a whole new message, not the answer
    if (!fresh.amount_rwf) return false;
    d.amount_rwf = fresh.amount_rwf;
    if (accountsGiven(t)) { d.account_id = accountLoose(t) || d.account_id; d.accountGiven = true; }
    if (!d.type) { if (IN_WORDS.test(k) && !OUT_WORDS.test(k)) d.type = "income"; else if (OUT_WORDS.test(k)) d.type = "expense"; }
    if (d.type && d.type !== "transfer" && (!d.category_id || /^other-/.test(d.category_id))) { const c = categoryLoose((d.raw || "") + " " + t, d.type, ctx.categories); d.category_id = c ? c.id : d.category_id; }
    d.raw = ((d.raw || "") + " · " + t).slice(0, 500);
    await record(from, sender, ctx, d); return true;
  }
  if (p.need === "type") {
    if (fresh.amount_rwf && fresh.type && t.split(/\s+/).length > 2 && fresh.amount_rwf !== d.amount_rwf) return false;
    const inn = /^(in|it came in|came in|income|received|we got|got it|they paid|paid us|money in|incoming|\+|ninjiye|byinjiye|entr[ée]e)\b/i.test(k) || (IN_WORDS.test(k) && !OUT_WORDS.test(k));
    const out = /^(out|went out|expense|we paid|i paid|paid|spent|money out|outgoing|-|byasohotse|sortie)\b/i.test(k) || (OUT_WORDS.test(k) && !IN_WORDS.test(k));
    if (inn === out) { await reply(from, "Sorry, was it money *in* or money *out*? (or say *cancel*)"); return true; }
    d.type = inn ? "income" : "expense";
    const c = categoryLoose(d.raw || "", d.type, ctx.categories); d.category_id = c ? c.id : (d.type === "income" ? "other-income" : "other-expense");
    if (!d.party) { const nm = (d.raw || "").match(/(?:^|\s)([A-Z][\w&'’.-]+(?:\s+[A-Z][\w&'’.-]+)*)/); if (nm && !accountLoose(nm[1]) && !/^(Paid|Got|Received|Sent|Gave|For|From|To|Rwf|Frw)$/i.test(nm[1])) d.party = nm[1].slice(0, 120); }
    if (!d.party) { const pr = (d.raw || "").match(inn ? /\b(?:from|by)\s+([A-Z][\w&'’.-]*(?:\s+[A-Z][\w&'’.-]*)*)/ : /\b(?:to|for)\s+([A-Z][\w&'’.-]*(?:\s+[A-Z][\w&'’.-]*)*)/); if (pr && !accountLoose(pr[1])) d.party = pr[1]; }
    if (accountsGiven(t)) { d.account_id = accountLoose(t); d.accountGiven = true; }
    await record(from, sender, ctx, d); return true;
  }
  if (p.need === "to_account") {
    const a = accountLoose(t); if (!a) return false;
    d.to_account_id = a; await record(from, sender, ctx, d); return true;
  }
  return false;
}

async function edit(from, ctx, fields) {
  const e = ctx.last;
  if (!e) return reply(from, "I can't find anything you recorded in the last 12 hours to change. Fix older entries in the dashboard (Finance).");
  if (!Object.keys(fields).length) return reply(from, `What should I change on ${describe(e, ctx)}? E.g. "make it 60k", "it was cash", "it was yesterday".`);
  const up = { ...fields };
  if (up.type && up.type !== e.type && e.type !== "transfer" && !up.category_id) { const c = categoryLoose(e.note || "", up.type, ctx.categories); up.category_id = c ? c.id : (up.type === "income" ? "other-income" : "other-expense"); }
  if (e.type === "transfer") { delete up.type; delete up.category_id; }
  const { error } = await sb.from("fin_entries").update(up).eq("id", e.id);
  if (error) return reply(from, "Sorry, I couldn't change that: " + error.message);
  return reply(from, `✏️ Fixed. It's now ${describe({ ...e, ...up }, ctx)}.`);
}

async function undo(from, ctx) {
  const e = ctx.last;
  if (!e) return reply(from, "There's nothing of yours from the last 12 hours to undo. Older entries can be deleted in the dashboard.");
  await sb.from("fin_entries").delete().eq("id", e.id);
  ctx.state.last_entry_id = null; ctx.state.pending = null; await setState(from, ctx.state);
  return reply(from, `↩️ Removed: ${describe(e, ctx)}.`);
}

async function owe(from, ctx, a) {
  if (!a.amount_rwf) return reply(from, `How much does ${a.client} owe? Send it like "${a.client} owes 400k for the menu shoot".`);
  const y = todayKigali().getFullYear();
  const { count } = await sb.from("fin_invoices").select("id", { count: "exact", head: true }).like("number", `INV-${y}-%`);
  const number = `INV-${y}-${String((count || 0) + 1).padStart(3, "0")}`;
  const [yy, mm, dd] = kigaliYMD(), due = dayIso(U(yy, mm, dd + 14));
  const { error } = await sb.from("fin_invoices").insert({ number, client: a.client, description: a.description || null, amount_rwf: a.amount_rwf, status: "sent", due_on: due });
  if (error) return reply(from, "Sorry, I couldn't save that: " + error.message);
  return reply(from, `🧾 Noted: ${a.client} owes *${rwf(a.amount_rwf)} RWF*${a.description ? " for " + a.description : ""} (${number}, due ${dateWord(due).replace(/^on /, "")}).\nWhen they pay, just tell me "${a.client} paid ${rwf(a.amount_rwf)}". Need a reminder to send them? Say "remind ${a.client}".`);
}

async function remind(from, client) {
  const name = client.replace(/[?.!]+$/, "").trim();
  const { data } = await sb.from("fin_invoices").select("number,client,amount_rwf,due_on,description").eq("status", "sent").ilike("client", `%${name}%`).order("due_on");
  if (!data?.length) return reply(from, `${name} has no unpaid invoice with us. Ask me "who owes us?" to see everyone.`);
  const total = data.reduce((s2, i) => s2 + Number(i.amount_rwf), 0);
  return reply(from, `Here's a reminder you can forward to ${data[0].client}:\n\n` +
    `Hello ${data[0].client}, a friendly reminder from CRT Media Agency: ${data.length > 1 ? data.length + " invoices are" : "invoice " + data[0].number + " is"} still open, ${rwf(total)} RWF in total${data[0].due_on ? " (due " + data[0].due_on + ")" : ""}. ` +
    "You can pay by MoMo to 0796 356 035 or by bank transfer. Thank you!");
}

async function answer(from, ctx, q) {
  const { catName, accName } = ctx;
  if (q.metric === "balance") {
    const { data } = await sb.from("fin_balances").select("id,name,balance_rwf").order("sort");
    const rows = (data || []).filter((a) => !q.account_id || a.id === q.account_id);
    if (q.account_id && rows.length === 1) return reply(from, `${rows[0].name} has *${rwf(rows[0].balance_rwf)} RWF* right now.`);
    const total = (data || []).reduce((s, a) => s + Number(a.balance_rwf), 0);
    return reply(from, `Here's what we have right now:\n${(data || []).map((a) => `• ${a.name}: ${rwf(a.balance_rwf)}`).join("\n")}\n*Total: ${rwf(total)} RWF*`);
  }
  if (q.metric === "owed") {
    const { data } = await sb.from("fin_invoices").select("number,client,amount_rwf,due_on").eq("status", "sent").order("due_on");
    const rows = (data || []).filter((i) => !q.party || i.client.toLowerCase().includes(q.party.toLowerCase()));
    if (q.party && !rows.length) return reply(from, `${q.party} doesn't owe us anything right now 👍`);
    if (!rows.length) return reply(from, "Nobody owes us anything right now 👍");
    const total = rows.reduce((s, i) => s + Number(i.amount_rwf), 0), today = dayIso(U(...kigaliYMD()));
    if (q.party) return reply(from, `${rows[0].client} owes *${rwf(total)} RWF* (${rows.map((i) => i.number + (i.due_on ? ", due " + dateWord(i.due_on).replace(/^on /, "") : "")).join("; ")}). Say "remind ${rows[0].client}" for a message to send them.`);
    return reply(from, `${rows.length === 1 ? "One client owes" : rows.length + " invoices are open,"} *${rwf(total)} RWF* in total:\n` + rows.map((i) => `• ${i.client}: ${rwf(i.amount_rwf)}${i.due_on ? (i.due_on < today ? " ⚠️ overdue since " : " · due ") + dateWord(i.due_on).replace(/^on /, "") : ""}`).join("\n") + `\n\nSay "remind ${rows[0].client}" for a ready reminder to forward.`);
  }
  const p = q.period;
  const { data } = await sb.from("fin_entries").select("id,type,amount_rwf,category_id,party,note,account_id,happened_on").gte("happened_on", p.from).lte("happened_on", p.to).neq("type", "transfer").order("happened_on", { ascending: false }).limit(5000);
  let rows = data || [];
  if (q.category_id) rows = rows.filter((r) => r.category_id === q.category_id);
  if (q.account_id) rows = rows.filter((r) => r.account_id === q.account_id);
  if (q.party) { const pl = q.party.toLowerCase(); rows = rows.filter((r) => (r.party || "").toLowerCase().includes(pl) || (r.note || "").toLowerCase().includes(pl)); }
  const sum = (ty) => rows.filter((r) => r.type === ty).reduce((s, r) => s + Number(r.amount_rwf), 0);
  const n = (ty) => rows.filter((r) => r.type === ty).length;
  const tops = (ty) => { const m = {}; rows.filter((r) => r.type === ty).forEach((r) => m[r.category_id] = (m[r.category_id] || 0) + Number(r.amount_rwf)); return Object.entries(m).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([c, v]) => `• ${catName(c)}: ${rwf(v)}`).join("\n"); };
  const L = p.label, cat = q.category_id ? catName(q.category_id).toLowerCase() : "", yet = p.now ? " yet" : "";
  const fromAcc = q.account_id ? ` from ${accName(q.account_id)}` : "";
  if (q.metric === "expense") {
    const s = sum("expense"), c = n("expense");
    if (!c) return reply(from, q.party ? `No payment to ${q.party}${cat ? " for " + cat : ""} ${L}${yet}.` : `Nothing spent${cat ? " on " + cat : ""}${fromAcc} ${L}${yet}.`);
    return reply(from, (q.party ? `We paid ${q.party} *${rwf(s)} RWF*${cat ? " for " + cat : ""}` : `We spent *${rwf(s)} RWF*${cat ? " on " + cat : ""}`) + `${fromAcc} ${L} (${c} payment${c > 1 ? "s" : ""}).` + (!q.category_id && c > 1 ? `\n\nWhere it went:\n${tops("expense")}` : ""));
  }
  if (q.metric === "income") {
    const s = sum("income"), c = n("income");
    if (!c) return reply(from, q.party ? `No payment from ${q.party} ${L}${yet}.` + (p.now && !q.periodGiven ? ` Ask "did ${q.party} pay us this year?" to look further back.` : "") : `No money in${cat ? " for " + cat : ""} ${L}${yet}.`);
    const lastDay = rows.find((r) => r.type === "income")?.happened_on;
    return reply(from, (q.party ? `${q.party} paid us *${rwf(s)} RWF* ${L}` : `We received *${rwf(s)} RWF*${cat ? " for " + cat : ""} ${L}`) + ` (${c} payment${c > 1 ? "s" : ""}${lastDay ? ", latest " + dateWord(lastDay) : ""}).` + (!q.category_id && !q.party && c > 1 ? `\n\nFrom:\n${tops("income")}` : ""));
  }
  if (q.metric === "list") {
    if (!rows.length) return reply(from, `Nothing recorded ${L}${yet}.`);
    return reply(from, `Latest entries ${L}:\n` + rows.slice(0, 10).map((e) => `${e.type === "income" ? "＋" : "−"} ${rwf(e.amount_rwf)} · ${e.party || catName(e.category_id)} · ${dateWord(e.happened_on).replace(/^on /, "")}`).join("\n") + (rows.length > 10 ? `\n…and ${rows.length - 10} more in the dashboard.` : ""));
  }
  const inc = sum("income"), exp = sum("expense"), net = inc - exp;
  const head = L.charAt(0).toUpperCase() + L.slice(1);
  if (!rows.length) return reply(from, `Nothing recorded ${L}${yet}.`);
  const verdict = net > 0 ? `a profit of *${rwf(net)} RWF* 👍` : net < 0 ? `a loss of *${rwf(-net)} RWF*` : "break-even";
  let msg = `${head}: ${rwf(inc)} RWF in, ${rwf(exp)} RWF out, so ${verdict}.`;
  const t3 = tops("expense"); if (t3) msg += `\n\nBiggest costs:\n${t3}`;
  if (q.metric === "summary" && (L === "today" || L === "yesterday" || L === "this week")) msg += `\n\nLatest:\n` + rows.slice(0, 6).map((e) => `${e.type === "income" ? "＋" : "−"} ${rwf(e.amount_rwf)} · ${e.party || catName(e.category_id)}`).join("\n");
  return reply(from, msg);
}

async function handle(from, text, sender) {
  const t = normAmounts(String(text || "").trim());
  const [{ data: accounts }, { data: categories }, state] = await Promise.all([
    sb.from("fin_accounts").select("id,name").eq("archived", false).order("sort"),
    sb.from("fin_categories").select("id,name,type,keywords").order("sort"),
    getState(from),
  ]);
  const ctx = { accounts: accounts || [], categories: categories || [], state, last: null,
    catName: (id) => ((categories || []).find((c) => c.id === id) || { name: "Other" }).name,
    accName: (id) => ((accounts || []).find((a) => a.id === id) || { name: id }).name };
  ctx.last = await lastEntry(sender, state);

  if (await resumePending(from, sender, ctx, t)) return;
  if (state.pending) { state.pending = null; await setState(from, state); }   // they moved on: drop the open question

  let a = localUnderstand(t, ctx);
  if (!a.sure && canRead()) { const b = fromBrain(await askBrain(t, ctx), t, ctx); if (b) a = b; }

  switch (a.intent) {
    case "help": return reply(from, HELP);
    case "greet": return reply(from, `Hi ${first(sender.name)} 👋 Tell me about any money in or out, e.g. "paid 50k for fuel", or ask me something like "how much did we spend this week?". Say *help* for more.`);
    case "thanks": return reply(from, pick(["Anytime 🙌", "You're welcome 👍", "Happy to help 🙂"]));
    case "chat": return reply(from, a.reply || `I'm here for the books 🙂 Tell me about money in or out, or ask "how much did we spend this week?".`);
    case "reminders":
      await sb.from("fin_whatsapp_senders").update({ remind: a.on }).eq("phone", from);
      return reply(from, a.on ? "Evening reminders are on: at 19:00, only on days with nothing recorded." : "OK, no more evening reminders. Say \"start reminders\" any time to turn them back on.");
    case "undo": return undo(from, ctx);
    case "edit": return edit(from, ctx, a.fields || {});
    case "query": return answer(from, ctx, a);
    case "owe": return owe(from, ctx, a);
    case "remind": return remind(from, a.client);
    case "clarify": return ask(from, ctx, a.draft?.amount_rwf ? "type" : "amount", a.draft || {}, a.question);
    case "record":
      if (a.ask && (!a.draft.amount_rwf || !a.draft.type)) return ask(from, ctx, !a.draft.amount_rwf ? "amount" : "type", a.draft, a.ask);
      return record(from, sender, ctx, a.draft);
  }
  if (a.question) return reply(from, `I'm not sure what you'd like to know. You can ask me things like:\n• how much did we spend this week?\n• what did RMB pay us this month?\n• balance · who owes us? · profit last month`);
  return reply(from, `Sorry, I didn't catch that. Tell me what happened with the money, e.g. "paid 50k for fuel" or "got 200k from RMB for the shoot", or ask "how much did we spend this week?". Say *help* for more.`);
}

// ---------------------------------------------------------------- receipt photos and PDFs
async function mediaBytes(id) {
  const meta = await fetch(`https://graph.facebook.com/v21.0/${id}`, { headers: { Authorization: `Bearer ${env("WHATSAPP_TOKEN")}` } }).then((r) => r.json());
  if (!meta?.url) throw new Error("no media url");
  const r = await fetch(meta.url, { headers: { Authorization: `Bearer ${env("WHATSAPP_TOKEN")}` } });
  return { bytes: new Uint8Array(await r.arrayBuffer()), type: meta.mime_type || r.headers.get("content-type") || "application/octet-stream" };
}
async function handleReceipt(from, m, sender) {
  if (!canRead()) return reply(from, "Receipts need the free reading key (Dashboard → Finance → WhatsApp books → Gemini key). For now, type it: \"paid 25k printing cash\".");
  const media = m.type === "image" ? m.image : m.document;
  const { bytes, type } = await mediaBytes(media.id);
  if (bytes.length > 10e6) return reply(from, "That file is too big. Send a photo instead.");
  let b = ""; for (let i = 0; i < bytes.length; i += 0x8000) b += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  const isPdf = /pdf/.test(type), img = { mime: isPdf ? "application/pdf" : (/png|webp|gif/.test(type) ? type : "image/jpeg"), data: btoa(b) };
  const [{ data: accounts }, { data: categories }] = await Promise.all([
    sb.from("fin_accounts").select("id,name").eq("archived", false).order("sort"),
    sb.from("fin_categories").select("id,name,type,keywords").order("sort"),
  ]);
  const p = await askReader(media.caption || "", accounts, categories, img);
  if (!p) return reply(from, "I couldn't read an amount on that. Type it instead, e.g. \"paid 25k printing cash\".");
  const path = `${new Date().toISOString().slice(0, 7)}/${crypto.randomUUID()}.${isPdf ? "pdf" : (type.split("/")[1] || "jpg").replace("jpeg", "jpg")}`;
  await sb.storage.from("receipts").upload(path, bytes, { contentType: type, upsert: false });
  const { error } = await sb.from("fin_entries").insert({ type: p.type, amount_rwf: p.amount_rwf, happened_on: p.happened_on, account_id: p.account_id, to_account_id: p.to_account_id,
    category_id: p.category_id, party: p.party || null, note: (media.caption || "Receipt").slice(0, 500), raw_message: "[receipt " + (isPdf ? "PDF" : "photo") + "]",
    source: "whatsapp", created_by: sender.user_id, created_by_name: sender.name, receipt_path: path });
  if (error) return reply(from, "Couldn't save that: " + error.message);
  const cat = (categories.find((c) => c.id === p.category_id) || { name: "" }).name, acc = (accounts.find((a) => a.id === p.account_id) || { name: p.account_id }).name;
  return reply(from, `✅ From the receipt: ${TYPE[p.type]} ${rwf(p.amount_rwf)} RWF\n${cat} · ${acc}${p.party ? " · " + p.party : ""}\n${p.happened_on}\n📎 Receipt saved\n\nWrong amount or account? Reply *undo* and type it.`);
}

// ---------------------------------------------------------------- evening reminder and Monday summary
async function runTask(task) {
  const { data: senders } = await sb.from("fin_whatsapp_senders").select("phone,name,user_id,remind,last_message_at");
  const today = todayKigali().toISOString().slice(0, 10), sent = [];
  for (const s of senders || []) {
    if (!s.remind) continue;
    // WhatsApp lets a business write freely only within 24 hours of the person's last message
    if (!s.last_message_at || Date.now() - new Date(s.last_message_at).getTime() > 23.5 * 3600e3) continue;
    if (task === "reminder") {
      const { count } = await sb.from("fin_entries").select("id", { count: "exact", head: true }).eq("happened_on", today).eq("created_by_name", s.name);
      if (count) continue;
      await reply(s.phone, `Good evening ${s.name.split(" ")[0]} 👋 Nothing recorded today. Any money in or out? Just type it, e.g. "paid 20k fuel momo", or send a receipt photo. Reply *stop reminders* to turn this off.`);
      sent.push(s.phone);
    } else if (task === "weekly") {
      await handle(s.phone, "week", s); sent.push(s.phone);
    }
  }
  return new Response(JSON.stringify({ ok: true, sent: sent.length }), { headers: { "Content-Type": "application/json" } });
}

// ---------------------------------------------------------------- dashboard (main admin): keys and status
const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const out = (b, st = 200) => new Response(JSON.stringify(b), { status: st, headers: { ...CORS, "Content-Type": "application/json" } });
// Subscribes every WhatsApp account the saved token can manage to this app, so Meta sends real messages here
// (Meta only delivers to apps listed in the account's subscribed_apps). Runs server-side with the stored token.
async function connectWaba(extra = []) {
  const T = env("WHATSAPP_TOKEN"); if (!T) return { error: "no_token" };
  const G = "https://graph.facebook.com/v21.0";
  const dbg = await fetch(`${G}/debug_token?input_token=${encodeURIComponent(T)}&access_token=${encodeURIComponent(T)}`).then((r) => r.json()).catch(() => ({}));
  const ids = new Set((Array.isArray(extra) ? extra : []).map((x) => String(x).replace(/\D/g, "")).filter(Boolean));
  for (const g of dbg?.data?.granular_scopes || []) if (/^whatsapp_business_(management|messaging)$/.test(g.scope)) for (const id of g.target_ids || []) ids.add(String(id));
  if (!ids.size) return { error: "no_whatsapp_account", detail: dbg?.error?.message || "token has no WhatsApp account" };
  const results = [];
  for (const id of ids) {
    const r = await fetch(`${G}/${id}/subscribed_apps`, { method: "POST", headers: { Authorization: `Bearer ${T}` } });
    const j = await r.json().catch(() => ({}));
    results.push({ id, ok: r.ok && j.success !== false, detail: j?.error?.message });
  }
  return { ok: results.some((x) => x.ok), results };
}

async function dashboard(req) {
  const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
  const { data: au } = await sb.auth.getUser(token); const user = au?.user;
  if (!user) return out({ error: "signed_out" }, 401);
  const { data: member } = await sb.from("team").select("role").eq("user_id", user.id).maybeSingle();
  if (member?.role !== "owner") return out({ error: "owner_only" }, 403);
  const body = await req.json().catch(() => ({}));
  const rnd = () => [...crypto.getRandomValues(new Uint8Array(24))].map((x) => x.toString(16).padStart(2, "0")).join("");
  for (const k of ["WHATSAPP_VERIFY_TOKEN", "FIN_CRON_SECRET"]) if (!env(k)) { const v = rnd(); await sb.from("app_secrets").upsert({ name: k, value: v }); SECRETS[k] = v; }
  if (body.action === "save" && body.values) {
    for (const k of ["WHATSAPP_TOKEN", "WHATSAPP_PHONE_NUMBER_ID", "WHATSAPP_APP_SECRET", "ANTHROPIC_API_KEY", "GEMINI_API_KEY"]) {
      const v = String(body.values[k] ?? "").trim(); if (v) { await sb.from("app_secrets").upsert({ name: k, value: v.slice(0, 600), updated_at: new Date().toISOString() }); SECRETS[k] = v; }
    }
    if (String(body.values.WHATSAPP_TOKEN ?? "").trim()) await connectWaba().catch(() => null);   // new token: make sure Meta delivers to this app
  }
  if (body.action === "receipt") {
    const { data, error } = await sb.storage.from("receipts").createSignedUrl(String(body.path || ""), 600);
    return error ? out({ error: "not_found" }, 404) : out({ url: data.signedUrl });
  }
  if (body.action === "connect") return out(await connectWaba(body.ids));
  if (body.action === "test") {
    const to = String(body.phone || "").replace(/\D/g, "");
    const r = await fetch(`https://graph.facebook.com/v21.0/${env("WHATSAPP_PHONE_NUMBER_ID")}/messages`, { method: "POST", headers: { Authorization: `Bearer ${env("WHATSAPP_TOKEN")}`, "Content-Type": "application/json" },
      body: JSON.stringify({ messaging_product: "whatsapp", to, type: "template", template: { name: "hello_world", language: { code: "en_US" } } }) });
    const j = await r.json().catch(() => ({}));
    return r.ok ? out({ ok: true }) : out({ error: "send_failed", detail: j?.error?.message || r.status }, 400);
  }
  return out({ webhook: Deno.env.get("SUPABASE_URL") + "/functions/v1/finance-whatsapp", verify_token: env("WHATSAPP_VERIFY_TOKEN"),
    set: Object.fromEntries(["WHATSAPP_TOKEN", "WHATSAPP_PHONE_NUMBER_ID", "WHATSAPP_APP_SECRET", "ANTHROPIC_API_KEY", "GEMINI_API_KEY"].map((k) => [k, !!env(k)])) });
}

// ---------------------------------------------------------------- webhook
Deno.serve(async (req) => {
  const url = new URL(req.url);
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  await loadSecrets();
  if (req.method === "POST" && req.headers.get("x-crt-cron") !== null) {
    if (!env("FIN_CRON_SECRET") || req.headers.get("x-crt-cron") !== env("FIN_CRON_SECRET")) return new Response("Forbidden", { status: 403 });
    const b = await req.json().catch(() => ({})); return runTask(String(b.task || ""));
  }
  if (req.method === "POST" && !req.headers.get("x-hub-signature-256") && /^Bearer\s+\S+\.\S+\.\S+/.test(req.headers.get("Authorization") || "")) return dashboard(req);
  if (req.method === "GET") {
    // Meta checks the webhook once when you save it
    const ok = url.searchParams.get("hub.mode") === "subscribe" && url.searchParams.get("hub.verify_token") === env("WHATSAPP_VERIFY_TOKEN") && env("WHATSAPP_VERIFY_TOKEN");
    return ok ? new Response(url.searchParams.get("hub.challenge") ?? "") : new Response("Forbidden", { status: 403 });
  }
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const body = await req.text();
  if (!(await hmacOk(req, body))) return new Response("Bad signature", { status: 401 });
  let payload; try { payload = JSON.parse(body); } catch { return new Response("ok"); }
  const msgs = (payload.entry ?? []).flatMap((e) => (e.changes ?? []).flatMap((c) => c.value?.messages ?? []));
  for (const m of msgs) {
    const from = String(m.from || "").replace(/\D/g, "");
    try {
      const { data: sender } = await sb.from("fin_whatsapp_senders").select("phone,name,user_id").eq("phone", from).maybeSingle();
      if (!sender) continue; // not on the list: ignore silently
      await sb.from("fin_whatsapp_senders").update({ last_message_at: new Date().toISOString() }).eq("phone", from);
      // Meta re-sends a message when it doesn't get a fast 200. Record each message id once, so money is never booked twice.
      if (m.id) {
        const { error: seen } = await sb.from("fin_whatsapp_seen").insert({ message_id: String(m.id).slice(0, 200) });
        if (seen) { if (seen.code === "23505") continue; console.error(seen); }
      }
      if (m.type === "image" || m.type === "document") { await handleReceipt(from, m, sender); continue; }
      if (m.type === "audio") { await reply(from, "Voice notes can't be read yet. Type it, e.g. \"paid 50k fuel momo\", or send a receipt photo."); continue; }
      if (m.type !== "text") { await reply(from, "Send it as text, e.g. \"paid 50k fuel momo\". Send *help* for examples."); continue; }
      const txt = m.text?.body ?? "";
      await handle(from, txt, sender);
    } catch (err) {
      console.error(err);
      try { await reply(from, "Something went wrong saving that. Please add it in the dashboard."); } catch {}
    }
  }
  return new Response("ok"); // always 200, or Meta retries
});
