// @ts-nocheck
// Supabase Edge Function "finance-whatsapp": record CRT money by sending a WhatsApp message.
//
//   "paid 50k fuel momo"                → Money out 50,000 · Transport & fuel · MTN MoMo
//   "received 400k from Inka bank"      → Money in 400,000 · Bank account · Inka
//   "moved 200k momo to bank"           → Transfer
//   balance · report · owed · undo · help
//
// The entry lands in Supabase (so the dashboard shows it within a second), and the
// database webhook copies it to the Google Sheet. Full setup: admin/FINANCE-SETUP.txt
//
// Secrets (Supabase → Edge Functions → Secrets):
//   WHATSAPP_TOKEN            permanent access token of the Meta app (System user token)
//   WHATSAPP_PHONE_NUMBER_ID  the phone number ID from Meta → WhatsApp → API setup
//   WHATSAPP_VERIFY_TOKEN     any long random text; paste the same text in Meta's webhook settings
//   WHATSAPP_APP_SECRET       Meta app → Settings → Basic → App secret (proves messages come from Meta)
//   ANTHROPIC_API_KEY         optional: lets Claude read messages the simple rules don't understand
// SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are provided by Supabase automatically.
// Deploy with "Verify JWT" switched OFF (Meta cannot send a Supabase login).
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const env = (k) => Deno.env.get(k) ?? "";
const sb = createClient(env("SUPABASE_URL"), env("SUPABASE_SERVICE_ROLE_KEY"), { auth: { persistSession: false } });
const rwf = (n) => Number(n || 0).toLocaleString("en-US");
const TYPE = { income: "Money in", expense: "Money out", transfer: "Transfer" };
const tz = "Africa/Kigali";
const todayKigali = () => new Date(new Date().toLocaleString("en-US", { timeZone: tz }));

// ---------------------------------------------------------------- parser (same as admin/fin-parse.js)
const parse = (() => {
  const MONTHS = {jan:0,feb:1,mar:2,apr:3,may:4,jun:5,jul:6,aug:7,sep:8,sept:8,oct:9,nov:10,dec:11};
  const ACCOUNT_WORDS = [
    ['momo', /\b(momo|mtn|mobile money|airtel( money)?)\b/i],
    ['bank', /\b(bank|bk|equity|i&m|im bank|access bank|ecobank|cogebanque|bpr|kcb|ncba|visa)\b/i],
    ['cash', /\b(cash|hand|in hand)\b/i],
  ];
  const INCOME = /^\s*\+|\b(received|receive|got|income|deposit from|payment from|paid by|client paid|sold|invoice paid|advance from|deposit for)\b/i;
  const EXPENSE = /^\s*-|\b(paid|pay|spent|spend|bought|buy|expense|cost|costs|purchase|purchased|gave|sent to|salary)\b/i;
  const TRANSFER = /\b(moved|move|transfer|transferred|withdraw|withdrew|withdrawal|topped up|top up)\b/i;

  const iso = d => new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())).toISOString().slice(0, 10);

  function amountOf(text){
    // 50k, 1.2m, 400,000, 400 000, 25000rwf, rwf 25,000
    const m = text.match(/(?:rwf|frw|rf)?\s*(\d{1,3}(?:[ ,.]\d{3})+|\d+(?:\.\d+)?)\s*(k|m|million|thousand|rwf|frw|rf)?\b/i);
    if(!m) return null;
    let raw = m[1], unit = (m[2] || '').toLowerCase();
    let n = /^\d{1,3}([ ,.]\d{3})+$/.test(raw) && !(unit === 'k' || unit === 'm') ? Number(raw.replace(/[ ,.]/g, '')) : Number(raw.replace(/[ ,]/g, ''));
    if(unit === 'k' || unit === 'thousand') n *= 1e3;
    if(unit === 'm' || unit === 'million') n *= 1e6;
    n = Math.round(n);
    return n > 0 ? {value: n, text: m[0]} : null;
  }

  function dateOf(text, now){
    now = now || new Date();
    const t = text.toLowerCase();
    if(/\byesterday\b/.test(t)){ const d = new Date(now); d.setDate(d.getDate() - 1); return iso(d); }
    let m = t.match(/\b(\d{1,2})[\/\-](\d{1,2})(?:[\/\-](\d{2,4}))?\b/);
    if(m){ const y = m[3] ? (m[3].length === 2 ? 2000 + Number(m[3]) : Number(m[3])) : now.getFullYear(); const d = new Date(y, Number(m[2]) - 1, Number(m[1])); if(!isNaN(d)) return iso(d); }
    m = t.match(/\b(\d{1,2})(?:st|nd|rd|th)?\s+(jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*\b/) || t.match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*\s+(\d{1,2})\b/);
    if(m){ const day = Number(/\d/.test(m[1]) ? m[1] : m[2]), mon = MONTHS[(/\d/.test(m[1]) ? m[2] : m[1]).slice(0, 4).replace(/t$/, 't')] ?? MONTHS[(/\d/.test(m[1]) ? m[2] : m[1]).slice(0, 3)];
      const d = new Date(now.getFullYear(), mon, day); if(d > now){ if(d - now < 60 * 864e5) return iso(now); d.setFullYear(d.getFullYear() - 1); } return iso(d); }
    return iso(now);
  }

  function accountsIn(text){
    const hits = [];
    ACCOUNT_WORDS.forEach(([id, re]) => { const m = text.match(re); if(m) hits.push({id, at: m.index}); });
    return hits.sort((a, b) => a.at - b.at).map(h => h.id);
  }

  function categoryOf(text, type, categories){
    const t = ' ' + text.toLowerCase().replace(/[^a-z0-9&' ]+/g, ' ') + ' ';
    let best = null, bestLen = 0;
    (categories || []).forEach(c => {
      if(type && c.type !== type) return;
      String(c.keywords || '').split(',').map(k => k.trim().toLowerCase()).filter(Boolean).forEach(k => {
        if(t.includes(' ' + k + ' ') || t.includes(' ' + k + 's ')){ if(k.length > bestLen){ best = c; bestLen = k.length; } }
      });
    });
    return best;
  }

  function partyOf(text, type){
    const re = type === 'income' ? /\b(?:from|by)\s+(.+?)(?=\s+(?:for|via|on|to|in|into|momo|mtn|bank|cash|yesterday|today)\b|[.,;]|$)/i
                                 : /\b(?:to|at)\s+(.+?)(?=\s+(?:for|via|on|from|momo|mtn|bank|cash|yesterday|today)\b|[.,;]|$)/i;
    const m = text.match(re);
    if(!m) return '';
    const p = m[1].trim();
    if(/^(momo|mtn|bank|cash|the bank|my|our)\b/i.test(p) || /^\d/.test(p)) return '';
    return p.slice(0, 120);
  }

  function parse(text, opts){
    opts = opts || {};
    const cats = opts.categories || [], now = opts.now || new Date(), defAcc = opts.defaultAccount || 'momo';
    const clean = String(text || '').trim().replace(/\s+/g, ' ');
    const out = {type: null, amount_rwf: null, account_id: null, to_account_id: null, category_id: null, party: '', happened_on: dateOf(clean, now), note: clean.slice(0, 500), missing: []};
    const amt = amountOf(clean.replace(/\b\d{1,2}[\/\-]\d{1,2}([\/\-]\d{2,4})?\b/g, ' '));
    if(amt) out.amount_rwf = amt.value; else out.missing.push('amount');
    const accs = accountsIn(clean);
    if(TRANSFER.test(clean) && accs.length >= 2){
      out.type = 'transfer'; out.account_id = accs[0]; out.to_account_id = accs[1];
      if(/\bfrom\b/i.test(clean) && /\bto\b/i.test(clean)){
        const f = clean.toLowerCase().search(/\bfrom\b/), tIdx = clean.toLowerCase().search(/\bto\b/);
        if(tIdx < f){ out.account_id = accs[1]; out.to_account_id = accs[0]; }
      }
      return out;
    }
    if(TRANSFER.test(clean) && accs.length === 1 && /withdr/i.test(clean)){ out.type = 'transfer'; out.account_id = accs[0]; out.to_account_id = accs[0] === 'cash' ? defAcc : 'cash'; return out; }
    if(INCOME.test(clean)) out.type = 'income';
    else if(EXPENSE.test(clean)) out.type = 'expense';
    const cat = categoryOf(clean, out.type, cats);
    if(!out.type && cat) out.type = cat.type;
    if(!out.type) out.missing.push('type');
    if(out.type){
      const c = cat && cat.type === out.type ? cat : null;
      out.category_id = c ? c.id : (out.type === 'income' ? 'other-income' : 'other-expense');
      out.party = partyOf(clean, out.type);
    }
    out.account_id = accs[0] || defAcc;
    return out;
  }
  return parse;
})();

// ---------------------------------------------------------------- helpers
async function hmacOk(req, body) {
  const secret = env("WHATSAPP_APP_SECRET");
  if (!secret) return true; // not configured yet: accept (set it before going live)
  const sig = (req.headers.get("x-hub-signature-256") || "").replace("sha256=", "");
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const mac = new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(body)));
  const hex = [...mac].map((b) => b.toString(16).padStart(2, "0")).join("");
  if (hex.length !== sig.length) return false;
  let diff = 0; for (let i = 0; i < hex.length; i++) diff |= hex.charCodeAt(i) ^ sig.charCodeAt(i);
  return diff === 0;
}

async function reply(to, text) {
  await fetch(`https://graph.facebook.com/v21.0/${env("WHATSAPP_PHONE_NUMBER_ID")}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${env("WHATSAPP_TOKEN")}`, "Content-Type": "application/json" },
    body: JSON.stringify({ messaging_product: "whatsapp", to, type: "text", text: { body: text.slice(0, 4000) } }),
  });
}

async function askClaude(text, accounts, categories) {
  const key = env("ANTHROPIC_API_KEY");
  if (!key) return null;
  const today = todayKigali().toISOString().slice(0, 10);
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({
      model: "claude-haiku-5-5",
      max_tokens: 300,
      system: "You turn one short bookkeeping message from a Rwandan creative agency into JSON. Amounts are in RWF (50k = 50000, 1.2m = 1200000). " +
        "Reply with JSON only: {\"type\":\"income|expense|transfer|unknown\",\"amount_rwf\":number|null,\"account_id\":string,\"to_account_id\":string|null,\"category_id\":string|null,\"party\":string|null,\"happened_on\":\"YYYY-MM-DD\"}. " +
        `Today is ${today}. Accounts: ${accounts.map((a) => a.id + " (" + a.name + ")").join(", ")}. ` +
        `Categories: ${categories.map((c) => c.id + " (" + c.type + ": " + c.name + ")").join(", ")}. ` +
        "If the message is not about money moving, use type unknown. Never invent an amount.",
      messages: [{ role: "user", content: text }],
    }),
  });
  if (!r.ok) return null;
  const d = await r.json();
  try {
    const j = JSON.parse((d.content?.[0]?.text || "").replace(/^```(json)?|```$/g, "").trim());
    if (!["income", "expense", "transfer"].includes(j.type) || !(j.amount_rwf > 0)) return null;
    if (!accounts.some((a) => a.id === j.account_id)) j.account_id = accounts[0].id;
    if (j.type === "transfer" && !accounts.some((a) => a.id === j.to_account_id)) return null;
    if (j.type !== "transfer" && !categories.some((c) => c.id === j.category_id && c.type === j.type)) j.category_id = j.type === "income" ? "other-income" : "other-expense";
    if (!/^\d{4}-\d{2}-\d{2}$/.test(j.happened_on || "")) j.happened_on = today;
    return { ...j, amount_rwf: Math.round(j.amount_rwf), to_account_id: j.type === "transfer" ? j.to_account_id : null, category_id: j.type === "transfer" ? null : j.category_id, party: j.party || "", missing: [] };
  } catch { return null; }
}

const HELP = "*CRT books on WhatsApp*\n\n" +
  "Record money in plain words:\n• paid 50k fuel momo\n• received 400k from Inka bank\n• +1.2m wedding Grace & Eric\n• -25000 lunch cash yesterday\n• moved 200k momo to bank\n\n" +
  "Ask:\n• *balance*: money in each account\n• *report*: this month's profit\n• *owed*: unpaid invoices\n• *undo*: remove your last entry";

function monthRange() {
  const d = todayKigali(), y = d.getFullYear(), m = d.getMonth();
  const f = (x) => x.toISOString().slice(0, 10);
  return [f(new Date(Date.UTC(y, m, 1))), f(new Date(Date.UTC(y, m + 1, 0))), d.toLocaleDateString("en-GB", { month: "long", year: "numeric" })];
}

async function handle(from, text, sender) {
  const t = text.trim(), lower = t.toLowerCase();
  const [{ data: accounts }, { data: categories }] = await Promise.all([
    sb.from("fin_accounts").select("id,name").eq("archived", false).order("sort"),
    sb.from("fin_categories").select("id,name,type,keywords").order("sort"),
  ]);
  const catName = (id) => (categories.find((c) => c.id === id) || { name: "" }).name;
  const accName = (id) => (accounts.find((a) => a.id === id) || { name: id }).name;

  if (/^(help|\?|hi|hello|menu|start)$/i.test(lower)) return reply(from, HELP);

  if (/^(balance|balances|bal)$/i.test(lower)) {
    const { data } = await sb.from("fin_balances").select("name,balance_rwf").order("sort");
    const total = data.reduce((s, a) => s + Number(a.balance_rwf), 0);
    return reply(from, "*Balances*\n" + data.map((a) => `${a.name}: ${rwf(a.balance_rwf)}`).join("\n") + `\n*Total: ${rwf(total)} RWF*`);
  }

  if (/^(report|summary|month|profit|p&l|pnl)$/i.test(lower)) {
    const [a, b, label] = monthRange();
    const { data } = await sb.from("fin_entries").select("type,amount_rwf,category_id").gte("happened_on", a).lte("happened_on", b).neq("type", "transfer");
    const sum = (ty) => data.filter((e) => e.type === ty).reduce((s, e) => s + Number(e.amount_rwf), 0);
    const top = {}; data.filter((e) => e.type === "expense").forEach((e) => top[e.category_id] = (top[e.category_id] || 0) + Number(e.amount_rwf));
    const tops = Object.entries(top).sort((x, y) => y[1] - x[1]).slice(0, 3).map(([k, v]) => `• ${catName(k)}: ${rwf(v)}`).join("\n");
    const inc = sum("income"), exp = sum("expense");
    return reply(from, `*${label}*\nMoney in: ${rwf(inc)}\nMoney out: ${rwf(exp)}\n*Profit: ${inc - exp < 0 ? "−" : ""}${rwf(Math.abs(inc - exp))} RWF*` + (tops ? `\n\nBiggest costs:\n${tops}` : ""));
  }

  if (/^(owed|owe|unpaid|invoices)$/i.test(lower)) {
    const { data } = await sb.from("fin_invoices").select("number,client,amount_rwf,due_on").eq("status", "sent").order("due_on");
    if (!data.length) return reply(from, "No unpaid invoices.");
    const total = data.reduce((s, i) => s + Number(i.amount_rwf), 0);
    return reply(from, "*Unpaid invoices*\n" + data.map((i) => `${i.number} · ${i.client}: ${rwf(i.amount_rwf)}${i.due_on ? " (due " + i.due_on + ")" : ""}`).join("\n") + `\n*Total: ${rwf(total)} RWF*`);
  }

  if (/^undo$/i.test(lower)) {
    const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const { data } = await sb.from("fin_entries").select("id,type,amount_rwf,note").eq("source", "whatsapp").eq("created_by_name", sender.name).gte("created_at", since).order("id", { ascending: false }).limit(1);
    if (!data.length) return reply(from, "Nothing to undo from the last hour.");
    await sb.from("fin_entries").delete().eq("id", data[0].id);
    return reply(from, `↩️ Removed: ${TYPE[data[0].type]} ${rwf(data[0].amount_rwf)} RWF ("${data[0].note || ""}")`);
  }

  let p = parse(t, { categories, defaultAccount: accounts[0]?.id, now: todayKigali() });
  if (p.missing.length) p = (await askClaude(t, accounts, categories)) || p;
  if (p.missing.length) {
    return reply(from, `I couldn't tell ${p.missing.map((m) => m === "amount" ? "the amount" : "if money came in or went out").join(" or ")}.\nTry: "paid 50k fuel momo" or "received 400k from Inka bank". Send *help* for more.`);
  }
  const row = {
    type: p.type, amount_rwf: p.amount_rwf, happened_on: p.happened_on, account_id: p.account_id, to_account_id: p.to_account_id,
    category_id: p.category_id, party: p.party || null, note: t.slice(0, 500), raw_message: t.slice(0, 1000),
    source: "whatsapp", created_by: sender.user_id, created_by_name: sender.name,
  };
  const { error } = await sb.from("fin_entries").insert(row);
  if (error) return reply(from, "Couldn't save that: " + error.message);
  const what = p.type === "transfer" ? `${accName(p.account_id)} → ${accName(p.to_account_id)}` : `${catName(p.category_id)} · ${accName(p.account_id)}${p.party ? " · " + p.party : ""}`;
  return reply(from, `✅ ${TYPE[p.type]} ${rwf(p.amount_rwf)} RWF\n${what}\n${p.happened_on}\n\nWrong? Reply *undo*, or fix it in the dashboard.`);
}

// ---------------------------------------------------------------- webhook
Deno.serve(async (req) => {
  const url = new URL(req.url);
  if (req.method === "GET") {
    // Meta checks the webhook once when you save it
    const ok = url.searchParams.get("hub.mode") === "subscribe" && url.searchParams.get("hub.verify_token") === env("WHATSAPP_VERIFY_TOKEN") && env("WHATSAPP_VERIFY_TOKEN");
    return ok ? new Response(url.searchParams.get("hub.challenge") ?? "") : new Response("Forbidden", { status: 403 });
  }
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const body = await req.text();
  if (!(await hmacOk(req, body))) return new Response("Bad signature", { status: 401 });
  let payload; try { payload = JSON.parse(body); } catch { return new Response("ok"); }
  const msgs = (payload.entry ?? []).flatMap((e) => (e.changes ?? []).flatMap((c) => c.value?.messages ?? []));
  for (const m of msgs) {
    const from = String(m.from || "").replace(/\D/g, "");
    try {
      const { data: sender } = await sb.from("fin_whatsapp_senders").select("phone,name,user_id").eq("phone", from).maybeSingle();
      if (!sender) continue; // not on the list: ignore silently
      if (m.type !== "text") { await reply(from, "Send it as text, e.g. \"paid 50k fuel momo\". Send *help* for examples."); continue; }
      await handle(from, m.text?.body ?? "", sender);
    } catch (err) {
      console.error(err);
      try { await reply(from, "Something went wrong saving that. Please add it in the dashboard."); } catch {}
    }
  }
  return new Response("ok"); // always 200, or Meta retries
});
