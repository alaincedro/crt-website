// @ts-nocheck
// Supabase Edge Function "finance-whatsapp": record CRT money by sending a WhatsApp message.
//
//   "paid 50k fuel momo"                → Money out 50,000 · Transport & fuel · MTN MoMo
//   "received 400k from Inka bank"      → Money in 400,000 · Bank account · Inka
//   "moved 200k momo to bank"           → Transfer
//   balance · report · owed · undo · help
//
// The entry lands in Supabase (so the dashboard shows it within a second), and the
// database webhook copies it to the Google Sheet. Full setup: admin/FINANCE-SETUP.txt
//
// Keys: entered by the main admin in the dashboard (Finance → WhatsApp), kept in the locked table app_secrets.
// (Supabase → Edge Functions → Secrets with the same names also work.)
//   WHATSAPP_TOKEN            permanent access token of the Meta app (System user token)
//   WHATSAPP_PHONE_NUMBER_ID  the phone number ID from Meta → WhatsApp → API setup
//   WHATSAPP_VERIFY_TOKEN     any long random text; paste the same text in Meta's webhook settings
//   WHATSAPP_APP_SECRET       Meta app → Settings → Basic → App secret (proves messages come from Meta)
//   GEMINI_API_KEY            optional, FREE (Google AI Studio free tier): reads receipt photos and tricky messages
//   ANTHROPIC_API_KEY         optional, paid per use: used instead of Gemini when set
// SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are provided by Supabase automatically.
// Deploy with "Verify JWT" switched OFF (Meta cannot send a Supabase login).
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

let SECRETS = {};
const env = (k) => Deno.env.get(k) || SECRETS[k] || "";
const sb = createClient(Deno.env.get("SUPABASE_URL"), Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"), { auth: { persistSession: false } });
const FIN_KEYS = ["WHATSAPP_TOKEN", "WHATSAPP_PHONE_NUMBER_ID", "WHATSAPP_APP_SECRET", "WHATSAPP_VERIFY_TOKEN", "ANTHROPIC_API_KEY", "GEMINI_API_KEY", "FIN_CRON_SECRET"];
async function loadSecrets() {
  const { data } = await sb.from("app_secrets").select("name,value").in("name", FIN_KEYS);
  SECRETS = Object.fromEntries((data || []).map((r) => [r.name, r.value]));
}
const rwf = (n) => Number(n || 0).toLocaleString("en-US");
const TYPE = { income: "Money in", expense: "Money out", transfer: "Transfer" };
const tz = "Africa/Kigali";
const todayKigali = () => new Date(new Date().toLocaleString("en-US", { timeZone: tz }));

// ---------------------------------------------------------------- parser (same as admin/fin-parse.js)
const parse = (() => {
  const MONTHS = {jan:0,feb:1,mar:2,apr:3,may:4,jun:5,jul:6,aug:7,sep:8,sept:8,oct:9,nov:10,dec:11};
  const ACCOUNT_WORDS = [
    ['momo', /\b(momo|mtn|mobile money|airtel( money)?)\b/i],
    ['bank', /\b(bank|bk|equity|i&m|im bank|access bank|ecobank|cogebanque|bpr|kcb|ncba|visa)\b/i],
    ['cash', /\b(cash|hand|in hand)\b/i],
  ];
  const INCOME = /^\s*\+|\b(received|receive|got|income|deposit from|payment from|paid by|client paid|sold|invoice paid|advance from|deposit for)\b/i;
  const EXPENSE = /^\s*-|\b(paid|pay|spent|spend|bought|buy|expense|cost|costs|purchase|purchased|gave|sent to|salary)\b/i;
  const TRANSFER = /\b(moved|move|transfer|transferred|withdraw|withdrew|withdrawal|topped up|top up)\b/i;

  const iso = d => new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())).toISOString().slice(0, 10);

  function amountOf(text){
    // 50k, 1.2m, 400,000, 400 000, 25000rwf, rwf 25,000
    const m = text.match(/(?:rwf|frw|rf)?\s*(\d{1,3}(?:[ ,.]\d{3})+|\d+(?:\.\d+)?)\s*(k|m|million|thousand|rwf|frw|rf)?\b/i);
    if(!m) return null;
    let raw = m[1], unit = (m[2] || '').toLowerCase();
    let n = /^\d{1,3}([ ,.]\d{3})+$/.test(raw) && !(unit === 'k' || unit === 'm') ? Number(raw.replace(/[ ,.]/g, '')) : Number(raw.replace(/[ ,]/g, ''));
    if(unit === 'k' || unit === 'thousand') n *= 1e3;
    if(unit === 'm' || unit === 'million') n *= 1e6;
    n = Math.round(n);
    return n > 0 ? {value: n, text: m[0]} : null;
  }

  function dateOf(text, now){
    now = now || new Date();
    const t = text.toLowerCase();
    if(/\byesterday\b/.test(t)){ const d = new Date(now); d.setDate(d.getDate() - 1); return iso(d); }
    let m = t.match(/\b(\d{1,2})[\/\-](\d{1,2})(?:[\/\-](\d{2,4}))?\b/);
    if(m){ const y = m[3] ? (m[3].length === 2 ? 2000 + Number(m[3]) : Number(m[3])) : now.getFullYear(); const d = new Date(y, Number(m[2]) - 1, Number(m[1])); if(!isNaN(d)) return iso(d); }
    m = t.match(/\b(\d{1,2})(?:st|nd|rd|th)?\s+(jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*\b/) || t.match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*\s+(\d{1,2})\b/);
    if(m){ const day = Number(/\d/.test(m[1]) ? m[1] : m[2]), mon = MONTHS[(/\d/.test(m[1]) ? m[2] : m[1]).slice(0, 4).replace(/t$/, 't')] ?? MONTHS[(/\d/.test(m[1]) ? m[2] : m[1]).slice(0, 3)];
      const d = new Date(now.getFullYear(), mon, day); if(d > now){ if(d - now < 60 * 864e5) return iso(now); d.setFullYear(d.getFullYear() - 1); } return iso(d); }
    return iso(now);
  }

  function accountsIn(text){
    const hits = [];
    ACCOUNT_WORDS.forEach(([id, re]) => { const m = text.match(re); if(m) hits.push({id, at: m.index}); });
    return hits.sort((a, b) => a.at - b.at).map(h => h.id);
  }

  function categoryOf(text, type, categories){
    const t = ' ' + text.toLowerCase().replace(/[^a-z0-9&' ]+/g, ' ') + ' ';
    let best = null, bestLen = 0;
    (categories || []).forEach(c => {
      if(type && c.type !== type) return;
      String(c.keywords || '').split(',').map(k => k.trim().toLowerCase()).filter(Boolean).forEach(k => {
        if(t.includes(' ' + k + ' ') || t.includes(' ' + k + 's ')){ if(k.length > bestLen){ best = c; bestLen = k.length; } }
      });
    });
    return best;
  }

  function partyOf(text, type){
    const re = type === 'income' ? /\b(?:from|by)\s+(.+?)(?=\s+(?:for|via|on|to|in|into|momo|mtn|bank|cash|yesterday|today)\b|[.,;]|$)/i
                                 : /\b(?:to|at)\s+(.+?)(?=\s+(?:for|via|on|from|momo|mtn|bank|cash|yesterday|today)\b|[.,;]|$)/i;
    let m = text.match(re);
    // "gave Eric 90k", "paid Aline 50k for editing": a capitalised name straight after the verb
    if(!m && type === 'expense') m = text.match(/\b(?:gave|paid|pay|sent|send)\s+([A-Z][\w'’-]+(?:\s+[A-Z][\w'’-]+)?)(?=\s)/);
    if(!m) return '';
    const p = m[1].trim();
    if(/^(momo|mtn|bank|cash|the bank|my|our)\b/i.test(p) || /^\d/.test(p)) return '';
    return p.slice(0, 120);
  }

  function parse(text, opts){
    opts = opts || {};
    const cats = opts.categories || [], now = opts.now || new Date(), defAcc = opts.defaultAccount || 'momo';
    const clean = String(text || '').trim().replace(/\s+/g, ' ');
    const out = {type: null, amount_rwf: null, account_id: null, to_account_id: null, category_id: null, party: '', happened_on: dateOf(clean, now), note: clean.slice(0, 500), missing: []};
    const amt = amountOf(clean.replace(/\b\d{1,2}[\/\-]\d{1,2}([\/\-]\d{2,4})?\b/g, ' '));
    if(amt) out.amount_rwf = amt.value; else out.missing.push('amount');
    const accs = accountsIn(clean);
    if(TRANSFER.test(clean) && accs.length >= 2){
      out.type = 'transfer'; out.account_id = accs[0]; out.to_account_id = accs[1];
      if(/\bfrom\b/i.test(clean) && /\bto\b/i.test(clean)){
        const f = clean.toLowerCase().search(/\bfrom\b/), tIdx = clean.toLowerCase().search(/\bto\b/);
        if(tIdx < f){ out.account_id = accs[1]; out.to_account_id = accs[0]; }
      }
      return out;
    }
    if(TRANSFER.test(clean) && accs.length === 1 && /withdr/i.test(clean)){ out.type = 'transfer'; out.account_id = accs[0]; out.to_account_id = accs[0] === 'cash' ? defAcc : 'cash'; return out; }
    if(INCOME.test(clean)) out.type = 'income';
    else if(EXPENSE.test(clean)) out.type = 'expense';
    const cat = categoryOf(clean, out.type, cats);
    if(!out.type && cat) out.type = cat.type;
    if(!out.type) out.missing.push('type');
    if(out.type){
      const c = cat && cat.type === out.type ? cat : null;
      out.category_id = c ? c.id : (out.type === 'income' ? 'other-income' : 'other-expense');
      out.party = partyOf(clean, out.type);
    }
    out.account_id = accs[0] || defAcc;
    return out;
  }
  return parse;
})();

// ---------------------------------------------------------------- helpers
async function hmacOk(req, body) {
  const secret = env("WHATSAPP_APP_SECRET");
  if (!secret) return false; // fail closed: without the app secret we cannot prove a message came from Meta
  const sig = (req.headers.get("x-hub-signature-256") || "").replace("sha256=", "");
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const mac = new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(body)));
  const hex = [...mac].map((b) => b.toString(16).padStart(2, "0")).join("");
  if (hex.length !== sig.length) return false;
  let diff = 0; for (let i = 0; i < hex.length; i++) diff |= hex.charCodeAt(i) ^ sig.charCodeAt(i);
  return diff === 0;
}

async function reply(to, text) {
  await fetch(`https://graph.facebook.com/v21.0/${env("WHATSAPP_PHONE_NUMBER_ID")}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${env("WHATSAPP_TOKEN")}`, "Content-Type": "application/json" },
    body: JSON.stringify({ messaging_product: "whatsapp", to, type: "text", text: { body: text.slice(0, 4000) } }),
  });
}

// Free first: Gemini (Google AI Studio free tier). Claude is used instead only if its paid key is set.
function readerPrompt(accounts, categories) {
  const today = todayKigali().toISOString().slice(0, 10);
  return "You turn one bookkeeping message from a Rwandan creative agency into JSON. It may be English, Kinyarwanda or French, or a forwarded MTN MoMo / Airtel Money / bank SMS, or a photo/PDF of a receipt or invoice. Amounts are in RWF (50k = 50000, 1.2m = 1200000). For a forwarded MoMo message, money received is income and money sent or paid is expense; the account is momo. A receipt is an expense unless it clearly shows money paid to us. " +
    "Reply with JSON only: {\"type\":\"income|expense|transfer|unknown\",\"amount_rwf\":number|null,\"account_id\":string,\"to_account_id\":string|null,\"category_id\":string|null,\"party\":string|null,\"happened_on\":\"YYYY-MM-DD\"}. " +
    `Today is ${today}. Accounts: ${accounts.map((a) => a.id + " (" + a.name + ")").join(", ")}. ` +
    `Categories: ${categories.map((c) => c.id + " (" + c.type + ": " + c.name + ")").join(", ")}. ` +
    "If it is not about money moving, use type unknown. Never invent an amount.";
}
function tidy(j, accounts, categories) {
  const today = todayKigali().toISOString().slice(0, 10);
  if (!j || !["income", "expense", "transfer"].includes(j.type) || !(j.amount_rwf > 0)) return null;
  if (!accounts.some((a) => a.id === j.account_id)) j.account_id = accounts[0].id;
  if (j.type === "transfer" && !accounts.some((a) => a.id === j.to_account_id)) return null;
  if (j.type !== "transfer" && !categories.some((c) => c.id === j.category_id && c.type === j.type)) j.category_id = j.type === "income" ? "other-income" : "other-expense";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(j.happened_on || "")) j.happened_on = today;
  return { ...j, amount_rwf: Math.round(j.amount_rwf), to_account_id: j.type === "transfer" ? j.to_account_id : null, category_id: j.type === "transfer" ? null : j.category_id, party: j.party || "", missing: [] };
}
async function askGemini(text, accounts, categories, img) {
  const key = env("GEMINI_API_KEY"); if (!key) return null;
  const model = Deno.env.get("GEMINI_MODEL") || "gemini-2.5-flash";
  const parts = [{ text: readerPrompt(accounts, categories) + "\n\nMessage: " + (text || (img ? "(receipt attached)" : "")) }];
  if (img) parts.push({ inline_data: { mime_type: img.mime, data: img.data } });
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ contents: [{ role: "user", parts }], generationConfig: { responseMimeType: "application/json", temperature: 0 } }),
  });
  if (!r.ok) { console.error("gemini", r.status, (await r.text()).slice(0, 300)); return null; }
  const d = await r.json();
  try { return tidy(JSON.parse((d.candidates?.[0]?.content?.parts?.[0]?.text || "").replace(/^```(json)?|```$/g, "").trim()), accounts, categories); } catch { return null; }
}
const canRead = () => !!(env("ANTHROPIC_API_KEY") || env("GEMINI_API_KEY"));
async function askReader(text, accounts, categories, img) {
  if (env("ANTHROPIC_API_KEY")) return askClaude(text, accounts, categories, img);
  return askGemini(text, accounts, categories, img);
}

async function askClaude(text, accounts, categories, img) {
  const key = env("ANTHROPIC_API_KEY");
  if (!key) return null;
  const image = img ? (/pdf/.test(img.mime) ? { type: "document", source: { type: "base64", media_type: "application/pdf", data: img.data } } : { type: "image", source: { type: "base64", media_type: img.mime, data: img.data } }) : null;
  const today = todayKigali().toISOString().slice(0, 10);
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({
      model: image ? "claude-sonnet-5-5" : "claude-haiku-5-5",
      max_tokens: 300,
      system: readerPrompt(accounts, categories),
      messages: [{ role: "user", content: image ? [image, { type: "text", text: "This is a receipt, invoice or payment screenshot. Book it. " + (text || "") }] : text }],
    }),
  });
  if (!r.ok) return null;
  const d = await r.json();
  try { return tidy(JSON.parse((d.content?.[0]?.text || "").replace(/^```(json)?|```$/g, "").trim()), accounts, categories); } catch { return null; }
}

const HELP = "*CRT books on WhatsApp*\n\n" +
  "Record money in plain words (English or Kinyarwanda):\n• paid 50k fuel momo\n• received 400k from Inka bank\n• +1.2m wedding Grace & Eric\n• moved 200k momo to bank\n\n" +
  "📷 Send a *photo or PDF of a receipt* and it's read and booked.\n📩 *Forward a MoMo message* and it's booked.\n\n" +
  "Who owes you:\n• Inka owes 400k for menu shoot\n• Inka paid 400k\n• *owed*: everyone who owes\n• *remind Inka*: a ready reminder to send them\n\n" +
  "Ask:\n• *today* · *week* · *report* (this month)\n• *balance*: money in each account\n• *undo*: remove your last entry";

function monthRange() {
  const d = todayKigali(), y = d.getFullYear(), m = d.getMonth();
  const f = (x) => x.toISOString().slice(0, 10);
  return [f(new Date(Date.UTC(y, m, 1))), f(new Date(Date.UTC(y, m + 1, 0))), d.toLocaleDateString("en-GB", { month: "long", year: "numeric" })];
}

async function handle(from, text, sender) {
  const t = text.trim(), lower = t.toLowerCase();
  const [{ data: accounts }, { data: categories }] = await Promise.all([
    sb.from("fin_accounts").select("id,name").eq("archived", false).order("sort"),
    sb.from("fin_categories").select("id,name,type,keywords").order("sort"),
  ]);
  const catName = (id) => (categories.find((c) => c.id === id) || { name: "" }).name;
  const accName = (id) => (accounts.find((a) => a.id === id) || { name: id }).name;

  if (/^(help|\?|hi|hello|menu|start)$/i.test(lower)) return reply(from, HELP);

  if (/^(balance|balances|bal)$/i.test(lower)) {
    const { data } = await sb.from("fin_balances").select("name,balance_rwf").order("sort");
    const total = data.reduce((s, a) => s + Number(a.balance_rwf), 0);
    return reply(from, "*Balances*\n" + data.map((a) => `${a.name}: ${rwf(a.balance_rwf)}`).join("\n") + `\n*Total: ${rwf(total)} RWF*`);
  }

  if (/^(report|summary|month|profit|p&l|pnl)$/i.test(lower)) {
    const [a, b, label] = monthRange();
    const { data } = await sb.from("fin_entries").select("type,amount_rwf,category_id").gte("happened_on", a).lte("happened_on", b).neq("type", "transfer");
    const sum = (ty) => data.filter((e) => e.type === ty).reduce((s, e) => s + Number(e.amount_rwf), 0);
    const top = {}; data.filter((e) => e.type === "expense").forEach((e) => top[e.category_id] = (top[e.category_id] || 0) + Number(e.amount_rwf));
    const tops = Object.entries(top).sort((x, y) => y[1] - x[1]).slice(0, 3).map(([k, v]) => `• ${catName(k)}: ${rwf(v)}`).join("\n");
    const inc = sum("income"), exp = sum("expense");
    return reply(from, `*${label}*\nMoney in: ${rwf(inc)}\nMoney out: ${rwf(exp)}\n*Profit: ${inc - exp < 0 ? "−" : ""}${rwf(Math.abs(inc - exp))} RWF*` + (tops ? `\n\nBiggest costs:\n${tops}` : ""));
  }

  if (/^(owed|owe|unpaid|invoices)$/i.test(lower)) {
    const { data } = await sb.from("fin_invoices").select("number,client,amount_rwf,due_on").eq("status", "sent").order("due_on");
    if (!data.length) return reply(from, "No unpaid invoices.");
    const total = data.reduce((s, i) => s + Number(i.amount_rwf), 0);
    return reply(from, "*Unpaid invoices*\n" + data.map((i) => `${i.number} · ${i.client}: ${rwf(i.amount_rwf)}${i.due_on ? " (due " + i.due_on + ")" : ""}`).join("\n") + `\n*Total: ${rwf(total)} RWF*`);
  }

  // who owes you: "Inka owes 400k for menu shoot"
  const owes = t.match(/^(.+?)\s+(?:owes|owe|is owing)\s+(?:us\s+)?(.+)$/i);
  if (owes) {
    const amt = parse(owes[2], { categories, now: todayKigali() }).amount_rwf;
    if (!amt) return reply(from, "How much? Try: \"Inka owes 400k for menu shoot\".");
    const client = owes[1].trim().slice(0, 120), desc = (owes[2].match(/\bfor\s+(.+)$/i) || [])[1] || "";
    const y = todayKigali().getFullYear();
    const { count } = await sb.from("fin_invoices").select("id", { count: "exact", head: true }).like("number", `INV-${y}-%`);
    const number = `INV-${y}-${String((count || 0) + 1).padStart(3, "0")}`;
    const due = new Date(todayKigali().getTime() + 14 * 864e5).toISOString().slice(0, 10);
    const { error } = await sb.from("fin_invoices").insert({ number, client, description: desc.slice(0, 500) || null, amount_rwf: amt, status: "sent", due_on: due });
    if (error) return reply(from, "Couldn't save that: " + error.message);
    return reply(from, `🧾 ${client} owes ${rwf(amt)} RWF (${number}, due ${due}).\nWhen they pay, send: *${client} paid ${rwf(amt)}*`);
  }
  // "remind Inka": a polite reminder to forward to the client
  const rem = t.match(/^remind\s+(.+)$/i);
  if (rem) {
    const { data } = await sb.from("fin_invoices").select("number,client,amount_rwf,due_on,description").eq("status", "sent").ilike("client", `%${rem[1].trim()}%`).order("due_on");
    if (!data?.length) return reply(from, `No unpaid invoice for "${rem[1].trim()}". Send *owed* to see who owes.`);
    const total = data.reduce((s2, i) => s2 + Number(i.amount_rwf), 0);
    return reply(from, `Forward this to ${data[0].client}:\n\n` +
      `Hello ${data[0].client}, a friendly reminder from CRT Media Agency: ${data.length > 1 ? data.length + " invoices are" : "invoice " + data[0].number + " is"} still open, ${rwf(total)} RWF in total${data[0].due_on ? " (due " + data[0].due_on + ")" : ""}. ` +
      "You can pay by MoMo to 0796 356 035 or by bank transfer. Thank you!");
  }
  if (/^(today|leo|uyu munsi)$/i.test(lower) || /^(week|this week|icyumweru)$/i.test(lower)) {
    const week = /week|icyumweru/i.test(lower), d = todayKigali();
    const from_ = new Date(d); if (week) from_.setDate(d.getDate() - ((d.getDay() + 6) % 7));
    const a = from_.toISOString().slice(0, 10), b = d.toISOString().slice(0, 10);
    const { data } = await sb.from("fin_entries").select("type,amount_rwf,category_id,party,note").gte("happened_on", a).lte("happened_on", b).neq("type", "transfer").order("id", { ascending: false });
    const inc = data.filter((e) => e.type === "income").reduce((x, e) => x + Number(e.amount_rwf), 0), exp = data.filter((e) => e.type === "expense").reduce((x, e) => x + Number(e.amount_rwf), 0);
    const lines = data.slice(0, 8).map((e) => `${e.type === "income" ? "＋" : "−"} ${rwf(e.amount_rwf)} · ${e.party || catName(e.category_id)}`).join("\n");
    return reply(from, `*${week ? "This week" : "Today"}*\nMoney in: ${rwf(inc)}\nMoney out: ${rwf(exp)}\n*Net: ${inc - exp < 0 ? "−" : ""}${rwf(Math.abs(inc - exp))} RWF*` + (lines ? `\n\n${lines}` : "\n\nNothing recorded yet."));
  }

  if (/^undo$/i.test(lower)) {
    const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const { data } = await sb.from("fin_entries").select("id,type,amount_rwf,note").eq("source", "whatsapp").eq("created_by_name", sender.name).gte("created_at", since).order("id", { ascending: false }).limit(1);
    if (!data.length) return reply(from, "Nothing to undo from the last hour.");
    await sb.from("fin_entries").delete().eq("id", data[0].id);
    return reply(from, `↩️ Removed: ${TYPE[data[0].type]} ${rwf(data[0].amount_rwf)} RWF ("${data[0].note || ""}")`);
  }

  let p = parse(t, { categories, defaultAccount: accounts[0]?.id, now: todayKigali() });
  let invoice = null;
  const paidBy = t.match(/^(.+?)\s+(?:paid|has paid|yishyuye)\b/i);
  const payer = paidBy ? paidBy[1].trim() : "";
  if (payer.length >= 3 && !/^(i|we|me|us|our|my|nous|je|nti|twe|njye)$/i.test(payer) && p.amount_rwf) {
    const { data: inv } = await sb.from("fin_invoices").select("id,number,client,amount_rwf").eq("status", "sent").ilike("client", `${payer}%`).order("due_on").limit(1).maybeSingle();
    if (inv) { invoice = inv; p = { ...p, type: "income", party: inv.client, category_id: categories.some((c) => c.id === p.category_id && c.type === "income") ? p.category_id : "other-income", missing: p.missing.filter((m) => m !== "type") }; }
  }
  if (p.missing.length) p = (await askReader(t, accounts, categories)) || p;
  if (p.missing.length) {
    return reply(from, `I couldn't tell ${p.missing.map((m) => m === "amount" ? "the amount" : "if money came in or went out").join(" or ")}.\nTry: "paid 50k fuel momo" or "received 400k from Inka bank". Send *help* for more.`);
  }
  const row = {
    type: p.type, amount_rwf: p.amount_rwf, happened_on: p.happened_on, account_id: p.account_id, to_account_id: p.to_account_id,
    category_id: p.category_id, party: p.party || null, note: t.slice(0, 500), raw_message: t.slice(0, 1000),
    source: "whatsapp", created_by: sender.user_id, created_by_name: sender.name, invoice_id: invoice?.id ?? null,
  };
  const { error } = await sb.from("fin_entries").insert(row);
  if (error) return reply(from, "Couldn't save that: " + error.message);
  if (invoice && p.amount_rwf >= Number(invoice.amount_rwf)) await sb.from("fin_invoices").update({ status: "paid" }).eq("id", invoice.id);
  const what = p.type === "transfer" ? `${accName(p.account_id)} → ${accName(p.to_account_id)}` : `${catName(p.category_id)} · ${accName(p.account_id)}${p.party ? " · " + p.party : ""}`;
  return reply(from, `✅ ${TYPE[p.type]} ${rwf(p.amount_rwf)} RWF\n${what}\n${p.happened_on}` + (invoice ? `\n🧾 ${invoice.number} ${p.amount_rwf >= Number(invoice.amount_rwf) ? "is now paid" : "part-paid"}` : "") + `\n\nWrong? Reply *undo*, or fix it in the dashboard.`);
}

// ---------------------------------------------------------------- receipt photos and PDFs
async function mediaBytes(id) {
  const meta = await fetch(`https://graph.facebook.com/v21.0/${id}`, { headers: { Authorization: `Bearer ${env("WHATSAPP_TOKEN")}` } }).then((r) => r.json());
  if (!meta?.url) throw new Error("no media url");
  const r = await fetch(meta.url, { headers: { Authorization: `Bearer ${env("WHATSAPP_TOKEN")}` } });
  return { bytes: new Uint8Array(await r.arrayBuffer()), type: meta.mime_type || r.headers.get("content-type") || "application/octet-stream" };
}
async function handleReceipt(from, m, sender) {
  if (!canRead()) return reply(from, "Receipts need the free reading key (Dashboard → Finance → WhatsApp books → Gemini key). For now, type it: \"paid 25k printing cash\".");
  const media = m.type === "image" ? m.image : m.document;
  const { bytes, type } = await mediaBytes(media.id);
  if (bytes.length > 10e6) return reply(from, "That file is too big. Send a photo instead.");
  let b = ""; for (let i = 0; i < bytes.length; i += 0x8000) b += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  const isPdf = /pdf/.test(type), img = { mime: isPdf ? "application/pdf" : (/png|webp|gif/.test(type) ? type : "image/jpeg"), data: btoa(b) };
  const [{ data: accounts }, { data: categories }] = await Promise.all([
    sb.from("fin_accounts").select("id,name").eq("archived", false).order("sort"),
    sb.from("fin_categories").select("id,name,type,keywords").order("sort"),
  ]);
  const p = await askReader(media.caption || "", accounts, categories, img);
  if (!p) return reply(from, "I couldn't read an amount on that. Type it instead, e.g. \"paid 25k printing cash\".");
  const path = `${new Date().toISOString().slice(0, 7)}/${crypto.randomUUID()}.${isPdf ? "pdf" : (type.split("/")[1] || "jpg").replace("jpeg", "jpg")}`;
  await sb.storage.from("receipts").upload(path, bytes, { contentType: type, upsert: false });
  const { error } = await sb.from("fin_entries").insert({ type: p.type, amount_rwf: p.amount_rwf, happened_on: p.happened_on, account_id: p.account_id, to_account_id: p.to_account_id,
    category_id: p.category_id, party: p.party || null, note: (media.caption || "Receipt").slice(0, 500), raw_message: "[receipt " + (isPdf ? "PDF" : "photo") + "]",
    source: "whatsapp", created_by: sender.user_id, created_by_name: sender.name, receipt_path: path });
  if (error) return reply(from, "Couldn't save that: " + error.message);
  const cat = (categories.find((c) => c.id === p.category_id) || { name: "" }).name, acc = (accounts.find((a) => a.id === p.account_id) || { name: p.account_id }).name;
  return reply(from, `✅ From the receipt: ${TYPE[p.type]} ${rwf(p.amount_rwf)} RWF\n${cat} · ${acc}${p.party ? " · " + p.party : ""}\n${p.happened_on}\n📎 Receipt saved\n\nWrong amount or account? Reply *undo* and type it.`);
}

// ---------------------------------------------------------------- evening reminder and Monday summary
async function runTask(task) {
  const { data: senders } = await sb.from("fin_whatsapp_senders").select("phone,name,user_id,remind,last_message_at");
  const today = todayKigali().toISOString().slice(0, 10), sent = [];
  for (const s of senders || []) {
    if (!s.remind) continue;
    // WhatsApp lets a business write freely only within 24 hours of the person's last message
    if (!s.last_message_at || Date.now() - new Date(s.last_message_at).getTime() > 23.5 * 3600e3) continue;
    if (task === "reminder") {
      const { count } = await sb.from("fin_entries").select("id", { count: "exact", head: true }).eq("happened_on", today).eq("created_by_name", s.name);
      if (count) continue;
      await reply(s.phone, `Good evening ${s.name.split(" ")[0]} 👋 Nothing recorded today. Any money in or out? Just type it, e.g. "paid 20k fuel momo", or send a receipt photo. Reply *stop reminders* to turn this off.`);
      sent.push(s.phone);
    } else if (task === "weekly") {
      await handle(s.phone, "week", s); sent.push(s.phone);
    }
  }
  return new Response(JSON.stringify({ ok: true, sent: sent.length }), { headers: { "Content-Type": "application/json" } });
}

// ---------------------------------------------------------------- dashboard (main admin): keys and status
const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const out = (b, st = 200) => new Response(JSON.stringify(b), { status: st, headers: { ...CORS, "Content-Type": "application/json" } });
async function dashboard(req) {
  const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
  const { data: au } = await sb.auth.getUser(token); const user = au?.user;
  if (!user) return out({ error: "signed_out" }, 401);
  const { data: member } = await sb.from("team").select("role").eq("user_id", user.id).maybeSingle();
  if (member?.role !== "owner") return out({ error: "owner_only" }, 403);
  const body = await req.json().catch(() => ({}));
  const rnd = () => [...crypto.getRandomValues(new Uint8Array(24))].map((x) => x.toString(16).padStart(2, "0")).join("");
  for (const k of ["WHATSAPP_VERIFY_TOKEN", "FIN_CRON_SECRET"]) if (!env(k)) { const v = rnd(); await sb.from("app_secrets").upsert({ name: k, value: v }); SECRETS[k] = v; }
  if (body.action === "save" && body.values) {
    for (const k of ["WHATSAPP_TOKEN", "WHATSAPP_PHONE_NUMBER_ID", "WHATSAPP_APP_SECRET", "ANTHROPIC_API_KEY", "GEMINI_API_KEY"]) {
      const v = String(body.values[k] ?? "").trim(); if (v) { await sb.from("app_secrets").upsert({ name: k, value: v.slice(0, 600), updated_at: new Date().toISOString() }); SECRETS[k] = v; }
    }
  }
  if (body.action === "receipt") {
    const { data, error } = await sb.storage.from("receipts").createSignedUrl(String(body.path || ""), 600);
    return error ? out({ error: "not_found" }, 404) : out({ url: data.signedUrl });
  }
  if (body.action === "test") {
    const to = String(body.phone || "").replace(/\D/g, "");
    const r = await fetch(`https://graph.facebook.com/v21.0/${env("WHATSAPP_PHONE_NUMBER_ID")}/messages`, { method: "POST", headers: { Authorization: `Bearer ${env("WHATSAPP_TOKEN")}`, "Content-Type": "application/json" },
      body: JSON.stringify({ messaging_product: "whatsapp", to, type: "template", template: { name: "hello_world", language: { code: "en_US" } } }) });
    const j = await r.json().catch(() => ({}));
    return r.ok ? out({ ok: true }) : out({ error: "send_failed", detail: j?.error?.message || r.status }, 400);
  }
  return out({ webhook: Deno.env.get("SUPABASE_URL") + "/functions/v1/finance-whatsapp", verify_token: env("WHATSAPP_VERIFY_TOKEN"),
    set: Object.fromEntries(["WHATSAPP_TOKEN", "WHATSAPP_PHONE_NUMBER_ID", "WHATSAPP_APP_SECRET", "ANTHROPIC_API_KEY", "GEMINI_API_KEY"].map((k) => [k, !!env(k)])) });
}

// ---------------------------------------------------------------- webhook
Deno.serve(async (req) => {
  const url = new URL(req.url);
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  await loadSecrets();
  if (req.method === "POST" && req.headers.get("x-crt-cron") !== null) {
    if (!env("FIN_CRON_SECRET") || req.headers.get("x-crt-cron") !== env("FIN_CRON_SECRET")) return new Response("Forbidden", { status: 403 });
    const b = await req.json().catch(() => ({})); return runTask(String(b.task || ""));
  }
  if (req.method === "POST" && !req.headers.get("x-hub-signature-256") && /^Bearer\s+\S+\.\S+\.\S+/.test(req.headers.get("Authorization") || "")) return dashboard(req);
  if (req.method === "GET") {
    // Meta checks the webhook once when you save it
    const ok = url.searchParams.get("hub.mode") === "subscribe" && url.searchParams.get("hub.verify_token") === env("WHATSAPP_VERIFY_TOKEN") && env("WHATSAPP_VERIFY_TOKEN");
    return ok ? new Response(url.searchParams.get("hub.challenge") ?? "") : new Response("Forbidden", { status: 403 });
  }
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const body = await req.text();
  if (!(await hmacOk(req, body))) return new Response("Bad signature", { status: 401 });
  let payload; try { payload = JSON.parse(body); } catch { return new Response("ok"); }
  const msgs = (payload.entry ?? []).flatMap((e) => (e.changes ?? []).flatMap((c) => c.value?.messages ?? []));
  for (const m of msgs) {
    const from = String(m.from || "").replace(/\D/g, "");
    try {
      const { data: sender } = await sb.from("fin_whatsapp_senders").select("phone,name,user_id").eq("phone", from).maybeSingle();
      if (!sender) continue; // not on the list: ignore silently
      await sb.from("fin_whatsapp_senders").update({ last_message_at: new Date().toISOString() }).eq("phone", from);
      // Meta re-sends a message when it doesn't get a fast 200. Record each message id once, so money is never booked twice.
      if (m.id) {
        const { error: seen } = await sb.from("fin_whatsapp_seen").insert({ message_id: String(m.id).slice(0, 200) });
        if (seen) { if (seen.code === "23505") continue; console.error(seen); }
      }
      if (m.type === "image" || m.type === "document") { await handleReceipt(from, m, sender); continue; }
      if (m.type === "audio") { await reply(from, "Voice notes can't be read yet. Type it, e.g. \"paid 50k fuel momo\", or send a receipt photo."); continue; }
      if (m.type !== "text") { await reply(from, "Send it as text, e.g. \"paid 50k fuel momo\". Send *help* for examples."); continue; }
      const txt = m.text?.body ?? "";
      if (/^stop reminders?$/i.test(txt.trim())) { await sb.from("fin_whatsapp_senders").update({ remind: false }).eq("phone", from); await reply(from, "Evening reminders are off. Send *start reminders* to turn them back on."); continue; }
      if (/^start reminders?$/i.test(txt.trim())) { await sb.from("fin_whatsapp_senders").update({ remind: true }).eq("phone", from); await reply(from, "Evening reminders are on (19:00, only on days with nothing recorded)."); continue; }
      await handle(from, txt, sender);
    } catch (err) {
      console.error(err);
      try { await reply(from, "Something went wrong saving that. Please add it in the dashboard."); } catch {}
    }
  }
  return new Response("ok"); // always 200, or Meta retries
});
