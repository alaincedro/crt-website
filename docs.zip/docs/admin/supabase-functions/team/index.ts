// CRT dashboard: team accounts and the phone code at sign-in. Supabase Edge Function "team".
// Runs inside Supabase with the service key Supabase provides (never in the website files).
//
// Actions (POST JSON {action, ...}, called by the signed-in dashboard):
//   status         → is the code required, is this sign-in verified, which phone it goes to, must the password change
//   send_code      → texts a 6-digit code to the member's phone (10 minutes, one per 45 seconds)
//   verify_code    → checks it (5 tries); the sign-in then counts as verified for 30 days
//   password_set   → clears "choose your own password" after the first sign-in
//   app_setup / app_confirm / app_remove → codes from an authenticator app instead of (or as well as) text messages
//   main admin only: create_member, update_member, remove_member, reset_password, set_security
//
// Connection keys are entered by the main admin in the dashboard (Team → Connections) and kept in the locked table
// public.app_secrets, which only server functions can read. (Supabase secrets with the same names also work.)
//   Text messages, ONE of:  Africa's Talking: AT_USERNAME, AT_API_KEY, optional AT_SENDER_ID
//                           Twilio:           TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM
//   Mailbox (Inbox tab):     ZOHO_CLIENT_ID, ZOHO_CLIENT_SECRET, ZOHO_REFRESH_TOKEN
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

let SECRETS: Record<string, string> = {};
const env = (k: string) => Deno.env.get(k) || SECRETS[k] || "";
const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
const KEYS = ["AT_USERNAME", "AT_API_KEY", "AT_SENDER_ID", "TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_FROM", "ZOHO_CLIENT_ID", "ZOHO_CLIENT_SECRET", "ZOHO_REFRESH_TOKEN"];
async function loadSecrets() {
  const { data } = await db.from("app_secrets").select("name,value");
  SECRETS = Object.fromEntries((data || []).map((r: { name: string; value: string }) => [r.name, r.value]));
}
const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });
const PHONE = /^\+[1-9][0-9]{7,14}$/;
const hint = (p?: string | null) => p ? p.slice(0, 4) + " " + "•".repeat(Math.max(0, p.length - 7)) + " " + p.slice(-3) : "";

async function sha(s: string) {
  const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join("");
}
function sessionId(token: string) {
  try { const p = JSON.parse(atob(token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"))); return p.session_id || ""; } catch { return ""; }
}
function tempPassword() {
  const abc = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
  const r = crypto.getRandomValues(new Uint32Array(14));
  return [...r].map((n) => abc[n % abc.length]).join("").replace(/(.{4})(.{5})(.{5})/, "$1-$2-$3");
}
// ---- authenticator app codes (RFC 6238: 6 digits, 30 seconds), checked here; the key never leaves the server after setup
const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
function b32enc(u8: Uint8Array) { let bits = 0, val = 0, out = ""; for (const b of u8) { val = (val << 8) | b; bits += 8; while (bits >= 5) { out += B32[(val >>> (bits - 5)) & 31]; bits -= 5; } } if (bits > 0) out += B32[(val << (5 - bits)) & 31]; return out; }
function b32dec(s: string) { let bits = 0, val = 0; const out: number[] = []; for (const c of s.replace(/=+$/, "").toUpperCase()) { const i = B32.indexOf(c); if (i < 0) continue; val = (val << 5) | i; bits += 5; if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; } } return new Uint8Array(out); }
async function totpAt(secret: string, step: number) {
  const key = await crypto.subtle.importKey("raw", b32dec(secret), { name: "HMAC", hash: "SHA-1" }, false, ["sign"]);
  const msg = new Uint8Array(8); let x = step; for (let i = 7; i >= 0; i--) { msg[i] = x & 255; x = Math.floor(x / 256); }
  const h = new Uint8Array(await crypto.subtle.sign("HMAC", key, msg)); const o = h[19] & 15;
  return String((((h[o] & 127) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3]) % 1e6).padStart(6, "0");
}
async function totpCheck(secret: string, code: string, after = 0) {   // returns the matching step, or 0
  const now = Math.floor(Date.now() / 30000), c = String(code || "").replace(/\D/g, "");
  if (c.length !== 6) return 0;
  for (const st of [now - 1, now, now + 1]) if (st > after && (await totpAt(secret, st)) === c) return st;
  return 0;
}

function provider() {
  if (env("AT_USERNAME") && env("AT_API_KEY")) return "africastalking";
  if (env("TWILIO_ACCOUNT_SID") && env("TWILIO_AUTH_TOKEN") && env("TWILIO_FROM")) return "twilio";
  return "";
}
async function sendSms(to: string, text: string) {
  const p = provider();
  if (p === "africastalking") {
    const form = new URLSearchParams({ username: env("AT_USERNAME"), to, message: text });
    if (env("AT_SENDER_ID")) form.set("from", env("AT_SENDER_ID"));
    const host = env("AT_USERNAME") === "sandbox" ? "api.sandbox.africastalking.com" : "api.africastalking.com";
    const r = await fetch(`https://${host}/version1/messaging`, { method: "POST", headers: { apiKey: env("AT_API_KEY"), Accept: "application/json", "Content-Type": "application/x-www-form-urlencoded" }, body: form });
    const j = await r.json().catch(() => ({}));
    const rec = j?.SMSMessageData?.Recipients?.[0];
    if (!r.ok || !rec || !/success/i.test(rec.status || "")) throw new Error("sms_failed: " + (rec?.status || j?.SMSMessageData?.Message || r.status));
    return;
  }
  if (p === "twilio") {
    const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${env("TWILIO_ACCOUNT_SID")}/Messages.json`, {
      method: "POST",
      headers: { Authorization: "Basic " + btoa(env("TWILIO_ACCOUNT_SID") + ":" + env("TWILIO_AUTH_TOKEN")), "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ To: to, From: env("TWILIO_FROM"), Body: text }),
    });
    if (!r.ok) throw new Error("sms_failed: " + (await r.text()).slice(0, 160));
    return;
  }
  throw new Error("no_sms_provider");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ error: "method" }, 405);
  await loadSecrets();
  const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
  const { data: au } = await db.auth.getUser(token);
  const user = au?.user; if (!user) return json({ error: "signed_out" }, 401);
  const sid = sessionId(token);
  const body = await req.json().catch(() => ({}));
  const action = String(body.action || "");

  const { data: member } = await db.from("team").select("user_id,name,role,phone,email").eq("user_id", user.id).maybeSingle();
  if (!member) return json({ error: "not_on_team" }, 403);
  const { data: sec } = await db.from("security_settings").select("require_code").eq("id", 1).maybeSingle();
  const required = !!sec?.require_code;
  const { data: row } = sid ? await db.from("login_codes").select("*").eq("user_id", user.id).eq("session_id", sid).maybeSingle() : { data: null };
  const verified = !!(row?.verified_at && Date.now() - new Date(row.verified_at).getTime() < 30 * 864e5);
  const { data: mfa } = await db.from("member_mfa").select("*").eq("user_id", user.id).maybeSingle();
  const appOn = !!mfa?.active, smsOn = !!(member.phone && provider());
  const markVerified = async () => db.from("login_codes").upsert({ user_id: user.id, session_id: sid, code_hash: "app", sent_at: new Date().toISOString(),
    expires_at: new Date().toISOString(), attempts: 0, verified_at: new Date().toISOString() });

  if (action === "status") {
    return json({ require_code: required, verified: !required || verified, code_ok: verified, phone_hint: hint(member.phone), has_phone: !!member.phone,
      role: member.role, must_change: !!user.user_metadata?.must_change_password, provider: provider() || null,
      app: appOn, sms: smsOn, method: appOn ? "app" : smsOn ? "sms" : "none" });
  }
  if (action === "send_code") {
    if (!smsOn) return appOn ? json({ method: "app" }) : json({ error: member.phone ? "no_sms_provider" : "no_method" }, 400);
    if (body.prefer !== "sms" && appOn) return json({ method: "app" });
    if (!sid) return json({ error: "no_session" }, 400);
    if (row?.sent_at && Date.now() - new Date(row.sent_at).getTime() < 45e3 && !row.verified_at) return json({ error: "wait", seconds: 45 }, 429);
    const code = String(crypto.getRandomValues(new Uint32Array(1))[0] % 1e6).padStart(6, "0");
    await db.from("login_codes").upsert({ user_id: user.id, session_id: sid, code_hash: await sha(code + sid + user.id), sent_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + 10 * 6e4).toISOString(), attempts: 0, verified_at: null });
    try { await sendSms(member.phone, `${code} is your CRT dashboard code. It expires in 10 minutes. Never share it.`); }
    catch (e) { return json({ error: String((e as Error).message).startsWith("no_sms") ? "no_sms_provider" : "sms_failed", detail: String((e as Error).message).slice(0, 200) }, 503); }
    return json({ sent: true, phone_hint: hint(member.phone) });
  }
  if (action === "verify_code") {
    if (!sid) return json({ error: "no_session" }, 400);
    if (appOn) {
      const st = await totpCheck(mfa.secret, body.code, Number(mfa.last_step) || 0);
      if (st) { await db.from("member_mfa").update({ last_step: st }).eq("user_id", user.id); await markVerified(); return json({ verified: true, method: "app" }); }
      if (!row || row.code_hash === "app") return json({ error: "wrong_code", left: 4 }, 400);
    }
    if (!row) return json({ error: "no_code" }, 400);
    if (new Date(row.expires_at).getTime() < Date.now()) return json({ error: "expired" }, 400);
    if (row.attempts >= 5) return json({ error: "too_many" }, 429);
    const ok = (await sha(String(body.code || "").replace(/\D/g, "") + sid + user.id)) === row.code_hash;
    if (!ok) { await db.from("login_codes").update({ attempts: row.attempts + 1 }).eq("user_id", user.id).eq("session_id", sid); return json({ error: "wrong_code", left: 4 - row.attempts }, 400); }
    await db.from("login_codes").update({ verified_at: new Date().toISOString() }).eq("user_id", user.id).eq("session_id", sid);
    return json({ verified: true });
  }
  if (action === "app_setup") {
    // first setup is allowed straight after the password only for someone with no other way to get a code
    if (required && !verified && (appOn || smsOn)) return json({ error: "verify_first" }, 403);
    const secret = b32enc(crypto.getRandomValues(new Uint8Array(20)));
    await db.from("member_mfa").upsert({ user_id: user.id, pending: secret, secret: mfa?.secret ?? null, active: !!mfa?.active, updated_at: new Date().toISOString() });
    const label = encodeURIComponent("CRT Dashboard:" + (member.email || user.email || "team"));
    return json({ secret, uri: `otpauth://totp/${label}?secret=${secret}&issuer=${encodeURIComponent("CRT Dashboard")}&digits=6&period=30` });
  }
  if (action === "app_confirm") {
    if (!mfa?.pending) return json({ error: "no_setup" }, 400);
    const st = await totpCheck(mfa.pending, body.code);
    if (!st) return json({ error: "wrong_code" }, 400);
    await db.from("member_mfa").update({ secret: mfa.pending, pending: null, active: true, last_step: st, updated_at: new Date().toISOString() }).eq("user_id", user.id);
    if (sid) await markVerified();
    return json({ ok: true });
  }
  if (action === "app_remove") {
    const uid = String(body.user_id || user.id);
    if (uid !== user.id && member.role !== "owner") return json({ error: "owner_only" }, 403);
    if (required && !verified) return json({ error: "verify_first" }, 403);
    await db.from("member_mfa").delete().eq("user_id", uid);
    return json({ ok: true });
  }
  if (action === "password_set") {
    await db.auth.admin.updateUserById(user.id, { user_metadata: { ...user.user_metadata, must_change_password: false } });
    return json({ ok: true });
  }

  // ---- main admin only, and only from a verified sign-in
  if (member.role !== "owner") return json({ error: "owner_only" }, 403);
  if (required && !verified) return json({ error: "verify_first" }, 403);

  if (action === "create_member") {
    const email = String(body.email || "").trim().toLowerCase(), name = String(body.name || "").trim().slice(0, 80);
    const phone = String(body.phone || "").replace(/[\s()-]/g, ""), role = body.role === "admin" ? "admin" : "staff";
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json({ error: "bad_email" }, 400);
    if (!name) return json({ error: "bad_name" }, 400);
    if (phone && !PHONE.test(phone)) return json({ error: "bad_phone" }, 400);
    const password = tempPassword();
    const { data: made, error } = await db.auth.admin.createUser({ email, password, email_confirm: true, user_metadata: { name, must_change_password: true } });
    if (error || !made?.user) return json({ error: /already/i.test(error?.message || "") ? "email_taken" : "create_failed", detail: error?.message }, 400);
    const { error: e2 } = await db.from("team").insert({ user_id: made.user.id, name, role, phone: phone || null, email });
    if (e2) { await db.auth.admin.deleteUser(made.user.id); return json({ error: "create_failed", detail: e2.message }, 400); }
    return json({ ok: true, user_id: made.user.id, password });
  }
  if (action === "update_member") {
    const uid = String(body.user_id || ""), patch: Record<string, unknown> = {};
    if (typeof body.name === "string") patch.name = body.name.trim().slice(0, 80);
    if (typeof body.phone === "string") { const p = body.phone.replace(/[\s()-]/g, ""); if (p && !PHONE.test(p)) return json({ error: "bad_phone" }, 400); patch.phone = p || null; }
    if (typeof body.role === "string") { if (uid === user.id) return json({ error: "own_role" }, 400); patch.role = body.role === "admin" ? "admin" : "staff"; }
    const { error } = await db.from("team").update(patch).eq("user_id", uid);
    return error ? json({ error: "update_failed", detail: error.message }, 400) : json({ ok: true });
  }
  if (action === "remove_member") {
    const uid = String(body.user_id || ""); if (!uid || uid === user.id) return json({ error: "cannot_remove_self" }, 400);
    const { error } = await db.auth.admin.deleteUser(uid);
    return error ? json({ error: "remove_failed", detail: error.message }, 400) : json({ ok: true });
  }
  if (action === "reset_password") {
    const uid = String(body.user_id || ""); if (!uid || uid === user.id) return json({ error: "own_password" }, 400);
    const { data: u } = await db.auth.admin.getUserById(uid);
    const password = tempPassword();
    const { error } = await db.auth.admin.updateUserById(uid, { password, user_metadata: { ...(u?.user?.user_metadata || {}), must_change_password: true } });
    return error ? json({ error: "reset_failed", detail: error.message }, 400) : json({ ok: true, password });
  }
  if (action === "connections") {
    // which keys are set (never the keys themselves)
    return json({ set: Object.fromEntries(KEYS.map((k) => [k, !!env(k)])), provider: provider() || null });
  }
  if (action === "save_connections") {
    const vals = (body.values || {}) as Record<string, unknown>;
    for (const k of Object.keys(vals)) {
      if (!KEYS.includes(k)) continue;
      const v = String(vals[k] ?? "").trim();
      if (v) await db.from("app_secrets").upsert({ name: k, value: v.slice(0, 500), updated_at: new Date().toISOString() });
      else await db.from("app_secrets").delete().eq("name", k);
    }
    await loadSecrets();
    return json({ ok: true, set: Object.fromEntries(KEYS.map((k) => [k, !!env(k)])), provider: provider() || null });
  }
  if (action === "test_sms") {
    if (!member.phone) return json({ error: "no_phone" }, 400);
    try { await sendSms(member.phone, "CRT dashboard: text messages are connected."); return json({ ok: true, phone_hint: hint(member.phone) }); }
    catch (e) { return json({ error: String((e as Error).message).startsWith("no_sms") ? "no_sms_provider" : "sms_failed", detail: String((e as Error).message).slice(0, 200) }, 400); }
  }
  if (action === "set_security") {
    const on = !!body.require_code;
    if (on) {
      if (!appOn && !smsOn) return json({ error: "no_method" }, 400);
      if (!verified) return json({ error: "test_code_first" }, 400);   // proves a code reaches the main admin before anyone depends on it
    }
    await db.from("security_settings").update({ require_code: on, updated_at: new Date().toISOString() }).eq("id", 1);
    return json({ ok: true, require_code: on });
  }
  return json({ error: "unknown_action" }, 400);
});
