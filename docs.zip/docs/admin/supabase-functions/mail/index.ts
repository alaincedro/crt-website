// CRT mail: the @crt.rw mailboxes in the dashboard. Supabase Edge Function "mail".
//
// Receiving (free): Resend receives mail for @crt.rw (one MX record) and notifies this function ("email.received"
//   webhook, signed). The original message is downloaded, parsed and stored in public.mail_messages; attachments go to
//   the private "mail" bucket. (A Cloudflare Email Worker, admin/MAIL-WORKER.js, also works instead.)
// Sending: through Resend (key in Team → Connections: RESEND_API_KEY), from name <mailbox@crt.rw>; a copy is kept in Sent.
// Dashboard actions (signed in): send, file (short-lived link to an attachment), setup (main admin: receiving key + worker).
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";
import PostalMime from "npm:postal-mime@2.2.7";

const DOMAIN = "crt.rw";
const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-crt-mail-secret", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });
let SECRETS: Record<string, string> = {};
const sec = (k: string) => Deno.env.get(k) || SECRETS[k] || "";
async function loadSecrets() {
  const { data } = await db.from("app_secrets").select("name,value").in("name", ["RESEND_API_KEY", "MAIL_INBOUND_SECRET", "RESEND_WEBHOOK_SECRET"]);
  SECRETS = Object.fromEntries((data || []).map((r: { name: string; value: string }) => [r.name, r.value]));
}
const clean = (s: string) => String(s || "").normalize("NFKD").replace(/[^\w.\- ]+/g, "").replace(/\s+/g, "-").slice(0, 80) || "file";
const b64 = (u8: Uint8Array) => { let s = ""; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode(...u8.subarray(i, i + 0x8000)); return btoa(s); };
const unb64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
const addr = (a: unknown) => String((a as { address?: string })?.address || a || "").trim().toLowerCase();
const random = (n = 32) => [...crypto.getRandomValues(new Uint8Array(n))].map((x) => x.toString(16).padStart(2, "0")).join("");

async function storeFiles(box: string, files: { name: string; type: string; bytes: Uint8Array }[]) {
  const out = [];
  for (const f of files.slice(0, 20)) {
    if (!f.bytes?.length) continue;
    const path = `${box}/${new Date().toISOString().slice(0, 10)}/${random(6)}-${clean(f.name)}`;
    const { error } = await db.storage.from("mail").upload(path, f.bytes, { contentType: f.type || "application/octet-stream", upsert: false });
    if (!error) out.push({ name: f.name || "file", path, size: f.bytes.length, type: f.type || "" });
  }
  return out;
}

// A copy of a website enquiry or review (filed into hello@ by the database) to the mailbox's forward addresses.
async function forwardCopy(id: number) {
  const { data: m } = await db.from("mail_messages").select("*").eq("id", id).maybeSingle();
  if (!m) return json({ error: "not_found" }, 404);
  const { data: box } = await db.from("mailboxes").select("local,display_name,forward_to").eq("local", m.mailbox).maybeSingle();
  if (!box?.forward_to?.length || !sec("RESEND_API_KEY")) return json({ skipped: true });
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST", headers: { Authorization: `Bearer ${sec("RESEND_API_KEY")}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from: `${(m.from_name || "CRT website").replace(/[<>"]/g, "").slice(0, 60)} via CRT <${box.local}@${DOMAIN}>`, to: box.forward_to.slice(0, 5), subject: m.subject,
      text: m.text_body || undefined, html: m.html_body || undefined,
      reply_to: /@/.test(m.from_addr) && !m.from_addr.endsWith("@" + DOMAIN) ? m.from_addr : undefined }),
  });
  return r.ok ? json({ ok: true }) : json({ error: "send_failed", detail: (await r.text()).slice(0, 200) }, 502);
}

async function inbound(req: Request) {
  if (!sec("MAIL_INBOUND_SECRET") || req.headers.get("x-crt-mail-secret") !== sec("MAIL_INBOUND_SECRET")) return json({ error: "forbidden" }, 403);
  const body = await req.json().catch(() => ({}));
  if (body.forward_id) return forwardCopy(Number(body.forward_id));
  return store(addr(body.to), String(body.raw || ""), addr(body.from), false);
}

// Resend's "email.received" webhook (Svix-signed). The webhook carries no body, so the original is downloaded.
async function resendInbound(req: Request) {
  const raw = await req.text();
  const secret = sec("RESEND_WEBHOOK_SECRET");
  if (!secret) return json({ error: "not_set_up" }, 403);
  const id = req.headers.get("svix-id") || "", ts = req.headers.get("svix-timestamp") || "", sigs = req.headers.get("svix-signature") || "";
  if (!id || !ts || Math.abs(Date.now() / 1000 - Number(ts)) > 600) return json({ error: "bad_signature" }, 401);
  let sk: Uint8Array; try { sk = unb64(secret.replace(/\s+/g, "").replace(/^whsec_/, "")); } catch { console.error("RESEND_WEBHOOK_SECRET is not a valid whsec_ secret"); return json({ error: "bad_secret" }, 401); }
  const key = await crypto.subtle.importKey("raw", sk, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const mac = b64(new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(`${id}.${ts}.${raw}`))));
  if (!sigs.split(" ").some((x) => x.split(",")[1] === mac)) return json({ error: "bad_signature" }, 401);
  const ev = JSON.parse(raw);
  if (ev.type !== "email.received") return json({ ok: true, ignored: ev.type });
  const r = await fetch(`https://api.resend.com/emails/receiving/${ev.data.email_id}`, { headers: { Authorization: `Bearer ${sec("RESEND_API_KEY")}` } });
  const m = await r.json().catch(() => ({}));
  if (!r.ok || !m?.raw?.download_url) return json({ error: "fetch_failed", detail: m?.message || r.status }, 502);
  const bytes = new Uint8Array(await (await fetch(m.raw.download_url)).arrayBuffer());
  const ours = [...(m.received_for || []), ...(m.to || []), ...(ev.data.to || [])].map(addr).find((x) => x.endsWith("@" + DOMAIN)) || "";
  return store(ours, b64(bytes), addr(m.from), true);
}

async function store(rcpt: string, rawB64: string, envelopeFrom: string, sendForward: boolean) {
  const local = rcpt.split("@")[0].split("+")[0];
  if (!rcpt.endsWith("@" + DOMAIN)) return json({ error: "not_our_domain" }, 400);
  let { data: box } = await db.from("mailboxes").select("local,forward_to").eq("local", local).maybeSingle();
  if (!box) ({ data: box } = await db.from("mailboxes").select("local,forward_to").eq("catch_all", true).limit(1).maybeSingle());
  if (!box) return json({ error: "no_such_mailbox" }, 404);
  const mail = await PostalMime.parse(unb64(rawB64));
  const files = (mail.attachments || []).map((a: { filename?: string; mimeType?: string; content: ArrayBuffer | string }) => ({
    name: a.filename || "attachment", type: a.mimeType || "", bytes: typeof a.content === "string" ? new TextEncoder().encode(a.content) : new Uint8Array(a.content) }));
  const row = {
    mailbox: box.local, folder: "inbox", direction: "in",
    from_addr: addr(mail.from) || envelopeFrom, from_name: String(mail.from?.name || "").slice(0, 200),
    to_addrs: (mail.to || []).map(addr).filter(Boolean).slice(0, 50), cc_addrs: (mail.cc || []).map(addr).filter(Boolean).slice(0, 50),
    subject: String(mail.subject || "(no subject)").slice(0, 500), text_body: String(mail.text || "").slice(0, 400000), html_body: String(mail.html || "").slice(0, 800000),
    message_id: mail.messageId || null, in_reply_to: mail.inReplyTo || null, attachments: await storeFiles(box.local, files), unread: true,
  };
  const { data: saved, error } = await db.from("mail_messages").insert(row).select("id").maybeSingle();
  if (error && !/duplicate/i.test(error.message)) return json({ error: "store_failed", detail: error.message }, 500);
  // with Resend receiving, the copy to Gmail (or any app) is sent from here; the Cloudflare worker forwards it itself
  if (sendForward && saved?.id && (box.forward_to || []).length) await forwardCopy(saved.id);
  return json({ ok: true, mailbox: box.local, forward: (box.forward_to || []).slice(0, 5) });   // the worker also delivers a copy there (Gmail, any app)
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ error: "method" }, 405);
  await loadSecrets();
  if (req.headers.get("x-crt-mail-secret") !== null) return inbound(req);
  if (req.headers.get("svix-id") !== null) return resendInbound(req);

  // ---- signed-in dashboard
  const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
  const { data: au } = await db.auth.getUser(token);
  const user = au?.user; if (!user) return json({ error: "signed_out" }, 401);
  const { data: member } = await db.from("team").select("user_id,name,role").eq("user_id", user.id).maybeSingle();
  if (!member) return json({ error: "not_on_team" }, 403);
  const { data: secset } = await db.from("security_settings").select("require_code").eq("id", 1).maybeSingle();
  if (secset?.require_code) {   // same rule as the database: a sign-in counts only after its text-message code
    let sid = ""; try { sid = JSON.parse(atob(token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"))).session_id || ""; } catch { /* */ }
    const { data: ok } = await db.from("login_codes").select("verified_at").eq("user_id", user.id).eq("session_id", sid).not("verified_at", "is", null).maybeSingle();
    if (!ok) return json({ error: "verify_first" }, 403);
  }
  const owner = member.role === "owner";
  const body = await req.json().catch(() => ({}));
  const canRead = async (box: string) => {
    const { data } = await db.from("mailboxes").select("local,display_name,members").eq("local", box).maybeSingle();
    return data && (owner || (data.members || []).includes(user.id)) ? data : null;
  };

  if (body.action === "send") {
    const box = await canRead(String(body.mailbox || "")); if (!box) return json({ error: "no_access" }, 403);
    if (!sec("RESEND_API_KEY")) return json({ error: "no_sender" }, 503);
    const list = (v: unknown) => (Array.isArray(v) ? v : String(v || "").split(/[,;\s]+/)).map((x) => String(x).trim().toLowerCase()).filter((x) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x));
    const to = list(body.to), cc = list(body.cc);
    if (!to.length) return json({ error: "no_recipient" }, 400);
    const subject = String(body.subject || "").slice(0, 300) || "(no subject)", text = String(body.text || "").slice(0, 200000);
    const html = `<div style="font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;font-size:15px;line-height:1.55;color:#1d1d1f">${text.replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c] as string)).replace(/\n/g, "<br>")}</div>`;
    const files = (Array.isArray(body.attachments) ? body.attachments : []).slice(0, 10).map((a: { name: string; type: string; base64: string }) => ({ name: String(a.name || "file"), type: String(a.type || ""), bytes: unb64(String(a.base64 || "")) }));
    if (files.reduce((n: number, f: { bytes: Uint8Array }) => n + f.bytes.length, 0) > 20e6) return json({ error: "too_big" }, 400);
    const from = `${(box.display_name || member.name || "CRT Media Agency").replace(/[<>"]/g, "")} <${box.local}@${DOMAIN}>`;
    const headers: Record<string, string> = {};
    if (body.in_reply_to) { headers["In-Reply-To"] = String(body.in_reply_to); headers["References"] = String(body.in_reply_to); }
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST", headers: { Authorization: `Bearer ${sec("RESEND_API_KEY")}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from, to, cc: cc.length ? cc : undefined, subject, text, html, headers, attachments: files.map((f: { name: string; bytes: Uint8Array }) => ({ filename: f.name, content: b64(f.bytes) })) }),
    });
    const res = await r.json().catch(() => ({}));
    if (!r.ok) return json({ error: "send_failed", detail: res?.message || r.status }, 502);
    const { data: saved } = await db.from("mail_messages").insert({ mailbox: box.local, folder: "sent", direction: "out", from_addr: `${box.local}@${DOMAIN}`, from_name: box.display_name || member.name,
      to_addrs: to, cc_addrs: cc, subject, text_body: text, html_body: html, message_id: res?.id ? `resend:${res.id}` : null, in_reply_to: body.in_reply_to || null,
      attachments: await storeFiles(box.local, files), unread: false, sent_by: user.id }).select("id").maybeSingle();
    return json({ ok: true, id: saved?.id });
  }
  if (body.action === "file") {
    const path = String(body.path || ""), box = path.split("/")[0];
    if (!(await canRead(box))) return json({ error: "no_access" }, 403);
    const { data, error } = await db.storage.from("mail").createSignedUrl(path, 600, { download: body.download ? String(body.name || true) : false });
    return error ? json({ error: "file_failed" }, 400) : json({ url: data.signedUrl });
  }
  if (body.action === "setup") {
    if (!owner) return json({ error: "owner_only" }, 403);
    if (typeof body.webhook_secret === "string" && body.webhook_secret.trim()) { const k = body.webhook_secret.replace(/\s+/g, "").slice(0, 200);
      if (!/^whsec_[A-Za-z0-9+/]+={0,2}$/.test(k)) return json({ error: "bad_secret" }, 400); await db.from("app_secrets").upsert({ name: "RESEND_WEBHOOK_SECRET", value: k, updated_at: new Date().toISOString() }); SECRETS.RESEND_WEBHOOK_SECRET = k; }
    if (typeof body.resend_key === "string" && body.resend_key.trim()) { const k = body.resend_key.trim().slice(0, 200); await db.from("app_secrets").upsert({ name: "RESEND_API_KEY", value: k, updated_at: new Date().toISOString() }); SECRETS.RESEND_API_KEY = k; }
    if (!sec("MAIL_INBOUND_SECRET") || body.new_key) {
      const k = random(24); await db.from("app_secrets").upsert({ name: "MAIL_INBOUND_SECRET", value: k, updated_at: new Date().toISOString() }); SECRETS.MAIL_INBOUND_SECRET = k;
    }
    let domain = null;
    if (sec("RESEND_API_KEY")) {
      const r = await fetch("https://api.resend.com/domains", { headers: { Authorization: `Bearer ${sec("RESEND_API_KEY")}` } });
      const d = await r.json().catch(() => ({}));
      const mine = (d?.data || []).find((x: { name: string }) => x.name === DOMAIN);
      domain = mine ? mine.status : (r.ok ? "not_added" : "bad_key");
    }
    const { count } = await db.from("mail_messages").select("id", { count: "exact", head: true }).eq("direction", "in");
    return json({ receiving_key: sec("MAIL_INBOUND_SECRET"), endpoint: Deno.env.get("SUPABASE_URL") + "/functions/v1/mail", sender: !!sec("RESEND_API_KEY"), webhook: !!sec("RESEND_WEBHOOK_SECRET"), domain, received: count || 0 });
  }
  return json({ error: "unknown_action" }, 400);
});
