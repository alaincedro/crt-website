/* CRT Finance: turns a short message into a ledger entry.
   Used by the dashboard quick-entry box and (same code, copied) by the WhatsApp function.
   Examples it understands:
     paid 50k fuel momo                         → money out, 50,000, Transport & fuel, MTN MoMo
     received 400,000 from Inka Steak House bank → money in, 400,000, Bank account, party Inka Steak House
     +1.2m wedding Grace & Eric                   → money in, 1,200,000, Weddings
     -25000 lunch on shoot cash yesterday         → money out, 25,000, Meals on shoots, Cash, yesterday
     moved 200k momo to bank                      → transfer, 200,000, MTN MoMo → Bank account
*/
(function(root){
  'use strict';
  const MONTHS = {jan:0,feb:1,mar:2,apr:3,may:4,jun:5,jul:6,aug:7,sep:8,sept:8,oct:9,nov:10,dec:11};
  const ACCOUNT_WORDS = [
    ['momo', /\b(momo|mtn|mobile money|airtel( money)?)\b/i],
    ['bank', /\b(bank|bk|equity|i&m|im bank|access bank|ecobank|cogebanque|bpr|kcb|ncba|visa)\b/i],
    ['cash', /\b(cash|hand|in hand)\b/i],
  ];
  const INCOME = /^\s*\+|\b(received|receive|got|income|deposit from|payment from|paid by|client paid|sold|invoice paid|advance from|deposit for)\b/i;
  const EXPENSE = /^\s*-|\b(paid|pay|spent|spend|bought|buy|expense|cost|costs|purchase|purchased|gave|sent to|salary)\b/i;
  const TRANSFER = /\b(moved|move|transfer|transferred|withdraw|withdrew|withdrawal|topped up|top up)\b/i;

  const iso = d => new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())).toISOString().slice(0, 10);

  function amountOf(text){
    // 50k, 1.2m, 400,000, 400 000, 25000rwf, rwf 25,000
    const m = text.match(/(?:rwf|frw|rf)?\s*(\d{1,3}(?:[ ,.]\d{3})+|\d+(?:\.\d+)?)\s*(k|m|million|thousand|rwf|frw|rf)?\b/i);
    if(!m) return null;
    let raw = m[1], unit = (m[2] || '').toLowerCase();
    let n = /^\d{1,3}([ ,.]\d{3})+$/.test(raw) && !(unit === 'k' || unit === 'm') ? Number(raw.replace(/[ ,.]/g, '')) : Number(raw.replace(/[ ,]/g, ''));
    if(unit === 'k' || unit === 'thousand') n *= 1e3;
    if(unit === 'm' || unit === 'million') n *= 1e6;
    n = Math.round(n);
    return n > 0 ? {value: n, text: m[0]} : null;
  }

  function dateOf(text, now){
    now = now || new Date();
    const t = text.toLowerCase();
    if(/\byesterday\b/.test(t)){ const d = new Date(now); d.setDate(d.getDate() - 1); return iso(d); }
    let m = t.match(/\b(\d{1,2})[\/\-](\d{1,2})(?:[\/\-](\d{2,4}))?\b/);
    if(m){ const y = m[3] ? (m[3].length === 2 ? 2000 + Number(m[3]) : Number(m[3])) : now.getFullYear(); const d = new Date(y, Number(m[2]) - 1, Number(m[1])); if(!isNaN(d)) return iso(d); }
    m = t.match(/\b(\d{1,2})(?:st|nd|rd|th)?\s+(jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*\b/) || t.match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*\s+(\d{1,2})\b/);
    if(m){ const day = Number(/\d/.test(m[1]) ? m[1] : m[2]), mon = MONTHS[(/\d/.test(m[1]) ? m[2] : m[1]).slice(0, 4).replace(/t$/, 't')] ?? MONTHS[(/\d/.test(m[1]) ? m[2] : m[1]).slice(0, 3)];
      const d = new Date(now.getFullYear(), mon, day); if(d > now){ if(d - now < 60 * 864e5) return iso(now); d.setFullYear(d.getFullYear() - 1); } return iso(d); }
    return iso(now);
  }

  function accountsIn(text){
    const hits = [];
    ACCOUNT_WORDS.forEach(([id, re]) => { const m = text.match(re); if(m) hits.push({id, at: m.index}); });
    return hits.sort((a, b) => a.at - b.at).map(h => h.id);
  }

  function categoryOf(text, type, categories){
    const t = ' ' + text.toLowerCase().replace(/[^a-z0-9&' ]+/g, ' ') + ' ';
    let best = null, bestLen = 0;
    (categories || []).forEach(c => {
      if(type && c.type !== type) return;
      String(c.keywords || '').split(',').map(k => k.trim().toLowerCase()).filter(Boolean).forEach(k => {
        if(t.includes(' ' + k + ' ') || t.includes(' ' + k + 's ')){ if(k.length > bestLen){ best = c; bestLen = k.length; } }
      });
    });
    return best;
  }

  function partyOf(text, type){
    const re = type === 'income' ? /\b(?:from|by)\s+(.+?)(?=\s+(?:for|via|on|to|in|into|momo|mtn|bank|cash|yesterday|today)\b|[.,;]|$)/i
                                 : /\b(?:to|at)\s+(.+?)(?=\s+(?:for|via|on|from|momo|mtn|bank|cash|yesterday|today)\b|[.,;]|$)/i;
    let m = text.match(re);
    // "gave Eric 90k", "paid Aline 50k for editing": a capitalised name straight after the verb
    if(!m && type === 'expense') m = text.match(/\b(?:gave|paid|pay|sent|send)\s+([A-Z][\w'’-]+(?:\s+[A-Z][\w'’-]+)?)(?=\s)/);
    if(!m) return '';
    const p = m[1].trim();
    if(/^(momo|mtn|bank|cash|the bank|my|our)\b/i.test(p) || /^\d/.test(p)) return '';
    return p.slice(0, 120);
  }

  function parse(text, opts){
    opts = opts || {};
    const cats = opts.categories || [], now = opts.now || new Date(), defAcc = opts.defaultAccount || 'momo';
    const clean = String(text || '').trim().replace(/\s+/g, ' ');
    const out = {type: null, amount_rwf: null, account_id: null, to_account_id: null, category_id: null, party: '', happened_on: dateOf(clean, now), note: clean.slice(0, 500), missing: []};
    const amt = amountOf(clean.replace(/\b\d{1,2}[\/\-]\d{1,2}([\/\-]\d{2,4})?\b/g, ' '));
    if(amt) out.amount_rwf = amt.value; else out.missing.push('amount');
    const accs = accountsIn(clean);
    if(TRANSFER.test(clean) && accs.length >= 2){
      out.type = 'transfer'; out.account_id = accs[0]; out.to_account_id = accs[1];
      if(/\bfrom\b/i.test(clean) && /\bto\b/i.test(clean)){
        const f = clean.toLowerCase().search(/\bfrom\b/), tIdx = clean.toLowerCase().search(/\bto\b/);
        if(tIdx < f){ out.account_id = accs[1]; out.to_account_id = accs[0]; }
      }
      return out;
    }
    if(TRANSFER.test(clean) && accs.length === 1 && /withdr/i.test(clean)){ out.type = 'transfer'; out.account_id = accs[0]; out.to_account_id = accs[0] === 'cash' ? defAcc : 'cash'; return out; }
    if(INCOME.test(clean)) out.type = 'income';
    else if(EXPENSE.test(clean)) out.type = 'expense';
    const cat = categoryOf(clean, out.type, cats);
    if(!out.type && cat) out.type = cat.type;
    if(!out.type) out.missing.push('type');
    if(out.type){
      const c = cat && cat.type === out.type ? cat : null;
      out.category_id = c ? c.id : (out.type === 'income' ? 'other-income' : 'other-expense');
      out.party = partyOf(clean, out.type);
    }
    out.account_id = accs[0] || defAcc;
    return out;
  }

  root.crtParseMoney = parse;
  if(typeof module !== 'undefined' && module.exports) module.exports = parse;
})(typeof globalThis !== 'undefined' ? globalThis : this);
