/* CRT admin dashboard. Works with Supabase when crt-config.js is filled in; otherwise runs a demo with sample data. */
(function(){
  'use strict';
  const CFG = window.CRT_CONFIG || {};
  const LIVE = !!(CFG.SUPABASE_URL && CFG.SUPABASE_ANON_KEY && window.supabase);
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];
  const esc = v => String(v == null ? '' : v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt = n => (n == null || n === '' || isNaN(n)) ? '—' : Number(n).toLocaleString('en-US');
  const STATUSES = [['new','New'],['replied','Replied'],['quoted','Quoted'],['booked','Booked'],['lost','Lost']];
  const STATUS_LABEL = Object.fromEntries(STATUSES);
  const PRICE_FIELDS = [
    // Only the four wedding packages are edited here: their amounts are unique on the site,
    // so changing one can never change an unrelated price that happens to share the same number.
    ['basic','Basic wedding package (4 days, photos)','Weddings page, home, menu, early-booking offer'],
    ['standard','Standard wedding package (4 days, photos and video)','Weddings page, home, menu, early-booking offer'],
    ['premium','Premium wedding package','Weddings page, home, menu, early-booking offer'],
    ['vip','VIP wedding package','Weddings page, home, menu, early-booking offer'],
  ];
  const PACKAGES = ['Basic','Standard','Premium','VIP'];
  const SERVICES = ['Wedding photography & video','Event photography & video','Commercial photography & video','Branding & graphic design','Social media & content','Websites & digital tools','Creative project'];
  const SOURCES = ['WhatsApp','Phone call','Instagram','Facebook','Referral','Walk-in','Other'];

  let me = null, leads = [], team = [], content = {}, filter = 'all', query = '', openId = null, started = false;
  let view = (()=>{ try{ return localStorage.getItem('crt-admin-view') || 'table'; }catch(e){ return 'table'; } })();

  // ------------------------------------------------------------------ data layer
  const sb = LIVE ? window.supabase.createClient(CFG.SUPABASE_URL, CFG.SUPABASE_ANON_KEY) : null;

  const demo = (() => {
    const day = 864e5, now = Date.now();
    const iso = d => new Date(now - d*day).toISOString();
    return {
      me: {user_id:'demo-1', name:'Alain (demo)', role:'admin', email:'alain@crt.rw'},
      team: [{user_id:'demo-1',name:'Alain Cedrick',role:'admin'},{user_id:'demo-2',name:'Ziggy',role:'staff'}],
      leads: [
        {id:7,created_at:iso(0.1),name:'Aline M.',contact:'+250 788 123 456',service:'Wedding photography & video',offer:'Book early, save 30%',event_date:'14 Feb 2027',details:'Church + reception at Kigali Serena, about 250 guests.',page:'/offer-wedding-early-booking',source:'instagram / paid / wedding-oct',status:'new',value_rwf:null,notes:'',assigned_to:null},
        {id:6,created_at:iso(0.6),name:'Kivu Coffee Ltd',contact:'hello@kivucoffee.rw',service:'Commercial photography & video',offer:'Content session',event_date:'Next month',details:'New packaging launch, 12 products.',page:'/offer-commercial-content-session',source:'google',status:'replied',value_rwf:400000,notes:'Sent shot list questions on WhatsApp.',assigned_to:'demo-2'},
        {id:5,created_at:iso(2),name:'Jean-Paul K.',contact:'0788 555 222',service:'Event photography & video',offer:'Event + social bundle',event_date:'22 Nov',details:'Product launch at Norrsken, 3 hours.',page:'/events',source:'direct',status:'quoted',value_rwf:450000,notes:'Quote sent 27 Oct. Follow up Friday.',assigned_to:'demo-1'},
        {id:4,created_at:iso(4),name:'Grace & Eric',contact:'+250 722 000 111',service:'Wedding photography & video',offer:'Premium',event_date:'June 2027',details:'Gusaba + wedding, two days.',page:'/wedding-packages',source:'instagram',status:'booked',value_rwf:2000000,notes:'Deposit received.',assigned_to:'demo-2'},
        {id:3,created_at:iso(9),name:'Tech Hub Rwanda',contact:'events@techhub.rw',service:'Websites & digital tools',offer:'Website launch',event_date:'December',details:'5-page site with event registrations.',page:'/offer-website-launch',source:'facebook / instagram ad',status:'quoted',value_rwf:600000,notes:'',assigned_to:'demo-1'},
        {id:2,created_at:iso(15),name:'Nadia U.',contact:'+250 789 999 000',service:'Branding & graphic design',offer:'Brand starter kit',event_date:'ASAP',details:'New bakery.',page:'/offer-brand-starter-kit',source:'google',status:'lost',value_rwf:300000,notes:'Went with a cheaper freelancer.',assigned_to:null},
        {id:1,created_at:iso(21),name:'Patrick N.',contact:'0781 234 567',service:'Wedding photography & video',offer:'Standard',event_date:'March 2027',details:'',page:'/weddings',source:'linktr.ee',status:'booked',value_rwf:1500000,notes:'',assigned_to:'demo-1'},
      ],
      inbox(body){
        const now = Date.now(), h = 36e5;
        const msgs = [
          {messageId:'1', folderId:'9', from:'Aline M.', fromAddress:'aline.m@example.com', subject:'Wedding in February: are you available?', summary:'Hello, we are getting married on 14 Feb 2027 at Kigali Serena and would love photos and a video.', received:now-2*h, unread:true},
          {messageId:'2', folderId:'9', from:'Kivu Coffee Ltd', fromAddress:'hello@kivucoffee.example', subject:'Product shoot quote', summary:'Could you send a quote for photographing 12 products for our new packaging?', received:now-26*h, unread:false},
        ];
        if(body.action === 'read'){ const m = msgs.find(x => x.messageId === body.messageId) || msgs[0]; return {html:'<p>(Demo) ' + m.summary + '</p><p>Thanks,<br>' + m.from + '</p>'}; }
        return {messages: msgs};
      },
      content: {
        prices:{basic:1200000,standard:2000000,premium:3000000,vip:4500000},
        packages:{
          Basic:['4 shooting days: pre-wedding, gufata irembo, civil marriage and wedding day','1 photographer, up to 8 hours on the wedding day','400+ edited photos','Photobook, 8×8 inch (about 50 photos)','Online gallery'],
          Standard:['The same 4 shooting days','Wedding day: 1 photographer + 1 videographer, up to 10 hours','500+ edited photos','Full video and a 3–5 minute highlight video','Short videos of gufata irembo and the civil marriage','Lay-flat photobook, 10×10 inch (about 80 photos)'],
          Premium:['The same 4 shooting days','Wedding day: 2 photographers + 2 videographers, up to 12 hours','650+ edited photos','Full video, a 5–8 minute highlight video and a teaser','Short videos of every shooting day','Livestream for family abroad','Flush-mount album, 12×12 inch, and a framed A3 print'],
          VIP:['Everything in Premium','A surprise proposal shoot','Same-day edit shown at the reception','Leather album, 12×12 inch (about 200 photos)','2 parent albums and 2 framed A2 prints']
        }
      }
    };
  })();

  const api = {
    async session(){ if(!LIVE) return {user:{email:demo.me.email,id:demo.me.user_id}}; const {data} = await sb.auth.getSession(); return data.session; },
    // Email + password: works when the site is opened straight from a folder,
    // where emailed sign-in links have no web address to return to.
    async signIn(email, password){
      if(!LIVE) return {error:null};
      return sb.auth.signInWithPassword({email, password});
    },
    async signOut(){ if(LIVE) await sb.auth.signOut(); location.reload(); },
    // The "team" server function (supabase-functions/team): accounts, sign-in codes, security switch.
    async teamFn(body){
      if(!LIVE) return {ok: true, password: 'Demo-Pass-1234', require_code: false, verified: true};
      const {data, error} = await sb.functions.invoke('team', {body});
      if(error){
        let detail = {}; try{ detail = await error.context.json(); }catch(e){}
        const err = new Error(detail.error || error.message || 'failed'); err.code = detail.error; err.info = detail; throw err;
      }
      return data;
    },
    async me(uid){
      if(!LIVE) return demo.me;
      let {data, error} = await sb.from('team').select('user_id,name,role,phone,email').eq('user_id', uid).maybeSingle();
      if(error && /column/i.test(error.message || '')) ({data, error} = await sb.from('team').select('user_id,name,role').eq('user_id', uid).maybeSingle());   // before team-security.sql
      if(error) throw error; return data;
    },
    async leads(){
      if(!LIVE) return demo.leads.slice();
      const {data, error} = await sb.from('leads').select('*').order('created_at',{ascending:false}).limit(2000);
      if(error) throw error; return data;
    },
    async addLead(row){
      if(!LIVE){ const l = Object.assign({id: Math.max(0, ...demo.leads.map(x => x.id)) + 1, created_at: new Date().toISOString()}, row); demo.leads.unshift(l); return Object.assign({}, l); }
      const {data, error} = await sb.from('leads').insert(row).select('*').single(); if(error) throw error; return data;
    },
    // Mailbox (Zoho Mail) through the "inbox" Edge Function. Demo mode shows sample mail.
    async inbox(body){
      if(!LIVE) return demo.inbox(body);
      const {data, error} = await sb.functions.invoke('inbox', {body});
      if(error){
        let msg = error.message;
        try{ const j = await error.context.json(); msg = j.error || msg; }catch(e){}
        throw new Error(msg);
      }
      return data;
    },
    async updateLead(id, patch){
      if(!LIVE){ Object.assign(demo.leads.find(l=>l.id===id), patch); return; }
      const {error} = await sb.from('leads').update(patch).eq('id', id); if(error) throw error;
    },
    async deleteLead(id){
      if(!LIVE){ demo.leads = demo.leads.filter(l=>l.id!==id); return; }
      const {error} = await sb.from('leads').delete().eq('id', id); if(error) throw error;
    },
    async team(){
      if(!LIVE) return demo.team.slice();
      let {data, error} = await sb.from('team').select('user_id,name,role,phone,email').order('name');
      if(error && /column/i.test(error.message || '')) ({data, error} = await sb.from('team').select('user_id,name,role').order('name'));
      if(error) throw error; return data;
    },
    async updateMember(uid, patch){
      if(!LIVE){ Object.assign(demo.team.find(m=>m.user_id===uid), patch); return; }
      await api.teamFn(Object.assign({action: 'update_member', user_id: uid}, patch));
    },
    async removeMember(uid){
      if(!LIVE){ demo.team = demo.team.filter(m=>m.user_id!==uid); return; }
      await api.teamFn({action: 'remove_member', user_id: uid});
    },
    async content(){
      if(!LIVE) return JSON.parse(JSON.stringify(demo.content));
      const {data, error} = await sb.from('site_content').select('key,value'); if(error) throw error;
      const c = {}; (data||[]).forEach(r => c[r.key] = r.value);
      // Price list v2 (Nov 2026): the site reads prices_v2 / wedding_packages. Until they are saved once,
      // show the current published prices instead of the retired list stored under prices / packages.
      c.prices = c.prices_v2 || JSON.parse(JSON.stringify(demo.content.prices));
      c.packages = c.wedding_packages || JSON.parse(JSON.stringify(demo.content.packages));
      return c;
    },
    async saveContent(key, value){
      if(!LIVE){ demo.content[key] = value; return; }
      const {error} = await sb.from('site_content').upsert({key, value, updated_by: me.user_id}); if(error) throw error;
    },
    // Upload a file to the public "media" bucket and return its public address.
    async upload(file, path){
      if(!LIVE) return URL.createObjectURL(file);           // demo: local preview only, nothing is stored
      path = String(path).replace(/(\.[a-z0-9]+)?$/i, m => '-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5) + m);   // unique: a plain upload, never a replace
      const {error} = await sb.storage.from('media').upload(path, file, {upsert:false, contentType:file.type || 'application/octet-stream', cacheControl:'31536000'});
      if(error) throw error;
      return sb.storage.from('media').getPublicUrl(path).data.publicUrl;
    },
    async removeFile(url){
      if(!LIVE || !url) return;
      const m = String(url).match(/\/storage\/v1\/object\/public\/media\/(.+)$/);
      if(m) await sb.storage.from('media').remove([decodeURIComponent(m[1])]);   // best effort
    }
  };

  // Booking messages from /book/ arrive as "BOOKING / Service: … / Package: … · price / Extras: / - item · price / Estimate: …"
  // Show them as a small table; any other message keeps its line breaks.
  function fmtMessage(v){
    const text = String(v || ''), lines = text.split(/\r?\n/);
    if(lines[0].trim() !== 'BOOKING') return esc(text).replace(/\n/g, '<br>');
    const rows = []; let notes = '', inExtras = false;
    lines.slice(1).forEach(raw => {
      const t = raw.trim(); if(!t) return;
      if(/^Notes:/.test(t)){ notes = t.replace(/^Notes:\s*/, ''); inExtras = false; return; }
      if(notes){ notes += '\n' + t; return; }
      if(t === 'Extras:'){ inExtras = true; return; }
      const isItem = inExtras && /^-\s/.test(t); if(!isItem) inExtras = false;
      const [label, price] = (isItem ? t.replace(/^-\s*/, '') : t).split(' · ');
      const m = !isItem && label.match(/^(Service|Package|Offer|Estimate):\s*(.*)$/);
      if(m && m[1] === 'Estimate') rows.push(['Estimate', '', m[2], true]);
      else rows.push(m ? [m[1], m[2], price || '', false] : ['Extra', label, price || '', false]);
    });
    return '<table class="bk-table">' + rows.map(([k, a, b, tot]) => `<tr${tot ? ' class="is-total"' : ''}><th>${esc(k)}</th><td>${esc(a)}</td><td class="num">${esc(b)}</td></tr>`).join('') + '</table>'
      + (notes ? `<p class="bk-notes"><strong>Notes</strong><br>${esc(notes).replace(/\n/g, '<br>')}</p>` : '');
  }
  // ------------------------------------------------------------------ case studies
  // Every work lives in the dashboard data (content.case_studies), in one shape (v: 2). The list below is built from it,
  // so works added here and works that were on the site before look and behave the same.
  let CASES = [];
  const CAT_LABEL = {business: 'Business', events: 'Events', weddings: 'Weddings'};
  const slugify = t => 'work-' + String(t || '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60);
  const caseThumb = e => (e.card && e.card.url) || (e.cover && e.cover.url) || ((e.photos || [])[0] || {}).url || '';
  function rebuildCaseList(){
    const all = content.case_studies || {};
    CASES = Object.keys(all).filter(sl => all[sl] && !all[sl].deleted).map(sl => {
      const e = all[sl];
      return {slug: sl, title: e.title || sl, group: CAT_LABEL[e.category] || 'Business', thumb: caseThumb(e), page: !!(caseSeed[sl] || e.page), order: e.order ?? 999, published: e.published !== false};
    }).sort((a, b) => a.order - b.order);
  }
  // Older dashboard entries kept their text under "fields": read them into the same shape as everything else.
  function normaliseCase(seed, e){
    const c = JSON.parse(JSON.stringify(seed || {}));
    if(!e) return c;
    if(e.v === 2) return Object.assign(c, JSON.parse(JSON.stringify(e)));
    const F = e.fields || {}, pick = (...k) => { for(const x of k){ if(F[x] != null) return F[x]; } };
    const set = (o, k, v) => { if(v !== undefined) o[k] = v; };
    set(c, 'title', pick('client')); set(c, 'headline', pick('headline')); set(c, 'summary', pick('summary'));
    set(c, 'brief', pick('challenge')); set(c, 'approach', pick('approach'));
    c.facts = c.facts || {};
    set(c.facts, 'client', pick('fact-Client', 'fact-Couple', 'fact-Clients')); set(c.facts, 'type', pick('fact-Industry', 'fact-Event'));
    set(c.facts, 'location', pick('fact-Location')); set(c.facts, 'date', pick('fact-Year', 'fact-Date', 'fact-When')); set(c.facts, 'services', pick('fact-Services', 'fact-Delivered'));
    if(['result-0','result-1','result-2','result-3'].some(k => F[k] != null)) c.results = [0,1,2,3].map(n => F['result-' + n] || '').filter(Boolean);
    if(e.photos && (e.photos.length || e.gallery_full)) c.photos = e.photos;
    ['video', 'review', 'credits', 'published', 'deleted'].forEach(k => { if(e[k] !== undefined && e[k] !== null) c[k] = e[k]; });
    c.v = 2; c.seeded = 1;
    return c;
  }

  const SLOT_HINTS = ['The full room during a session','Speakers on stage','Attendees in conversation between sessions','Both brands’ logos on stage','Q&A with the audience','Speakers and organisers group photo','Details: badges, notes, coffee break','Behind the scenes: the crew at work','A candid moment worth remembering'];
  const MAX_PHOTOS = 40, MAX_VIDEO_MB = 50;
  // Every case study's content (text, fact sheet, story, outcomes, gallery photos, review) is stored here as the
  // admin's own entry, so all of it can be edited or removed. The first time the dashboard opens, the content the
  // site already shows (../data/case-studies.json, made by tools/export_cases.py) is copied in once and saved.
  let caseSeed = {};
  async function seedCases(){
    let seed = null;
    try{ const r = await fetch('../data/case-studies.json', {cache:'no-store'}); if(r.ok) seed = await r.json(); }catch(e){}
    content.case_studies = content.case_studies || {};
    let changed = false;
    if(seed){
      caseSeed = seed;
      Object.keys(seed).forEach(slug => {
        const e = content.case_studies[slug], sd = seed[slug];
        if(sd.v !== 2) return;
        if(!e || e.v !== 2){ content.case_studies[slug] = Object.assign(normaliseCase(sd, e), {v: 2, seeded: 1}); changed = true; }
      });
    }
    // anything older that is not in the data file (added here before v2) gets the same shape too
    Object.keys(content.case_studies).forEach(slug => { const e = content.case_studies[slug]; if(e && e.v !== 2){ content.case_studies[slug] = normaliseCase({title: slug, category: 'business', facts: {}, results: [], photos: []}, e); changed = true; } });
    rebuildCaseList();
    if(CASES.length && !CASES.some(c => c.slug === caseSlug)) caseSlug = CASES[0].slug;
    if(changed && isAdmin()){
      try{ await api.saveContent('case_studies', content.case_studies); toast('Every work is now stored in the dashboard. Edit, hide or remove any of them here.'); }catch(e){ fail(e); }
    }
  }
  let pendingPhotos = [], dragPhoto = null;
  let caseSlug = '', busy = false;
  const caseEntry = () => { content.case_studies = content.case_studies || {}; return content.case_studies[caseSlug] = content.case_studies[caseSlug] || {video:null, photos:[]}; };

  // Resize to max 2000 px and compress (WebP when the browser supports it, else JPEG ~82%), so the site stays fast.
  async function prepPhoto(file){
    try{
      const img = await createImageBitmap(file, {imageOrientation:'from-image'});
      const scale = Math.min(1, 2000 / Math.max(img.width, img.height));
      const c = document.createElement('canvas'); c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      let blob = await new Promise(r => c.toBlob(r, 'image/webp', 0.82));
      if(!blob || blob.type !== 'image/webp') blob = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.82));
      if(!blob) throw new Error('could not read the image');
      const ext = blob.type === 'image/webp' ? 'webp' : 'jpg';
      return {file: new File([blob], file.name.replace(/\.\w+$/, '') + '.' + ext, {type: blob.type}), ext, w: c.width, h: c.height};
    }catch(e){
      if(/^image\/(jpeg|png|webp|gif|avif)$/.test(file.type)) return {file, ext: (file.type.split('/')[1] || 'jpg').replace('jpeg', 'jpg'), w: 0, h: 0};
      throw new Error(file.name + ' is not a photo this browser can read (HEIC? export it as JPEG first)');
    }
  }
  async function saveCases(msg){
    try{ await api.saveContent('case_studies', content.case_studies || {}); toast(msg || 'Saved. Live on the site.'); }catch(e){ fail(e); }
  }

  // Credits: pick a person and a position from dropdowns (team members + people and positions added to the list),
  // add someone new to the lists, or type both for a part-time / one-off person.
  // Extra people and positions are saved once in site_content.credit_options and offered on every work.
  const creditOpts = () => { const o = content.credit_options = content.credit_options || {}; o.people = o.people || []; o.roles = o.roles || []; return o; };
  const uniq = a => [...new Set(a.map(x => String(x || '').trim()).filter(Boolean))];
  const creditPeople = () => uniq(team.map(m => m.name).concat(creditOpts().people.map(p => p.name)));
  const creditRoles = () => uniq([...document.querySelectorAll('#credit-roles option')].map(o => o.value || o.textContent).concat(creditOpts().roles, creditOpts().people.map(p => p.role)));
  function renderCredits(ro, entry){
    const rows = entry.credits || [], people = creditPeople(), roles = creditRoles(), teamNames = uniq(team.map(m => m.name));
    const extra = creditOpts().people.map(p => p.name).filter(n => !teamNames.includes(n));
    const dis = ro ? ' disabled' : '';
    const nameSel = (cur, i) => `<select class="credit-name-sel" aria-label="Person ${i + 1}"${dis}><option value="">Choose a person…</option>`
      + (teamNames.length ? `<optgroup label="Team">${teamNames.map(n => `<option${n === cur ? ' selected' : ''}>${esc(n)}</option>`).join('')}</optgroup>` : '')
      + (extra.length ? `<optgroup label="Others on the list">${extra.map(n => `<option${n === cur ? ' selected' : ''}>${esc(n)}</option>`).join('')}</optgroup>` : '')
      + `<optgroup label="Someone else"><option value="__add">+ Add someone to the list…</option><option value="__manual">Type a name and position (part-time)…</option></optgroup></select>`;
    const roleSel = (cur, i) => `<select class="credit-role-sel" aria-label="Position ${i + 1}"${dis}><option value="">Choose a position…</option>${roles.map(r => `<option${r === cur ? ' selected' : ''}>${esc(r)}</option>`).join('')}<option value="__add">+ Add a position to the list…</option></select>`;
    const tools = i => ro ? '' : `<button class="link" data-action="credit-up" data-i="${i}" aria-label="Move up"${i ? '' : ' disabled'}>↑</button><button class="link danger" data-action="remove-credit" data-i="${i}">Remove</button>`;
    $('#credit-rows').innerHTML = rows.length ? rows.map((c, i) => {
      const manual = c.manual || (c.name && !people.includes(c.name)) || (c.role && !roles.includes(c.role));
      return manual
        ? `<div class="credit-row is-manual" data-i="${i}"><input type="text" class="credit-name" value="${esc(c.name || '')}" placeholder="Full name" maxlength="80" aria-label="Name ${i + 1}"${dis}>
           <input type="text" class="credit-role" value="${esc(c.role || '')}" placeholder="Position, e.g. Second photographer" maxlength="80" list="credit-roles" aria-label="Position ${i + 1}"${dis}>${tools(i)}
           <p class="credit-note"><span class="credit-tag">Part-time</span> Typed for this work only.${ro ? '' : ` <button class="link" data-action="credit-lists" data-i="${i}">Use the dropdowns</button>`}</p></div>`
        : `<div class="credit-row" data-i="${i}">${nameSel(c.name, i)}${roleSel(c.role, i)}${tools(i)}<div class="credit-add" hidden></div></div>`;
    }).join('') : '<p class="muted small">No credits yet.</p>';
    $$('[data-action="add-credit"],[data-action="save-credits"]').forEach(el => el.hidden = ro);
  }
  function readCredits(){
    return $$('#credit-rows .credit-row').map(r => {
      if(r.classList.contains('is-manual')) return {name: r.querySelector('.credit-name').value.trim().slice(0, 80), role: r.querySelector('.credit-role').value.trim().slice(0, 80), manual: true};
      const v = sel => { const x = r.querySelector(sel).value; return /^__/.test(x) ? '' : x; };
      return {name: v('.credit-name-sel'), role: v('.credit-role-sel')};
    });
  }
  // The small form that appears inside a row: add a person (with a position) or a position to the lists
  function showCreditAdd(row, kind){
    const box = row.querySelector('.credit-add'); if(!box) return;
    const roles = creditRoles();
    box.dataset.kind = kind;
    box.innerHTML = kind === 'person'
      ? `<input type="text" class="ca-name" placeholder="Their full name" maxlength="80" aria-label="New person's name">
         <select class="ca-role" aria-label="Their usual position"><option value="">Their usual position…</option>${roles.map(r => `<option>${esc(r)}</option>`).join('')}<option value="__new">Another position…</option></select>
         <input type="text" class="ca-role-new" placeholder="New position" maxlength="80" hidden aria-label="New position">
         <button class="btn small" data-action="credit-add-save">Add to the list</button><button class="link" data-action="credit-add-cancel">Cancel</button>`
      : `<input type="text" class="ca-role-new" placeholder="Position, e.g. Drone pilot" maxlength="80" aria-label="New position">
         <button class="btn small" data-action="credit-add-save">Add to the list</button><button class="link" data-action="credit-add-cancel">Cancel</button>`;
    box.hidden = false;
    (box.querySelector('.ca-name') || box.querySelector('.ca-role-new')).focus();
  }
  async function saveCreditAdd(row){
    const box = row.querySelector('.credit-add'), kind = box.dataset.kind, o = creditOpts(), i = +row.dataset.i;
    const entry = caseEntry(); entry.credits = readCredits();
    if(kind === 'person'){
      const name = box.querySelector('.ca-name').value.trim(), pick = box.querySelector('.ca-role').value;
      const role = pick === '__new' ? box.querySelector('.ca-role-new').value.trim() : pick;
      if(!name){ toast('Write their name first'); return; }
      if(!o.people.some(x => x.name.toLowerCase() === name.toLowerCase())) o.people.push({name, role});
      if(role && !creditRoles().includes(role)) o.roles.push(role);
      entry.credits[i] = {name, role: role || entry.credits[i].role || ''};
    } else {
      const role = box.querySelector('.ca-role-new').value.trim();
      if(!role){ toast('Write the position first'); return; }
      if(!creditRoles().includes(role)) o.roles.push(role);
      entry.credits[i] = {name: entry.credits[i].name, role};
    }
    try{ await api.saveContent('credit_options', o); toast(kind === 'person' ? 'Added to the list. You can pick them on every work.' : 'Position added to the list.'); }catch(e){ fail(e); }
    renderCredits(false, entry);
  }
  document.addEventListener('change', e => {
    const t = e.target; if(!t.closest || !t.closest('#credit-rows')) return;
    const row = t.closest('.credit-row');
    if(t.classList.contains('credit-name-sel')){
      if(t.value === '__add'){ t.value = ''; showCreditAdd(row, 'person'); }
      else if(t.value === '__manual'){ const entry = caseEntry(); entry.credits = readCredits(); entry.credits[+row.dataset.i] = Object.assign(entry.credits[+row.dataset.i], {manual: true}); renderCredits(false, entry); const r = $$('#credit-rows .credit-row')[+row.dataset.i]; if(r) r.querySelector('.credit-name').focus(); }
      else { const p = creditOpts().people.find(x => x.name === t.value), rs = row.querySelector('.credit-role-sel'); if(p && p.role && rs && !rs.value) rs.value = p.role; }
    } else if(t.classList.contains('credit-role-sel') && t.value === '__add'){ t.value = ''; showCreditAdd(row, 'role'); }
    else if(t.classList.contains('ca-role')){ const n = row.querySelector('.ca-role-new'); if(n){ n.hidden = t.value !== '__new'; if(!n.hidden) n.focus(); } }
  });
  function renderReview(ro, entry){
    const r = entry.review || {}, q = $('#review-quote');
    q.value = r.quote || ''; $('#review-name').value = r.name || ''; $('#review-role').value = r.role || '';
    [q, $('#review-name'), $('#review-role')].forEach(el => el.disabled = ro);
    const count = () => { $('#review-count').textContent = q.value.length + ' / 600'; };
    count(); q.oninput = count;
    $('[data-action="save-review"]').hidden = ro;
    $('[data-action="remove-review"]').hidden = ro || !r.quote;
  }
  // ---- Case study list: pick one, edit it, go back (thumbnail, category, status at a glance) ----
  let caseFilter = 'All', caseQuery = '';
  const caseHref = c => c.page ? '../' + c.slug + '/index.html' : '../case/?s=' + encodeURIComponent(c.slug);
  function caseStatus(c){
    const e = (content.case_studies || {})[c.slug] || {}, out = [];
    if(e.published === false) out.push(['warn', 'Hidden']);
    const needsFilm = c.group !== 'Business';
    out.push(e.video && e.video.url ? ['ok', 'Video'] : needsFilm ? ['warn', 'Video needed'] : null);
    const n = (e.photos || []).length; if(n) out.push(['ok', n + ' photo' + (n === 1 ? '' : 's')]);
    if(e.review && e.review.quote) out.push(['ok', 'Review']);
    if(!e.headline || !e.summary) out.push(['warn', 'Text missing']);
    return out.filter(Boolean);
  }
  function renderCaseList(){
    const groups = ['All', ...new Set(CASES.map(c => c.group))];
    $('#case-filters').innerHTML = groups.map(g => `<button class="pill${g === caseFilter ? ' is-active' : ''}" data-action="case-filter" data-g="${esc(g)}">${esc(g)}<em>${g === 'All' ? CASES.length : CASES.filter(c => c.group === g).length}</em></button>`).join('');
    const q = caseQuery.trim().toLowerCase();
    const rows = CASES.filter(c => (caseFilter === 'All' || c.group === caseFilter) && (!q || c.title.toLowerCase().includes(q)));
    $('#case-rows').innerHTML = rows.length ? rows.map(c => `<div class="case-row" role="button" tabindex="0" data-action="open-case" data-slug="${esc(c.slug)}">
      ${c.thumb ? `<img src="${esc(c.thumb)}" alt="" width="56" height="70" loading="lazy">` : '<span class="case-noimg" aria-hidden="true"></span>'}
      <div class="case-main"><strong>${esc(c.title)}</strong><span class="muted small">${esc(c.group)}</span></div>
      <div class="case-status">${caseStatus(c).map(([k, t]) => `<span class="badge ${k}">${esc(t)}</span>`).join('') || '<span class="muted small">Nothing added yet</span>'}</div>
      <div class="case-go"><span class="btn secondary small">Edit</span><a class="link small" href="${esc(caseHref(c))}" target="_blank" rel="noopener" aria-label="View ${esc(c.title)} on the site">View ↗</a></div></div>`).join('')
      : '<p class="muted" style="padding:18px">No case study matches that search.</p>';
  }
  function showCaseView(view){
    $('#case-list').hidden = view !== 'list'; $('#case-editor').hidden = view !== 'edit';
    if(view === 'edit') window.scrollTo({top: 0});
  }
  document.addEventListener('input', e => { if(e.target.id === 'case-search'){ caseQuery = e.target.value; renderCaseList(); } });
  document.addEventListener('keydown', e => { const r = e.target.closest && e.target.closest('.case-row'); if(r && (e.key === 'Enter' || e.key === ' ') && e.target === r){ e.preventDefault(); openCase(r.dataset.slug); } });
  function openCase(slug){ caseSlug = slug; renderCases(); showCaseView('edit'); }
  function stepCase(d){ const i = CASES.findIndex(c => c.slug === caseSlug); openCase(CASES[(i + d + CASES.length) % CASES.length].slug); }
  // ---- Details: the same organised form for every case study (headline, fact sheet, story, why it works) ----
  // The page template, top to bottom. Every work fills the same boxes.
  const DETAIL_GROUPS = [
    ['Title and summary', 'The top of the page.', [['title','Client or project name','input',120,'e.g. ORYX Energies'],['category','Section','category'],['kicker','Type of work','input',80,'e.g. Product & brand photography'],['headline','Headline','input',160,'One line about the result, e.g. Engine oil, shot like a premium product.'],['summary','Summary','textarea',600,'2–3 sentences: who the client is, what we made, why it mattered.']]],
    ['Cover photo', 'The large photo under the title. Pick one of this work’s photos.', [['cover','Cover photo','cover']]],
    ['Thumbnail', 'The small picture shown where this work is featured: the home page, the Work page and “More work like this”. It can be different from the cover.', [['thumb','Thumbnail','thumb']]],
    ['Facts', 'One row under the cover. Leave a box empty to hide it.', [['facts.client','Client','input',120],['facts.type','Type (industry or event)','input',120],['facts.location','Location','input',80,'e.g. Kigali'],['facts.date','Date','input',40,'e.g. June 2026'],['facts.services','Services','input',160,'e.g. Photography, video']]],
    ['The story', 'Three short parts, shown after the photos.', [['brief','The brief (what the client needed)','textarea',600],['approach','What we did','textarea',600],['results.0','What we delivered · 1','input',140],['results.1','What we delivered · 2','input',140],['results.2','What we delivered · 3','input',140],['results.3','What we delivered · 4 (optional)','input',140]]],
    ['Photos heading', 'The title above the photos.', [['gallery_title','Heading','input',120,'The work, up close.']]]
  ];
  const getPath = (o, k) => k.split('.').reduce((v, x) => v == null ? v : v[x], o);
  function setPath(o, k, v){ const ks = k.split('.'); let t = o; ks.slice(0, -1).forEach((x, n) => { if(t[x] == null) t[x] = /^\d+$/.test(ks[n + 1]) ? [] : {}; t = t[x]; }); t[ks[ks.length - 1]] = v; }
  function renderDetails(ro, entry){
    const dis = ro ? ' disabled' : '';
    $('#detail-form').innerHTML = DETAIL_GROUPS.map(([g, hint, fields]) => `<fieldset><legend>${esc(g)}</legend><p class="muted small">${esc(hint)}</p>` + fields.map(([key, label, kind, max, ph]) => {
      const val = getPath(entry, key) ?? '';
      if(kind === 'category') return `<label class="review-field"><span>${esc(label)}</span><select data-key="${key}"${dis}>${Object.keys(CAT_LABEL).map(k => `<option value="${k}"${(entry.category || 'business') === k ? ' selected' : ''}>${CAT_LABEL[k]}</option>`).join('')}</select><small class="muted">Where it is listed and which prices the page links to.</small></label>`;
      if(kind === 'thumb'){
        const photos = entry.photos || [], cur = (entry.card || {}).url || '', custom = !!entry.card_custom;
        const isCur = ph => custom && (ph.sm === cur || ph.url === cur);
        return `<div class="thumb-current"><span class="thumb-frame">${cur ? `<img src="${esc(cur)}" alt="">` : ''}</span><span class="muted small">${custom ? 'Chosen thumbnail.' : 'Using the cover photo (or the picture already on the site).'}${custom && !ro ? ' <button type="button" class="link" data-action="thumb-reset">Use the cover instead</button>' : ''}</span></div>`
          + `<div class="cover-pick thumb-pick">${photos.map((ph, n) => `<button type="button" class="cover-opt${isCur(ph) ? ' is-on' : ''}" data-action="pick-thumb" data-i="${n}"${dis} aria-label="Use photo ${n + 1} as the thumbnail"${isCur(ph) ? ' aria-pressed="true"' : ''}><img src="${esc(ph.sm || ph.url)}" alt="" loading="lazy"></button>`).join('')}`
          + (ro ? '' : `<label class="cover-opt thumb-up" title="Upload a different picture"><input type="file" accept="image/*" data-thumb-file hidden><span>+ Upload<br>another</span></label>`) + `</div>`
          + '<p class="muted small">Upright pictures (4:5) look best in the cards.</p>';
      }
      if(kind === 'cover'){
        const photos = entry.photos || [], cur = (entry.cover || {}).url || '';
        return `<div class="cover-pick" data-cover-pick>${photos.length ? photos.map((ph, n) => `<button type="button" class="cover-opt${ph.url === cur ? ' is-on' : ''}" data-action="pick-cover" data-i="${n}"${dis} aria-label="Use photo ${n + 1} as the cover"${ph.url === cur ? ' aria-pressed="true"' : ''}><img src="${esc(ph.sm || ph.url)}" alt="" loading="lazy"></button>`).join('') : '<p class="muted small">Add photos below first, then pick the cover here.</p>'}</div>`
          + (cur && !photos.some(ph => ph.url === cur) ? `<p class="muted small">Current cover: <a href="${esc(cur)}" target="_blank" rel="noopener">open ↗</a></p>` : '');
      }
      const ctl = kind === 'textarea' ? `<textarea rows="3" maxlength="${max}"` : `<input type="text" maxlength="${max}"`;
      return `<label class="review-field"><span>${esc(label)}</span>${ctl} data-key="${key}" placeholder="${esc(ph || '')}"${dis}` + (kind === 'textarea' ? `>${esc(val)}</textarea>` : ` value="${esc(val)}">`) + '</label>';
    }).join('') + '</fieldset>').join('')
      + `<fieldset><legend>Visibility</legend><label class="vis-row"><input type="checkbox" data-key="published"${entry.published !== false ? ' checked' : ''}${dis}> <span><b>Show this work on the website</b><small class="muted">Untick to hide it from the Work page and “More work” without deleting it.</small></span></label></fieldset>`;
    $$('[data-action="save-details"],[data-action="reset-details"],[data-action="delete-case"]').forEach(b => b.hidden = ro);
  }
  function saveDetails(){
    const entry = caseEntry();
    const title = ($('#detail-form [data-key="title"]') || {}).value || '';
    if(!title.trim()){ toast('The work needs a client or project name'); return; }
    $$('#detail-form [data-key]').forEach(el => {
      const k = el.dataset.key;
      const v = el.type === 'checkbox' ? el.checked : el.value.trim().slice(0, +el.maxLength > 0 ? +el.maxLength : 900);
      setPath(entry, k, v);
    });
    entry.results = (entry.results || []).map(r => String(r || '').trim()).filter(Boolean).slice(0, 4);
    entry.v = 2;
    rebuildCaseList();
    saveCases(entry.published === false ? 'Saved. This work is hidden from the website.' : 'Saved. Live on the website.');
    renderCases();
  }
  document.addEventListener('change', async e => {
    const inp = e.target; if(!inp.matches || !inp.matches('[data-thumb-file]') || !inp.files[0]) return;
    const f = inp.files[0]; inp.value = ''; const slug = caseSlug;
    try{
      toast('Uploading the thumbnail…');
      const ready = await prepPhoto(f);
      const url = await api.upload(ready.file, `case-studies/${slug}/thumb-${Date.now().toString(36)}.${ready.ext}`);
      const entry = content.case_studies[slug]; entry.card = {url}; entry.card_custom = 1;
      rebuildCaseList(); if(caseSlug === slug) renderDetails(!isAdmin(), entry); await saveCases('Thumbnail uploaded. Live on the website.');
    }catch(err){ fail(err); }
  });
  function addWork(){
    const box = $('#new-work'); box.hidden = false; $('#new-work-title').value = ''; $('#new-work-title').focus();
  }
  async function createWork(){
    const title = $('#new-work-title').value.trim(), category = $('#new-work-cat').value;
    if(!title){ toast('Write the client or project name first'); return; }
    const all = content.case_studies = content.case_studies || {};
    let slug = slugify(title) || 'work-' + Date.now().toString(36), n = 2; const base = slug;
    while(all[slug] || caseSeed[slug]) slug = base + '-' + n++;
    const maxOrder = Math.max(-1, ...Object.values(all).map(e => e && e.order != null ? e.order : -1));
    all[slug] = {v: 2, title, category, kicker: '', headline: '', summary: '', cover: null, facts: {client: title, type: '', location: 'Kigali', date: new Date().toLocaleDateString('en-GB', {month: 'long', year: 'numeric'}), services: ''},
                 brief: '', approach: '', results: [], gallery_title: 'The work, up close.', video: null, photos: [], review: null, credits: [], published: false, order: maxOrder + 1, created: new Date().toISOString(), seeded: 1};
    $('#new-work').hidden = true;
    rebuildCaseList(); await saveCases('Work added as hidden. Fill it in, then tick “Show this work on the website”.');
    openCase(slug);
  }
  async function deleteCase(){
    const entry = caseEntry(), name = entry.title || caseSlug;
    if(!confirm(`Delete “${name}”? It disappears from the website. Photos you uploaded stay in storage.`)) return;
    if(caseSeed[caseSlug]) entry.deleted = true; else delete content.case_studies[caseSlug];
    rebuildCaseList(); await saveCases('Deleted.');
    caseSlug = (CASES[0] || {}).slug || ''; renderCaseList(); showCaseView('list');
  }
  function renderCases(){
    if(!caseSlug){ renderCaseList(); return; }
    const ro = !isAdmin(), entry = caseEntry();
    renderDetails(ro, entry);
    $('#cases-readonly').hidden = !ro;
    const cur = CASES.find(c => c.slug === caseSlug) || CASES[0] || {slug: caseSlug, title: entry.title || ''};
    $('#case-title').textContent = entry.title || cur.title;
    $('#case-pos').textContent = (CASES.indexOf(cur) + 1) + ' of ' + CASES.length;
    renderCaseList();
    $('#case-preview').href = caseHref(cur) + (cur.page ? '?' : '&') + 'preview=1';
    renderCredits(ro, entry);
    renderReview(ro, entry);
    const v = entry.video;
    $('#film-url').value = v && v.type === 'link' ? v.url : '';
    $('#film-url').disabled = ro;
    $$('[data-action="save-film-url"],[data-action="remove-film"],.upload-btn').forEach(el => el.hidden = ro);
    $('#film-preview').innerHTML = v && v.url
      ? `<p class="small"><strong>${v.type === 'file' ? 'Uploaded video' : 'Linked video'}:</strong> <a href="${esc(v.url)}" target="_blank" rel="noopener">${esc(v.type === 'file' ? 'open the file' : v.url)}</a></p>` +
        (v.type === 'file' ? `<video src="${esc(v.url)}" controls preload="metadata"></video>` : '')
      : '<p class="muted small">No video yet. The video section stays hidden on the site until you add one.</p>';
    renderPhotos(ro, entry);
  }
  function renderPhotos(ro, entry){
    const photos = entry.photos || [], mine = pendingPhotos.filter(j => j.slug === caseSlug);
    const full = photos.length + mine.length >= MAX_PHOTOS;
    $('#photo-count').textContent = photos.length + ' of ' + MAX_PHOTOS + (mine.length ? ' · uploading ' + mine.filter(j => !j.done).length : '');
    let html = photos.map((p, i) => `<figure class="ph-item" draggable="${ro ? 'false' : 'true'}" data-pi="${i}">
      <div class="ph-thumb"><img src="${esc(p.url)}" alt="" loading="lazy"><span class="ph-num">${i + 1}</span>
      ${ro ? '' : `<div class="ph-tools"><button class="ph-btn" data-action="photo-move" data-i="${i}" data-d="-1" aria-label="Move photo ${i + 1} earlier"${i ? '' : ' disabled'}>←</button><button class="ph-btn" data-action="photo-move" data-i="${i}" data-d="1" aria-label="Move photo ${i + 1} later"${i < photos.length - 1 ? '' : ' disabled'}>→</button><button class="ph-btn danger" data-action="remove-photo" data-i="${i}" aria-label="Remove photo ${i + 1}">✕</button></div>`}</div>
      <input type="text" class="slot-caption" data-i="${i}" value="${esc(p.caption || '')}" placeholder="Describe this photo" maxlength="160" ${ro ? 'disabled' : ''} aria-label="Caption for photo ${i + 1}">
      <select class="slot-group" data-i="${i}" ${ro ? 'disabled' : ''} aria-label="Group for photo ${i + 1}"><option value=""${p.group ? '' : ' selected'}>Group: automatic</option><option value="print"${p.group === 'print' ? ' selected' : ''}>Printed, in use</option><option value="design"${p.group === 'design' ? ' selected' : ''}>Design file</option></select></figure>`).join('');
    html += mine.map(j => `<figure class="ph-item is-up${j.error ? ' is-err' : ''}"><div class="ph-thumb"><img src="${esc(j.preview)}" alt=""><span class="ph-state">${j.error ? 'Failed' : j.done ? 'Done' : j.started ? 'Uploading…' : 'Waiting…'}</span></div><small class="ph-name">${esc(j.error ? String(j.error.message || j.error).slice(0, 90) : j.name)}</small></figure>`).join('');
    if(!ro && !full) html += `<label class="ph-add"><input type="file" accept="image/*" multiple data-photo hidden><span class="ph-plus">+</span><strong>Add photos</strong><small>or drop them here</small></label>`;
    if(ro && !photos.length) html = '<p class="muted small">No uploaded photos.</p>';
    $('#photo-grid').innerHTML = html;
    $('#photo-note').innerHTML = 'These are the photos on this work page, in this order. '
      + 'Drop several at once: they\'re resized and compressed for you. Drag to reorder. A short caption helps Google and blind visitors. '
      + 'For branding work, set each photo to “Printed, in use” or “Design file”: the page then shows them in two groups.';
  }
  async function addPhotos(files){
    const slug = caseSlug, entry = caseEntry(); entry.photos = entry.photos || [];
    files = files.filter(f => /^image\//.test(f.type) || /\.(heic|heif)$/i.test(f.name));
    if(!files.length){ toast('Those aren\'t photos'); return; }
    const room = MAX_PHOTOS - entry.photos.length - pendingPhotos.filter(j => j.slug === slug && !j.done).length;
    if(room <= 0){ toast('This case study is full (' + MAX_PHOTOS + ' photos). Remove one first.'); return; }
    if(files.length > room){ toast('Only ' + room + ' more fit. Adding the first ' + room + '.'); files = files.slice(0, room); }
    const jobs = files.map((f, k) => ({slug, name: f.name, file: f, preview: URL.createObjectURL(f), key: Date.now().toString(36) + k}));
    pendingPhotos.push(...jobs); renderPhotos(false, entry);
    let next = 0;
    const worker = async () => {
      while(next < jobs.length){
        const j = jobs[next++]; j.started = true; if(caseSlug === slug) renderPhotos(false, caseEntry());
        try{
          const ready = await prepPhoto(j.file);
          const url = await api.upload(ready.file, `case-studies/${slug}/photo-${j.key}.${ready.ext}`);
          j.result = {url, caption: '', w: ready.w, h: ready.h};
        }catch(e){ j.error = e; }
        j.done = true; if(caseSlug === slug) renderPhotos(false, caseEntry());
      }
    };
    await Promise.all([worker(), worker(), worker()]);
    jobs.forEach(j => { if(j.result) entry.photos.push(j.result); });
    const ok = jobs.filter(j => j.result).length, bad = jobs.length - ok;
    setTimeout(() => { jobs.forEach(j => URL.revokeObjectURL(j.preview)); pendingPhotos = pendingPhotos.filter(j => !jobs.includes(j) || j.error); if(caseSlug === slug) renderPhotos(false, caseEntry()); }, bad ? 8000 : 0);
    pendingPhotos = pendingPhotos.filter(j => !jobs.includes(j) || j.error);
    if(caseSlug === slug) renderCases();
    if(ok) await saveCases(ok + ' photo' + (ok === 1 ? '' : 's') + ' added. Live on the site.' + (bad ? ' ' + bad + ' failed.' : ''));
    else toast('Upload failed: ' + ((jobs[0].error && jobs[0].error.message) || 'please try again') + (/bucket/i.test(String(jobs[0].error && jobs[0].error.message)) ? '. Run admin/supabase-setup.sql again to create the media storage.' : ''));
  }
  function movePhoto(from, to){
    const entry = caseEntry(), list = entry.photos || [];
    if(to < 0 || to >= list.length || from === to) return;
    const [p] = list.splice(from, 1); list.splice(to, 0, p);
    renderPhotos(false, entry); saveCases('Order saved.');
  }
  async function uploadFilm(file){
    if(file.size > MAX_VIDEO_MB * 1024 * 1024){ toast('That video is over ' + MAX_VIDEO_MB + ' MB. Put it on YouTube, Instagram or Google Drive and paste the link instead.'); return; }
    if(busy) return; busy = true;
    try{
      toast('Uploading video… keep this page open');
      const ext = (file.name.split('.').pop() || 'mp4').toLowerCase();
      const url = await api.upload(file, `case-studies/${caseSlug}/film-${Date.now()}.${ext}`);
      const entry = caseEntry(), old = entry.video;
      entry.video = {type:'file', url};
      if(old && old.type === 'file') api.removeFile(old.url).catch(()=>{});
      renderCases(); await saveCases('Video saved. Live on the site.');
    }catch(e){ fail(e); }
    busy = false;
  }

  // ------------------------------------------------------------------ helpers
  function toast(msg){ const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(t._h); t._h = setTimeout(()=>t.classList.remove('show'), 2600); }
  function fail(e){ console.error(e); if(e && /row-level security|violates row level|Unauthorized|not authorized/i.test(e.message || '')){ toast('Not saved: your account is missing a permission in Supabase. Run admin/dashboard-fix.sql once in Supabase (SQL Editor), then try again.'); return; } if(e && (e.code === '23514' || /site_content_key_check/.test(e.message || ''))){ toast('Not saved: the database needs a one-time update. Run admin/dashboard-fix.sql in Supabase (SQL Editor), then publish again.'); return; } toast('Something went wrong: ' + (e && e.message ? e.message : 'please try again')); }
  function show(id){ ['view-login','view-noaccess','view-app','view-code','view-password','view-app-setup'].forEach(v => { const el = $('#'+v); if(el) el.hidden = v !== id; }); }
  function when(iso){
    const d = new Date(iso), diff = (Date.now() - d) / 1000;
    if(diff < 3600) return Math.max(1, Math.round(diff/60)) + ' min ago';
    if(diff < 86400) return Math.round(diff/3600) + ' h ago';
    if(diff < 7*86400) return Math.round(diff/86400) + ' d ago';
    return d.toLocaleDateString('en-GB', {day:'numeric', month:'short'});
  }
  function waNumber(contact){
    if(!contact || contact.includes('@')) return null;
    let d = contact.replace(/\D/g,'');
    if(d.startsWith('0')) d = '250' + d.slice(1);
    else if(d.length === 9 && d.startsWith('7')) d = '250' + d;
    return d.length >= 10 ? d : null;
  }
  const memberName = uid => (team.find(m => m.user_id === uid) || {}).name || '';
  const initials = n => (n || '?').split(/\s+/).map(w => w.replace(/[^\p{L}]/gu,'')).filter(Boolean).slice(0,2).map(w => w[0].toUpperCase()).join('') || '?';
  const isAdmin = () => me && (me.role === 'admin' || me.role === 'owner');
  const isOwner = () => me && me.role === 'owner';
  const roleName = r => r === 'owner' ? 'Main admin' : r === 'admin' ? 'Admin' : 'Staff';

  // ------------------------------------------------------------------ leads
  function renderLeads(){
    const counts = Object.fromEntries(STATUSES.map(([k]) => [k, 0]));
    leads.forEach(l => counts[l.status] = (counts[l.status]||0) + 1);

    // KPIs
    const weekAgo = Date.now() - 7*864e5, month = new Date(); month.setDate(1); month.setHours(0,0,0,0);
    const newWeek = leads.filter(l => new Date(l.created_at) > weekAgo).length;
    const open = leads.filter(l => ['new','replied','quoted'].includes(l.status));
    const pipeline = leads.filter(l => l.status === 'quoted').reduce((s,l) => s + (Number(l.value_rwf)||0), 0);
    const bookedMonth = leads.filter(l => l.status === 'booked' && new Date(l.updated_at || l.created_at) >= month);
    const bookedValue = bookedMonth.reduce((s,l) => s + (Number(l.value_rwf)||0), 0);
    const closed = counts.booked + counts.lost;
    const win = closed ? Math.round(counts.booked / closed * 100) + '%' : '—';
    $('#kpis').innerHTML = [
      ['Waiting for reply', counts.new, counts.new ? 'New enquiries to answer' : 'All caught up'],
      ['New this week', newWeek, 'Enquiries in 7 days'],
      ['Open leads', open.length, 'New, replied or quoted'],
      ['Quoted value', fmt(pipeline), 'RWF waiting on a decision'],
      ['Booked this month', bookedMonth.length, fmt(bookedValue) + ' RWF · win rate ' + win],
    ].map(([a,b,c]) => `<div class="kpi"><span>${esc(a)}</span><strong>${esc(b)}</strong><small>${esc(c)}</small></div>`).join('');

    // Insights
    const top = (key) => {
      const m = {}; leads.forEach(l => { const k = (l[key] || 'unknown').toString(); m[k] = (m[k]||0) + 1; });
      const rows = Object.entries(m).sort((a,b) => b[1]-a[1]).slice(0,6), max = rows.length ? rows[0][1] : 1;
      return rows.length ? rows.map(([k,v]) => `<div class="bar"><span class="bar-label"><i style="width:${Math.round(v/max*100)}%"></i><b>${esc(k)}</b></span><span class="bar-count">${v}</span></div>`).join('') : '<p class="muted small">No data yet.</p>';
    };
    $('#by-source').innerHTML = top('source');
    $('#by-service').innerHTML = top('service');

    // Pills
    $('#status-pills').innerHTML = [['all','All', leads.length], ...STATUSES.map(([k,l]) => [k,l,counts[k]])]
      .map(([k,l,n]) => `<button class="pill${filter===k?' is-active':''}" data-filter="${k}" role="tab" aria-selected="${filter===k}">${l}<em>${n}</em></button>`).join('');

    // Rows
    const q = query.trim().toLowerCase();
    const rows = leads.filter(l => (filter === 'all' || l.status === filter) &&
      (!q || [l.name,l.contact,l.service,l.offer,l.source,l.details].join(' ').toLowerCase().includes(q)));
    $('#leads-table tbody').innerHTML = rows.map(l => `
      <tr data-id="${l.id}" class="${l.status==='new'?'is-new-row':''}">
        <td data-label="Received">${esc(when(l.created_at))}</td>
        <td><div class="lead-name">${esc(l.name)}</div><div class="lead-sub">${esc(l.contact)}</div></td>
        <td data-label="Service">${esc(l.offer || l.service || '—')}${l.offer && l.service ? `<div class="lead-sub">${esc(l.service)}</div>` : ''}</td>
        <td data-label="Date wanted">${esc(l.event_date || '—')}</td>
        <td data-label="Source">${esc(l.source || '—')}</td>
        <td class="num" data-label="Value">${fmt(l.value_rwf)}</td>
        <td><span class="badge s-${esc(l.status)}">${esc(STATUS_LABEL[l.status] || l.status)}</span></td>
      </tr>`).join('');
    $('#leads-empty').hidden = rows.length > 0;
    $('#leads-sub').textContent = `${leads.length} enquiries from the website${LIVE ? '' : ' (demo)'}.`;
    const lc = $('#leads-count'); if(lc){ lc.textContent = counts.new || ''; lc.hidden = !counts.new; }
    // Pipeline board: one column per status, cards can be dragged between columns
    const board = $('#leads-board');
    if(board){
      board.innerHTML = STATUSES.map(([k,lab]) => {
        const col = rows.filter(l => l.status === k);
        const total = col.reduce((s,l) => s + (Number(l.value_rwf)||0), 0);
        return `<section class="col s-${k}" data-col="${k}"><header><span class="dot"></span><b>${esc(lab)}</b><em>${col.length}</em>${total ? `<small>${fmt(total)} RWF</small>` : ''}</header>
          <div class="col-body" data-drop="${k}">${col.map(l => `<article class="card" draggable="true" data-lead="${l.id}" tabindex="0">
            <div class="card-top"><b>${esc(l.name)}</b><time>${esc(when(l.created_at))}</time></div>
            <p>${esc(l.offer || l.service || '—')}</p>
            <div class="card-meta">${l.event_date ? `<span>${esc(l.event_date)}</span>` : ''}${l.value_rwf ? `<span>${fmt(l.value_rwf)} RWF</span>` : ''}${l.assigned_to ? `<span class="who" title="${esc(memberName(l.assigned_to))}">${esc(initials(memberName(l.assigned_to)))}</span>` : ''}</div>
          </article>`).join('') || '<p class="col-empty">Drop leads here</p>'}</div></section>`;
      }).join('');
      board.hidden = view !== 'board';
    }
    if($('#table-wrap')) $('#table-wrap').hidden = view === 'board';
    const ins = document.querySelector('.insights'); if(ins) ins.hidden = view === 'board';
    if(view === 'board') $('#leads-empty').hidden = true;
    $$('[data-action="view-table"],[data-action="view-board"]').forEach(b => { const on = b.dataset.action === 'view-' + view; b.classList.toggle('is-active', on); b.setAttribute('aria-pressed', on); });
  }

  function openDrawer(id){
    const l = leads.find(x => x.id === id); if(!l) return;
    openId = id;
    $('#d-new').hidden = true; $('#d-facts').hidden = false; $('#d-quick').hidden = false;
    $('#d-name').textContent = l.name;
    const wa = waNumber(l.contact), first = (l.name || '').split(' ')[0];
    const about = l.offer ? `our “${l.offer}” offer` : (l.service ? l.service.toLowerCase() : 'your project');
    const msg = encodeURIComponent(`Hi ${first}, thank you for contacting CRT Media Agency about ${about}. `);
    $('#d-quick').innerHTML =
      (wa ? `<a class="btn small" href="https://wa.me/${wa}?text=${msg}" target="_blank" rel="noopener" data-action="wa-reply">Reply on WhatsApp</a><a class="btn secondary small" href="tel:+${wa}">Call</a>` : '') +
      (l.contact && l.contact.includes('@') ? `<a class="btn small" href="mailto:${esc(l.contact)}?subject=${encodeURIComponent('Your enquiry with CRT Media Agency')}" data-action="wa-reply">Reply by email</a>` : '');
    const facts = [['Contact', l.contact], ['Service', l.service], ['Offer / package', l.offer], ['Date wanted', l.event_date],
      ['Message', l.details], ['Source', l.source], ['Page', l.page], ['Received', new Date(l.created_at).toLocaleString('en-GB')]];
    $('#d-facts').innerHTML = facts.filter(f => f[1]).map(([k,v]) => `<dt>${esc(k)}</dt><dd${k === 'Message' ? ' class="d-msg"' : ''}>${k === 'Message' ? fmtMessage(v) : esc(v)}</dd>`).join('');
    $('#d-status').innerHTML = STATUSES.map(([k,lab]) => `<option value="${k}"${l.status===k?' selected':''}>${lab}</option>`).join('');
    $('#d-value').value = l.value_rwf ?? '';
    $('#d-assigned').innerHTML = '<option value="">Nobody yet</option>' + team.map(m => `<option value="${esc(m.user_id)}"${l.assigned_to===m.user_id?' selected':''}>${esc(m.name || 'Team member')}</option>`).join('');
    $('#d-notes').value = l.notes || '';
    $('#d-delete').hidden = !isAdmin();
    $('#drawer').classList.add('is-open'); $('#drawer').setAttribute('aria-hidden','false'); $('#drawer-scrim').hidden = false;
    setTimeout(() => $('#d-status').focus(), 50);
  }
  // A lead that came in outside the website form (WhatsApp, phone, walk-in).
  function openNewLead(){
    openId = 'new';
    $('#d-name').textContent = 'Add a lead';
    $('#d-new').hidden = false; $('#d-facts').hidden = true; $('#d-quick').hidden = true; $('#d-delete').hidden = true;
    ['n-name','n-contact','n-offer','n-date','n-details','d-value','d-notes'].forEach(id => $('#'+id).value = '');
    $('#n-service').innerHTML = SERVICES.map(s => `<option>${esc(s)}</option>`).join('');
    $('#n-source').innerHTML = SOURCES.map(s => `<option>${esc(s)}</option>`).join('');
    $('#d-status').innerHTML = STATUSES.map(([k,lab]) => `<option value="${k}"${k==='new'?' selected':''}>${lab}</option>`).join('');
    $('#d-assigned').innerHTML = '<option value="">Nobody yet</option>' + team.map(m => `<option value="${esc(m.user_id)}"${me && m.user_id===me.user_id?' selected':''}>${esc(m.name || 'Team member')}</option>`).join('');
    $('#drawer').classList.add('is-open'); $('#drawer').setAttribute('aria-hidden','false'); $('#drawer-scrim').hidden = false;
    setTimeout(() => $('#n-name').focus(), 50);
  }
  async function addLead(){
    const name = $('#n-name').value.trim(), contact = $('#n-contact').value.trim();
    if(!name || !contact){ toast('Add a name and a way to contact them'); (name ? $('#n-contact') : $('#n-name')).focus(); return; }
    const v = $('#d-value').value.trim();
    const row = {
      name: name.slice(0,120), contact: contact.slice(0,160), service: $('#n-service').value,
      offer: $('#n-offer').value.trim().slice(0,120) || null, event_date: $('#n-date').value.trim().slice(0,120) || null,
      details: $('#n-details').value.trim().slice(0,2000) || null, source: $('#n-source').value, page: 'Added by hand',
      status: $('#d-status').value, value_rwf: v === '' ? null : Math.max(0, Math.round(Number(v))),
      assigned_to: $('#d-assigned').value || null, notes: $('#d-notes').value.slice(0,5000) || null
    };
    try{ const saved = await api.addLead(row); leads.unshift(saved); filter = 'all'; renderLeads(); closeDrawer(); toast('Lead added'); }catch(e){ fail(e); }
  }

  function closeDrawer(){ openId = null; $('#drawer').classList.remove('is-open'); $('#drawer').setAttribute('aria-hidden','true'); $('#drawer-scrim').hidden = true; }

  async function saveLead(){
    if(openId === 'new') return addLead();
    const l = leads.find(x => x.id === openId); if(!l) return;
    const v = $('#d-value').value.trim();
    const patch = { status: $('#d-status').value, value_rwf: v === '' ? null : Math.max(0, Math.round(Number(v))), assigned_to: $('#d-assigned').value || null, notes: $('#d-notes').value.slice(0,5000) };
    try{ await api.updateLead(l.id, patch); Object.assign(l, patch, {updated_at: new Date().toISOString()}); renderLeads(); closeDrawer(); toast('Lead saved'); }catch(e){ fail(e); }
  }

  function exportCsv(){
    const cols = ['created_at','name','contact','service','offer','event_date','details','source','page','status','value_rwf','notes'];
    const cell = v => '"' + String(v == null ? '' : v).replace(/"/g,'""') + '"';
    const header = [...cols, 'handled_by'];
    const csv = [header.join(','), ...leads.map(l => [...cols.map(c => cell(l[c])), cell(memberName(l.assigned_to))].join(','))].join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob(['﻿' + csv], {type:'text/csv'}));
    a.download = 'crt-leads-' + new Date().toISOString().slice(0,10) + '.csv';
    document.body.appendChild(a); a.click(); a.remove();
  }

  // ------------------------------------------------------------------ content
  function renderContent(){
    const p = content.prices || {}, pk = content.packages || {}, ro = !isAdmin();
    $('#content-readonly').hidden = !ro;
    $('#prices-form').innerHTML = PRICE_FIELDS.map(([k,label,where]) => `
      <div class="price-item"><label for="p-${k}">${esc(label)}</label>
      <input id="p-${k}" name="${k}" type="number" min="0" step="1000" value="${esc(p[k] ?? '')}" ${ro?'disabled':''}>
      <small>${p[k] ? fmt(p[k]) + ' RWF · ' : ''}${esc(where)}</small></div>`).join('');
    $$('[data-action="save-prices"]').forEach(b => b.hidden = ro);
    renderTestimonials();
  }

  // Testimonials: real client words, shown on the home page when at least one exists.
  const MAX_TESTIMONIALS = 6;
  function renderTestimonials(){
    const list = Array.isArray(content.testimonials) ? content.testimonials : [], ro = !isAdmin();
    if(!$('#t-tags')) document.body.insertAdjacentHTML('beforeend', '<datalist id="t-tags"><option>Wedding photography</option><option>Wedding video</option><option>Event photography</option><option>Event branding</option><option>Product photography</option><option>Brand photography</option><option>Branding & logo</option><option>Social media content</option><option>Website</option><option>Print</option></datalist>');
    $('#testimonials-list').innerHTML = list.length ? list.map((t, i) => `
      <div class="testimonial-row" data-i="${i}">
        <div class="field"><label for="t-quote-${i}">What they said</label><textarea id="t-quote-${i}" data-t="quote" rows="3" maxlength="400" ${ro?'disabled':''}>${esc(t.quote)}</textarea></div>
        <div class="price-grid">
          <div class="field"><label for="t-name-${i}">Name</label><input id="t-name-${i}" data-t="name" maxlength="80" value="${esc(t.name)}" ${ro?'disabled':''}></div>
          <div class="field"><label for="t-role-${i}">Job title</label><input id="t-role-${i}" data-t="role" maxlength="80" value="${esc(t.company ? t.role : (t.role || '').split(', ').slice(0, -1).join(', ') || t.role)}" placeholder="e.g. Marketing manager, or Bride" ${ro?'disabled':''}></div>
          <div class="field"><label for="t-co-${i}">Company or project</label><input id="t-co-${i}" data-t="company" maxlength="80" value="${esc(t.company || ((t.role || '').includes(', ') ? (t.role || '').split(', ').pop() : ''))}" placeholder="e.g. Rwanda Mines Board, or Wedding, June 2026" ${ro?'disabled':''}></div>
        </div>
        <div class="price-grid">
          <div class="field"><label for="t-tag-${i}">Service</label><input id="t-tag-${i}" data-t="tag" maxlength="40" list="t-tags" value="${esc(t.tag || '')}" placeholder="e.g. Wedding photography" ${ro?'disabled':''}></div>
          <div class="field"><label for="t-link-${i}">Link to the work (optional)</label><select id="t-link-${i}" data-t="link" ${ro?'disabled':''}><option value="">No link</option>${CASES.filter(c => c.published).map(c => { const v = c.page ? '/' + c.slug + '/index.html' : '/case/?s=' + c.slug; return `<option value="${esc(v)}"${t.link === v ? ' selected' : ''}>${esc(c.title)}</option>`; }).join('')}</select></div>
        </div>
        ${ro ? '' : `<button class="link danger" data-action="remove-testimonial" data-i="${i}">Remove</button>`}
      </div>`).join('') : '<p class="muted small">No testimonials yet. The section stays hidden on the site until you add one.</p>';
    $$('[data-action="add-testimonial"],[data-action="save-testimonials"]').forEach(b => b.hidden = ro);
  }
  function readTestimonials(){
    return $$('#testimonials-list .testimonial-row').map(row => ({
      quote: row.querySelector('[data-t="quote"]').value.trim().slice(0, 400),
      name: row.querySelector('[data-t="name"]').value.trim().slice(0, 80),
      role: row.querySelector('[data-t="role"]').value.trim().slice(0, 80),
      company: row.querySelector('[data-t="company"]').value.trim().slice(0, 80),
      tag: row.querySelector('[data-t="tag"]').value.trim().slice(0, 40),
      link: row.querySelector('[data-t="link"]').value
    }));
  }
  async function saveTestimonials(){
    const list = readTestimonials();
    if(list.some(t => !t.quote || !t.name)){ toast('Each testimonial needs the words and a name'); return; }
    try{ await api.saveContent('testimonials', list); content.testimonials = list; renderTestimonials(); toast(list.length ? 'Testimonials saved. Live on the home page.' : 'Saved. The section is hidden.'); }catch(e){ fail(e); }
  }
  async function savePrices(){
    const next = {}; let bad = false;
    PRICE_FIELDS.forEach(([k]) => { const v = Number($('#p-'+k).value); if(!(v > 0)) bad = true; next[k] = Math.round(v); });
    if(bad){ toast('Every price needs a number above 0'); return; }
    try{ await api.saveContent('prices_v2', next); content.prices = next; renderContent(); toast('Prices saved. The site updates on the next page load.'); }catch(e){ fail(e); }
  }

  // ------------------------------------------------------------------ inbox
  let inbox = [], inboxLoaded = false, inboxOpen = null, inboxStart = 1;
  const INBOX_PAGE = 50;
  const mailWhen = ms => ms ? when(new Date(ms).toISOString()) : '';
  function renderInbox(){
    $('#inbox-list').innerHTML = inbox.map(m => `
      <li data-mid="${esc(m.messageId)}" class="${m.unread ? 'unread' : ''}${inboxOpen && inboxOpen.messageId === m.messageId ? ' is-open' : ''}">
        <div class="m-row"><span class="m-from">${esc(m.from || m.fromAddress)}</span><span class="m-time">${esc(mailWhen(m.received))}</span></div>
        <div class="m-subject">${esc(m.subject)}</div>
        <div class="m-summary">${esc(m.summary)}</div>
      </li>`).join('');
    $('#inbox-empty').hidden = inbox.length > 0;
    const unread = inbox.filter(m => m.unread).length;
    $('#inbox-count').hidden = !unread; $('#inbox-count').textContent = unread;
  }
  async function loadInbox(more){
    $('#inbox-setup').hidden = true;
    try{
      if(!more) inboxStart = 1;
      const res = await api.inbox({action:'list', limit:INBOX_PAGE, start:inboxStart});
      const got = res.messages || [];
      inbox = more ? inbox.concat(got) : got;
      inboxStart += got.length;
      $('#inbox-more').hidden = got.length < INBOX_PAGE;
      inboxLoaded = true; renderInbox();
      $('#inbox-sub').textContent = 'Email sent to hello@crt.rw and alain@crt.rw' + (LIVE ? '.' : ' (demo).');
    }catch(e){
      const notConnected = /not_connected/.test(e.message);
      $('#inbox-setup').hidden = false;
      $('#inbox-setup-msg').innerHTML = notConnected
        ? 'The inbox isn’t connected yet. Follow <code>admin/INBOX-SETUP.txt</code> to connect Zoho Mail (about 10 minutes, once).'
        : 'Couldn’t load email: ' + esc(e.message) + '. If this keeps happening, check the Zoho connection in <code>admin/INBOX-SETUP.txt</code>.';
      inbox = []; renderInbox();
    }
  }
  async function openMail(mid){
    const m = inbox.find(x => x.messageId === mid); if(!m) return;
    inboxOpen = m; m.unread = false; renderInbox();
    const r = $('#inbox-reader');
    r.innerHTML = `<h2>${esc(m.subject)}</h2>
      <div class="reader-meta">From <strong>${esc(m.from)}</strong> &lt;${esc(m.fromAddress)}&gt; · ${esc(m.received ? new Date(m.received).toLocaleString('en-GB') : '')}</div>
      <div class="reader-actions">
        <a class="btn small" href="mailto:${esc(m.fromAddress)}?subject=${encodeURIComponent('Re: ' + m.subject)}">Reply</a>
        <button class="btn secondary small" data-action="mail-to-lead">Save as lead</button>
        <a class="btn secondary small" href="https://mail.zoho.com/zm/#mail/folder/inbox/p/${encodeURIComponent(m.messageId)}" target="_blank" rel="noopener">Open in Zoho ↗</a>
      </div>
      <p class="muted small" id="reader-status">Loading…</p>`;
    try{
      const res = await api.inbox({action:'read', folderId:m.folderId, messageId:m.messageId});
      if(inboxOpen !== m) return;
      const frame = document.createElement('iframe');
      frame.className = 'reader-frame'; frame.title = 'Email: ' + m.subject;
      // No scripts can run inside the email; links open in a new tab.
      frame.setAttribute('sandbox', 'allow-popups allow-popups-to-escape-sandbox');
      frame.setAttribute('referrerpolicy', 'no-referrer');
      frame.srcdoc = '<!doctype html><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="script-src \'none\'"><base target="_blank"><style>body{font:15px/1.5 -apple-system,system-ui,sans-serif;margin:16px;color:#141a2e}img{max-width:100%;height:auto}</style>' + (res.html || '<p>(empty message)</p>');
      $('#reader-status').replaceWith(frame);
    }catch(e){ const s = $('#reader-status'); if(s) s.textContent = 'Couldn’t open this email: ' + e.message; }
  }
  async function mailToLead(){
    const m = inboxOpen; if(!m) return;
    const row = {
      name: (m.from || m.fromAddress || 'Email enquiry').slice(0,120), contact: (m.fromAddress || m.from || 'unknown').slice(0,160),
      service: 'Creative project', offer: null, event_date: null,
      details: (m.subject + (m.summary ? ': ' + m.summary : '')).slice(0,2000),
      source: 'Email', page: 'Email to crt.rw', status: 'new', value_rwf: null,
      assigned_to: me ? me.user_id : null, notes: null
    };
    try{ const saved = await api.addLead(row); leads.unshift(saved); renderLeads(); toast('Saved as a lead. Find it in Leads.'); }catch(e){ fail(e); }
  }

  // ------------------------------------------------------------------ team
  // The main admin adds, changes and removes people here; nobody needs to open Supabase.
  let security = null;
  const TEAM_ERR = {bad_email: 'That email doesn’t look right.', bad_name: 'Add their name.', bad_phone: 'Write the phone with the country code, like +250 788 123 456.', email_taken: 'That email already has an account.',
    owner_only: 'Only the main admin can do that.', verify_first: 'Enter your sign-in code first.', no_phone: 'Add your phone number first.', no_method: 'Set up the authenticator app (or text messages) first.', no_sms_provider: 'Text messages aren’t connected yet. Add the keys in Team → Connections.',
    test_code_first: 'Receive and enter a test code first, so we know texts reach you.', cannot_remove_self: 'You can’t remove yourself.', own_role: 'You can’t change your own role.'};
  const teamErr = e => TEAM_ERR[e && e.code] || ('Something went wrong: ' + ((e && e.message) || 'please try again'));
  function renderTeam(){
    const own = isOwner();
    $('#team-table tbody').innerHTML = team.map(m => {
      const self = m.user_id === me.user_id, edit = own && m.role !== 'owner';
      return `<tr data-uid="${esc(m.user_id)}">
        <td>${own ? `<input type="text" value="${esc(m.name)}" data-field="name" aria-label="Name">` : esc(m.name)}${self ? ' <span class="lead-sub">(you)</span>' : ''}</td>
        <td class="muted small">${esc(m.email || '')}</td>
        <td>${own ? `<input type="tel" value="${esc(m.phone || '')}" data-field="phone" placeholder="+250 7xx xxx xxx" aria-label="Phone for ${esc(m.name)}">` : esc(m.phone || '—')}</td>
        <td>${edit ? `<select data-field="role" aria-label="Role"><option value="staff"${m.role === 'staff' ? ' selected' : ''}>Staff</option><option value="admin"${m.role === 'admin' ? ' selected' : ''}>Admin</option></select>` : `<span class="role-chip is-${esc(m.role)}">${roleName(m.role)}</span>`}</td>
        <td class="num">${edit ? '<button class="link" data-action="reset-member">New password</button> <button class="link" data-action="reset-app">Reset app</button> <button class="link danger" data-action="remove-member">Remove</button>' : ''}</td>
      </tr>`; }).join('');
    $('#team-add').hidden = !own;
    $('#team-sub').textContent = own ? 'Who can use this dashboard. You are the main admin: only you add, change or remove people.' : 'Who can use this dashboard. Ask the main admin to add or change people.';
    renderSecurity();
  }
  function renderSecurity(){
    const box = $('#team-security'); if(!box) return;
    box.hidden = !isOwner(); if(box.hidden) return;
    const s = security || {}, on = !!s.require_code, ready = !!(s.app || (s.provider && s.has_phone));
    box.innerHTML = `<div class="sec-head"><div><h2>Sign-in code on your phone</h2><p class="muted small">After the password, everyone also enters a 6-digit code from their phone: from the authenticator app, or by text message. The database refuses everything until the code is entered.</p></div>
      <span class="role-chip ${on ? 'is-on' : 'is-off'}">${on ? 'On' : 'Off'}</span></div>
      <ul class="sec-ways"><li><b>Authenticator app</b> (free, works now) ${s.app ? '<span class="role-chip is-on">Set up</span>' : '<span class="role-chip is-off">Not set up</span>'}<button type="button" class="link" data-action="app-setup">${s.app ? 'Move to a new phone' : 'Set up on my phone'}</button></li>
        <li><b>Text message</b> ${s.provider && s.has_phone ? '<span class="role-chip is-on">Ready</span>' : `<span class="role-chip is-off">${s.provider ? 'Add your phone number above' : 'Add the keys in Connections below'}</span>`}</li></ul>
      ${!LIVE ? '<p class="muted small">Not available in demo mode.</p>' : ''}
      <div class="row-end">${on ? '<button class="btn secondary small" data-action="sec-off">Switch off</button>' : `<button class="btn small" data-action="sec-on"${LIVE && ready ? '' : ' disabled'}>Check my code and switch on</button>`}</div>`;
  }
  async function loadSecurity(){ if(!LIVE) return; try{ security = await api.teamFn({action: 'status'}); }catch(e){ security = null; } renderSecurity(); loadConnections(); }

  // ---- Connections: the keys for text messages and the mailbox, entered here instead of in Supabase.
  // Kept in a locked table only the server functions can read; this screen only learns whether each key is set.
  let conn = null;
  const CONN = [
    ['Text messages: Africa’s Talking (recommended in Rwanda)', [['AT_USERNAME', 'Username'], ['AT_API_KEY', 'API key', 1], ['AT_SENDER_ID', 'Sender ID (optional, once approved, e.g. CRT)']]],
    ['Text messages: Twilio (instead of Africa’s Talking)', [['TWILIO_ACCOUNT_SID', 'Account SID'], ['TWILIO_AUTH_TOKEN', 'Auth token', 1], ['TWILIO_FROM', 'From number (+1…)']]],
    ['Mailbox for the Inbox tab: Zoho Mail', [['ZOHO_CLIENT_ID', 'Client ID'], ['ZOHO_CLIENT_SECRET', 'Client secret', 1], ['ZOHO_REFRESH_TOKEN', 'Refresh token', 1]]]
  ];
  async function loadConnections(){ if(!LIVE || !isOwner()) return; try{ conn = await api.teamFn({action: 'connections'}); }catch(e){ conn = null; } renderConnections(); }
  function renderConnections(){
    const box = $('#team-connections'); if(!box) return;
    box.hidden = !isOwner(); if(box.hidden) return;
    const set = (conn && conn.set) || {};
    box.innerHTML = `<h2>Connections</h2><p class="muted small">Keys from your text-message and mailbox accounts. They stay locked on the server: once saved, nobody can read them back, not even here. Leave a field empty to keep what is saved.</p>
      <form id="conn-form">${CONN.map(([title, keys]) => `<fieldset class="conn-set"><legend>${esc(title)}</legend>${keys.map(([k, label, secret]) => `<div class="field"><label for="c-${k}">${esc(label)} ${set[k] ? '<span class="role-chip is-on">Saved</span>' : ''}</label><input id="c-${k}" name="${k}" ${secret ? 'type="password"' : ''} autocomplete="off" spellcheck="false" placeholder="${set[k] ? '•••••••• (saved, type to replace)' : ''}"></div>`).join('')}</fieldset>`).join('')}
      <div class="row-end">${set.AT_API_KEY || set.TWILIO_AUTH_TOKEN ? '<button type="button" class="btn secondary small" data-action="conn-test">Send me a test text</button>' : ''}<button class="btn small" type="submit">Save connections</button></div></form>
      ${!LIVE ? '<p class="muted small">Not available in demo mode.</p>' : ''}`;
    $('#conn-form').onsubmit = async e => {
      e.preventDefault(); const values = {};
      [...e.target.querySelectorAll('input')].forEach(i => { if(i.value.trim()) values[i.name] = i.value.trim(); });
      if(!Object.keys(values).length){ toast('Nothing new to save'); return; }
      try{ conn = await api.teamFn({action: 'save_connections', values}); renderConnections(); if(security){ security.provider = conn.provider; renderSecurity(); } toast('Connections saved'); }catch(err){ toast(teamErr(err)); }
    };
  }
  function shareText(name, email, password){
    return `Hi ${name.split(' ')[0]}, your CRT dashboard account is ready.\nSign in at https://crt.rw/admin/\nEmail: ${email}\nOne-time password: ${password}\nYou'll choose your own password when you sign in.`;
  }
  function showMade(name, email, password){
    const box = $('#team-made'), msg = shareText(name, email, password);
    box.hidden = false;
    box.innerHTML = `<h3>Account ready for ${esc(name)}</h3><p class="muted small">Send this privately (WhatsApp is fine). The password works once: they choose their own when they sign in. It isn’t shown again.</p>
      <pre class="code" id="made-msg">${esc(msg)}</pre><div class="row-end"><button type="button" class="btn secondary small" data-action="copy-made">Copy message</button><a class="btn small" target="_blank" rel="noopener" href="https://wa.me/?text=${encodeURIComponent(msg)}">Send on WhatsApp ↗</a></div>`;
  }

  // ---- sign-in gate: one-time password → own password; then the code by text message
  function askPassword(){
    return new Promise(res => {
      show('view-password'); $('#pw-new').focus();
      $('#pw-form').onsubmit = async e => {
        e.preventDefault(); const a = $('#pw-new').value, b = $('#pw-again').value, msg = $('#pw-msg');
        if(a.length < 10){ msg.textContent = 'Use at least 10 characters.'; return; }
        if(a !== b){ msg.textContent = 'The two passwords don’t match.'; return; }
        msg.textContent = 'Saving…';
        const {error} = await sb.auth.updateUser({password: a});
        if(error){ msg.textContent = 'Couldn’t save: ' + error.message; return; }
        try{ await api.teamFn({action: 'password_set'}); }catch(err){}
        msg.textContent = ''; res();
      };
    });
  }
  function askCode(st){
    return new Promise(res => {
      show('view-code');
      const msg = $('#code-msg'), inp = $('#code-input'), again = $('#code-resend');
      let t = 0;
      const wait = n => { again.disabled = true; clearInterval(t); let left = n; again.textContent = `Send a new code (${left}s)`; t = setInterval(() => { left--; if(left <= 0){ clearInterval(t); again.disabled = false; again.textContent = 'Send a new code'; } else again.textContent = `Send a new code (${left}s)`; }, 1000); };
      const appMode = () => { $('#code-sub').textContent = 'Open your authenticator app and enter the 6-digit code for CRT Dashboard.'; msg.textContent = ''; again.disabled = !st.sms; again.textContent = st.sms ? 'Text me a code instead' : ''; again.hidden = !st.sms; inp.focus(); };
      const send = async (prefer) => {
        if(st.method === 'app' && prefer !== 'sms'){ appMode(); return; }
        msg.textContent = 'Sending your code…'; again.hidden = false;
        try{ const r = await api.teamFn({action: 'send_code', prefer: prefer || ''});
          if(r.method === 'app'){ appMode(); return; } $('#code-sub').textContent = 'We sent a 6-digit code to ' + (r.phone_hint || 'your phone') + '. It works for 10 minutes.'; msg.textContent = ''; wait(45); inp.focus(); }
        catch(e){ msg.textContent = e.code === 'wait' ? 'A code was sent a moment ago. Check your messages.' : e.code === 'no_phone' ? 'Your account has no phone number. Ask the main admin to add it.' : teamErr(e); if(e.code === 'wait') wait(45); else again.disabled = false; }
      };
      again.onclick = () => send('sms');
      inp.oninput = () => { inp.value = inp.value.replace(/\D/g, '').slice(0, 6); if(inp.value.length === 6) $('#code-form').requestSubmit(); };
      $('#code-form').onsubmit = async e => {
        e.preventDefault(); msg.textContent = 'Checking…';
        try{ await api.teamFn({action: 'verify_code', code: inp.value}); clearInterval(t); inp.value = ''; msg.textContent = ''; res(); }
        catch(err){ inp.select(); msg.textContent = err.code === 'wrong_code' ? 'That code isn’t right.' + (err.info && err.info.left > 0 ? ' ' + err.info.left + ' tries left.' : '') : err.code === 'expired' ? 'That code has expired. Send a new one.' : err.code === 'too_many' ? 'Too many tries. Send a new code.' : teamErr(err); }
      };
      send();
    });
  }
  // Authenticator app: show a QR code, confirm one code, done. `first` = during sign-in (no other way to get a code yet).
  let qrLib = null;
  function loadQr(){ return qrLib || (qrLib = new Promise((res, rej) => { const s = document.createElement('script'); s.src = 'https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.js'; s.onload = () => res(window.qrcode); s.onerror = rej; document.head.appendChild(s); })); }
  function setupApp(first){
    return new Promise(async (res, rej) => {
      show('view-app-setup'); const msg = $('#qr-msg'), inp = $('#qr-code'); msg.textContent = 'Preparing your code…'; inp.value = '';
      $('#qr-cancel').hidden = !!first;
      $('#qr-cancel').onclick = () => rej(new Error('cancel'));
      try{
        const r = await api.teamFn({action: 'app_setup'});
        $('#qr-secret').textContent = r.secret.replace(/(.{4})/g, '$1 ').trim();
        try{ const qr = (await loadQr())(0, 'M'); qr.addData(r.uri); qr.make(); $('#qr-box').innerHTML = qr.createSvgTag({cellSize: 5, margin: 2, scalable: true}); }
        catch(e){ $('#qr-box').innerHTML = '<p class="muted small">Couldn’t draw the QR code. Type the key below instead.</p>'; $('.qr-manual').open = true; }
        msg.textContent = ''; inp.focus();
      }catch(e){ msg.textContent = teamErr(e); return; }
      inp.oninput = () => { inp.value = inp.value.replace(/\D/g, '').slice(0, 6); if(inp.value.length === 6) $('#qr-form').requestSubmit(); };
      $('#qr-form').onsubmit = async e => {
        e.preventDefault(); msg.textContent = 'Checking…';
        try{ await api.teamFn({action: 'app_confirm', code: inp.value}); msg.textContent = ''; res(); }
        catch(err){ inp.select(); msg.textContent = err.code === 'wrong_code' ? 'That code isn’t right. Check the time on your phone is automatic, then try the newest code.' : teamErr(err); }
      };
    });
  }
  async function gate(){
    if(!LIVE) return;
    let st = null;
    try{ st = await api.teamFn({action: 'status'}); }catch(e){ return; }   // function not set up yet: the database decides, as before
    security = st;
    if(st.require_code && !st.verified){ if(st.method === 'none') await setupApp(true); else await askCode(st); }
    if(st.must_change) await askPassword();
  }

  // ------------------------------------------------------------------ boot
  async function loadAll(){
    [leads, team, content] = await Promise.all([api.leads(), api.team(), api.content()]);
    await seedCases();
    renderLeads(); renderContent(); renderTeam(); renderCases();
    loadSecurity();
  }

  async function boot(){
    $('#demo-banner').hidden = LIVE;
    let session = null;
    try{ session = await api.session(); }catch(e){ fail(e); }
    if(!session){ show('view-login'); return; }
    if(started) return; started = true;
    await gate();
    try{ me = await api.me(session.user.id); }catch(e){ fail(e); }
    if(!me){ $('#noaccess-email').textContent = session.user.email; show('view-noaccess'); return; }
    me.email = session.user.email;
    $('#me-name').textContent = me.name || me.email;
    if($('#me-role')) $('#me-role').textContent = roleName(me.role);
    if($('#me-avatar')) $('#me-avatar').textContent = initials(me.name || me.email);
    show('view-app');
    window.CRT_ADMIN = {sb, LIVE, me, isAdmin, toast, fail, esc, leads: () => leads};
    document.dispatchEvent(new CustomEvent('crt:ready'));
    try{ await loadAll(); }catch(e){ fail(e); }
    setInterval(async () => { if(document.hidden || openId) return; try{ leads = await api.leads(); renderLeads(); }catch(e){} }, 60000);
  }

  function goTab(name){
    $$('.tab').forEach(b => { const on = b.dataset.tab === name; b.classList.toggle('is-active', on); b.setAttribute('aria-current', on ? 'page' : 'false'); });
    $$('.tab-panel').forEach(p => p.hidden = p.id !== 'tab-' + name);
    if(name === 'inbox'){ if(window.CRT_MAIL) window.CRT_MAIL.open(); else if(!inboxLoaded) loadInbox(); }   // Mail (mail.js) replaced the Zoho inbox
    document.dispatchEvent(new CustomEvent('crt:tab', {detail: name}));
    window.scrollTo(0, 0);
  }
  function setTheme(t){
    document.documentElement.dataset.theme = t;
    try{ localStorage.setItem('crt-admin-theme', t); }catch(e){}
    $$('.theme-lbl').forEach(el => el.textContent = t === 'dark' ? 'Light mode' : 'Dark mode');
  }
  setTheme((()=>{ try{ return localStorage.getItem('crt-admin-theme') || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'); }catch(e){ return 'light'; } })());

  // Pipeline drag and drop: moving a card changes the lead's status
  let dragId = null;
  document.addEventListener('dragstart', e => { const c = e.target.closest && e.target.closest('.card[data-lead]'); if(!c) return; dragId = Number(c.dataset.lead); c.classList.add('is-dragging'); e.dataTransfer.effectAllowed = 'move'; });
  document.addEventListener('dragend', e => { const c = e.target.closest && e.target.closest('.card'); if(c) c.classList.remove('is-dragging'); $$('.col-body.is-over').forEach(x => x.classList.remove('is-over')); });
  document.addEventListener('dragover', e => { const z = e.target.closest && e.target.closest('[data-drop]'); if(!z || dragId === null) return; e.preventDefault(); $$('.col-body.is-over').forEach(x => { if(x !== z) x.classList.remove('is-over'); }); z.classList.add('is-over'); });
  document.addEventListener('drop', async e => {
    const z = e.target.closest && e.target.closest('[data-drop]'); if(!z || dragId === null) return;
    e.preventDefault(); z.classList.remove('is-over');
    const l = leads.find(x => x.id === dragId); const status = z.dataset.drop; dragId = null;
    if(!l || l.status === status) return;
    const prev = l.status; l.status = status; renderLeads();
    try{ await api.updateLead(l.id, {status}); l.updated_at = new Date().toISOString(); toast(l.name + ' → ' + STATUS_LABEL[status]); }
    catch(err){ l.status = prev; renderLeads(); fail(err); }
  });

  // Keyboard shortcuts: / search, N new lead, 1-5 switch sections, Enter opens a focused card
  document.addEventListener('keydown', e => {
    if($('#view-app').hidden) return;
    const typing = /^(input|textarea|select)$/i.test(e.target.tagName) || e.target.isContentEditable;
    if(e.key === 'Enter' && e.target.matches && e.target.matches('.card[data-lead]')){ openDrawer(Number(e.target.dataset.lead)); return; }
    if(typing || e.metaKey || e.ctrlKey || e.altKey || openId) return;
    if(e.key === '/'){ e.preventDefault(); goTab('leads'); $('#search').focus(); }
    else if(e.key === 'n' || e.key === 'N'){ e.preventDefault(); openNewLead(); }
    else if(/^[1-6]$/.test(e.key)){ const tabs = $$('.tab'); const t = tabs[Number(e.key) - 1]; if(t) goTab(t.dataset.tab); }
  });


  // Case study photos: drop files to upload, drag thumbnails to reorder
  const hasFiles = e => e.dataTransfer && [...(e.dataTransfer.types || [])].includes('Files');
  document.addEventListener('dragstart', e => { const it = e.target.closest && e.target.closest('.ph-item[data-pi]'); if(!it) return; dragPhoto = Number(it.dataset.pi); it.classList.add('is-dragging'); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', 'photo'); });
  document.addEventListener('dragend', e => { $$('.ph-item.is-dragging,.ph-item.is-target').forEach(x => x.classList.remove('is-dragging', 'is-target')); dragPhoto = null; });
  document.addEventListener('dragover', e => {
    const panel = e.target.closest && e.target.closest('#photo-panel,#film-drop');
    if(!panel || !isAdmin()) return;
    if(hasFiles(e)){ e.preventDefault(); panel.classList.add('is-drop'); return; }
    const it = e.target.closest('.ph-item[data-pi]');
    if(dragPhoto !== null && it){ e.preventDefault(); $$('.ph-item.is-target').forEach(x => x !== it && x.classList.remove('is-target')); it.classList.add('is-target'); }
  });
  document.addEventListener('dragleave', e => { const panel = e.target.closest && e.target.closest('#photo-panel,#film-drop'); if(panel && !panel.contains(e.relatedTarget)) panel.classList.remove('is-drop'); });
  document.addEventListener('drop', e => {
    const panel = e.target.closest && e.target.closest('#photo-panel,#film-drop');
    if(!panel || !isAdmin()) return;
    panel.classList.remove('is-drop');
    if(hasFiles(e)){
      e.preventDefault(); const files = [...e.dataTransfer.files];
      if(panel.id === 'film-drop'){ const v = files.find(f => /^video\//.test(f.type)); if(v) uploadFilm(v); else toast('Drop a video file here'); }
      else addPhotos(files);
      return;
    }
    const it = e.target.closest('.ph-item[data-pi]');
    if(dragPhoto !== null && it){ e.preventDefault(); movePhoto(dragPhoto, Number(it.dataset.pi)); }
  });
  window.addEventListener('dragover', e => { if(hasFiles(e) && !$('#tab-cases').hidden) e.preventDefault(); });
  window.addEventListener('drop', e => { if(hasFiles(e) && !(e.target.closest && e.target.closest('#photo-panel,#film-drop'))) e.preventDefault(); });

  // ------------------------------------------------------------------ events
  document.addEventListener('click', async e => {
    const li = e.target.closest('#inbox-list li[data-mid]'); if(li){ openMail(li.dataset.mid); return; }
    const card = e.target.closest('.card[data-lead]'); if(card){ openDrawer(Number(card.dataset.lead)); return; }
    const t = e.target.closest('[data-action],[data-tab],[data-filter],tr[data-id]');
    if(!t) return;
    if(t.dataset.tab){ goTab(t.dataset.tab); return; }
    if(t.dataset.filter){ filter = t.dataset.filter; renderLeads(); return; }
    if(t.matches('tr[data-id]')){ openDrawer(Number(t.dataset.id)); return; }
    const a = t.dataset.action;
    if(a === 'signout') api.signOut();
    else if(a === 'view-table' || a === 'view-board'){ view = a === 'view-board' ? 'board' : 'table'; try{ localStorage.setItem('crt-admin-view', view); }catch(err){} renderLeads(); }
    else if(a === 'focus-search'){ goTab('leads'); $('#search').focus(); }
    else if(a === 'toggle-theme'){ setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'); }
    else if(a === 'new-lead') openNewLead();
    else if(a === 'inbox-refresh'){ await loadInbox(); toast('Inbox up to date'); }
    else if(a === 'inbox-more') loadInbox(true);
    else if(a === 'mail-to-lead') mailToLead();
    else if(a === 'refresh'){ try{ leads = await api.leads(); renderLeads(); toast('Up to date'); }catch(err){ fail(err); } }
    else if(a === 'export') exportCsv();
    else if(a === 'close-drawer') closeDrawer();
    else if(a === 'save-lead') saveLead();
    else if(a === 'wa-reply'){ const l = leads.find(x => x.id === openId); if(l && l.status === 'new'){ $('#d-status').value = 'replied'; } }
    else if(a === 'delete-lead'){
      if(!confirm('Delete this lead permanently?')) return;
      try{ await api.deleteLead(openId); leads = leads.filter(l => l.id !== openId); closeDrawer(); renderLeads(); toast('Lead deleted'); }catch(err){ fail(err); }
    }
    else if(a === 'save-prices'){ e.preventDefault(); savePrices(); }
    else if(a === 'add-testimonial'){
      const list = readTestimonials();
      if(list.length >= MAX_TESTIMONIALS){ toast('Maximum ' + MAX_TESTIMONIALS + ' testimonials'); return; }
      content.testimonials = [...list, {quote:'', name:'', role:''}]; renderTestimonials();
      const rows = $$('#testimonials-list .testimonial-row'); rows[rows.length - 1].querySelector('textarea').focus();
    }
    else if(a === 'remove-testimonial'){ const list = readTestimonials(); list.splice(Number(t.dataset.i), 1); content.testimonials = list; renderTestimonials(); }
    else if(a === 'save-testimonials') saveTestimonials();
    else if(a === 'copy-review-msg'){ try{ await navigator.clipboard.writeText($('#review-msg').textContent); toast('Copied. Paste it into WhatsApp.'); }catch(err){ toast('Select the text and copy it'); } }
    else if(a === 'save-film-url'){
      const raw = $('#film-url').value.trim();
      let ok = false; try{ ok = new URL(raw).protocol === 'https:'; }catch(err){}
      if(!ok){ toast('Paste a full https:// link from YouTube, Instagram, Google Drive or Vimeo'); return; }
      const entry = caseEntry(), old = entry.video;
      entry.video = {type:'link', url: raw};
      if(old && old.type === 'file') api.removeFile(old.url).catch(()=>{});
      renderCases(); saveCases('Video link saved. Live on the site.');
    }
    else if(a === 'remove-film'){
      const entry = caseEntry(); if(!entry.video) return;
      if(!confirm('Remove the video from this case study?')) return;
      if(entry.video.type === 'file') api.removeFile(entry.video.url).catch(()=>{});
      entry.video = null; renderCases(); saveCases('Video removed.');
    }
    else if(a === 'photo-move'){ const i = Number(t.dataset.i); movePhoto(i, i + Number(t.dataset.d)); }
    else if(a === 'remove-photo'){
      const i = Number(t.dataset.i), entry = caseEntry(), p = entry.photos[i];
      if(!p || !confirm('Remove photo ' + (i + 1) + ' from the case study?')) return;
      entry.photos.splice(i, 1); api.removeFile(p.url).catch(()=>{});
      renderCases(); saveCases('Photo removed.');
    }
    else if(a === 'open-case'){ if(e.target.closest('a')) return; openCase(t.dataset.slug); }
    else if(a === 'back-cases'){ renderCaseList(); showCaseView('list'); }
    else if(a === 'prev-case'){ stepCase(-1); }
    else if(a === 'next-case'){ stepCase(1); }
    else if(a === 'case-filter'){ caseFilter = t.dataset.g; renderCaseList(); }
    else if(a === 'save-details'){ saveDetails(); }
    else if(a === 'add-work'){ addWork(); }
    else if(a === 'create-work'){ createWork(); }
    else if(a === 'cancel-work'){ $('#new-work').hidden = true; }
    else if(a === 'delete-case'){ deleteCase(); }
    else if(a === 'pick-thumb'){ const entry = caseEntry(), ph = (entry.photos || [])[+t.dataset.i]; if(ph){ entry.card = {url: ph.sm || ph.url}; entry.card_custom = 1; rebuildCaseList(); renderDetails(!isAdmin(), entry); saveCases('Thumbnail saved. Live on the website.'); } }
    else if(a === 'thumb-reset'){ const entry = caseEntry(); delete entry.card_custom; const sd = caseSeed[caseSlug]; entry.card = (sd && sd.card) ? JSON.parse(JSON.stringify(sd.card)) : (entry.cover ? {url: entry.cover.sm || entry.cover.url} : null); rebuildCaseList(); renderDetails(!isAdmin(), entry); saveCases('Thumbnail reset to the cover.'); }
    else if(a === 'pick-cover'){ const entry = caseEntry(), ph = (entry.photos || [])[+t.dataset.i]; if(ph){ entry.cover = {url: ph.url, sm: ph.sm || '', pos: '50% 50%', contain: false}; if(!entry.card_custom) entry.card = {url: ph.sm || ph.url}; rebuildCaseList(); renderDetails(!isAdmin(), entry); saveCases('Cover photo saved. Live on the website.'); } }
    else if(a === 'reset-details'){ const sd = caseSeed[caseSlug]; if(!sd){ toast('This work was added in the dashboard, so there is no earlier version.'); return; } if(!confirm('Put back the text and photos this work had when it moved into the dashboard?')) return; const keep = caseEntry(); content.case_studies[caseSlug] = Object.assign(JSON.parse(JSON.stringify(sd)), {seeded: 1, v: 2, published: keep.published}); rebuildCaseList(); renderCases(); saveCases('Restored.'); }
    else if(a === 'save-review'){
      const entry = caseEntry(), quote = $('#review-quote').value.trim().replace(/^["“”']+|["“”']+$/g, '').trim().slice(0, 600);
      if(!quote){ toast('Write the quote first, or use Remove review.'); return; }
      if(!$('#review-name').value.trim()){ toast('Add the name of the person quoted.'); return; }
      const old = entry.review || {};
      entry.review = {quote, name: $('#review-name').value.trim().slice(0, 80), role: $('#review-role').value.trim().slice(0, 100)};
      if(old.logo && old.name === entry.review.name){ entry.review.logo = old.logo; entry.review.logo_alt = old.logo_alt || ''; }
      renderReview(false, entry); saveCases('Review saved. Live on the site.');
    }
    else if(a === 'remove-review'){ const entry = caseEntry(); delete entry.review; renderReview(false, entry); saveCases('Review removed.'); }
    else if(a === 'add-credit'){
      const entry = caseEntry(); entry.credits = readCredits(); entry.credits.push({name:'', role:''}); renderCredits(false, entry);
      const rows = $$('#credit-rows .credit-row'); const last = rows[rows.length - 1]; (last.querySelector('.credit-name-sel') || last.querySelector('.credit-name')).focus();
    }
    else if(a === 'remove-credit'){ const entry = caseEntry(); entry.credits = readCredits(); entry.credits.splice(Number(t.dataset.i), 1); renderCredits(false, entry); }
    else if(a === 'credit-up'){ const entry = caseEntry(), list = readCredits(), i = Number(t.dataset.i); if(i > 0){ [list[i - 1], list[i]] = [list[i], list[i - 1]]; } entry.credits = list; renderCredits(false, entry); }
    else if(a === 'save-credits'){
      const entry = caseEntry(), list = readCredits();
      if(list.some(c => (c.name && !c.role) || (!c.name && c.role))){ toast('Each credit needs a person and a position'); return; }
      entry.credits = list.filter(c => c.name && c.role); renderCredits(false, entry); saveCases('Credits saved. Live on the site.');
    }
    else if(a === 'credit-lists'){ const entry = caseEntry(); entry.credits = readCredits(); const c = entry.credits[+t.dataset.i]; if(c){ delete c.manual; if(!creditPeople().includes(c.name)) c.name = ''; if(!creditRoles().includes(c.role)) c.role = ''; } renderCredits(false, entry); }
    else if(a === 'credit-add-save'){ saveCreditAdd(t.closest('.credit-row')); }
    else if(a === 'credit-add-cancel'){ const b = t.closest('.credit-add'); b.hidden = true; b.innerHTML = ''; }
    else if(a === 'remove-member'){
      const uid = t.closest('tr').dataset.uid, m = team.find(x => x.user_id === uid) || {};
      if(!confirm('Remove ' + (m.name || 'this person') + '? Their account is deleted and they can no longer sign in.')) return;
      try{ await api.removeMember(uid); team = team.filter(x => x.user_id !== uid); renderTeam(); toast('Removed'); }catch(err){ toast(teamErr(err)); }
    }
    else if(a === 'reset-member'){
      const uid = t.closest('tr').dataset.uid, m = team.find(x => x.user_id === uid) || {};
      if(!confirm('Give ' + (m.name || 'this person') + ' a new one-time password? Their current password stops working.')) return;
      try{ const r = await api.teamFn({action: 'reset_password', user_id: uid}); showMade(m.name || '', m.email || '', r.password); $('#team-made').scrollIntoView({behavior: 'smooth', block: 'center'}); }catch(err){ toast(teamErr(err)); }
    }
    else if(a === 'conn-test'){
      try{ const r = await api.teamFn({action: 'test_sms'}); toast('Test text sent to ' + (r.phone_hint || 'your phone')); }
      catch(err){ toast(err.code === 'no_phone' ? 'Add your phone number in the table first.' : err.code === 'sms_failed' ? 'The text didn’t go out: ' + ((err.info && err.info.detail) || 'check the keys') : teamErr(err)); }
    }
    else if(a === 'copy-made'){ try{ await navigator.clipboard.writeText($('#made-msg').textContent); toast('Copied'); }catch(err){ toast('Select the message and copy it'); } }
    else if(a === 'sec-on'){
      try{
        if(!security || !security.code_ok){ await askCode(security || {}); show('view-app'); }
        security = Object.assign(security || {}, await api.teamFn({action: 'set_security', require_code: true}), {code_ok: true});
        renderSecurity(); toast('Sign-in codes are on for everyone.');
      }catch(err){ show('view-app'); toast(teamErr(err)); }
    }
    else if(a === 'app-setup'){ try{ await setupApp(false); show('view-app'); security = await api.teamFn({action: 'status'}); renderSecurity(); toast('Authenticator app is set up.'); }catch(err){ show('view-app'); if(err && err.message !== 'cancel') toast(teamErr(err)); } }
    else if(a === 'reset-app'){ const uid = t.closest('tr').dataset.uid, m = team.find(x => x.user_id === uid) || {}; if(!confirm('Reset ' + (m.name || 'this person') + '’s authenticator app (lost phone)? They set it up again at their next sign-in.')) return; try{ await api.teamFn({action: 'app_remove', user_id: uid}); toast('Reset. They will scan a new code at their next sign-in.'); }catch(err){ toast(teamErr(err)); } }
    else if(a === 'sec-off'){
      if(!confirm('Switch off sign-in codes? A password alone will be enough again.')) return;
      try{ security = Object.assign(security || {}, await api.teamFn({action: 'set_security', require_code: false})); renderSecurity(); toast('Sign-in codes are off.'); }catch(err){ toast(teamErr(err)); }
    }
  });
  document.addEventListener('change', async e => {
    const el = e.target;
    if(el.id === 'case-select'){ caseSlug = el.value; renderCases(); return; }
    if(el.id === 'film-file' && el.files[0]){ const f0 = el.files[0]; el.value = ''; uploadFilm(f0); return; }
    if(el.dataset && el.dataset.photo !== undefined && el.files && el.files.length){ const files = [...el.files]; el.value = ''; addPhotos(files); return; }
    if(el.classList && el.classList.contains('slot-group')){
      const entry = caseEntry(), p = entry.photos[Number(el.dataset.i)];
      if(p){ if(el.value) p.group = el.value; else delete p.group; saveCases('Photo group saved.'); }
      return;
    }
    if(el.classList && el.classList.contains('slot-caption')){
      const entry = caseEntry(), p = entry.photos[Number(el.dataset.i)];
      if(p){ p.caption = el.value.trim().slice(0, 160); saveCases('Caption saved.'); }
      return;
    }
    const f = el.closest('#team-table [data-field]'); if(!f) return;
    const uid = f.closest('tr').dataset.uid, v = f.dataset.field === 'phone' ? f.value.replace(/[\s()-]/g, '') : f.value.trim(), patch = {[f.dataset.field]: v};
    try{ await api.updateMember(uid, patch); Object.assign(team.find(m => m.user_id === uid), patch); if(uid === me.user_id && f.dataset.field === 'phone' && security) security.has_phone = !!v; renderSecurity(); toast('Team updated'); }catch(err){ toast(teamErr(err)); }
  });
  $('#drawer-scrim').addEventListener('click', closeDrawer);
  document.addEventListener('keydown', e => { if(e.key === 'Escape' && openId) closeDrawer(); });
  $('#search').addEventListener('input', e => { query = e.target.value; renderLeads(); });
  $('#team-form').addEventListener('submit', async e => {
    e.preventDefault();
    const name = $('#tm-name').value.trim(), email = $('#tm-email').value.trim(), phone = $('#tm-phone').value.replace(/[\s()-]/g, ''), role = $('#tm-role').value;
    const btn = e.target.querySelector('button[type="submit"]'); btn.disabled = true;
    try{
      const r = await api.teamFn({action: 'create_member', name, email, phone, role});
      team.push({user_id: r.user_id || ('demo-' + Date.now()), name, email, phone: phone || null, role}); renderTeam();
      showMade(name, email, r.password); e.target.reset(); toast('Account created');
    }catch(err){ toast(teamErr(err)); }
    btn.disabled = false;
  });
  $('#login-form').addEventListener('submit', async e => {
    e.preventDefault();
    const email = $('#login-email').value.trim(), msg = $('#login-msg');
    const btn = e.target.querySelector('button[type="submit"]');
    msg.textContent = 'Signing in…'; btn.disabled = true;
    let error = null;
    try{ ({error} = await api.signIn(email, $('#login-password').value)); }catch(err){ error = err; }
    btn.disabled = false;
    if(error){ msg.textContent = /invalid/i.test(error.message || '') ? 'Wrong email or password.' : 'Couldn’t sign in: ' + (error.message || 'please try again') + '.'; return; }
    msg.textContent = '';
    $('#login-password').value = '';
    if(!LIVE) boot();
  });
  $$('#prices-form').forEach(f => f.addEventListener('submit', e => e.preventDefault()));
  if(LIVE) sb.auth.onAuthStateChange((ev) => { if(ev === 'SIGNED_IN' && !started) boot(); });

  boot();
})();
