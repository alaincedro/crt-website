/* CRT admin dashboard. Works with Supabase when crt-config.js is filled in; otherwise runs a demo with sample data. */
(function(){
  'use strict';
  const CFG = window.CRT_CONFIG || {};
  const LIVE = !!(CFG.SUPABASE_URL && CFG.SUPABASE_ANON_KEY && window.supabase);
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];
  const esc = v => String(v == null ? '' : v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt = n => (n == null || n === '' || isNaN(n)) ? '—' : Number(n).toLocaleString('en-US');
  const STATUSES = [['new','New'],['replied','Replied'],['quoted','Quoted'],['booked','Booked'],['lost','Lost']];
  const STATUS_LABEL = Object.fromEntries(STATUSES);
  const PRICE_FIELDS = [
    // Only the four wedding packages are edited here: their amounts are unique on the site,
    // so changing one can never change an unrelated price that happens to share the same number.
    ['basic','Basic wedding package (4 days, photos)','Weddings page, home, menu, early-booking offer'],
    ['standard','Standard wedding package (4 days, photos and video)','Weddings page, home, menu, early-booking offer'],
    ['premium','Premium wedding package','Weddings page, home, menu, early-booking offer'],
    ['vip','VIP wedding package','Weddings page, home, menu, early-booking offer'],
  ];
  const PACKAGES = ['Basic','Standard','Premium','VIP'];
  const SERVICES = ['Wedding photography & video','Event photography & video','Commercial photography & video','Branding & graphic design','Social media & content','Websites & digital tools','Creative project'];
  const SOURCES = ['WhatsApp','Phone call','Instagram','Facebook','Referral','Walk-in','Other'];

  let me = null, leads = [], team = [], content = {}, filter = 'all', query = '', openId = null, started = false;
  // Leads v2 (2026-11-25): filters, selection, keyboard cursor, follow-ups and history
  const LF = {service: '', source: '', period: '', who: '', sort: 'new'}, picked = new Set();
  let shown = [], cursor = -1, v2 = true;   // v2 = the database has follow_up / replied_at / activity
  let view = (()=>{ try{ return localStorage.getItem('crt-admin-view') || 'table'; }catch(e){ return 'table'; } })();

  // ------------------------------------------------------------------ data layer
  const sb = LIVE ? window.supabase.createClient(CFG.SUPABASE_URL, CFG.SUPABASE_ANON_KEY) : null;

  const dayIso = n => { const d = new Date(); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
  const demo = (() => {
    const day = 864e5, now = Date.now();
    const iso = d => new Date(now - d*day).toISOString();
    return {
      me: {user_id:'demo-1', name:'Alain (demo)', role:'admin', email:'alain@crt.rw'},
      team: [{user_id:'demo-1',name:'Alain Cedrick',role:'admin'},{user_id:'demo-2',name:'Ziggy',role:'staff'}],
      leads: [
        {id:8,created_at:iso(0.3),name:'Diane U.',contact:'Client review (no contact given)',service:'Client review',offer:'Yes, with my name and role',event_date:null,details:'Project: Photos of my wedding\nRole: Bride\nPublish: Yes, with my name and role\n\nThe team was calm, kind and everywhere at once. Our photos arrived on time and our families cried watching the video.',page:'/review/',source:'Review form',status:'new',value_rwf:null,notes:'',assigned_to:null},
        {id:7,created_at:iso(0.1),name:'Aline M.',contact:'+250 788 123 456',service:'Wedding photography & video',offer:'Book early, save 30%',event_date:'14 Feb 2027',details:'Church + reception at Kigali Serena, about 250 guests.',page:'/offer-wedding-early-booking',source:'instagram / paid / wedding-oct',status:'new',value_rwf:null,notes:'',assigned_to:null},
        {id:6,created_at:iso(0.6),name:'Kivu Coffee Ltd',contact:'hello@kivucoffee.rw',service:'Commercial photography & video',offer:'Content session',event_date:'Next month',details:'New packaging launch, 12 products.',page:'/offer-commercial-content-session',source:'google',status:'replied',value_rwf:400000,notes:'Sent shot list questions on WhatsApp.',assigned_to:'demo-2',follow_up:dayIso(0),replied_at:iso(0.55),activity:[{t:iso(0.55),k:'reply',v:'Replied by WhatsApp',by:'Ziggy'},{t:iso(0.55),k:'status',v:'New → Replied',by:'Ziggy'}]},
        {id:5,created_at:iso(2),name:'Jean-Paul K.',contact:'0788 555 222',service:'Event photography & video',offer:'Event + social bundle',event_date:'22 Nov',details:'Product launch at Norrsken, 3 hours.',page:'/events',source:'direct',status:'quoted',value_rwf:450000,notes:'Quote sent 27 Oct. Follow up Friday.',assigned_to:'demo-1',follow_up:dayIso(-1),replied_at:iso(1.95)},
        {id:4,created_at:iso(4),name:'Grace & Eric',contact:'+250 722 000 111',service:'Wedding photography & video',offer:'Premium',event_date:'June 2027',details:'Gusaba + wedding, two days.',page:'/wedding-packages',source:'instagram',status:'booked',value_rwf:2000000,notes:'Deposit received.',assigned_to:'demo-2'},
        {id:3,created_at:iso(9),name:'Tech Hub Rwanda',contact:'events@techhub.rw',service:'Websites & digital tools',offer:'Website launch',event_date:'December',details:'5-page site with event registrations.',page:'/offer-website-launch',source:'facebook / instagram ad',status:'quoted',value_rwf:600000,notes:'',assigned_to:'demo-1'},
        {id:2,created_at:iso(15),name:'Nadia U.',contact:'+250 789 999 000',service:'Branding & graphic design',offer:'Brand starter kit',event_date:'ASAP',details:'New bakery.',page:'/offer-brand-starter-kit',source:'google',status:'lost',value_rwf:300000,notes:'Went with a cheaper freelancer.',assigned_to:null},
        {id:1,created_at:iso(21),name:'Patrick N.',contact:'0781 234 567',service:'Wedding photography & video',offer:'Standard',event_date:'March 2027',details:'',page:'/weddings',source:'linktr.ee',status:'booked',value_rwf:1500000,notes:'',assigned_to:'demo-1'},
      ],
      inbox(body){
        const now = Date.now(), h = 36e5;
        const msgs = [
          {messageId:'1', folderId:'9', from:'Aline M.', fromAddress:'aline.m@example.com', subject:'Wedding in February: are you available?', summary:'Hello, we are getting married on 14 Feb 2027 at Kigali Serena and would love photos and a video.', received:now-2*h, unread:true},
          {messageId:'2', folderId:'9', from:'Kivu Coffee Ltd', fromAddress:'hello@kivucoffee.example', subject:'Product shoot quote', summary:'Could you send a quote for photographing 12 products for our new packaging?', received:now-26*h, unread:false},
        ];
        if(body.action === 'read'){ const m = msgs.find(x => x.messageId === body.messageId) || msgs[0]; return {html:'<p>(Demo) ' + m.summary + '</p><p>Thanks,<br>' + m.from + '</p>'}; }
        return {messages: msgs};
      },
      content: {
        prices:{basic:1200000,standard:2000000,premium:3000000,vip:4500000},
        packages:{
          Basic:['4 shooting days: pre-wedding, gufata irembo, civil marriage and wedding day','1 photographer, up to 8 hours on the wedding day','400+ edited photos','Photobook, 8×8 inch (about 50 photos)','Online gallery'],
          Standard:['The same 4 shooting days','Wedding day: 1 photographer + 1 videographer, up to 10 hours','500+ edited photos','Full video and a 3–5 minute highlight video','Short videos of gufata irembo and the civil marriage','Lay-flat photobook, 10×10 inch (about 80 photos)'],
          Premium:['The same 4 shooting days','Wedding day: 2 photographers + 2 videographers, up to 12 hours','650+ edited photos','Full video, a 5–8 minute highlight video and a teaser','Short videos of every shooting day','Livestream for family abroad','Flush-mount album, 12×12 inch, and a framed A3 print'],
          VIP:['Everything in Premium','A surprise proposal shoot','Same-day edit shown at the reception','Leather album, 12×12 inch (about 200 photos)','2 parent albums and 2 framed A2 prints']
        }
      }
    };
  })();

  // Reviews sent from crt.rw/review/ arrive in the leads table (service "Client review"). They are not sales:
  // they are shown in Content → Reviews ("Sent by clients") and kept out of Leads, counts and the pipeline.
  const isReviewLead = l => l && (l.service === 'Client review' || l.page === '/review/');
  const REVIEWS = {list: []};
  const api = {
    async session(){ if(!LIVE) return {user:{email:demo.me.email,id:demo.me.user_id}}; const {data} = await sb.auth.getSession(); return data.session; },
    // Email + password: works when the site is opened straight from a folder,
    // where emailed sign-in links have no web address to return to.
    async signIn(email, password){
      if(!LIVE) return {error:null};
      return sb.auth.signInWithPassword({email, password});
    },
    async signOut(){ if(LIVE) await sb.auth.signOut(); location.reload(); },
    // The "team" server function (supabase-functions/team): accounts, sign-in codes, security switch.
    async teamFn(body){
      if(!LIVE) return {ok: true, password: 'Demo-Pass-1234', require_code: false, verified: true};
      const {data, error} = await sb.functions.invoke('team', {body});
      if(error){
        let detail = {}; try{ detail = await error.context.json(); }catch(e){}
        const err = new Error(detail.error || error.message || 'failed'); err.code = detail.error; err.info = detail; throw err;
      }
      return data;
    },
    async me(uid){
      if(!LIVE) return demo.me;
      let {data, error} = await sb.from('team').select('user_id,name,role,phone,email').eq('user_id', uid).maybeSingle();
      if(error && /column/i.test(error.message || '')) ({data, error} = await sb.from('team').select('user_id,name,role').eq('user_id', uid).maybeSingle());   // before team-security.sql
      if(error) throw error; return data;
    },
    async leads(){
      const all = !LIVE ? demo.leads.slice() : await (async () => { const {data, error} = await sb.from('leads').select('*').order('created_at',{ascending:false}).limit(2000); if(error) throw error; return data || []; })();
      REVIEWS.list = all.filter(isReviewLead);
      if(typeof renderReviewInbox === 'function') setTimeout(renderReviewInbox, 0);
      return all.filter(l => !isReviewLead(l));
    },
    async addLead(row){
      if(!LIVE){ const l = Object.assign({id: Math.max(0, ...demo.leads.map(x => x.id)) + 1, created_at: new Date().toISOString()}, row); demo.leads.unshift(l); return Object.assign({}, l); }
      const {data, error} = await sb.from('leads').insert(row).select('*').single(); if(error) throw error; return data;
    },
    // Mailbox (Zoho Mail) through the "inbox" Edge Function. Demo mode shows sample mail.
    async inbox(body){
      if(!LIVE) return demo.inbox(body);
      const {data, error} = await sb.functions.invoke('inbox', {body});
      if(error){
        let msg = error.message;
        try{ const j = await error.context.json(); msg = j.error || msg; }catch(e){}
        throw new Error(msg);
      }
      return data;
    },
    async updateLead(id, patch){
      if(!LIVE){ Object.assign(demo.leads.find(l=>l.id===id), patch); return; }
      let {error} = await sb.from('leads').update(patch).eq('id', id);
      if(error && /follow_up|replied_at|activity/.test(error.message || '')){   // before admin/leads-v2.sql: save the rest
        v2 = false; const $u = document.getElementById('leads-upgrade'); if($u) $u.hidden = false;
        const rest = Object.assign({}, patch); delete rest.follow_up; delete rest.replied_at; delete rest.activity;
        if(!Object.keys(rest).length) return; ({error} = await sb.from('leads').update(rest).eq('id', id));
      }
      if(error) throw error;
    },
    async deleteLead(id){
      if(!LIVE){ demo.leads = demo.leads.filter(l=>l.id!==id); return; }
      const {error} = await sb.from('leads').delete().eq('id', id); if(error) throw error;
    },
    async team(){
      if(!LIVE) return demo.team.slice();
      let {data, error} = await sb.from('team').select('user_id,name,role,phone,email').order('name');
      if(error && /column/i.test(error.message || '')) ({data, error} = await sb.from('team').select('user_id,name,role').order('name'));
      if(error) throw error; return data;
    },
    async updateMember(uid, patch){
      if(!LIVE){ Object.assign(demo.team.find(m=>m.user_id===uid), patch); return; }
      await api.teamFn(Object.assign({action: 'update_member', user_id: uid}, patch));
    },
    async removeMember(uid){
      if(!LIVE){ demo.team = demo.team.filter(m=>m.user_id!==uid); return; }
      await api.teamFn({action: 'remove_member', user_id: uid});
    },
    async content(){
      if(!LIVE) return JSON.parse(JSON.stringify(demo.content));
      const {data, error} = await sb.from('site_content').select('key,value'); if(error) throw error;
      const c = {}; (data||[]).forEach(r => c[r.key] = r.value);
      // Price list v2 (Nov 2026): the site reads prices_v2 / wedding_packages. Until they are saved once,
      // show the current published prices instead of the retired list stored under prices / packages.
      c.prices = c.prices_v2 || JSON.parse(JSON.stringify(demo.content.prices));
      c.packages = c.wedding_packages || JSON.parse(JSON.stringify(demo.content.packages));
      return c;
    },
    async saveContent(key, value){
      if(!LIVE){ demo.content[key] = value; return; }
      const {error} = await sb.from('site_content').upsert({key, value, updated_by: me.user_id}); if(error) throw error;
    },
    // Upload a file to the public "media" bucket and return its public address.
    async upload(file, path){
      if(!LIVE) return URL.createObjectURL(file);           // demo: local preview only, nothing is stored
      path = String(path).replace(/(\.[a-z0-9]+)?$/i, m => '-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5) + m);   // unique: a plain upload, never a replace
      const {error} = await sb.storage.from('media').upload(path, file, {upsert:false, contentType:file.type || 'application/octet-stream', cacheControl:'31536000'});
      if(error) throw error;
      return sb.storage.from('media').getPublicUrl(path).data.publicUrl;
    },
    async removeFile(url){
      if(!LIVE || !url) return;
      const m = String(url).match(/\/storage\/v1\/object\/public\/media\/(.+)$/);
      if(m) await sb.storage.from('media').remove([decodeURIComponent(m[1])]);   // best effort
    }
  };

  // Booking messages from /book/ arrive as "BOOKING / Service: … / Package: … · price / Extras: / - item · price / Estimate: …"
  // Show them as a small table; any other message keeps its line breaks.
  function fmtMessage(v){
    const text = String(v || ''), lines = text.split(/\r?\n/);
    if(lines[0].trim() !== 'BOOKING') return esc(text).replace(/\n/g, '<br>');
    const rows = []; let notes = '', inExtras = false;
    lines.slice(1).forEach(raw => {
      const t = raw.trim(); if(!t) return;
      if(/^Notes:/.test(t)){ notes = t.replace(/^Notes:\s*/, ''); inExtras = false; return; }
      if(notes){ notes += '\n' + t; return; }
      if(t === 'Extras:'){ inExtras = true; return; }
      const isItem = inExtras && /^-\s/.test(t); if(!isItem) inExtras = false;
      const [label, price] = (isItem ? t.replace(/^-\s*/, '') : t).split(' · ');
      const m = !isItem && label.match(/^(Service|Package|Offer|Estimate):\s*(.*)$/);
      if(m && m[1] === 'Estimate') rows.push(['Estimate', '', m[2], true]);
      else rows.push(m ? [m[1], m[2], price || '', false] : ['Extra', label, price || '', false]);
    });
    return '<table class="bk-table">' + rows.map(([k, a, b, tot]) => `<tr${tot ? ' class="is-total"' : ''}><th>${esc(k)}</th><td>${esc(a)}</td><td class="num">${esc(b)}</td></tr>`).join('') + '</table>'
      + (notes ? `<p class="bk-notes"><strong>Notes</strong><br>${esc(notes).replace(/\n/g, '<br>')}</p>` : '');
  }
  // ------------------------------------------------------------------ case studies
  // Every work lives in the dashboard data (content.case_studies), in one shape (v: 2). The list below is built from it,
  // so works added here and works that were on the site before look and behave the same.
  let CASES = [];
  const CAT_LABEL = {business: 'Business', events: 'Events', weddings: 'Weddings'};
  const slugify = t => 'work-' + String(t || '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60);
  const caseThumb = e => (e.card && e.card.url) || (e.cover && e.cover.url) || ((e.photos || [])[0] || {}).url || '';
  function rebuildCaseList(){
    const all = content.case_studies || {};
    CASES = Object.keys(all).filter(sl => all[sl] && !all[sl].deleted).map(sl => {
      const e = all[sl];
      return {slug: sl, title: e.title || sl, group: CAT_LABEL[e.category] || 'Business', thumb: caseThumb(e), page: !!(caseSeed[sl] || e.page), order: e.order ?? 999, published: e.published !== false};
    }).sort((a, b) => a.order - b.order);
  }
  // Older dashboard entries kept their text under "fields": read them into the same shape as everything else.
  function normaliseCase(seed, e){
    const c = JSON.parse(JSON.stringify(seed || {}));
    if(!e) return c;
    if(e.v === 2) return Object.assign(c, JSON.parse(JSON.stringify(e)));
    const F = e.fields || {}, pick = (...k) => { for(const x of k){ if(F[x] != null) return F[x]; } };
    const set = (o, k, v) => { if(v !== undefined) o[k] = v; };
    set(c, 'title', pick('client')); set(c, 'headline', pick('headline')); set(c, 'summary', pick('summary'));
    set(c, 'brief', pick('challenge')); set(c, 'approach', pick('approach'));
    c.facts = c.facts || {};
    set(c.facts, 'client', pick('fact-Client', 'fact-Couple', 'fact-Clients')); set(c.facts, 'type', pick('fact-Industry', 'fact-Event'));
    set(c.facts, 'location', pick('fact-Location')); set(c.facts, 'date', pick('fact-Year', 'fact-Date', 'fact-When')); set(c.facts, 'services', pick('fact-Services', 'fact-Delivered'));
    if(['result-0','result-1','result-2','result-3'].some(k => F[k] != null)) c.results = [0,1,2,3].map(n => F['result-' + n] || '').filter(Boolean);
    if(e.photos && (e.photos.length || e.gallery_full)) c.photos = e.photos;
    ['video', 'videos', 'review', 'credits', 'published', 'deleted'].forEach(k => { if(e[k] !== undefined && e[k] !== null) c[k] = e[k]; });
    c.v = 2; c.seeded = 1;
    return c;
  }

  const SLOT_HINTS = ['The full room during a session','Speakers on stage','Attendees in conversation between sessions','Both brands’ logos on stage','Q&A with the audience','Speakers and organisers group photo','Details: badges, notes, coffee break','Behind the scenes: the crew at work','A candid moment worth remembering'];
  const MAX_PHOTOS = 40, MAX_VIDEO_MB = 50;
  // Every case study's content (text, fact sheet, story, outcomes, gallery photos, review) is stored here as the
  // admin's own entry, so all of it can be edited or removed. The first time the dashboard opens, the content the
  // site already shows (../data/case-studies.json, made by tools/export_cases.py) is copied in once and saved.
  let caseSeed = {};
  async function seedCases(){
    let seed = null;
    try{ const r = await fetch('../data/case-studies.json', {cache:'no-store'}); if(r.ok) seed = await r.json(); }catch(e){}
    content.case_studies = content.case_studies || {};
    let changed = false;
    try{ const r = await fetch('../data/work-categories.json', {cache:'no-store'}); if(r.ok) catSeed = await r.json(); }catch(e){}
    if(seed){
      caseSeed = seed;
      Object.keys(seed).forEach(slug => {
        const e = content.case_studies[slug], sd = seed[slug];
        if(sd.v !== 2) return;
        if(!e || e.v !== 2){ content.case_studies[slug] = Object.assign(normaliseCase(sd, e), {v: 2, seeded: 1}); changed = true; }
      });
    }
    // anything older that is not in the data file (added here before v2) gets the same shape too
    Object.keys(content.case_studies).forEach(slug => { const e = content.case_studies[slug]; if(e && e.v !== 2){ content.case_studies[slug] = normaliseCase({title: slug, category: 'business', facts: {}, results: [], photos: []}, e); changed = true; } });
    rebuildCaseList();
    if(CASES.length && !CASES.some(c => c.slug === caseSlug)) caseSlug = CASES[0].slug;
    if(changed && isAdmin()){
      try{ await api.saveContent('case_studies', content.case_studies); toast('Every work is now stored in the dashboard. Edit, hide or remove any of them here.'); }catch(e){ fail(e); }
    }
  }
  // ---- Service categories ("What we made") and industries: lists Alain can grow, each work can carry several ----
  // site_content.work_categories = {services:[{id,name,say,menu,hidden}], industries:[{id,name,say,hidden}]}
  // Until saved once, the lists come from ../data/work-categories.json (made by tools/build_work2.py's data).
  let catSeed = {services: [], industries: []}, catManage = false;
  const CAT_LISTS = {services: ['Our Work menu · What we made', 'Service category', 'e.g. Drone video'], industries: ['Our Work menu · By industry', 'Industry', 'e.g. Real estate']};
  // Work page sections: a work can sit in several; the Section under "Title and summary" is the main one (booking + price links)
  const SECTION_LABEL = {business: 'For businesses', events: 'Events', weddings: 'Weddings'};
  function entrySections(entry){
    const main = entry.category || 'business';
    let l = Array.isArray(entry.sections) ? entry.sections.filter(x => SECTION_LABEL[x]) : [];
    if(!l.includes(main)) l = [main].concat(l);
    return entry.sections = [main].concat(l.filter(x => x !== main));
  }
  // one line that lists every place on the Our Work menu and the Work page where this work shows
  function placesHTML(entry){
    const W = wcats(), nm = (list, id) => (W[list].find(c => c.id === id && !c.hidden) || {});
    const sv = entryCats(entry, 'services').map(id => nm('services', id)).filter(c => c.name), ind = entryCats(entry, 'industries').map(id => nm('industries', id)).filter(c => c.name);
    const menu = sv.concat(ind).filter(c => c.menu).map(c => c.name), filt = sv.concat(ind).filter(c => !c.menu).map(c => c.name);
    const row = (k, v) => `<div><dt>${k}</dt><dd>${v.length ? v.map(esc).join(', ') : '<span class="muted">none</span>'}</dd></div>`;
    return `<dl class="places">${row('Our Work menu', menu)}${row('Work page sections', entrySections(entry).map(x => SECTION_LABEL[x]))}${row('Work page filters only', filt)}<div><dt>Also</dt><dd>All work, and “More work like this” on similar works</dd></div></dl>`;
  }
  const wcats = () => { const w = content.work_categories || JSON.parse(JSON.stringify(catSeed)); w.services = w.services || []; w.industries = w.industries || []; return w; };
  const catId = name => String(name || '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40);
  function entryCats(entry, list){
    if(!Array.isArray(entry[list])){ const sd = caseSeed[caseSlug]; entry[list] = sd && Array.isArray(sd[list]) ? sd[list].slice() : (list === 'services' ? ['photography'] : []); }
    return entry[list];
  }
  const catUse = (list, id) => Object.keys(content.case_studies || {}).filter(sl => { const e = content.case_studies[sl]; return e && !e.deleted && (Array.isArray(e[list]) ? e[list] : ((caseSeed[sl] || {})[list] || [])).includes(id); }).length;
  function catPickHTML(ro, entry){
    const W = wcats(), dis = ro ? ' disabled' : '', secs = entrySections(entry);
    return placesHTML(entry) + `<div class="cat-block"><p class="cat-l"><strong>Work page sections</strong> <span class="muted small">${secs.length} chosen · the first is the main one, set under “Title and summary”</span></p>
        <div class="cat-chips" role="group" aria-label="Work page sections">${Object.keys(SECTION_LABEL).map(k => { const sel = secs.includes(k); return `<button type="button" class="cat-chip${sel ? ' is-on' : ''}${k === secs[0] ? ' is-main' : ''}" data-action="sec-toggle" data-id="${k}" aria-pressed="${sel}"${dis}>${SECTION_LABEL[k]}</button>`; }).join('')}</div></div>`
      + Object.keys(CAT_LISTS).map(list => {
      const [label, one, eg] = CAT_LISTS[list], on = entryCats(entry, list), cats = W[list].filter(c => !c.hidden || on.includes(c.id));
      const primary = list === 'services' && on.length > 1 ? `<label class="cat-main"><span>Main category</span><select data-cat-main${dis}>${on.map(id => { const c = W.services.find(x => x.id === id); return c ? `<option value="${esc(id)}"${id === on[0] ? ' selected' : ''}>${esc(c.name)}</option>` : ''; }).join('')}</select><small class="muted">Names the work and leads its links.</small></label>` : '';
      const manage = catManage && !ro ? `<div class="cat-manage">${W[list].map((c, i) => `<div class="cat-mrow"><input type="text" value="${esc(c.name)}" maxlength="40" data-cat-rename="${list}:${i}" aria-label="${one} name">`
          + `<label><input type="checkbox" data-cat-menu="${list}:${i}"${c.menu ? ' checked' : ''}> In the menu</label>`
          + `<label><input type="checkbox" data-cat-hide="${list}:${i}"${c.hidden ? ' checked' : ''}> Hidden</label><span class="muted small">${catUse(list, c.id)} work${catUse(list, c.id) === 1 ? '' : 's'}</span>`
          + (catUse(list, c.id) ? '' : `<button type="button" class="link danger" data-action="cat-delete" data-list="${list}" data-i="${i}">Delete</button>`) + `</div>`).join('')}</div>` : '';
      return `<div class="cat-block"><p class="cat-l"><strong>${label}</strong> <span class="muted small">${on.length} chosen</span></p>
        <div class="cat-chips" role="group" aria-label="${label}">${cats.map(c => { const sel = on.includes(c.id); return `<button type="button" class="cat-chip${sel ? ' is-on' : ''}${sel && list === 'services' && c.id === on[0] && on.length > 1 ? ' is-main' : ''}${c.menu ? '' : ' is-offmenu'}" data-action="cat-toggle" data-list="${list}" data-id="${esc(c.id)}" aria-pressed="${sel}"${c.menu ? '' : ' title="Not in the menu: shows on the Work page filters only"'}${dis}>${esc(c.name)}</button>`; }).join('')}</div>
        ${primary}${ro ? '' : `<div class="cat-new"><input type="text" maxlength="40" placeholder="New ${one.toLowerCase()}, ${eg}" data-cat-new="${list}" aria-label="New ${one.toLowerCase()}"><button type="button" class="btn secondary small" data-action="cat-add" data-list="${list}">+ Add</button></div>`}${manage}</div>`;
    }).join('') + (ro ? '' : `<button type="button" class="link small" data-action="cat-manage">${catManage ? 'Done editing the lists' : 'Rename, hide, delete or put categories in the menu'}</button>`);
  }
  function redrawCats(){ const box = $('#cat-pick'); if(box) box.innerHTML = catPickHTML(!isAdmin(), caseEntry()); }
  async function saveCats(msg){ try{ await api.saveContent('work_categories', content.work_categories); toast(msg); }catch(e){ fail(e); } }
  document.addEventListener('change', e => {
    const t = e.target; if(!t.closest || !t.closest('#cat-pick')) return;
    const W = content.work_categories = wcats();
    if(t.matches('[data-cat-main]')){ const entry = caseEntry(), on = entryCats(entry, 'services'); if(!on.includes(t.value)) return; entry.services = [t.value].concat(on.filter(x => x !== t.value)); redrawCats(); saveCases('Main category saved.'); }
    else if(t.matches('[data-cat-rename]')){ const [l, i] = t.dataset.catRename.split(':'), c = W[l][+i], v = t.value.trim().slice(0, 40); if(!v){ t.value = c.name; return; } c.name = v; c.say = v.toLowerCase(); saveCats('Renamed. Every work using it updates.'); }
    else if(t.matches('[data-cat-menu]')){ const [l, i] = t.dataset.catMenu.split(':'); W[l][+i].menu = t.checked; redrawCats(); saveCats(t.checked ? 'Added to the Work menu.' : 'Taken out of the Work menu.'); }
    else if(t.matches('[data-cat-hide]')){ const [l, i] = t.dataset.catHide.split(':'); W[l][+i].hidden = t.checked; redrawCats(); saveCats(t.checked ? 'Hidden from the website’s filters and menu.' : 'Shown again.'); }
  });
  document.addEventListener('keydown', e => { if(e.key === 'Enter' && e.target.matches && e.target.matches('[data-cat-new]')){ e.preventDefault(); addCat(e.target.dataset.catNew); } });
  function addCat(list){
    const inp = $(`[data-cat-new="${list}"]`), name = (inp.value || '').trim().slice(0, 40);
    if(!name){ toast('Write the name first'); inp.focus(); return; }
    const W = content.work_categories = wcats(), id = catId(name);
    if(!id){ toast('Use letters or numbers in the name'); return; }
    let c = W[list].find(x => x.id === id || x.name.toLowerCase() === name.toLowerCase());
    if(!c){ c = {id, name, say: name.toLowerCase()}; if(list === 'services') c.menu = false; W[list].push(c); }
    else c.hidden = false;
    const entry = caseEntry(), on = entryCats(entry, list); if(!on.includes(c.id)) on.push(c.id);
    redrawCats(); saveCats('“' + c.name + '” added and ticked on this work. It shows on the Work page once a visible work uses it.'); saveCases('Saved.');
  }
  let pendingPhotos = [], dragPhoto = null;
  let caseSlug = '', busy = false;
  const caseEntry = () => { content.case_studies = content.case_studies || {}; return content.case_studies[caseSlug] = content.case_studies[caseSlug] || {video:null, videos:[], photos:[]}; };

  // Resize to max 2000 px and compress (WebP when the browser supports it, else JPEG ~82%), so the site stays fast.
  async function prepPhoto(file){
    try{
      const img = await createImageBitmap(file, {imageOrientation:'from-image'});
      const scale = Math.min(1, 2000 / Math.max(img.width, img.height));
      const c = document.createElement('canvas'); c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      let blob = await new Promise(r => c.toBlob(r, 'image/webp', 0.82));
      if(!blob || blob.type !== 'image/webp') blob = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.82));
      if(!blob) throw new Error('could not read the image');
      const ext = blob.type === 'image/webp' ? 'webp' : 'jpg';
      return {file: new File([blob], file.name.replace(/\.\w+$/, '') + '.' + ext, {type: blob.type}), ext, w: c.width, h: c.height};
    }catch(e){
      if(/^image\/(jpeg|png|webp|gif|avif)$/.test(file.type)) return {file, ext: (file.type.split('/')[1] || 'jpg').replace('jpeg', 'jpg'), w: 0, h: 0};
      throw new Error(file.name + ' is not a photo this browser can read (HEIC? export it as JPEG first)');
    }
  }
  async function saveCases(msg){
    try{ await api.saveContent('case_studies', content.case_studies || {}); toast(msg || 'Saved. Live on the site.'); }catch(e){ fail(e); }
    if(typeof renderSteps === 'function') renderSteps();
  }

  // Credits: pick a person and a position from dropdowns (team members + people and positions added to the list),
  // add someone new to the lists, or type both for a part-time / one-off person.
  // Extra people and positions are saved once in site_content.credit_options and offered on every work.
  const creditOpts = () => { const o = content.credit_options = content.credit_options || {}; o.people = o.people || []; o.roles = o.roles || []; return o; };
  const uniq = a => [...new Set(a.map(x => String(x || '').trim()).filter(Boolean))];
  const creditPeople = () => uniq(team.map(m => m.name).concat(creditOpts().people.map(p => p.name)));
  const creditRoles = () => uniq([...document.querySelectorAll('#credit-roles option')].map(o => o.value || o.textContent).concat(creditOpts().roles, creditOpts().people.map(p => p.role)));
  function renderCredits(ro, entry){
    const rows = entry.credits || [], people = creditPeople(), roles = creditRoles(), teamNames = uniq(team.map(m => m.name));
    const extra = creditOpts().people.map(p => p.name).filter(n => !teamNames.includes(n));
    const dis = ro ? ' disabled' : '';
    const nameSel = (cur, i) => `<select class="credit-name-sel" aria-label="Person ${i + 1}"${dis}><option value="">Choose a person…</option>`
      + (teamNames.length ? `<optgroup label="Team">${teamNames.map(n => `<option${n === cur ? ' selected' : ''}>${esc(n)}</option>`).join('')}</optgroup>` : '')
      + (extra.length ? `<optgroup label="Others on the list">${extra.map(n => `<option${n === cur ? ' selected' : ''}>${esc(n)}</option>`).join('')}</optgroup>` : '')
      + `<optgroup label="Someone else"><option value="__add">+ Add someone to the list…</option><option value="__manual">Type a name and position (part-time)…</option></optgroup></select>`;
    const roleSel = (cur, i) => `<select class="credit-role-sel" aria-label="Position ${i + 1}"${dis}><option value="">Choose a position…</option>${roles.map(r => `<option${r === cur ? ' selected' : ''}>${esc(r)}</option>`).join('')}<option value="__add">+ Add a position to the list…</option></select>`;
    const tools = i => ro ? '' : `<button class="link" data-action="credit-up" data-i="${i}" aria-label="Move up"${i ? '' : ' disabled'}>↑</button><button class="link danger" data-action="remove-credit" data-i="${i}">Remove</button>`;
    $('#credit-rows').innerHTML = rows.length ? rows.map((c, i) => {
      const manual = c.manual || (c.name && !people.includes(c.name)) || (c.role && !roles.includes(c.role));
      return manual
        ? `<div class="credit-row is-manual" data-i="${i}"><input type="text" class="credit-name" value="${esc(c.name || '')}" placeholder="Full name" maxlength="80" aria-label="Name ${i + 1}"${dis}>
           <input type="text" class="credit-role" value="${esc(c.role || '')}" placeholder="Position, e.g. Second photographer" maxlength="80" list="credit-roles" aria-label="Position ${i + 1}"${dis}>${tools(i)}
           <p class="credit-note"><span class="credit-tag">Part-time</span> Typed for this work only.${ro ? '' : ` <button class="link" data-action="credit-lists" data-i="${i}">Use the dropdowns</button>`}</p></div>`
        : `<div class="credit-row" data-i="${i}">${nameSel(c.name, i)}${roleSel(c.role, i)}${tools(i)}<div class="credit-add" hidden></div></div>`;
    }).join('') : '<p class="muted small">No credits yet.</p>';
    $$('[data-action="add-credit"]').forEach(el => el.hidden = ro);
  }
  function readCredits(){
    return $$('#credit-rows .credit-row').map(r => {
      if(r.classList.contains('is-manual')) return {name: r.querySelector('.credit-name').value.trim().slice(0, 80), role: r.querySelector('.credit-role').value.trim().slice(0, 80), manual: true};
      const v = sel => { const x = r.querySelector(sel).value; return /^__/.test(x) ? '' : x; };
      return {name: v('.credit-name-sel'), role: v('.credit-role-sel')};
    });
  }
  // The small form that appears inside a row: add a person (with a position) or a position to the lists
  function showCreditAdd(row, kind){
    const box = row.querySelector('.credit-add'); if(!box) return;
    const roles = creditRoles();
    box.dataset.kind = kind;
    box.innerHTML = kind === 'person'
      ? `<input type="text" class="ca-name" placeholder="Their full name" maxlength="80" aria-label="New person's name">
         <select class="ca-role" aria-label="Their usual position"><option value="">Their usual position…</option>${roles.map(r => `<option>${esc(r)}</option>`).join('')}<option value="__new">Another position…</option></select>
         <input type="text" class="ca-role-new" placeholder="New position" maxlength="80" hidden aria-label="New position">
         <button class="btn small" data-action="credit-add-save">Add to the list</button><button class="link" data-action="credit-add-cancel">Cancel</button>`
      : `<input type="text" class="ca-role-new" placeholder="Position, e.g. Drone pilot" maxlength="80" aria-label="New position">
         <button class="btn small" data-action="credit-add-save">Add to the list</button><button class="link" data-action="credit-add-cancel">Cancel</button>`;
    box.hidden = false;
    (box.querySelector('.ca-name') || box.querySelector('.ca-role-new')).focus();
  }
  async function saveCreditAdd(row){
    const box = row.querySelector('.credit-add'), kind = box.dataset.kind, o = creditOpts(), i = +row.dataset.i;
    const entry = caseEntry(); entry.credits = readCredits();
    if(kind === 'person'){
      const name = box.querySelector('.ca-name').value.trim(), pick = box.querySelector('.ca-role').value;
      const role = pick === '__new' ? box.querySelector('.ca-role-new').value.trim() : pick;
      if(!name){ toast('Write their name first'); return; }
      if(!o.people.some(x => x.name.toLowerCase() === name.toLowerCase())) o.people.push({name, role});
      if(role && !creditRoles().includes(role)) o.roles.push(role);
      entry.credits[i] = {name, role: role || entry.credits[i].role || ''};
    } else {
      const role = box.querySelector('.ca-role-new').value.trim();
      if(!role){ toast('Write the position first'); return; }
      if(!creditRoles().includes(role)) o.roles.push(role);
      entry.credits[i] = {name: entry.credits[i].name, role};
    }
    try{ await api.saveContent('credit_options', o); toast(kind === 'person' ? 'Added to the list. You can pick them on every work.' : 'Position added to the list.'); }catch(e){ fail(e); }
    renderCredits(false, entry);
  }
  document.addEventListener('change', e => {
    const t = e.target; if(!t.closest || !t.closest('#credit-rows')) return;
    const row = t.closest('.credit-row');
    if(t.classList.contains('credit-name-sel')){
      if(t.value === '__add'){ t.value = ''; showCreditAdd(row, 'person'); }
      else if(t.value === '__manual'){ const entry = caseEntry(); entry.credits = readCredits(); entry.credits[+row.dataset.i] = Object.assign(entry.credits[+row.dataset.i], {manual: true}); renderCredits(false, entry); const r = $$('#credit-rows .credit-row')[+row.dataset.i]; if(r) r.querySelector('.credit-name').focus(); }
      else { const p = creditOpts().people.find(x => x.name === t.value), rs = row.querySelector('.credit-role-sel'); if(p && p.role && rs && !rs.value) rs.value = p.role; }
    } else if(t.classList.contains('credit-role-sel') && t.value === '__add'){ t.value = ''; showCreditAdd(row, 'role'); }
    else if(t.classList.contains('ca-role')){ const n = row.querySelector('.ca-role-new'); if(n){ n.hidden = t.value !== '__new'; if(!n.hidden) n.focus(); } }
  });
  function renderReview(ro, entry){
    const r = entry.review || {}, q = $('#review-quote');
    q.value = r.quote || ''; $('#review-name').value = r.name || ''; $('#review-role').value = r.role || '';
    [q, $('#review-name'), $('#review-role')].forEach(el => el.disabled = ro);
    const count = () => { $('#review-count').textContent = q.value.length + ' / 600'; };
    count(); q.oninput = count;
    $('[data-action="remove-review"]').hidden = ro || !r.quote;
  }
  // ---- Case study list: pick one, edit it, go back (thumbnail, category, status at a glance) ----
  let caseFilter = 'All', caseQuery = '';
  const caseHref = c => c.page ? '../' + c.slug + '/index.html' : '../case/?s=' + encodeURIComponent(c.slug);
  function caseStatus(c){
    const e = (content.case_studies || {})[c.slug] || {}, out = [];
    if(e.published === false) out.push(['warn', 'Hidden']);
    const needsFilm = c.group !== 'Business';
    const nv = caseVideos(e).length;
    out.push(nv ? ['ok', nv === 1 ? 'Video' : nv + ' videos'] : needsFilm ? ['warn', 'Video needed'] : null);
    const n = (e.photos || []).length; if(n) out.push(['ok', n + ' photo' + (n === 1 ? '' : 's')]);
    if(e.review && e.review.quote) out.push(['ok', 'Review']);
    if(!e.headline || !e.summary) out.push(['warn', 'Text missing']);
    return out.filter(Boolean);
  }
  function renderCaseList(){
    const groups = ['All', ...new Set(CASES.map(c => c.group))];
    $('#case-filters').innerHTML = groups.map(g => `<button class="pill${g === caseFilter ? ' is-active' : ''}" data-action="case-filter" data-g="${esc(g)}">${esc(g)}<em>${g === 'All' ? CASES.length : CASES.filter(c => c.group === g).length}</em></button>`).join('');
    const q = caseQuery.trim().toLowerCase();
    const rows = CASES.filter(c => (caseFilter === 'All' || c.group === caseFilter) && (!q || c.title.toLowerCase().includes(q)));
    $('#case-rows').innerHTML = rows.length ? rows.map(c => `<div class="case-row" role="button" tabindex="0" data-action="open-case" data-slug="${esc(c.slug)}">
      ${c.thumb ? `<img src="${esc(c.thumb)}" alt="" width="56" height="70" loading="lazy">` : '<span class="case-noimg" aria-hidden="true"></span>'}
      <div class="case-main"><strong>${esc(c.title)}</strong><span class="muted small">${esc(c.group)}</span></div>
      <div class="case-status">${caseStatus(c).map(([k, t]) => `<span class="badge ${k}">${esc(t)}</span>`).join('') || '<span class="muted small">Nothing added yet</span>'}</div>
      <div class="case-go"><span class="btn secondary small">Edit</span><a class="link small" href="${esc(caseHref(c))}" target="_blank" rel="noopener" aria-label="View ${esc(c.title)} on the site">View ↗</a></div></div>`).join('')
      : '<p class="muted" style="padding:18px">No case study matches that search.</p>';
  }
  function showCaseView(view){
    $('#case-list').hidden = view !== 'list'; $('#case-editor').hidden = view !== 'edit';
    if(view === 'edit') window.scrollTo({top: 0});
  }
  document.addEventListener('input', e => { if(e.target.id === 'case-search'){ caseQuery = e.target.value; renderCaseList(); } });
  document.addEventListener('keydown', e => { const r = e.target.closest && e.target.closest('.case-row'); if(r && (e.key === 'Enter' || e.key === ' ') && e.target === r){ e.preventDefault(); openCase(r.dataset.slug); } });
  function openCase(slug){ if(slug !== caseSlug && !leaveOK()) return; caseSlug = slug; setDirty(false); pickOpen = ''; menuAt = -1; renderCases(); showCaseView('edit'); }
  function stepCase(d){ const i = CASES.findIndex(c => c.slug === caseSlug); openCase(CASES[(i + d + CASES.length) % CASES.length].slug); }
  // ---- Details: the same organised form for every case study (headline, fact sheet, story, why it works) ----
  // The page template, top to bottom. Every work fills the same boxes.
  // The editor, in the order a work is put together (each group fills its own step in index.html, data-group="…").
  // [step, small heading (empty = the step's own title), hint, fields]
  const DETAIL_GROUPS = [
    ['basics', '', '', [['title','Client or project name','input',120,'e.g. ORYX Energies'],['kicker','Type of work','input',80,'e.g. Product & brand photography'],['headline','Headline','input',160,'One line about the result, e.g. Engine oil, shot like a premium product.'],['summary','Summary','textarea',600,'2–3 sentences: who the client is, what we made, why it mattered.']]],
    ['images', 'Photos heading', 'The title above the photos on the page.', [['gallery_title','Heading','input',120,'The work, up close.']]],
    ['facts', '', '', [['facts.client','Client','input',120],['facts.type','Type (industry or event)','input',120],['facts.location','Location','input',80,'e.g. Kigali'],['facts.date','Date','input',40,'e.g. June 2026'],['facts.services','Services','input',160,'e.g. Photography, video']]],
    ['story', '', '', [['brief','The brief (what the client needed)','textarea',600],['approach','What we did','textarea',600],['results.0','What we delivered · 1','input',140],['results.1','What we delivered · 2','input',140],['results.2','What we delivered · 3','input',140],['results.3','What we delivered · 4 (optional)','input',140]]],
    ['where', '', '', [['category','Main section','category'],['cats','','cats']]]
  ];
  const getPath = (o, k) => k.split('.').reduce((v, x) => v == null ? v : v[x], o);
  function setPath(o, k, v){ const ks = k.split('.'); let t = o; ks.slice(0, -1).forEach((x, n) => { if(t[x] == null) t[x] = /^\d+$/.test(ks[n + 1]) ? [] : {}; t = t[x]; }); t[ks[ks.length - 1]] = v; }
  function renderDetails(ro, entry){
    const dis = ro ? ' disabled' : '';
    const keep = typed();
    const html = {};
    DETAIL_GROUPS.forEach(([step, g, hint, fields]) => { html[step] = (html[step] || '') + `<fieldset${g ? '' : ' class="is-plain"'}>${g ? `<legend>${esc(g)}</legend><p class="muted small">${esc(hint)}</p>` : ''}` + fields.map(([key, label, kind, max, ph]) => {
      const val = getPath(entry, key) ?? '';
      if(kind === 'category') return `<label class="review-field"><span>${esc(label)}</span><select data-key="${key}"${dis}>${Object.keys(CAT_LABEL).map(k => `<option value="${k}"${(entry.category || 'business') === k ? ' selected' : ''}>${CAT_LABEL[k]}</option>`).join('')}</select><small class="muted">Its main group on the Work page, and which prices and booking form the page links to.</small></label>`;
      if(kind === 'cats') return `<div class="cat-pick" id="cat-pick">${catPickHTML(ro, entry)}</div>`;
      if(kind === 'thumb'){
        const photos = entry.photos || [], cur = (entry.card || {}).url || '', custom = !!entry.card_custom;
        const isCur = ph => custom && (ph.sm === cur || ph.url === cur);
        return `<div class="thumb-current"><span class="thumb-frame">${cur ? `<img src="${esc(cur)}" alt="">` : ''}</span><span class="muted small">${custom ? 'Chosen thumbnail.' : 'Using the cover photo (or the picture already on the site).'}${custom && !ro ? ' <button type="button" class="link" data-action="thumb-reset">Use the cover instead</button>' : ''}</span></div>`
          + `<div class="cover-pick thumb-pick">${photos.map((ph, n) => `<button type="button" class="cover-opt${isCur(ph) ? ' is-on' : ''}" data-action="pick-thumb" data-i="${n}"${dis} aria-label="Use photo ${n + 1} as the thumbnail"${isCur(ph) ? ' aria-pressed="true"' : ''}><img src="${esc(ph.sm || ph.url)}" alt="" loading="lazy"></button>`).join('')}`
          + (ro ? '' : `<label class="cover-opt thumb-up" title="Upload a different picture"><input type="file" accept="image/*" data-thumb-file hidden><span>+ Upload<br>another</span></label>`) + `</div>`
          + '<p class="muted small">Upright pictures (4:5) look best in the cards.</p>';
      }
      if(kind === 'cover'){
        const photos = entry.photos || [], cur = (entry.cover || {}).url || '';
        return `<div class="cover-pick" data-cover-pick>${photos.length ? photos.map((ph, n) => `<button type="button" class="cover-opt${ph.url === cur ? ' is-on' : ''}" data-action="pick-cover" data-i="${n}"${dis} aria-label="Use photo ${n + 1} as the cover"${ph.url === cur ? ' aria-pressed="true"' : ''}><img src="${esc(ph.sm || ph.url)}" alt="" loading="lazy"></button>`).join('') : '<p class="muted small">Add photos below first, then pick the cover here.</p>'}</div>`
          + (cur && !photos.some(ph => ph.url === cur) ? `<p class="muted small">Current cover: <a href="${esc(cur)}" target="_blank" rel="noopener">open ↗</a></p>` : '');
      }
      const ctl = kind === 'textarea' ? `<textarea rows="3" maxlength="${max}"` : `<input type="text" maxlength="${max}"`;
      return `<label class="review-field"><span>${esc(label)}</span>${ctl} data-key="${key}" placeholder="${esc(ph || '')}"${dis}` + (kind === 'textarea' ? `>${esc(val)}</textarea>` : ` value="${esc(val)}">`) + '</label>';
    }).join('') + '</fieldset>'; });
    $$('#case-editor [data-group]').forEach(box => { box.innerHTML = html[box.dataset.group] || ''; });
    restoreTyped(keep);
    renderPicks();
    const vis = $('#ce-visible'); vis.checked = entry.published !== false; vis.disabled = ro; visLabel();
    $$('[data-action="reset-details"],[data-action="delete-case"]').forEach(b => b.hidden = ro);
  }
  // ---- One save model (Shopify-style): typed text waits for the save bar; uploads, picks and tags save at once ----
  let dirty = false, snap = null;
  const TYPED = '#case-editor [data-group] input[data-key][type="text"], #case-editor [data-group] textarea[data-key], #review-quote, #review-name, #review-role, #credit-rows input, #credit-rows select';
  function typed(){ if(!dirty) return null; const m = {}; $$('#case-editor [data-key]').forEach(el => { if(el.type !== 'checkbox' && el.tagName !== 'SELECT') m[el.dataset.key] = el.value; }); return m; }
  function restoreTyped(m){ if(!m) return; $$('#case-editor [data-key]').forEach(el => { if(m[el.dataset.key] !== undefined) el.value = m[el.dataset.key]; }); }
  function setDirty(on){
    if(on && !dirty){ const e = caseEntry(); snap = JSON.stringify({credits: e.credits || [], review: e.review || null}); }
    dirty = !!on; $('#ce-savebar').hidden = !dirty; document.body.classList.toggle('has-savebar', dirty);
  }
  document.addEventListener('input', e => { if(e.target.matches && e.target.matches(TYPED) && isAdmin()) setDirty(true); });
  document.addEventListener('change', e => { if(e.target.matches && e.target.matches('#credit-rows select') && isAdmin()) setDirty(true); });
  window.addEventListener('beforeunload', e => { if(dirty){ e.preventDefault(); e.returnValue = ''; } });
  const leaveOK = () => !dirty || (confirm('You have unsaved changes on this work. Leave without saving?') && (discardTyped(true), true));
  function discardTyped(quiet){
    const e = caseEntry(); if(snap){ const o = JSON.parse(snap); e.credits = o.credits; if(o.review) e.review = o.review; else delete e.review; }
    setDirty(false); snap = null; if(!quiet) renderCases();
  }
  async function saveAll(){
    const entry = caseEntry();
    const title = ($('#case-editor [data-key="title"]') || {}).value || '';
    if(!title.trim()){ toast('The work needs a client or project name'); $('#case-editor [data-key="title"]').focus(); return; }
    // review: a quote needs a name; an empty quote removes it
    const quote = $('#review-quote').value.trim().replace(/^["“”']+|["“”']+$/g, '').trim().slice(0, 600);
    if(quote && !$('#review-name').value.trim()){ toast('Add the name of the person quoted.'); $('#review-name').focus(); return; }
    const credits = readCredits();
    if(credits.some(c => (c.name && !c.role) || (!c.name && c.role))){ toast('Each credit needs a person and a position'); document.getElementById('ce-s-credits').scrollIntoView({block: 'center'}); return; }
    $$('#case-editor [data-group] [data-key]').forEach(el => {
      if(el.tagName === 'SELECT' || el.type === 'checkbox') return;
      setPath(entry, el.dataset.key, el.value.trim().slice(0, +el.maxLength > 0 ? +el.maxLength : 900));
    });
    entry.results = (entry.results || []).map(r => String(r || '').trim()).filter(Boolean).slice(0, 4);
    if(quote){ const old = entry.review || {}; entry.review = {quote, name: $('#review-name').value.trim().slice(0, 80), role: $('#review-role').value.trim().slice(0, 100)}; if(old.logo && old.name === entry.review.name){ entry.review.logo = old.logo; entry.review.logo_alt = old.logo_alt || ''; } }
    else delete entry.review;
    entry.credits = credits.filter(c => c.name && c.role);
    entrySections(entry); entry.v = 2;
    setDirty(false); snap = null;
    rebuildCaseList(); renderCases();
    await saveCases(entry.published === false ? 'Saved. This work is still hidden from the website.' : 'Saved. Live on the website.');
  }
  function visLabel(){ const on = $('#ce-visible').checked; $('#ce-vis-label').textContent = on ? 'Live on the website' : 'Hidden'; $('#ce-vis-note').textContent = on ? 'Shown on the Work page, the menu and “More work like this”.' : 'Only you can see it. Switch on when it is ready.'; }
  document.addEventListener('change', e => {
    const t = e.target;
    if(t.id === 'ce-visible'){ const entry = caseEntry(); entry.published = t.checked; visLabel(); $('#case-live').hidden = !t.checked; rebuildCaseList(); renderSteps(); saveCases(t.checked ? 'Live on the website.' : 'Hidden from the website.'); }
    else if(t.matches && t.matches('#case-editor [data-key="category"]')){ const entry = caseEntry(); entry.category = t.value; entry.sections = [t.value].concat((entry.sections || []).filter(x => x !== t.value)); rebuildCaseList(); redrawCats(); saveCases('Main section saved.'); }
  });
  // Steps: a checklist that jumps to each part and shows what is done
  const STEPS = [
    ['basics', 'Title and summary', e => !!(e.title && e.headline && e.summary)],
    ['photos', 'Photos and cover', e => !!((e.photos || []).length && e.cover && e.cover.url)],
    ['videos', 'Videos', e => caseVideos(e).length > 0, 1],
    ['facts', 'Facts', e => Object.values(e.facts || {}).some(Boolean)],
    ['story', 'The story', e => !!(e.brief && e.approach && (e.results || []).length)],
    ['review', 'Client review', e => !!(e.review && e.review.quote), 1],
    ['credits', 'Credits', e => (e.credits || []).some(c => c.name), 1],
    ['where', 'Where it appears', e => Array.isArray(e.services) ? e.services.length > 0 : !!caseSeed[caseSlug]]
  ];
  function renderSteps(){
    if(!$('#ce-steps') || !caseSlug) return;
    const e = caseEntry(), need = STEPS.filter(s => !s[3]), done = need.filter(s => s[2](e)).length;
    $('#ce-progress').textContent = done + ' of ' + need.length + ' needed';
    $('#ce-steps').innerHTML = STEPS.map(([id, name, ok, opt], i) => { const d = ok(e); return `<li class="${d ? 'is-done' : ''}"><a href="#ce-s-${id}" data-step-link="${id}"><span class="ce-dot" aria-hidden="true">${d ? '✓' : i + 1}</span><span>${name}${opt ? ' <small>optional</small>' : ''}</span><span class="sr-only">${d ? ' (done)' : ''}</span></a></li>`; }).join('');
  }
  document.addEventListener('click', e => {
    const a = e.target.closest && e.target.closest('[data-step-link]'); if(!a) return;
    e.preventDefault(); const sec = document.getElementById('ce-s-' + a.dataset.stepLink); if(!sec) return;
    sec.scrollIntoView({behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start'});
    const f = sec.querySelector('input:not([type=file]):not([type=checkbox]),textarea'); if(f) setTimeout(() => f.focus({preventScroll: true}), 400);
  });
  // highlight the step in view
  let stepIO = null;
  function watchSteps(){
    if(stepIO || !('IntersectionObserver' in window)) return;
    stepIO = new IntersectionObserver(es => es.forEach(x => { if(x.isIntersecting) $$('#ce-steps li').forEach(li => li.classList.toggle('is-here', li.querySelector('a').dataset.stepLink === x.target.dataset.step)); }), {rootMargin: '-30% 0px -60% 0px'});
    $$('.ce-sec').forEach(s => stepIO.observe(s));
  }
  document.addEventListener('change', async e => {
    const inp = e.target; if(!inp.matches || !inp.matches('[data-thumb-file]') || !inp.files[0]) return;
    const f = inp.files[0]; inp.value = ''; const slug = caseSlug;
    try{
      toast('Uploading the thumbnail…');
      const ready = await prepPhoto(f);
      const url = await api.upload(ready.file, `case-studies/${slug}/thumb-${Date.now().toString(36)}.${ready.ext}`);
      const entry = content.case_studies[slug]; entry.card = {url}; entry.card_custom = 1;
      rebuildCaseList(); if(caseSlug === slug){ renderDetails(!isAdmin(), entry); paintGrid(); } await saveCases('Thumbnail uploaded. Live on the website.');
    }catch(err){ fail(err); }
  });
  function addWork(){
    const box = $('#new-work'); box.hidden = false; $('#new-work-title').value = ''; $('#new-work-title').focus();
  }
  async function createWork(){
    const title = $('#new-work-title').value.trim(), category = $('#new-work-cat').value;
    if(!title){ toast('Write the client or project name first'); return; }
    const all = content.case_studies = content.case_studies || {};
    let slug = slugify(title) || 'work-' + Date.now().toString(36), n = 2; const base = slug;
    while(all[slug] || caseSeed[slug]) slug = base + '-' + n++;
    const maxOrder = Math.max(-1, ...Object.values(all).map(e => e && e.order != null ? e.order : -1));
    all[slug] = {v: 2, title, category, kicker: '', headline: '', summary: '', cover: null, facts: {client: title, type: '', location: 'Kigali', date: new Date().toLocaleDateString('en-GB', {month: 'long', year: 'numeric'}), services: ''},
                 brief: '', approach: '', results: [], gallery_title: 'The work, up close.', video: null, videos: [], services: [], industries: [], photos: [], review: null, credits: [], published: false, order: maxOrder + 1, created: new Date().toISOString(), seeded: 1};
    $('#new-work').hidden = true;
    rebuildCaseList(); await saveCases('Work added as hidden. Fill it in, then tick “Show this work on the website”.');
    openCase(slug);
  }
  async function deleteCase(){
    const entry = caseEntry(), name = entry.title || caseSlug;
    if(!confirm(`Delete “${name}”? It disappears from the website. Photos you uploaded stay in storage.`)) return;
    if(caseSeed[caseSlug]) entry.deleted = true; else delete content.case_studies[caseSlug];
    rebuildCaseList(); await saveCases('Deleted.');
    caseSlug = (CASES[0] || {}).slug || ''; renderCaseList(); showCaseView('list');
  }
  function renderCases(){
    if(!caseSlug){ renderCaseList(); return; }
    const ro = !isAdmin(), entry = caseEntry();
    renderDetails(ro, entry);
    $('#cases-readonly').hidden = !ro;
    const cur = CASES.find(c => c.slug === caseSlug) || CASES[0] || {slug: caseSlug, title: entry.title || ''};
    $('#case-title').textContent = entry.title || cur.title;
    $('#case-pos').textContent = (CASES.indexOf(cur) + 1) + ' of ' + CASES.length;
    renderCaseList();
    $('#case-preview').href = caseHref(cur) + (cur.page ? '?' : '&') + 'preview=1';
    const keepRv = dirty ? ['#review-quote', '#review-name', '#review-role'].map(x => $(x).value) : null, keepCr = dirty ? readCredits() : null;
    renderCredits(ro, keepCr ? {credits: keepCr} : entry);
    renderReview(ro, entry);
    if(keepRv){ ['#review-quote', '#review-name', '#review-role'].forEach((x, i) => { $(x).value = keepRv[i]; }); $('#review-count').textContent = keepRv[0].length + ' / 600'; }
    renderVideos(ro, entry);
    renderPhotos(ro, entry);
    const live = $('#case-live'); live.href = caseHref(cur); live.hidden = entry.published === false;
    renderSteps(); watchSteps();
  }
  function renderPhotos(ro, entry){
    const photos = entry.photos || [], mine = pendingPhotos.filter(j => j.slug === caseSlug);
    const full = photos.length + mine.length >= MAX_PHOTOS;
    $('#photo-count').textContent = photos.length + ' of ' + MAX_PHOTOS + (mine.length ? ' · uploading ' + mine.filter(j => !j.done).length : '');
    let html = photos.map((p, i) => `<figure class="ph-item" draggable="${ro ? 'false' : 'true'}" data-pi="${i}">
      <div class="ph-thumb"><img src="${esc(p.url)}" alt="" loading="lazy"><span class="ph-num">${i + 1}</span>${ro ? '' : `<button type="button" class="ph-open" data-action="ph-menu" data-i="${i}" aria-label="Photo ${i + 1}: use as cover or thumbnail" aria-haspopup="menu"></button>`}<span class="ph-badges" data-badges="${i}"></span>
      ${ro ? '' : `<div class="ph-tools"><button class="ph-btn" data-action="photo-move" data-i="${i}" data-d="-1" aria-label="Move photo ${i + 1} earlier"${i ? '' : ' disabled'}>←</button><button class="ph-btn" data-action="photo-move" data-i="${i}" data-d="1" aria-label="Move photo ${i + 1} later"${i < photos.length - 1 ? '' : ' disabled'}>→</button><button class="ph-btn danger" data-action="remove-photo" data-i="${i}" aria-label="Remove photo ${i + 1}">✕</button></div>`}</div>
      <input type="text" class="slot-caption" data-i="${i}" value="${esc(p.caption || '')}" placeholder="Describe this photo" maxlength="160" ${ro ? 'disabled' : ''} aria-label="Caption for photo ${i + 1}">
      <select class="slot-group" data-i="${i}" ${ro ? 'disabled' : ''} aria-label="Group for photo ${i + 1}"><option value=""${p.group ? '' : ' selected'}>Group: automatic</option><option value="print"${p.group === 'print' ? ' selected' : ''}>Printed, in use</option><option value="design"${p.group === 'design' ? ' selected' : ''}>Design file</option></select></figure>`).join('');
    html += mine.map(j => `<figure class="ph-item is-up${j.error ? ' is-err' : ''}"><div class="ph-thumb"><img src="${esc(j.preview)}" alt=""><span class="ph-state">${j.error ? 'Failed' : j.done ? 'Done' : j.started ? 'Uploading…' : 'Waiting…'}</span></div><small class="ph-name">${esc(j.error ? String(j.error.message || j.error).slice(0, 90) : j.name)}</small></figure>`).join('');
    if(!ro && !full) html += `<label class="ph-add"><input type="file" accept="image/*" multiple data-photo hidden><span class="ph-plus">+</span><strong>Add photos</strong><small>or drop them here</small></label>`;
    if(ro && !photos.length) html = '<p class="muted small">No uploaded photos.</p>';
    $('#photo-grid').innerHTML = html;
    $('#photo-note').innerHTML = 'These are the photos on this work page, in this order. '
      + 'Drop several at once: they\'re resized and compressed for you. Drag to reorder. A short caption helps Google and blind visitors. '
      + 'For branding work, set each photo to “Printed, in use” or “Design file”: the page then shows them in two groups. '
      + '<b>Tap a photo</b> to use it as the cover or the thumbnail; the ★ tags suggest what each photo suits best.';
    paintGrid(); analyseAll();
  }
  // ---- Cover and thumbnail: suggestions from the photos themselves, a best-first picker, a menu on each photo ----
  // Each photo is measured once (in a 96 px copy): shape, size, sharpness, exposure, contrast and colour. The cover is
  // shown 16:9 (4:3 on phones) and large, so it wants a wide, big, sharp photo; the thumbnail is a 4:5 card, so it wants
  // an upright, sharp, punchy one. Sharpness and colour are compared with the other photos of the same work.
  const photoStats = new Map();
  let pickOpen = '', menuAt = -1;
  function measure(url){
    if(photoStats.has(url)) return photoStats.get(url);
    const job = new Promise(res => {
      const im = new Image(); im.crossOrigin = 'anonymous'; im.decoding = 'async';
      im.onload = () => {
        const out = {w: im.naturalWidth, h: im.naturalHeight};
        try{
          const k = 96 / Math.max(out.w, out.h), W = Math.max(8, Math.round(out.w * k)), H = Math.max(8, Math.round(out.h * k));
          const c = document.createElement('canvas'); c.width = W; c.height = H;
          const g = c.getContext('2d', {willReadFrequently: true}); g.drawImage(im, 0, 0, W, H);
          const d = g.getImageData(0, 0, W, H).data, L = new Float32Array(W * H);
          let sum = 0, sq = 0, rg = 0, yb = 0, rg2 = 0, yb2 = 0;
          for(let i = 0, j = 0; i < d.length; i += 4, j++){
            const r = d[i], gg = d[i + 1], b = d[i + 2], y = (0.299 * r + 0.587 * gg + 0.114 * b) / 255;
            L[j] = y; sum += y; sq += y * y;
            const a = r - gg, bb = 0.5 * (r + gg) - b; rg += a; yb += bb; rg2 += a * a; yb2 += bb * bb;
          }
          const n = W * H, mean = sum / n;
          let lap = 0;
          for(let y = 1; y < H - 1; y++) for(let x = 1; x < W - 1; x++){ const i = y * W + x; lap += Math.abs(4 * L[i] - L[i - 1] - L[i + 1] - L[i - W] - L[i + W]); }
          out.mean = mean; out.contrast = Math.sqrt(Math.max(0, sq / n - mean * mean));
          out.sharp = lap / ((W - 2) * (H - 2));
          const mrg = rg / n, myb = yb / n;
          out.color = Math.sqrt(Math.max(0, rg2 / n - mrg * mrg) + Math.max(0, yb2 / n - myb * myb)) + 0.3 * Math.sqrt(mrg * mrg + myb * myb);
        }catch(e){ /* the image host does not allow reading pixels: shape and size only */ }
        res(out);
      };
      im.onerror = () => res(null);
      im.src = url;
    });
    photoStats.set(url, job); job.then(v => photoStats.set(url, v || {})); return job;
  }
  let analysing = false;
  async function analyseAll(){
    if(analysing || !caseSlug) return;
    const todo = (caseEntry().photos || []).map(p => p.sm || p.url).filter(u => u && !photoStats.has(u));
    if(!todo.length) return;
    analysing = true;
    for(let i = 0; i < todo.length; i += 3) await Promise.all(todo.slice(i, i + 3).map(measure));
    analysing = false; paintGrid(); renderPicks();
  }
  const statOf = p => { const v = photoStats.get(p.sm || p.url); return v && !(v instanceof Promise) ? v : null; };
  // percent rank of v among the list (0 = lowest of this work, 1 = highest)
  const rankIn = (list, v) => list.length < 2 ? 0.5 : list.filter(x => x < v).length / (list.length - 1);
  function suggestions(entry){
    const photos = entry.photos || [];
    const st = photos.map(p => Object.assign({w: p.w, h: p.h}, statOf(p) || {}));
    const sharpL = st.map(s => s.sharp).filter(x => x != null), colL = st.map(s => s.color).filter(x => x != null);
    const keep = (r, t) => r ? Math.min(r, t) / Math.max(r, t) : 0.6;
    const res = (w, need) => w ? Math.min(1, w / need) : 0.6;
    const out = st.map((s, i) => {
      const r = s.w && s.h ? s.w / s.h : 0, px = Math.max(s.w || 0, s.h || 0);
      const sharp = s.sharp != null ? rankIn(sharpL, s.sharp) : 0.5, col = s.color != null ? rankIn(colL, s.color) : 0.5;
      const expo = s.mean != null ? Math.max(0, 1 - Math.abs(s.mean - 0.5) * 2.2) : 0.6, con = s.contrast != null ? Math.min(1, s.contrast / 0.22) : 0.6;
      const cover = 0.34 * keep(r, 16 / 9) + 0.2 * res(px, 1800) + 0.2 * sharp + 0.14 * expo + 0.06 * con + 0.06 * col;
      const thumb = 0.34 * keep(r, 4 / 5) + 0.08 * res(px, 900) + 0.22 * sharp + 0.12 * expo + 0.12 * con + 0.12 * col;
      const why = [], warn = [];
      if(r){ if(r >= 1.3) why.push('wide'); else if(r <= 0.9) why.push('upright'); else why.push('square-ish'); }
      if(s.sharp != null && sharp >= 0.7) why.push('one of the sharpest'); if(s.color != null && col >= 0.75) why.push('rich colour');
      if(s.mean != null && expo > 0.75) why.push('well exposed');
      if(px && px < 1200) warn.push('small for a cover (' + px + ' px)');
      if(s.mean != null && s.mean < 0.22) warn.push('quite dark'); if(s.mean != null && s.mean > 0.85) warn.push('very bright');
      if(s.sharp != null && sharpL.length > 3 && sharp <= 0.1 && s.sharp < 0.03) warn.push('looks soft');
      return {i, cover, thumb, why, warn, measured: s.mean != null || !!s.w};
    });
    const best = k => out.length ? out.reduce((a, b) => b[k] > a[k] ? b : a) : null;
    const bc = best('cover'), bt = best('thumb');
    const top = k => { const v = out.map(o => o[k]).sort((a, b) => b - a); return v[Math.min(v.length - 1, Math.max(1, Math.round(v.length * 0.25)))] || 1; };
    const tc = top('cover'), tt = top('thumb');
    out.forEach(o => {
      o.tag = o === bc ? 'Best cover' : o === bt ? 'Best thumbnail' : o.cover >= tc && o.cover >= o.thumb ? 'Good cover' : o.thumb >= tt ? 'Good thumbnail' : o.warn.length ? 'Gallery only' : 'Gallery';
      if(o === bc && o === bt) o.tag = 'Best cover';
    });
    return {list: out, bestCover: bc, bestThumb: bt};
  }
  const isCoverPh = (e, p) => !!(e.cover && (e.cover.url === p.url || (p.sm && e.cover.url === p.sm)));
  function sugText(o){
    if(!o || !o.measured) return 'Measuring this photo…';
    const what = o.tag.startsWith('Best') || o.tag.startsWith('Good') ? o.tag.replace('Best', 'Best as the').replace('Good', 'Works well as the').replace('cover', 'cover').toLowerCase() : 'Best kept in the gallery';
    return what.charAt(0).toUpperCase() + what.slice(1) + (o.why.length ? ': ' + o.why.join(', ') : '') + (o.warn.length ? '. Note: ' + o.warn.join(', ') : '') + '.';
  }
  function paintGrid(){
    if(!$('#photo-grid') || !caseSlug) return;
    const e = caseEntry(), S = suggestions(e);
    (e.photos || []).forEach((p, i) => {
      const box = $(`[data-badges="${i}"]`); if(!box) return;
      const o = S.list[i], b = [];
      if(isCoverPh(e, p)) b.push('<span class="phb is-cover">Cover</span>');
      if(e.card && (e.card.url === p.url || e.card.url === p.sm)) b.push('<span class="phb is-thumb">Thumbnail</span>');
      if(o && o.measured && /^(Best|Good)/.test(o.tag)) b.push(`<span class="phb is-tip" title="${esc(sugText(o))}">★ ${esc(o.tag)}</span>`);
      box.innerHTML = b.join('');
    });
  }
  function renderPicks(){
    const bar = $('#pick-bar'); if(!bar || !caseSlug) return;
    const e = caseEntry(), photos = e.photos || [], S = suggestions(e), ro = !isAdmin();
    const cov = (e.cover || {}).url || '', th = (e.card || {}).url || '';
    const covI = photos.findIndex(p => isCoverPh(e, p));
    const hint = (kind, best, curI) => best && best.measured && best.i !== curI && photos.length > 1 && !ro
      ? `<button type="button" class="pick-sug" data-action="pick-${kind === 'cover' ? 'cover' : 'thumb'}" data-i="${best.i}"><img src="${esc(photos[best.i].sm || photos[best.i].url)}" alt=""><span>Suggested: photo ${best.i + 1}<small>${esc(best.why.slice(0, 2).join(', ') || 'best fit')}</small></span><b>Use it</b></button>` : '';
    const thI = photos.findIndex(p => th && (th === p.url || th === p.sm));
    bar.innerHTML = `<div class="pick-slot"><span class="pick-img is-wide">${cov ? `<img src="${esc(cov)}" alt="">` : '<em>No cover yet</em>'}</span><span class="pick-txt"><b>Cover</b><small>The large photo at the top of the page (16:9).</small>${ro ? '' : `<button type="button" class="btn secondary small" data-action="pick-open" data-kind="cover" aria-expanded="${pickOpen === 'cover'}">${pickOpen === 'cover' ? 'Close' : 'Change'}</button>`}</span>${hint('cover', S.bestCover, covI)}</div>`
      + `<div class="pick-slot"><span class="pick-img is-tall">${th ? `<img src="${esc(th)}" alt="">` : '<em>None</em>'}</span><span class="pick-txt"><b>Thumbnail</b><small>${e.card_custom ? 'The card on the home page, the Work page and “More work like this” (4:5).' : 'Same as the cover until you choose one (4:5 card).'}</small>${ro ? '' : `<button type="button" class="btn secondary small" data-action="pick-open" data-kind="thumb" aria-expanded="${pickOpen === 'thumb'}">${pickOpen === 'thumb' ? 'Close' : 'Change'}</button>`}</span>${hint('thumb', S.bestThumb, e.card_custom ? thI : covI)}</div>`;
    const strip = $('#pick-strip');
    if(!pickOpen || ro){ strip.hidden = true; strip.innerHTML = ''; return; }
    const k = pickOpen, order = S.list.slice().sort((a, b) => b[k] - a[k]);
    const on = p => k === 'cover' ? isCoverPh(e, p) : !!(e.card_custom && th && (th === p.url || th === p.sm));
    const label = (o, n) => !o.measured ? '' : n === 0 ? 'Best match' : o.tag === (k === 'cover' ? 'Good cover' : 'Good thumbnail') || n < 3 ? 'Good' : '';
    strip.hidden = false;
    strip.innerHTML = `<div class="pick-head"><b>Choose the ${k === 'cover' ? 'cover' : 'thumbnail'}</b><span class="muted small">Best matches first</span><span class="pick-nav"><button type="button" class="ph-btn" data-action="pick-scroll" data-d="-1" aria-label="Scroll back">‹</button><button type="button" class="ph-btn" data-action="pick-scroll" data-d="1" aria-label="Scroll on">›</button></span><button type="button" class="link small" data-action="pick-open" data-kind="${k}">Done</button></div>`
      + `<div class="pick-scroll" role="listbox" aria-label="Photos">`
      + (k === 'thumb' ? `<button type="button" class="pick-opt is-tall pick-special${e.card_custom ? '' : ' is-on'}" data-action="thumb-reset"><span>Same as<br>the cover</span></button><label class="pick-opt is-tall pick-special" title="Upload a different picture"><input type="file" accept="image/*" data-thumb-file hidden><span>+ Upload<br>another</span></label>` : '')
      + (photos.length ? order.map((o, n) => { const p = photos[o.i], l = label(o, n); return `<button type="button" role="option" aria-selected="${on(p)}" class="pick-opt ${k === 'cover' ? 'is-wide' : 'is-tall'}${on(p) ? ' is-on' : ''}" data-action="pick-${k === 'cover' ? 'cover' : 'thumb'}" data-i="${o.i}" title="${esc(sugText(o))}"><img src="${esc(p.sm || p.url)}" alt="" loading="lazy">${l ? `<span class="pick-tag${n === 0 ? ' is-best' : ''}">${l}</span>` : ''}<span class="pick-n">Photo ${o.i + 1}</span>${on(p) ? '<span class="pick-check" aria-hidden="true">✓</span>' : ''}</button>`; }).join('') : '<p class="muted small">Add photos above first.</p>')
      + `</div>`;
  }
  function photoMenu(i){
    $$('.ph-menu').forEach(m => m.remove()); $$('.ph-item.has-menu').forEach(x => x.classList.remove('has-menu'));
    if(i < 0){ menuAt = -1; return; }
    const e = caseEntry(), p = (e.photos || [])[i], fig = $(`.ph-item[data-pi="${i}"]`); if(!p || !fig){ menuAt = -1; return; }
    menuAt = i;
    const o = suggestions(e).list[i], c = isCoverPh(e, p), t = !!(e.card_custom && e.card && (e.card.url === p.url || e.card.url === p.sm));
    fig.classList.add('has-menu'); fig.insertAdjacentHTML('beforeend', `<div class="ph-menu" role="menu" aria-label="Photo ${i + 1}">
      <p class="ph-menu-sug">${esc(sugText(o))}</p>
      <button type="button" role="menuitem" data-action="pick-cover" data-i="${i}"${c ? ' disabled' : ''}>${c ? '✓ This is the cover' : 'Use as the cover'}</button>
      <button type="button" role="menuitem" data-action="pick-thumb" data-i="${i}"${t ? ' disabled' : ''}>${t ? '✓ This is the thumbnail' : 'Use as the thumbnail'}</button>
      ${window.CRT_FOCUS ? `<button type="button" role="menuitem" data-action="ph-crop" data-i="${i}">Adjust crop…</button>` : ''}
      <a role="menuitem" href="${esc(p.url)}" target="_blank" rel="noopener">Open full size ↗</a></div>`);
    const first = fig.querySelector('.ph-menu button:not([disabled]),.ph-menu a'); if(first) first.focus();
  }
  document.addEventListener('click', e => { if(menuAt >= 0 && !(e.target.closest && e.target.closest('.ph-menu,[data-action="ph-menu"]'))) photoMenu(-1); }, true);
  document.addEventListener('keydown', e => { if(e.key === 'Escape'){ if(menuAt >= 0){ const i = menuAt; photoMenu(-1); const b = $(`[data-action="ph-menu"][data-i="${i}"]`); if(b) b.focus(); } else if(pickOpen){ pickOpen = ''; renderPicks(); } } });
  async function addPhotos(files){
    const slug = caseSlug, entry = caseEntry(); entry.photos = entry.photos || [];
    files = files.filter(f => /^image\//.test(f.type) || /\.(heic|heif)$/i.test(f.name));
    if(!files.length){ toast('Those aren\'t photos'); return; }
    const room = MAX_PHOTOS - entry.photos.length - pendingPhotos.filter(j => j.slug === slug && !j.done).length;
    if(room <= 0){ toast('This case study is full (' + MAX_PHOTOS + ' photos). Remove one first.'); return; }
    if(files.length > room){ toast('Only ' + room + ' more fit. Adding the first ' + room + '.'); files = files.slice(0, room); }
    const jobs = files.map((f, k) => ({slug, name: f.name, file: f, preview: URL.createObjectURL(f), key: Date.now().toString(36) + k}));
    pendingPhotos.push(...jobs); renderPhotos(false, entry);
    let next = 0;
    const worker = async () => {
      while(next < jobs.length){
        const j = jobs[next++]; j.started = true; if(caseSlug === slug) renderPhotos(false, caseEntry());
        try{
          const ready = await prepPhoto(j.file);
          const url = await api.upload(ready.file, `case-studies/${slug}/photo-${j.key}.${ready.ext}`);
          j.result = {url, caption: '', w: ready.w, h: ready.h};
        }catch(e){ j.error = e; }
        j.done = true; if(caseSlug === slug) renderPhotos(false, caseEntry());
      }
    };
    await Promise.all([worker(), worker(), worker()]);
    jobs.forEach(j => { if(j.result) entry.photos.push(j.result); });
    const ok = jobs.filter(j => j.result).length, bad = jobs.length - ok;
    setTimeout(() => { jobs.forEach(j => URL.revokeObjectURL(j.preview)); pendingPhotos = pendingPhotos.filter(j => !jobs.includes(j) || j.error); if(caseSlug === slug) renderPhotos(false, caseEntry()); }, bad ? 8000 : 0);
    pendingPhotos = pendingPhotos.filter(j => !jobs.includes(j) || j.error);
    if(caseSlug === slug) renderCases();
    if(ok) await saveCases(ok + ' photo' + (ok === 1 ? '' : 's') + ' added. Live on the site.' + (bad ? ' ' + bad + ' failed.' : ''));
    else toast('Upload failed: ' + ((jobs[0].error && jobs[0].error.message) || 'please try again') + (/bucket/i.test(String(jobs[0].error && jobs[0].error.message)) ? '. Run admin/supabase-setup.sql again to create the media storage.' : ''));
  }
  function movePhoto(from, to){
    const entry = caseEntry(), list = entry.photos || [];
    if(to < 0 || to >= list.length || from === to) return;
    const [p] = list.splice(from, 1); list.splice(to, 0, p);
    renderPhotos(false, entry); saveCases('Order saved.');
  }
  // ---- Videos: any number per work, each an uploaded file or a link (YouTube, Vimeo, Google Drive, Instagram) ----
  // Stored as entry.videos = [{type, url, title, poster, w, h}]; entry.video keeps the first one for older readers.
  const caseVideos = e => Array.isArray(e.videos) ? e.videos.filter(v => v && v.url) : (e.video && e.video.url ? [e.video] : []);
  function setVideos(e, list){ e.videos = list; e.video = list[0] || null; }
  const MAX_VIDEOS = 12;
  function videoInfo(url){
    const yt = url.match(/(?:youtube\.com\/(?:watch\?(?:.*&)?v=|shorts\/|embed\/|live\/)|youtu\.be\/)([\w-]{11})/);
    if(yt) return {kind: 'YouTube', thumb: `https://i.ytimg.com/vi/${yt[1]}/hqdefault.jpg`, vertical: /\/shorts\//.test(url)};
    const gd = url.match(/drive\.google\.com\/(?:file\/d\/|open\?id=|uc\?(?:export=\w+&)?id=)([\w-]{20,})/);
    if(gd) return {kind: 'Google Drive', thumb: `https://drive.google.com/thumbnail?id=${gd[1]}&sz=w640`};
    if(/vimeo\.com\/(?:video\/)?\d+/.test(url)) return {kind: 'Vimeo'};
    if(/instagram\.com\//.test(url)) return {kind: 'Instagram', vertical: true};
    return {kind: 'Link'};
  }
  function renderVideos(ro, entry){
    const list = caseVideos(entry);
    $('#film-url').disabled = ro;
    $$('[data-action="save-film-url"],#film-drop .upload-btn').forEach(el => el.hidden = ro);
    $('#film-drop').hidden = ro || list.length >= MAX_VIDEOS;
    $('#film-count').textContent = list.length ? list.length + ' of ' + MAX_VIDEOS : '';
    $('#film-preview').innerHTML = list.length ? list.map((v, i) => {
      const info = v.type === 'file' ? {kind: 'Uploaded video'} : videoInfo(v.url);
      const th = v.poster || info.thumb;
      const thumb = th ? `<img src="${esc(th)}" alt="" loading="lazy">` : v.type === 'file' ? `<video src="${esc(v.url)}" preload="metadata" muted playsinline></video>` : `<span class="film-kind">${esc(info.kind)}</span>`;
      return `<div class="film-item" data-vi="${i}"><div class="film-thumb">${thumb}<span class="film-play" aria-hidden="true">▶</span></div>
        <div class="film-meta"><input type="text" class="film-title" data-vi="${i}" value="${esc(v.title || '')}" maxlength="80" placeholder="${i ? 'Title, e.g. Behind the scenes' : 'Title, e.g. Highlight video'}" aria-label="Title of video ${i + 1}"${ro ? ' disabled' : ''}>
        <span class="muted small">${i === 0 ? '<span class="badge ok">Main video</span> ' : ''}${esc(info.kind)} · <a href="${esc(v.url)}" target="_blank" rel="noopener">open ↗</a></span></div>
        ${ro ? '' : `<div class="film-tools"><button class="ph-btn" data-action="film-move" data-i="${i}" data-d="-1" aria-label="Move video ${i + 1} up"${i ? '' : ' disabled'}>↑</button><button class="ph-btn" data-action="film-move" data-i="${i}" data-d="1" aria-label="Move video ${i + 1} down"${i < list.length - 1 ? '' : ' disabled'}>↓</button><button class="link danger" data-action="remove-film" data-i="${i}">Remove</button></div>`}</div>`;
    }).join('') : '<p class="muted small">No videos yet. The video section stays hidden on the site until you add one.</p>';
  }
  // A still from the uploaded video (about 1 second in), used as its poster so the page loads no video until play.
  function videoPoster(file){
    return new Promise(res => {
      const v = document.createElement('video'), src = URL.createObjectURL(file);
      const done = r => { clearTimeout(to); URL.revokeObjectURL(src); res(r); };
      const to = setTimeout(() => done(null), 10000);
      v.muted = true; v.playsInline = true; v.preload = 'auto'; v.src = src;
      v.onerror = () => done(null);
      v.onloadedmetadata = () => { v.currentTime = Math.min(1, (v.duration || 2) / 3); };
      v.onseeked = () => {
        try{
          const k = Math.min(1, 1280 / Math.max(v.videoWidth, v.videoHeight || 1)), c = document.createElement('canvas');
          c.width = Math.round(v.videoWidth * k); c.height = Math.round(v.videoHeight * k);
          if(!c.width || !c.height) return done(null);
          c.getContext('2d').drawImage(v, 0, 0, c.width, c.height);
          c.toBlob(b => done(b ? {blob: b, w: v.videoWidth, h: v.videoHeight} : null), 'image/webp', 0.8);
        }catch(e){ done(null); }
      };
    });
  }
  async function uploadFilm(files){
    files = [].concat(files).filter(f => /^video\//.test(f.type));
    if(!files.length){ toast('Drop a video file here'); return; }
    const big = files.filter(f => f.size > MAX_VIDEO_MB * 1024 * 1024);
    if(big.length){ toast((big.length === 1 ? 'That video is' : big.length + ' videos are') + ' over ' + MAX_VIDEO_MB + ' MB. Put long videos on YouTube (unlisted is fine) or Google Drive and paste the link instead.'); files = files.filter(f => !big.includes(f)); if(!files.length) return; }
    if(busy) return; busy = true;
    const slug = caseSlug;
    try{
      for(const [n, file] of files.entries()){
        const entry = content.case_studies[slug], list = caseVideos(entry);
        if(list.length >= MAX_VIDEOS){ toast('This work already has ' + MAX_VIDEOS + ' videos.'); break; }
        toast('Uploading video' + (files.length > 1 ? ' ' + (n + 1) + ' of ' + files.length : '') + '… keep this page open');
        const ext = (file.name.split('.').pop() || 'mp4').toLowerCase(), key = Date.now().toString(36);
        const still = await videoPoster(file);
        const url = await api.upload(file, `case-studies/${slug}/film-${key}.${ext}`);
        const item = {type: 'file', url, title: ''};
        if(still){ item.w = still.w; item.h = still.h; try{ item.poster = await api.upload(new File([still.blob], 'poster.webp', {type: 'image/webp'}), `case-studies/${slug}/film-${key}-poster.webp`); }catch(e){} }
        setVideos(entry, list.concat(item));
        if(caseSlug === slug) renderVideos(false, entry);
        await saveCases(files.length > 1 ? 'Video ' + (n + 1) + ' saved. Live on the site.' : 'Video saved. Live on the site.');
      }
    }catch(e){ fail(e); }
    busy = false;
  }

  // ------------------------------------------------------------------ helpers
  function toast(msg, undo){
    const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(t._h);
    if(typeof undo === 'function'){ const b = document.createElement('button'); b.type = 'button'; b.className = 'toast-undo'; b.textContent = 'Undo'; b.onclick = () => { undo(); t.classList.remove('show'); }; t.append(' ', b); }
    t._h = setTimeout(()=>t.classList.remove('show'), typeof undo === 'function' ? 6000 : 2600);
  }
  function fail(e){ console.error(e); if(e && /row-level security|violates row level|Unauthorized|not authorized/i.test(e.message || '')){ toast('Not saved: your account is missing a permission in Supabase. Run admin/dashboard-fix.sql once in Supabase (SQL Editor), then try again.'); return; } if(e && (e.code === '23514' || /site_content_key_check/.test(e.message || ''))){ toast('Not saved: the database needs a one-time update. Run admin/dashboard-fix.sql in Supabase (SQL Editor), then publish again.'); return; } toast('Something went wrong: ' + (e && e.message ? e.message : 'please try again')); }
  function show(id){ ['view-login','view-noaccess','view-app','view-code','view-password','view-app-setup'].forEach(v => { const el = $('#'+v); if(el) el.hidden = v !== id; }); }
  function when(iso){
    const d = new Date(iso), diff = (Date.now() - d) / 1000;
    if(diff < 3600) return Math.max(1, Math.round(diff/60)) + ' min ago';
    if(diff < 86400) return Math.round(diff/3600) + ' h ago';
    if(diff < 7*86400) return Math.round(diff/86400) + ' d ago';
    return d.toLocaleDateString('en-GB', {day:'numeric', month:'short'});
  }
  function waNumber(contact){
    if(!contact || contact.includes('@')) return null;
    let d = contact.replace(/\D/g,'');
    if(d.startsWith('0')) d = '250' + d.slice(1);
    else if(d.length === 9 && d.startsWith('7')) d = '250' + d;
    return d.length >= 10 ? d : null;
  }
  const memberName = uid => (team.find(m => m.user_id === uid) || {}).name || '';
  const initials = n => (n || '?').split(/\s+/).map(w => w.replace(/[^\p{L}]/gu,'')).filter(Boolean).slice(0,2).map(w => w[0].toUpperCase()).join('') || '?';
  const isAdmin = () => me && (me.role === 'admin' || me.role === 'owner');
  const isOwner = () => me && me.role === 'owner';
  const roleName = r => r === 'owner' ? 'Main admin' : r === 'admin' ? 'Admin' : 'Staff';

  // ------------------------------------------------------------------ leads
  // ---- helpers for Leads v2
  const today = () => new Date().toISOString().slice(0, 10);
  const ageMin = l => (Date.now() - new Date(l.created_at)) / 6e4;
  const dur = m => m < 60 ? Math.max(1, Math.round(m)) + ' min' : m < 1440 ? Math.round(m / 60) + ' h' : Math.round(m / 1440) + ' d';
  const isOpen = l => ['new', 'replied', 'quoted'].includes(l.status);
  const due = l => isOpen(l) && l.follow_up && l.follow_up <= today();
  const fuText = d => { if(!d) return ''; const t = today(); if(d === t) return 'Today'; const n = Math.round((new Date(d) - new Date(t)) / 864e5); return n < 0 ? (n === -1 ? 'Yesterday' : -n + ' d overdue') : n === 1 ? 'Tomorrow' : new Date(d).toLocaleDateString('en-GB', {day: 'numeric', month: 'short'}); };
  const act = l => Array.isArray(l.activity) ? l.activity : [];
  function log(l, k, v){ return act(l).concat([{t: new Date().toISOString(), k, v, by: (me && me.name) || ''}]).slice(-80); }
  // change a lead now (status, follow-up, reply) and remember it in its history
  async function patchLead(l, patch, msg, undo){
    const before = {}; Object.keys(patch).forEach(k => before[k] = l[k] === undefined ? null : l[k]);
    try{ await api.updateLead(l.id, patch); Object.assign(l, patch, {updated_at: new Date().toISOString()}); renderLeads(); if(openId === l.id) openDrawer(l.id, true);
      if(msg) toast(msg, undo ? async () => { await api.updateLead(l.id, before); Object.assign(l, before); renderLeads(); if(openId === l.id) openDrawer(l.id, true); } : null); }
    catch(e){ fail(e); }
  }
  function setStatus(l, st){
    if(!l || l.status === st) return;
    const patch = {status: st, activity: log(l, 'status', STATUS_LABEL[l.status] + ' → ' + STATUS_LABEL[st])};
    if(st !== 'new' && !l.replied_at) patch.replied_at = new Date().toISOString();
    if(['booked', 'lost'].includes(st)) patch.follow_up = null;
    patchLead(l, patch, l.name + ': ' + STATUS_LABEL[st], true);
  }
  function setFollow(l, d){ patchLead(l, {follow_up: d || null, activity: log(l, 'follow', d ? 'Follow-up: ' + fuText(d) : 'Follow-up cleared')}, d ? 'Follow-up set: ' + fuText(d) : 'Follow-up cleared'); }
  // the reply was sent: a new lead becomes "Replied" and the reply time is kept
  function replied(l, how){
    if(!l) return;
    const patch = {activity: log(l, 'reply', 'Replied by ' + how)};
    if(l.status === 'new'){ patch.status = 'replied'; if(!l.replied_at) patch.replied_at = new Date().toISOString(); if(!l.follow_up) patch.follow_up = dayIso(2); }
    patchLead(l, patch, l.status === 'new' ? 'Marked as replied · follow-up in 2 days' : null, l.status === 'new');
  }
  const waLink = (l, text) => { const wa = waNumber(l.contact); return wa ? 'https://wa.me/' + wa + '?text=' + encodeURIComponent(text) : ''; };
  const TEMPLATES = l => {
    const first = (l.name || '').split(' ')[0] || 'there', about = l.offer ? `our “${l.offer}” offer` : (l.service ? l.service.toLowerCase() : 'your project');
    return [
      ['Thank you', `Hi ${first}, thank you for contacting CRT Media Agency about ${about}. `],
      ['Ask for details', `Hi ${first}, thank you for your enquiry about ${about}. To prepare your price, could you share the date, the place and roughly how many people or products? `],
      ['Follow up on the quote', `Hi ${first}, just checking in on the quote we sent for ${about}. Happy to answer any questions or adjust it. `],
      ['Confirm the booking', `Hi ${first}, great news: your booking for ${about} is confirmed. We'll send the details and payment steps shortly. `]];
  };
  function rowsFor(){
    const q = query.trim().toLowerCase(), since = LF.period ? Date.now() - Number(LF.period) * 864e5 : 0;
    let r = leads.filter(l =>
      (filter === 'all' || (filter === 'due' ? due(l) : l.status === filter)) &&
      (!LF.service || (l.service || '') === LF.service) && (!LF.source || (l.source || '') === LF.source) &&
      (!since || new Date(l.created_at) >= since) &&
      (!LF.who || (LF.who === 'me' ? me && l.assigned_to === me.user_id : !l.assigned_to)) &&
      (!q || [l.name, l.contact, l.service, l.offer, l.source, l.details, l.notes].join(' ').toLowerCase().includes(q)));
    const by = {new: (a, b) => new Date(b.created_at) - new Date(a.created_at), old: (a, b) => new Date(a.created_at) - new Date(b.created_at),
      value: (a, b) => (Number(b.value_rwf) || 0) - (Number(a.value_rwf) || 0), follow: (a, b) => (a.follow_up || '9999') < (b.follow_up || '9999') ? -1 : (a.follow_up || '9999') > (b.follow_up || '9999') ? 1 : 0};
    return r.sort(by[LF.sort] || by.new);
  }
  const opts = (sel, list, all) => { const e = $(sel); if(!e) return; const cur = e.value; e.innerHTML = `<option value="">${all}</option>` + list.map(x => `<option${x === cur ? ' selected' : ''}>${esc(x)}</option>`).join(''); };

  function renderLeads(){
    const counts = Object.fromEntries(STATUSES.map(([k]) => [k, 0]));
    leads.forEach(l => counts[l.status] = (counts[l.status]||0) + 1);
    const month = new Date(); month.setDate(1); month.setHours(0,0,0,0);
    const waiting = leads.filter(l => l.status === 'new').sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
    const late = waiting.filter(l => ageMin(l) > 120).length, dues = leads.filter(due), overdue = dues.filter(l => l.follow_up < today()).length;
    const quoted = leads.filter(l => l.status === 'quoted'), qVal = quoted.reduce((s, l) => s + (Number(l.value_rwf) || 0), 0);
    const bookedMonth = leads.filter(l => l.status === 'booked' && new Date(l.updated_at || l.created_at) >= month), bVal = bookedMonth.reduce((s, l) => s + (Number(l.value_rwf) || 0), 0);
    const closed = counts.booked + counts.lost, win = closed ? Math.round(counts.booked / closed * 100) + '%' : '—';
    // first-reply time over the last 30 days, against the 2-hour promise
    const rt = leads.filter(l => l.replied_at && new Date(l.created_at) > Date.now() - 30 * 864e5).map(l => (new Date(l.replied_at) - new Date(l.created_at)) / 6e4).filter(m => m >= 0).sort((a, b) => a - b);
    const med = rt.length ? rt[Math.floor(rt.length / 2)] : null, inTime = rt.length ? Math.round(rt.filter(m => m <= 120).length / rt.length * 100) : null;
    const card = (f, tone, label, big, small) => `<button type="button" class="lf-card${tone ? ' is-' + tone : ''}${filter === f ? ' is-on' : ''}"${f ? ` data-filter="${f}"` : ' data-action="lf-none"'}><span>${esc(label)}</span><strong>${esc(big)}</strong><small>${esc(small)}</small></button>`;
    $('#lead-focus').innerHTML =
      card('new', late ? 'bad' : waiting.length ? 'warn' : 'ok', 'Reply now', waiting.length, !waiting.length ? 'All caught up' : late ? late + ' past the 2-hour promise' : 'Oldest waiting ' + dur(ageMin(waiting[0]))) +
      card('due', overdue ? 'bad' : dues.length ? 'warn' : 'ok', 'Follow-ups due', dues.length, !dues.length ? 'Nothing due today' : overdue ? overdue + ' overdue' : 'Due today') +
      card('quoted', '', 'Quoted, waiting', quoted.length, qVal ? fmt(qVal) + ' RWF on the table' : 'No open quotes') +
      card('booked', '', 'Booked this month', bookedMonth.length, (bVal ? fmt(bVal) + ' RWF · ' : '') + 'win rate ' + win) +
      card('', med == null ? '' : med <= 120 ? 'ok' : 'bad', 'First reply', med == null ? '—' : dur(med), med == null ? 'Shows after your next replies' : inTime + '% within 2 hours (30 days)');

    const top = key => { const m = {}; leads.forEach(l => { const k = (l[key] || 'unknown').toString(); m[k] = (m[k]||0) + 1; });
      const rows = Object.entries(m).sort((a,b) => b[1]-a[1]).slice(0,6), max = rows.length ? rows[0][1] : 1;
      return rows.length ? rows.map(([k,v]) => `<div class="bar"><span class="bar-label"><i style="width:${Math.round(v/max*100)}%"></i><b>${esc(k)}</b></span><span class="bar-count">${v}</span></div>`).join('') : '<p class="muted small">No data yet.</p>'; };
    $('#by-source').innerHTML = top('source'); $('#by-service').innerHTML = top('service');

    $('#status-pills').innerHTML = [['all','All', leads.length], ...STATUSES.map(([k,l]) => [k,l,counts[k]]), ['due', 'Follow-up due', dues.length]]
      .map(([k,l,n]) => `<button class="pill${filter===k?' is-active':''}${k === 'due' ? ' pill-due' : ''}" data-filter="${k}" role="tab" aria-selected="${filter===k}">${l}<em>${n}</em></button>`).join('');
    opts('#lt-service', [...new Set(leads.map(l => l.service).filter(Boolean))].sort(), 'Any service');
    opts('#lt-source', [...new Set(leads.map(l => l.source).filter(Boolean))].sort(), 'Any source');
    $('#lt-clear').hidden = !(LF.service || LF.source || LF.period || LF.who || query || filter !== 'all');

    const rows = shown = rowsFor();
    [...picked].forEach(id => { if(!leads.some(l => l.id === id)) picked.delete(id); });
    const stSel = l => `<select class="lt-st s-${esc(l.status)}" data-st="${l.id}" aria-label="Status of ${esc(l.name)}">${STATUSES.map(([k, lab]) => `<option value="${k}"${l.status === k ? ' selected' : ''}>${lab}</option>`).join('')}</select>`;
    const quick = l => { const wa = waLink(l, TEMPLATES(l)[0][1]), mail = (l.contact || '').includes('@');
      return (wa ? `<a class="lt-ic" href="${esc(wa)}" target="_blank" rel="noopener" data-reply="${l.id}" data-how="WhatsApp" title="Reply on WhatsApp" aria-label="Reply to ${esc(l.name)} on WhatsApp">${IC.wa}</a><a class="lt-ic" href="tel:+${waNumber(l.contact)}" data-reply="${l.id}" data-how="phone" title="Call" aria-label="Call ${esc(l.name)}">${IC.call}</a>` : '')
        + (mail ? `<button type="button" class="lt-ic" data-mailto="${l.id}" title="Reply by email" aria-label="Email ${esc(l.name)}">${IC.mail}</button>` : ''); };
    const sla = l => { if(l.status !== 'new') return ''; const m = ageMin(l); return `<span class="sla ${m > 120 ? 'is-late' : m > 60 ? 'is-warn' : ''}" title="Waiting for a reply">${m > 120 ? 'Late · ' : ''}${dur(m)}</span>`; };
    $('#leads-table tbody').innerHTML = rows.map((l, i) => `
      <tr data-id="${l.id}" class="${l.status==='new'?'is-new-row':''}${picked.has(l.id) ? ' is-picked' : ''}${i === cursor ? ' is-cursor' : ''}">
        <td class="lt-c"><input type="checkbox" data-pick="${l.id}"${picked.has(l.id) ? ' checked' : ''} aria-label="Select ${esc(l.name)}"></td>
        <td data-label="Received">${esc(when(l.created_at))}${sla(l)}</td>
        <td><div class="lead-name">${esc(l.name)}</div><div class="lead-sub">${esc(l.contact)}</div></td>
        <td data-label="Service">${esc(l.offer || l.service || '—')}${l.offer && l.service ? `<div class="lead-sub">${esc(l.service)}</div>` : ''}</td>
        <td data-label="Date wanted">${esc(l.event_date || '—')}</td>
        <td data-label="Follow-up">${l.follow_up && isOpen(l) ? `<span class="fu${l.follow_up < today() ? ' is-late' : l.follow_up === today() ? ' is-today' : ''}">${esc(fuText(l.follow_up))}</span>` : '<span class="muted">—</span>'}</td>
        <td class="num${l.value_rwf ? '' : ' is-empty'}" data-label="Value">${fmt(l.value_rwf)}</td>
        <td class="lt-stc">${stSel(l)}</td>
        <td class="lt-q">${quick(l)}</td>
      </tr>`).join('');
    $('#leads-empty').hidden = rows.length > 0;
    const allBox = $('#lt-all'); if(allBox){ allBox.checked = rows.length > 0 && rows.every(l => picked.has(l.id)); allBox.indeterminate = !allBox.checked && rows.some(l => picked.has(l.id)); }
    const bulk = $('#lt-bulk'); if(bulk){ bulk.hidden = !picked.size; $('#lt-bulk-n').textContent = picked.size + ' selected';
      $('#lt-bulk-status').innerHTML = '<option value="">Set status…</option>' + STATUSES.map(([k, lab]) => `<option value="${k}">${lab}</option>`).join('');
      $('#lt-bulk-who').innerHTML = '<option value="">Assign to…</option><option value="none">Nobody</option>' + team.map(m => `<option value="${esc(m.user_id)}">${esc(m.name || 'Team member')}</option>`).join(''); }
    $('#leads-sub').textContent = `${rows.length === leads.length ? leads.length : rows.length + ' of ' + leads.length} enquiries${LIVE ? '' : ' (demo)'}.`;
    const lc = $('#leads-count'); if(lc){ lc.textContent = counts.new || ''; lc.hidden = !counts.new; }
    const board = $('#leads-board');
    if(board){
      board.innerHTML = STATUSES.map(([k,lab]) => {
        const col = rows.filter(l => l.status === k), total = col.reduce((s,l) => s + (Number(l.value_rwf)||0), 0);
        return `<section class="col s-${k}" data-col="${k}"><header><span class="dot"></span><b>${esc(lab)}</b><em>${col.length}</em>${total ? `<small>${fmt(total)} RWF</small>` : ''}</header>
          <div class="col-body" data-drop="${k}">${col.map(l => `<article class="card" draggable="true" data-lead="${l.id}" tabindex="0">
            <div class="card-top"><b>${esc(l.name)}</b><time>${esc(when(l.created_at))}</time></div>
            <p>${esc(l.offer || l.service || '—')}</p>
            <div class="card-meta">${sla(l)}${l.follow_up && isOpen(l) ? `<span class="fu${l.follow_up < today() ? ' is-late' : l.follow_up === today() ? ' is-today' : ''}">${esc(fuText(l.follow_up))}</span>` : ''}${l.event_date ? `<span>${esc(l.event_date)}</span>` : ''}${l.value_rwf ? `<span>${fmt(l.value_rwf)} RWF</span>` : ''}${l.assigned_to ? `<span class="who" title="${esc(memberName(l.assigned_to))}">${esc(initials(memberName(l.assigned_to)))}</span>` : ''}</div>
          </article>`).join('') || '<p class="col-empty">Drop leads here</p>'}</div></section>`;
      }).join('');
      board.hidden = view !== 'board';
    }
    if($('#table-wrap')) $('#table-wrap').hidden = view === 'board';
    if(view === 'board') $('#leads-empty').hidden = true;
    $$('[data-action="view-table"],[data-action="view-board"]').forEach(b => { const on = b.dataset.action === 'view-' + view; b.classList.toggle('is-active', on); b.setAttribute('aria-pressed', on); });
  }
  const IC = {
    wa: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 19.5l1.2-3.6A8 8 0 1 1 8.3 18.4z"/></svg>',
    call: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4h3.5l1.5 4-2 1.5a11 11 0 0 0 6.5 6.5l1.5-2 4 1.5V19a1.5 1.5 0 0 1-1.6 1.5C10.6 20 4 13.4 3.5 5.6A1.5 1.5 0 0 1 5 4z"/></svg>',
    mail: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5.5" width="18" height="13" rx="2"/><path d="M3.5 7l8.5 6.5L20.5 7"/></svg>'};
  // email from hello@crt.rw through the Mail tab (a plain mail app link in the demo)
  function emailLead(l){
    if(!l) return; const t = TEMPLATES(l)[0][1], subj = 'Your enquiry with CRT Media Agency';
    if(LIVE && window.CRT_MAIL && window.CRT_MAIL.write){ closeDrawer(); window.CRT_MAIL.write({to: l.contact, subject: subj, text: t}); }
    else { location.href = 'mailto:' + encodeURIComponent(l.contact) + '?subject=' + encodeURIComponent(subj) + '&body=' + encodeURIComponent(t); }
    replied(l, 'email');
  }

  function openDrawer(id, keep){
    const l = leads.find(x => x.id === id); if(!l) return;
    openId = id;
    const ci = shown.findIndex(x => x.id === id); if(ci > -1) cursor = ci;
    $('#d-new').hidden = true; $('#d-facts').hidden = false; $('#d-quick').hidden = false;
    $('#d-nav').hidden = false; $('[data-action="d-prev"]').disabled = ci <= 0; $('[data-action="d-next"]').disabled = ci < 0 || ci >= shown.length - 1;
    $('#d-name').textContent = l.name;
    $('#d-stat').hidden = false;
    $('#d-stat').innerHTML = STATUSES.map(([k, lab]) => `<button type="button" role="radio" aria-checked="${l.status === k}" class="s-${k}${l.status === k ? ' is-on' : ''}" data-dstat="${k}">${lab}</button>`).join('');
    const wa = waNumber(l.contact), mail = (l.contact || '').includes('@');
    $('#d-quick').innerHTML =
      (wa ? `<div class="d-wa"><a class="btn small" href="${esc(waLink(l, TEMPLATES(l)[0][1]))}" target="_blank" rel="noopener" data-reply="${l.id}" data-how="WhatsApp">Reply on WhatsApp</a><select class="d-tpl" data-tpl="${l.id}" aria-label="WhatsApp message"><option value="">Other message…</option>${TEMPLATES(l).map((t, i) => `<option value="${i}">${esc(t[0])}</option>`).join('')}</select></div><a class="btn secondary small" href="tel:+${wa}" data-reply="${l.id}" data-how="phone">Call</a>` : '') +
      (mail ? `<button type="button" class="btn${wa ? ' secondary' : ''} small" data-mailto="${l.id}">Email from hello@crt.rw</button>` : '') +
      (!wa && !mail ? '<p class="muted small">No phone number or email to reply to.</p>' : '');
    const fd = l.follow_up || '', open = isOpen(l);
    $('#d-follow').hidden = !open;
    $('#d-follow').innerHTML = `<span class="d-lab">Follow up</span>${[['Today', 0], ['Tomorrow', 1], ['In 3 days', 3], ['Next week', 7]].map(([t, n]) => `<button type="button" class="chip${fd === dayIso(n) ? ' is-on' : ''}" data-fu="${dayIso(n)}">${t}</button>`).join('')}<input type="date" data-fu-date value="${esc(fd)}" aria-label="Follow-up date">${fd ? `<button type="button" class="link small" data-fu="">Clear</button>` : ''}${fd ? `<span class="fu${fd < today() ? ' is-late' : fd === today() ? ' is-today' : ''}">${esc(fuText(fd))}</span>` : ''}`;
    const facts = [['Contact', l.contact], ['Service', l.service], ['Offer / package', l.offer], ['Date wanted', l.event_date],
      ['Message', l.details], ['Source', l.source], ['Page', l.page], ['Received', new Date(l.created_at).toLocaleString('en-GB')]];
    $('#d-facts').innerHTML = facts.filter(f => f[1]).map(([k,v]) => `<dt>${esc(k)}</dt><dd${k === 'Message' ? ' class="d-msg"' : ''}>${k === 'Message' ? fmtMessage(v) : esc(v)}</dd>`).join('');
    $('#d-status').innerHTML = STATUSES.map(([k,lab]) => `<option value="${k}"${l.status===k?' selected':''}>${lab}</option>`).join('');
    $('#d-status').closest('.field').hidden = true;   // the status buttons at the top replace this list
    if(!keep || document.activeElement !== $('#d-value')) $('#d-value').value = l.value_rwf ?? '';
    $('#d-assigned').innerHTML = '<option value="">Nobody yet</option>' + team.map(m => `<option value="${esc(m.user_id)}"${l.assigned_to===m.user_id?' selected':''}>${esc(m.name || 'Team member')}</option>`).join('');
    if(!keep) $('#d-notes').value = l.notes || '';
    const hist = act(l).slice().reverse().map(a => `<li><span class="h-${esc(a.k)}"></span><div><b>${esc(a.v)}</b><small>${esc(new Date(a.t).toLocaleString('en-GB', {day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit'}))}${a.by ? ' · ' + esc(a.by) : ''}</small></div></li>`).join('');
    $('#d-history').innerHTML = `<h3>History</h3><ol>${hist}<li><span class="h-in"></span><div><b>Enquiry received${l.source ? ' · ' + esc(l.source) : ''}</b><small>${esc(new Date(l.created_at).toLocaleString('en-GB', {day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit'}))}</small></div></li></ol>`;
    $('#d-delete').hidden = !isAdmin();
    if(!keep){ $('#drawer').classList.add('is-open'); $('#drawer').setAttribute('aria-hidden','false'); $('#drawer-scrim').hidden = false; $('#drawer .drawer-body').scrollTop = 0; renderLeads(); setTimeout(() => { const b = $('#d-quick .btn'); (b || $('#d-notes')).focus(); }, 60); }
  }
  // A lead that came in outside the website form (WhatsApp, phone, walk-in).
  function openNewLead(){
    openId = 'new';
    $('#d-name').textContent = 'Add a lead';
    $('#d-new').hidden = false; $('#d-facts').hidden = true; $('#d-quick').hidden = true; $('#d-delete').hidden = true;
    $('#d-stat').hidden = true; $('#d-follow').hidden = true; $('#d-nav').hidden = true; $('#d-history').innerHTML = ''; $('#d-status').closest('.field').hidden = false;
    ['n-name','n-contact','n-offer','n-date','n-details','d-value','d-notes'].forEach(id => $('#'+id).value = '');
    $('#n-service').innerHTML = SERVICES.map(s => `<option>${esc(s)}</option>`).join('');
    $('#n-source').innerHTML = SOURCES.map(s => `<option>${esc(s)}</option>`).join('');
    $('#d-status').innerHTML = STATUSES.map(([k,lab]) => `<option value="${k}"${k==='new'?' selected':''}>${lab}</option>`).join('');
    $('#d-assigned').innerHTML = '<option value="">Nobody yet</option>' + team.map(m => `<option value="${esc(m.user_id)}"${me && m.user_id===me.user_id?' selected':''}>${esc(m.name || 'Team member')}</option>`).join('');
    $('#drawer').classList.add('is-open'); $('#drawer').setAttribute('aria-hidden','false'); $('#drawer-scrim').hidden = false;
    setTimeout(() => $('#n-name').focus(), 50);
  }
  async function addLead(){
    const name = $('#n-name').value.trim(), contact = $('#n-contact').value.trim();
    if(!name || !contact){ toast('Add a name and a way to contact them'); (name ? $('#n-contact') : $('#n-name')).focus(); return; }
    const v = $('#d-value').value.trim();
    const row = {
      name: name.slice(0,120), contact: contact.slice(0,160), service: $('#n-service').value,
      offer: $('#n-offer').value.trim().slice(0,120) || null, event_date: $('#n-date').value.trim().slice(0,120) || null,
      details: $('#n-details').value.trim().slice(0,2000) || null, source: $('#n-source').value, page: 'Added by hand',
      status: $('#d-status').value, value_rwf: v === '' ? null : Math.max(0, Math.round(Number(v))),
      assigned_to: $('#d-assigned').value || null, notes: $('#d-notes').value.slice(0,5000) || null
    };
    try{ const saved = await api.addLead(row); leads.unshift(saved); filter = 'all'; renderLeads(); closeDrawer(); toast('Lead added'); }catch(e){ fail(e); }
  }

  async function onLeadsChange(e){
    const t = e.target, id = Number(t.dataset.st || t.dataset.pick || 0), l = id && leads.find(x => x.id === id);
    if(t.dataset.st && l){ setStatus(l, t.value); return; }
    if(t.dataset.pick){ t.checked ? picked.add(id) : picked.delete(id); renderLeads(); return; }
    if(t.id === 'lt-all'){ shown.forEach(x => t.checked ? picked.add(x.id) : picked.delete(x.id)); renderLeads(); return; }
    const f = {'lt-service': 'service', 'lt-source': 'source', 'lt-period': 'period', 'lt-who': 'who', 'lt-sort': 'sort'}[t.id];
    if(f){ LF[f] = t.value; cursor = -1; renderLeads(); return; }
    if(t.dataset.tpl && t.value !== ''){ const lead = leads.find(x => x.id === Number(t.dataset.tpl)); const tx = TEMPLATES(lead)[Number(t.value)][1]; window.open(waLink(lead, tx), '_blank', 'noopener'); t.value = ''; setTimeout(() => replied(lead, 'WhatsApp'), 300); return; }
    if(t.matches('[data-fu-date]')){ setFollow(leads.find(x => x.id === openId), t.value); return; }
    if(t.id === 'lt-bulk-status' && t.value){ const st = t.value, list = leads.filter(x => picked.has(x.id));
      try{ for(const x of list){ const p = {status: st, activity: log(x, 'status', STATUS_LABEL[x.status] + ' → ' + STATUS_LABEL[st])}; if(st !== 'new' && !x.replied_at) p.replied_at = new Date().toISOString(); await api.updateLead(x.id, p); Object.assign(x, p); } toast(list.length + ' leads: ' + STATUS_LABEL[st]); picked.clear(); renderLeads(); }catch(err){ fail(err); } return; }
    if(t.id === 'lt-bulk-who' && t.value){ const who = t.value === 'none' ? null : t.value, list = leads.filter(x => picked.has(x.id));
      try{ for(const x of list){ const p = {assigned_to: who, activity: log(x, 'edit', 'Handled by ' + (memberName(who) || 'nobody'))}; await api.updateLead(x.id, p); Object.assign(x, p); } toast(list.length + ' leads assigned'); picked.clear(); renderLeads(); }catch(err){ fail(err); } return; }
  }
  function closeDrawer(){ openId = null; $('#drawer').classList.remove('is-open'); $('#drawer').setAttribute('aria-hidden','true'); $('#drawer-scrim').hidden = true; }

  async function saveLead(){
    if(openId === 'new') return addLead();
    const l = leads.find(x => x.id === openId); if(!l) return;
    const v = $('#d-value').value.trim();
    const patch = { value_rwf: v === '' ? null : Math.max(0, Math.round(Number(v))), assigned_to: $('#d-assigned').value || null, notes: $('#d-notes').value.slice(0,5000) };
    const changed = [];
    if((patch.value_rwf ?? null) !== (l.value_rwf ?? null)) changed.push('Value ' + (patch.value_rwf == null ? 'cleared' : fmt(patch.value_rwf) + ' RWF'));
    if((patch.assigned_to || null) !== (l.assigned_to || null)) changed.push('Handled by ' + (memberName(patch.assigned_to) || 'nobody'));
    if((patch.notes || '') !== (l.notes || '')) changed.push('Notes updated');
    if(changed.length) patch.activity = log(l, 'edit', changed.join(' · '));
    try{ await api.updateLead(l.id, patch); Object.assign(l, patch, {updated_at: new Date().toISOString()}); renderLeads(); closeDrawer(); toast('Lead saved'); }catch(e){ fail(e); }
  }

  function exportCsv(){
    const cols = ['created_at','name','contact','service','offer','event_date','details','source','page','status','value_rwf','notes'];
    const cell = v => '"' + String(v == null ? '' : v).replace(/"/g,'""') + '"';
    const header = [...cols, 'handled_by'];
    const list = picked.size ? leads.filter(l => picked.has(l.id)) : leads;
    const csv = [header.join(','), ...list.map(l => [...cols.map(c => cell(l[c])), cell(memberName(l.assigned_to))].join(','))].join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob(['﻿' + csv], {type:'text/csv'}));
    a.download = 'crt-leads-' + new Date().toISOString().slice(0,10) + '.csv';
    document.body.appendChild(a); a.click(); a.remove();
  }

  // ------------------------------------------------------------------ content
  function renderContent(){
    const p = content.prices || {}, pk = content.packages || {}, ro = !isAdmin();
    $('#content-readonly').hidden = !ro;
    $('#prices-form').innerHTML = PRICE_FIELDS.map(([k,label,where]) => `
      <div class="price-item"><label for="p-${k}">${esc(label)}</label>
      <input id="p-${k}" name="${k}" type="number" min="0" step="1000" value="${esc(p[k] ?? '')}" ${ro?'disabled':''}>
      <small>${p[k] ? fmt(p[k]) + ' RWF · ' : ''}${esc(where)}</small></div>`).join('');
    $$('[data-action="save-prices"]').forEach(b => b.hidden = ro);
    renderTestimonials();
  }

  // Testimonials: real client words, shown on the home page when at least one exists.
  const MAX_TESTIMONIALS = 6;
  function parseReview(l){
    const d = String(l.details || ''), i = d.indexOf('\n\n'), head = i > -1 ? d.slice(0, i) : '', body = i > -1 ? d.slice(i + 2) : d;
    const get = k => ((head.match(new RegExp('^' + k + ': (.*)$', 'm')) || [])[1] || '').trim();
    const publish = get('Publish') || l.offer || '';
    return {id: l.id, at: l.created_at, name: l.name || '', role: get('Role').replace(/^—$/, ''), project: get('Project'), publish, text: body.trim(), ok: !/^No\b/i.test(publish), first: /first name/i.test(publish)};
  }
  function renderReviewInbox(){
    const list = $('#testimonials-list'); if(!list) return;
    let box = $('#review-inbox');
    if(!box){ list.insertAdjacentHTML('beforebegin', '<div id="review-inbox" class="rv-inbox"></div>'); box = $('#review-inbox'); }
    const subs = REVIEWS.list.map(parseReview), ro = !isAdmin();
    box.hidden = !subs.length;
    box.innerHTML = subs.length ? `<h3>Sent by clients <em>${subs.length}</em></h3><p class="muted small">From crt.rw/review/. Add one to the website in one click, or dismiss it. Nothing shows until you add it.</p>`
      + subs.map(r => `<div class="rv-sub" data-sub="${r.id}"><div class="rv-sub-h"><b>${esc(r.name)}</b>${r.role ? `<span class="muted small">${esc(r.role)}</span>` : ''}<span class="muted small">${esc(r.project)}</span><span class="muted small">${new Date(r.at).toLocaleDateString('en-GB', {day: 'numeric', month: 'short'})}</span></div>
        <blockquote>${esc(r.text)}</blockquote>
        <p class="small ${r.ok ? 'muted' : 'rv-private'}">${r.ok ? 'Can be published: ' + esc(r.publish.replace(/^Yes, /, '')) : 'Private feedback: the client asked not to publish it.'}</p>
        ${ro ? '' : `<div class="row-end">${r.ok ? `<button type="button" class="btn small" data-action="review-use" data-id="${r.id}">Add to the website</button>` : ''}<button type="button" class="btn secondary small" data-action="review-drop" data-id="${r.id}">${r.ok ? 'Dismiss' : 'Done, remove'}</button></div>`}</div>`).join('') : '';
  }
  async function useReview(id, keep){
    const l = REVIEWS.list.find(x => String(x.id) === String(id)); if(!l) return;
    if(!keep){
      const r = parseReview(l), cur = readTestimonials();
      if(cur.length >= MAX_TESTIMONIALS){ toast('The website shows up to ' + MAX_TESTIMONIALS + ' reviews. Remove one first.'); return; }
      content.testimonials = [{quote: r.text.slice(0, 400), name: r.first ? r.name.split(' ')[0] : r.name, role: r.first ? '' : r.role, company: '', tag: '', link: ''}, ...cur];
      renderTestimonials();
      if(!await saveTestimonials()) return;
    } else if(!confirm('Remove this review from the list? It is not on the website.')) return;
    try{ await api.deleteLead(l.id); }catch(e){ fail(e); return; }
    REVIEWS.list = REVIEWS.list.filter(x => x !== l); renderReviewInbox();
    if(!keep) toast('Added to the website. Edit the service or the link below if you like.');
  }
  function renderTestimonials(){
    const list = Array.isArray(content.testimonials) ? content.testimonials : [], ro = !isAdmin();
    if(!$('#t-tags')) document.body.insertAdjacentHTML('beforeend', '<datalist id="t-tags"><option>Wedding photography</option><option>Wedding video</option><option>Event photography</option><option>Event branding</option><option>Product photography</option><option>Brand photography</option><option>Branding & logo</option><option>Social media content</option><option>Website</option><option>Print</option></datalist>');
    $('#testimonials-list').innerHTML = list.length ? list.map((t, i) => `
      <div class="testimonial-row" data-i="${i}">
        <div class="field"><label for="t-quote-${i}">What they said</label><textarea id="t-quote-${i}" data-t="quote" rows="3" maxlength="400" ${ro?'disabled':''}>${esc(t.quote)}</textarea></div>
        <div class="price-grid">
          <div class="field"><label for="t-name-${i}">Name</label><input id="t-name-${i}" data-t="name" maxlength="80" value="${esc(t.name)}" ${ro?'disabled':''}></div>
          <div class="field"><label for="t-role-${i}">Job title</label><input id="t-role-${i}" data-t="role" maxlength="80" value="${esc(t.company ? t.role : (t.role || '').split(', ').slice(0, -1).join(', ') || t.role)}" placeholder="e.g. Marketing manager, or Bride" ${ro?'disabled':''}></div>
          <div class="field"><label for="t-co-${i}">Company or project</label><input id="t-co-${i}" data-t="company" maxlength="80" value="${esc(t.company || ((t.role || '').includes(', ') ? (t.role || '').split(', ').pop() : ''))}" placeholder="e.g. Rwanda Mines Board, or Wedding, June 2026" ${ro?'disabled':''}></div>
        </div>
        <div class="price-grid">
          <div class="field"><label for="t-tag-${i}">Service</label><input id="t-tag-${i}" data-t="tag" maxlength="40" list="t-tags" value="${esc(t.tag || '')}" placeholder="e.g. Wedding photography" ${ro?'disabled':''}></div>
          <div class="field"><label for="t-link-${i}">Link to the work (optional)</label><select id="t-link-${i}" data-t="link" ${ro?'disabled':''}><option value="">No link</option>${CASES.filter(c => c.published).map(c => { const v = c.page ? '/' + c.slug + '/index.html' : '/case/?s=' + c.slug; return `<option value="${esc(v)}"${t.link === v ? ' selected' : ''}>${esc(c.title)}</option>`; }).join('')}</select></div>
        </div>
        ${ro ? '' : `<button class="link danger" data-action="remove-testimonial" data-i="${i}">Remove</button>`}
      </div>`).join('') : '<p class="muted small">No testimonials yet. The section stays hidden on the site until you add one.</p>';
    $$('[data-action="add-testimonial"],[data-action="save-testimonials"]').forEach(b => b.hidden = ro);
    renderReviewInbox();
  }
  function readTestimonials(){
    return $$('#testimonials-list .testimonial-row').map(row => ({
      quote: row.querySelector('[data-t="quote"]').value.trim().slice(0, 400),
      name: row.querySelector('[data-t="name"]').value.trim().slice(0, 80),
      role: row.querySelector('[data-t="role"]').value.trim().slice(0, 80),
      company: row.querySelector('[data-t="company"]').value.trim().slice(0, 80),
      tag: row.querySelector('[data-t="tag"]').value.trim().slice(0, 40),
      link: row.querySelector('[data-t="link"]').value
    }));
  }
  async function saveTestimonials(){
    const list = readTestimonials();
    if(list.some(t => !t.quote || !t.name)){ toast('Each testimonial needs the words and a name'); return false; }
    try{ await api.saveContent('testimonials', list); content.testimonials = list; renderTestimonials(); toast(list.length ? 'Testimonials saved. Live on the home page.' : 'Saved. The section is hidden.'); return true; }catch(e){ fail(e); return false; }
  }
  async function savePrices(){
    const next = {}; let bad = false;
    PRICE_FIELDS.forEach(([k]) => { const v = Number($('#p-'+k).value); if(!(v > 0)) bad = true; next[k] = Math.round(v); });
    if(bad){ toast('Every price needs a number above 0'); return; }
    try{ await api.saveContent('prices_v2', next); content.prices = next; renderContent(); toast('Prices saved. The site updates on the next page load.'); }catch(e){ fail(e); }
  }

  // ------------------------------------------------------------------ inbox
  let inbox = [], inboxLoaded = false, inboxOpen = null, inboxStart = 1;
  const INBOX_PAGE = 50;
  const mailWhen = ms => ms ? when(new Date(ms).toISOString()) : '';
  function renderInbox(){
    $('#inbox-list').innerHTML = inbox.map(m => `
      <li data-mid="${esc(m.messageId)}" class="${m.unread ? 'unread' : ''}${inboxOpen && inboxOpen.messageId === m.messageId ? ' is-open' : ''}">
        <div class="m-row"><span class="m-from">${esc(m.from || m.fromAddress)}</span><span class="m-time">${esc(mailWhen(m.received))}</span></div>
        <div class="m-subject">${esc(m.subject)}</div>
        <div class="m-summary">${esc(m.summary)}</div>
      </li>`).join('');
    $('#inbox-empty').hidden = inbox.length > 0;
    const unread = inbox.filter(m => m.unread).length;
    $('#inbox-count').hidden = !unread; $('#inbox-count').textContent = unread;
  }
  async function loadInbox(more){
    $('#inbox-setup').hidden = true;
    try{
      if(!more) inboxStart = 1;
      const res = await api.inbox({action:'list', limit:INBOX_PAGE, start:inboxStart});
      const got = res.messages || [];
      inbox = more ? inbox.concat(got) : got;
      inboxStart += got.length;
      $('#inbox-more').hidden = got.length < INBOX_PAGE;
      inboxLoaded = true; renderInbox();
      $('#inbox-sub').textContent = 'Email sent to hello@crt.rw and alain@crt.rw' + (LIVE ? '.' : ' (demo).');
    }catch(e){
      const notConnected = /not_connected/.test(e.message);
      $('#inbox-setup').hidden = false;
      $('#inbox-setup-msg').innerHTML = notConnected
        ? 'The inbox isn’t connected yet. Follow <code>admin/INBOX-SETUP.txt</code> to connect Zoho Mail (about 10 minutes, once).'
        : 'Couldn’t load email: ' + esc(e.message) + '. If this keeps happening, check the Zoho connection in <code>admin/INBOX-SETUP.txt</code>.';
      inbox = []; renderInbox();
    }
  }
  async function openMail(mid){
    const m = inbox.find(x => x.messageId === mid); if(!m) return;
    inboxOpen = m; m.unread = false; renderInbox();
    const r = $('#inbox-reader');
    r.innerHTML = `<h2>${esc(m.subject)}</h2>
      <div class="reader-meta">From <strong>${esc(m.from)}</strong> &lt;${esc(m.fromAddress)}&gt; · ${esc(m.received ? new Date(m.received).toLocaleString('en-GB') : '')}</div>
      <div class="reader-actions">
        <a class="btn small" href="mailto:${esc(m.fromAddress)}?subject=${encodeURIComponent('Re: ' + m.subject)}">Reply</a>
        <button class="btn secondary small" data-action="mail-to-lead">Save as lead</button>
        <a class="btn secondary small" href="https://mail.zoho.com/zm/#mail/folder/inbox/p/${encodeURIComponent(m.messageId)}" target="_blank" rel="noopener">Open in Zoho ↗</a>
      </div>
      <p class="muted small" id="reader-status">Loading…</p>`;
    try{
      const res = await api.inbox({action:'read', folderId:m.folderId, messageId:m.messageId});
      if(inboxOpen !== m) return;
      const frame = document.createElement('iframe');
      frame.className = 'reader-frame'; frame.title = 'Email: ' + m.subject;
      // No scripts can run inside the email; links open in a new tab.
      frame.setAttribute('sandbox', 'allow-popups allow-popups-to-escape-sandbox');
      frame.setAttribute('referrerpolicy', 'no-referrer');
      frame.srcdoc = '<!doctype html><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="script-src \'none\'"><base target="_blank"><style>body{font:15px/1.5 -apple-system,system-ui,sans-serif;margin:16px;color:#141a2e}img{max-width:100%;height:auto}</style>' + (res.html || '<p>(empty message)</p>');
      $('#reader-status').replaceWith(frame);
    }catch(e){ const s = $('#reader-status'); if(s) s.textContent = 'Couldn’t open this email: ' + e.message; }
  }
  async function mailToLead(){
    const m = inboxOpen; if(!m) return;
    const row = {
      name: (m.from || m.fromAddress || 'Email enquiry').slice(0,120), contact: (m.fromAddress || m.from || 'unknown').slice(0,160),
      service: 'Creative project', offer: null, event_date: null,
      details: (m.subject + (m.summary ? ': ' + m.summary : '')).slice(0,2000),
      source: 'Email', page: 'Email to crt.rw', status: 'new', value_rwf: null,
      assigned_to: me ? me.user_id : null, notes: null
    };
    try{ const saved = await api.addLead(row); leads.unshift(saved); renderLeads(); toast('Saved as a lead. Find it in Leads.'); }catch(e){ fail(e); }
  }

  // ------------------------------------------------------------------ team
  // The main admin adds, changes and removes people here; nobody needs to open Supabase.
  let security = null;
  const TEAM_ERR = {bad_email: 'That email doesn’t look right.', bad_name: 'Add their name.', bad_phone: 'Write the phone with the country code, like +250 788 123 456.', email_taken: 'That email already has an account.',
    owner_only: 'Only the main admin can do that.', verify_first: 'Enter your sign-in code first.', no_phone: 'Add your phone number first.', no_method: 'Set up the authenticator app (or text messages) first.', no_sms_provider: 'Text messages aren’t connected yet. Add the keys in Team → Connections.',
    test_code_first: 'Receive and enter a test code first, so we know texts reach you.', cannot_remove_self: 'You can’t remove yourself.', own_role: 'You can’t change your own role.'};
  const teamErr = e => TEAM_ERR[e && e.code] || ('Something went wrong: ' + ((e && e.message) || 'please try again'));
  function renderTeam(){
    const own = isOwner();
    $('#team-table tbody').innerHTML = team.map(m => {
      const self = m.user_id === me.user_id, edit = own && m.role !== 'owner';
      return `<tr data-uid="${esc(m.user_id)}">
        <td>${own ? `<input type="text" value="${esc(m.name)}" data-field="name" aria-label="Name">` : esc(m.name)}${self ? ' <span class="lead-sub">(you)</span>' : ''}</td>
        <td class="muted small">${esc(m.email || '')}</td>
        <td>${own ? `<input type="tel" value="${esc(m.phone || '')}" data-field="phone" placeholder="+250 7xx xxx xxx" aria-label="Phone for ${esc(m.name)}">` : esc(m.phone || '—')}</td>
        <td>${edit ? `<select data-field="role" aria-label="Role"><option value="staff"${m.role === 'staff' ? ' selected' : ''}>Staff</option><option value="admin"${m.role === 'admin' ? ' selected' : ''}>Admin</option></select>` : `<span class="role-chip is-${esc(m.role)}">${roleName(m.role)}</span>`}</td>
        <td class="num">${edit ? '<button class="link" data-action="reset-member">New password</button> <button class="link" data-action="reset-app">Reset app</button> <button class="link danger" data-action="remove-member">Remove</button>' : ''}</td>
      </tr>`; }).join('');
    $('#team-add').hidden = !own;
    $('#team-sub').textContent = own ? 'Who can use this dashboard. You are the main admin: only you add, change or remove people.' : 'Who can use this dashboard. Ask the main admin to add or change people.';
    renderSecurity();
  }
  function renderSecurity(){
    const box = $('#team-security'); if(!box) return;
    box.hidden = !isOwner(); if(box.hidden) return;
    const s = security || {}, on = !!s.require_code, ready = !!(s.app || s.email || (s.provider && s.has_phone));
    box.innerHTML = `<div class="sec-head"><div><h2>Sign-in code on your phone</h2><p class="muted small">After the password, everyone also enters a 6-digit code from their phone: from the authenticator app, or by text message. The database refuses everything until the code is entered.</p></div>
      <span class="role-chip ${on ? 'is-on' : 'is-off'}">${on ? 'On' : 'Off'}</span></div>
      <ul class="sec-ways"><li><b>Authenticator app</b> (free, works now) ${s.app ? '<span class="role-chip is-on">Set up</span>' : '<span class="role-chip is-off">Not set up</span>'}<button type="button" class="link" data-action="app-setup">${s.app ? 'Move to a new phone' : 'Set up on my phone'}</button></li>
        <li><b>Email</b> (free, backup) ${s.email ? '<span class="role-chip is-on">Ready</span>' : '<span class="role-chip is-off">Connect sending in Settings → Mail</span>'}</li>
        <li><b>Text message</b> (optional, paid) ${s.provider && s.has_phone ? '<span class="role-chip is-on">Ready</span>' : '<span class="role-chip is-off">Not used</span>'}</li></ul>
      ${!LIVE ? '<p class="muted small">Not available in demo mode.</p>' : ''}
      <div class="row-end">${on ? '<button class="btn secondary small" data-action="sec-off">Switch off</button>' : `<button class="btn small" data-action="sec-on"${LIVE && ready ? '' : ' disabled'}>Check my code and switch on</button>`}</div>`;
  }
  async function loadSecurity(){ if(!LIVE) return; try{ security = await api.teamFn({action: 'status'}); }catch(e){ security = null; } renderSecurity(); loadConnections(); }

  // ---- Connections: the keys for text messages and the mailbox, entered here instead of in Supabase.
  // Kept in a locked table only the server functions can read; this screen only learns whether each key is set.
  let conn = null;
  const CONN = [
    ['Text messages: Africa’s Talking (optional, paid per text — not needed: the authenticator app is free)', [['AT_USERNAME', 'Username'], ['AT_API_KEY', 'API key', 1], ['AT_SENDER_ID', 'Sender ID (optional, once approved, e.g. CRT)']]],
    ['Text messages: Twilio (optional, paid — not needed)', [['TWILIO_ACCOUNT_SID', 'Account SID'], ['TWILIO_AUTH_TOKEN', 'Auth token', 1], ['TWILIO_FROM', 'From number (+1…)']]],
    ['Mailbox for the old Inbox: Zoho Mail (free plan; not needed once Mail is switched over)', [['ZOHO_CLIENT_ID', 'Client ID'], ['ZOHO_CLIENT_SECRET', 'Client secret', 1], ['ZOHO_REFRESH_TOKEN', 'Refresh token', 1]]]
  ];
  async function loadConnections(){ if(!LIVE || !isOwner()) return; try{ conn = await api.teamFn({action: 'connections'}); }catch(e){ conn = null; } renderConnections(); }
  function renderConnections(){
    const box = $('#team-connections'); if(!box) return;
    box.hidden = !isOwner(); if(box.hidden) return;
    const set = (conn && conn.set) || {};
    box.innerHTML = `<h2>Connections</h2><p class="muted small">Keys from your text-message and mailbox accounts. They stay locked on the server: once saved, nobody can read them back, not even here. Leave a field empty to keep what is saved.</p>
      <form id="conn-form">${CONN.map(([title, keys]) => `<fieldset class="conn-set"><legend>${esc(title)}</legend>${keys.map(([k, label, secret]) => `<div class="field"><label for="c-${k}">${esc(label)} ${set[k] ? '<span class="role-chip is-on">Saved</span>' : ''}</label><input id="c-${k}" name="${k}" ${secret ? 'type="password"' : ''} autocomplete="off" spellcheck="false" placeholder="${set[k] ? '•••••••• (saved, type to replace)' : ''}"></div>`).join('')}</fieldset>`).join('')}
      <div class="row-end">${set.AT_API_KEY || set.TWILIO_AUTH_TOKEN ? '<button type="button" class="btn secondary small" data-action="conn-test">Send me a test text</button>' : ''}<button class="btn small" type="submit">Save connections</button></div></form>
      ${!LIVE ? '<p class="muted small">Not available in demo mode.</p>' : ''}`;
    $('#conn-form').onsubmit = async e => {
      e.preventDefault(); const values = {};
      [...e.target.querySelectorAll('input')].forEach(i => { if(i.value.trim()) values[i.name] = i.value.trim(); });
      if(!Object.keys(values).length){ toast('Nothing new to save'); return; }
      try{ conn = await api.teamFn({action: 'save_connections', values}); renderConnections(); if(security){ security.provider = conn.provider; renderSecurity(); } toast('Connections saved'); }catch(err){ toast(teamErr(err)); }
    };
  }
  function shareText(name, email, password){
    return `Hi ${name.split(' ')[0]}, your CRT dashboard account is ready.\nSign in at https://crt.rw/admin/\nEmail: ${email}\nOne-time password: ${password}\nYou'll choose your own password when you sign in.`;
  }
  function showMade(name, email, password){
    const box = $('#team-made'), msg = shareText(name, email, password);
    box.hidden = false;
    box.innerHTML = `<h3>Account ready for ${esc(name)}</h3><p class="muted small">Send this privately (WhatsApp is fine). The password works once: they choose their own when they sign in. It isn’t shown again.</p>
      <pre class="code" id="made-msg">${esc(msg)}</pre><div class="row-end"><button type="button" class="btn secondary small" data-action="copy-made">Copy message</button><a class="btn small" target="_blank" rel="noopener" href="https://wa.me/?text=${encodeURIComponent(msg)}">Send on WhatsApp ↗</a></div>`;
  }

  // ---- sign-in gate: one-time password → own password; then the code by text message
  function askPassword(){
    return new Promise(res => {
      show('view-password'); $('#pw-new').focus();
      $('#pw-form').onsubmit = async e => {
        e.preventDefault(); const a = $('#pw-new').value, b = $('#pw-again').value, msg = $('#pw-msg');
        if(a.length < 10){ msg.textContent = 'Use at least 10 characters.'; return; }
        if(a !== b){ msg.textContent = 'The two passwords don’t match.'; return; }
        msg.textContent = 'Saving…';
        const {error} = await sb.auth.updateUser({password: a});
        if(error){ msg.textContent = 'Couldn’t save: ' + error.message; return; }
        try{ await api.teamFn({action: 'password_set'}); }catch(err){}
        msg.textContent = ''; res();
      };
    });
  }
  function askCode(st){
    return new Promise(res => {
      show('view-code');
      const msg = $('#code-msg'), inp = $('#code-input'), again = $('#code-resend');
      let t = 0;
      const wait = n => { again.disabled = true; clearInterval(t); let left = n; again.textContent = `Send a new code (${left}s)`; t = setInterval(() => { left--; if(left <= 0){ clearInterval(t); again.disabled = false; again.textContent = 'Send a new code'; } else again.textContent = `Send a new code (${left}s)`; }, 1000); };
      const alt = st.sms ? 'sms' : st.email ? 'email' : '';
      const appMode = () => { $('#code-sub').textContent = 'Open your authenticator app and enter the 6-digit code for CRT Dashboard.'; msg.textContent = ''; again.disabled = !alt; again.textContent = alt === 'sms' ? 'Text me a code instead' : alt === 'email' ? 'Email me a code instead' : ''; again.hidden = !alt; inp.focus(); };
      const send = async (prefer) => {
        if(st.method === 'app' && prefer !== 'sms'){ appMode(); return; }
        msg.textContent = 'Sending your code…'; again.hidden = false;
        try{ const r = await api.teamFn({action: 'send_code', prefer: prefer || ''});
          if(r.method === 'app'){ appMode(); return; }
          if(r.method === 'email'){ $('#code-sub').textContent = 'We emailed a 6-digit code to ' + (r.phone_hint || 'you') + '. It works for 10 minutes.'; msg.textContent = ''; wait(45); inp.focus(); return; } $('#code-sub').textContent = 'We sent a 6-digit code to ' + (r.phone_hint || 'your phone') + '. It works for 10 minutes.'; msg.textContent = ''; wait(45); inp.focus(); }
        catch(e){ msg.textContent = e.code === 'wait' ? 'A code was sent a moment ago. Check your messages.' : e.code === 'no_phone' ? 'Your account has no phone number. Ask the main admin to add it.' : teamErr(e); if(e.code === 'wait') wait(45); else again.disabled = false; }
      };
      again.onclick = () => send(alt || 'sms');
      inp.oninput = () => { inp.value = inp.value.replace(/\D/g, '').slice(0, 6); if(inp.value.length === 6) $('#code-form').requestSubmit(); };
      $('#code-form').onsubmit = async e => {
        e.preventDefault(); msg.textContent = 'Checking…';
        try{ await api.teamFn({action: 'verify_code', code: inp.value}); clearInterval(t); inp.value = ''; msg.textContent = ''; res(); }
        catch(err){ inp.select(); msg.textContent = err.code === 'wrong_code' ? 'That code isn’t right.' + (err.info && err.info.left > 0 ? ' ' + err.info.left + ' tries left.' : '') : err.code === 'expired' ? 'That code has expired. Send a new one.' : err.code === 'too_many' ? 'Too many tries. Send a new code.' : teamErr(err); }
      };
      send();
    });
  }
  // Authenticator app: show a QR code, confirm one code, done. `first` = during sign-in (no other way to get a code yet).
  let qrLib = null;
  function loadQr(){ return qrLib || (qrLib = new Promise((res, rej) => { const s = document.createElement('script'); s.src = 'https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.js'; s.onload = () => res(window.qrcode); s.onerror = rej; document.head.appendChild(s); })); }
  function setupApp(first){
    return new Promise(async (res, rej) => {
      show('view-app-setup'); const msg = $('#qr-msg'), inp = $('#qr-code'); msg.textContent = 'Preparing your code…'; inp.value = '';
      $('#qr-cancel').hidden = !!first;
      $('#qr-cancel').onclick = () => rej(new Error('cancel'));
      try{
        const r = await api.teamFn({action: 'app_setup'});
        $('#qr-secret').textContent = r.secret.replace(/(.{4})/g, '$1 ').trim();
        try{ const qr = (await loadQr())(0, 'M'); qr.addData(r.uri); qr.make(); $('#qr-box').innerHTML = qr.createSvgTag({cellSize: 5, margin: 2, scalable: true}); }
        catch(e){ $('#qr-box').innerHTML = '<p class="muted small">Couldn’t draw the QR code. Type the key below instead.</p>'; $('.qr-manual').open = true; }
        msg.textContent = ''; inp.focus();
      }catch(e){ msg.textContent = teamErr(e); return; }
      inp.oninput = () => { inp.value = inp.value.replace(/\D/g, '').slice(0, 6); if(inp.value.length === 6) $('#qr-form').requestSubmit(); };
      $('#qr-form').onsubmit = async e => {
        e.preventDefault(); msg.textContent = 'Checking…';
        try{ await api.teamFn({action: 'app_confirm', code: inp.value}); msg.textContent = ''; res(); }
        catch(err){ inp.select(); msg.textContent = err.code === 'wrong_code' ? 'That code isn’t right. Check the time on your phone is automatic, then try the newest code.' : teamErr(err); }
      };
    });
  }
  async function gate(){
    if(!LIVE) return;
    let st = null;
    try{ st = await api.teamFn({action: 'status'}); }catch(e){ return; }   // function not set up yet: the database decides, as before
    security = st;
    if(st.require_code && !st.verified){ if(st.method === 'none') await setupApp(true); else await askCode(st); }
    if(st.must_change) await askPassword();
  }

  // ------------------------------------------------------------------ boot
  async function loadAll(){
    [leads, team, content] = await Promise.all([api.leads(), api.team(), api.content()]);
    await seedCases();
    renderLeads(); renderContent(); renderTeam(); renderCases();
    loadSecurity();
  }

  async function boot(){
    $('#demo-banner').hidden = LIVE;
    let session = null;
    try{ session = await api.session(); }catch(e){ fail(e); }
    if(!session){ show('view-login'); return; }
    if(started) return; started = true;
    await gate();
    try{ me = await api.me(session.user.id); }catch(e){ fail(e); }
    if(!me){ $('#noaccess-email').textContent = session.user.email; show('view-noaccess'); return; }
    me.email = session.user.email;
    $('#me-name').textContent = me.name || me.email;
    if($('#me-role')) $('#me-role').textContent = roleName(me.role);
    if($('#me-avatar')) $('#me-avatar').textContent = initials(me.name || me.email);
    show('view-app');
    window.CRT_ADMIN = {sb, LIVE, me, isAdmin, toast, fail, esc, leads: () => leads, _leads: onLeadsChange};
    document.dispatchEvent(new CustomEvent('crt:ready'));
    try{ await loadAll(); }catch(e){ fail(e); }
    setInterval(async () => { if(document.hidden || openId) return; try{ leads = await api.leads(); renderLeads(); }catch(e){} }, 60000);
  }

  function goTab(name){
    $$('.tab').forEach(b => { const on = b.dataset.tab === name; b.classList.toggle('is-active', on); b.setAttribute('aria-current', on ? 'page' : 'false'); });
    $$('.tab-panel').forEach(p => p.hidden = p.id !== 'tab-' + name);
    if(name === 'inbox'){ if(window.CRT_MAIL) window.CRT_MAIL.open(); else if(!inboxLoaded) loadInbox(); }   // Mail (mail.js) replaced the Zoho inbox
    document.dispatchEvent(new CustomEvent('crt:tab', {detail: name}));
    window.scrollTo(0, 0);
  }
  // Theme (Settings → Appearance): 'light', 'dark' or 'auto' (follows the device)
  const darkQ = window.matchMedia ? matchMedia('(prefers-color-scheme: dark)') : null;
  let themePick = 'auto';
  function setTheme(t){
    themePick = t === 'light' || t === 'dark' ? t : 'auto';
    document.documentElement.dataset.theme = themePick === 'auto' ? (darkQ && darkQ.matches ? 'dark' : 'light') : themePick;
    try{ localStorage.setItem('crt-admin-theme', themePick); }catch(e){}
  }
  window.CRT_THEME = setTheme;
  if(darkQ && darkQ.addEventListener) darkQ.addEventListener('change', () => { if(themePick === 'auto') setTheme('auto'); });
  setTheme((()=>{ try{ return localStorage.getItem('crt-admin-theme') || 'auto'; }catch(e){ return 'auto'; } })());

  // Pipeline drag and drop: moving a card changes the lead's status
  let dragId = null;
  document.addEventListener('dragstart', e => { const c = e.target.closest && e.target.closest('.card[data-lead]'); if(!c) return; dragId = Number(c.dataset.lead); c.classList.add('is-dragging'); e.dataTransfer.effectAllowed = 'move'; });
  document.addEventListener('dragend', e => { const c = e.target.closest && e.target.closest('.card'); if(c) c.classList.remove('is-dragging'); $$('.col-body.is-over').forEach(x => x.classList.remove('is-over')); });
  document.addEventListener('dragover', e => { const z = e.target.closest && e.target.closest('[data-drop]'); if(!z || dragId === null) return; e.preventDefault(); $$('.col-body.is-over').forEach(x => { if(x !== z) x.classList.remove('is-over'); }); z.classList.add('is-over'); });
  document.addEventListener('drop', async e => {
    const z = e.target.closest && e.target.closest('[data-drop]'); if(!z || dragId === null) return;
    e.preventDefault(); z.classList.remove('is-over');
    const l = leads.find(x => x.id === dragId); const status = z.dataset.drop; dragId = null;
    if(!l || l.status === status) return;
    setStatus(l, status);   // logs the change, the reply time and offers Undo
  });

  // Keyboard shortcuts: / search, N new lead, 1-5 switch sections, Enter opens a focused card
  document.addEventListener('keydown', e => {
    if($('#view-app').hidden) return;
    const typing = /^(input|textarea|select)$/i.test(e.target.tagName) || e.target.isContentEditable;
    if(e.key === 'Enter' && e.target.matches && e.target.matches('.card[data-lead]')){ openDrawer(Number(e.target.dataset.lead)); return; }
    if(!typing && !e.metaKey && !e.ctrlKey && !e.altKey && openId && openId !== 'new'){
      const k = e.key.toLowerCase();
      if(k === 'j' || k === 'k'){ e.preventDefault(); const i = shown.findIndex(x => x.id === openId) + (k === 'j' ? 1 : -1); if(shown[i]) openDrawer(shown[i].id); return; }
      if(k === 'r'){ e.preventDefault(); const b = $('#d-quick .btn'); if(b) b.click(); return; }
    }
    if(typing || e.metaKey || e.ctrlKey || e.altKey || openId) return;
    if(!$('#tab-leads').hidden && view !== 'board' && /^[jkx]$/i.test(e.key) || (!$('#tab-leads').hidden && e.key === 'Enter' && cursor > -1)){
      e.preventDefault(); const k = e.key.toLowerCase();
      if(k === 'j') cursor = Math.min(shown.length - 1, cursor + 1); else if(k === 'k') cursor = Math.max(0, cursor - 1);
      else if(k === 'x' && shown[cursor]){ const id = shown[cursor].id; picked.has(id) ? picked.delete(id) : picked.add(id); }
      else if(e.key === 'Enter' && shown[cursor]){ openDrawer(shown[cursor].id); return; }
      renderLeads(); const r = $('#leads-table tbody tr.is-cursor'); if(r) r.scrollIntoView({block: 'nearest'}); return;
    }
    if(e.key === '/'){ e.preventDefault(); goTab('leads'); $('#search').focus(); }
    else if(e.key === 'n' || e.key === 'N'){ e.preventDefault(); openNewLead(); }
    else if(/^[1-6]$/.test(e.key)){ const tabs = $$('.tab'); const t = tabs[Number(e.key) - 1]; if(t) goTab(t.dataset.tab); }
  });


  // Case study photos: drop files to upload, drag thumbnails to reorder
  const hasFiles = e => e.dataTransfer && [...(e.dataTransfer.types || [])].includes('Files');
  document.addEventListener('dragstart', e => { const it = e.target.closest && e.target.closest('.ph-item[data-pi]'); if(!it) return; dragPhoto = Number(it.dataset.pi); it.classList.add('is-dragging'); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', 'photo'); });
  document.addEventListener('dragend', e => { $$('.ph-item.is-dragging,.ph-item.is-target').forEach(x => x.classList.remove('is-dragging', 'is-target')); dragPhoto = null; });
  document.addEventListener('dragover', e => {
    const panel = e.target.closest && e.target.closest('#photo-panel,#film-drop');
    if(!panel || !isAdmin()) return;
    if(hasFiles(e)){ e.preventDefault(); panel.classList.add('is-drop'); return; }
    const it = e.target.closest('.ph-item[data-pi]');
    if(dragPhoto !== null && it){ e.preventDefault(); $$('.ph-item.is-target').forEach(x => x !== it && x.classList.remove('is-target')); it.classList.add('is-target'); }
  });
  document.addEventListener('dragleave', e => { const panel = e.target.closest && e.target.closest('#photo-panel,#film-drop'); if(panel && !panel.contains(e.relatedTarget)) panel.classList.remove('is-drop'); });
  document.addEventListener('drop', e => {
    const panel = e.target.closest && e.target.closest('#photo-panel,#film-drop');
    if(!panel || !isAdmin()) return;
    panel.classList.remove('is-drop');
    if(hasFiles(e)){
      e.preventDefault(); const files = [...e.dataTransfer.files];
      if(panel.id === 'film-drop') uploadFilm(files);
      else addPhotos(files);
      return;
    }
    const it = e.target.closest('.ph-item[data-pi]');
    if(dragPhoto !== null && it){ e.preventDefault(); movePhoto(dragPhoto, Number(it.dataset.pi)); }
  });
  window.addEventListener('dragover', e => { if(hasFiles(e) && !$('#tab-cases').hidden) e.preventDefault(); });
  window.addEventListener('drop', e => { if(hasFiles(e) && !(e.target.closest && e.target.closest('#photo-panel,#film-drop'))) e.preventDefault(); });

  // ------------------------------------------------------------------ events
  document.addEventListener('click', async e => {
    const li = e.target.closest('#inbox-list li[data-mid]'); if(li){ openMail(li.dataset.mid); return; }
    const card = e.target.closest('.card[data-lead]'); if(card){ openDrawer(Number(card.dataset.lead)); return; }
    const rp = e.target.closest('[data-reply]'); if(rp){ const l = leads.find(x => x.id === Number(rp.dataset.reply)); setTimeout(() => replied(l, rp.dataset.how), 300); return; }
    const em = e.target.closest('[data-mailto]'); if(em){ emailLead(leads.find(x => x.id === Number(em.dataset.mailto))); return; }
    const ds = e.target.closest('[data-dstat]'); if(ds){ setStatus(leads.find(x => x.id === openId), ds.dataset.dstat); return; }
    const fu = e.target.closest('[data-fu]'); if(fu){ setFollow(leads.find(x => x.id === openId), fu.dataset.fu); return; }
    const t = e.target.closest('[data-action],[data-tab],[data-filter],tr[data-id]');
    if(!t) return;
    if(t.dataset.tab){ if(t.dataset.tab !== 'cases' && !leaveOK()) return; goTab(t.dataset.tab); return; }
    if(t.dataset.filter){ filter = filter === t.dataset.filter && t.classList.contains('lf-card') ? 'all' : t.dataset.filter; cursor = -1; renderLeads(); return; }
    if(t.matches('tr[data-id]')){ if(e.target.closest('input,select,a,button,.lt-q')) return; openDrawer(Number(t.dataset.id)); return; }
    const a = t.dataset.action;
    if(a === 'signout') api.signOut();
    else if(a === 'view-table' || a === 'view-board'){ view = a === 'view-board' ? 'board' : 'table'; try{ localStorage.setItem('crt-admin-view', view); }catch(err){} renderLeads(); }
    else if(a === 'focus-search'){ goTab('leads'); $('#search').focus(); }
    else if(a === 'toggle-theme'){ setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'); }
    else if(a === 'new-lead') openNewLead();
    else if(a === 'inbox-refresh'){ await loadInbox(); toast('Inbox up to date'); }
    else if(a === 'inbox-more') loadInbox(true);
    else if(a === 'mail-to-lead') mailToLead();
    else if(a === 'refresh'){ try{ leads = await api.leads(); renderLeads(); toast('Up to date'); }catch(err){ fail(err); } }
    else if(a === 'export' || a === 'lt-bulk-export') exportCsv();
    else if(a === 'lt-clear'){ Object.assign(LF, {service: '', source: '', period: '', who: ''}); query = ''; filter = 'all'; ['#lt-service','#lt-source','#lt-period','#lt-who','#search'].forEach(x => { if($(x)) $(x).value = ''; }); renderLeads(); }
    else if(a === 'lt-bulk-clear'){ picked.clear(); renderLeads(); }
    else if(a === 'lt-bulk-delete'){ if(!isAdmin() || !confirm('Delete ' + picked.size + ' leads? This cannot be undone.')) return; try{ for(const id of picked) await api.deleteLead(id); leads = leads.filter(l => !picked.has(l.id)); toast(picked.size + ' leads deleted'); picked.clear(); renderLeads(); }catch(err){ fail(err); } }
    else if(a === 'd-prev' || a === 'd-next'){ const i = shown.findIndex(x => x.id === openId) + (a === 'd-next' ? 1 : -1); if(shown[i]) openDrawer(shown[i].id); }
    else if(a === 'close-drawer') closeDrawer();
    else if(a === 'save-lead') saveLead();
    else if(a === 'wa-reply'){ const l = leads.find(x => x.id === openId); if(l && l.status === 'new'){ $('#d-status').value = 'replied'; } }
    else if(a === 'delete-lead'){
      if(!confirm('Delete this lead permanently?')) return;
      try{ await api.deleteLead(openId); leads = leads.filter(l => l.id !== openId); closeDrawer(); renderLeads(); toast('Lead deleted'); }catch(err){ fail(err); }
    }
    else if(a === 'save-prices'){ e.preventDefault(); savePrices(); }
    else if(a === 'add-testimonial'){
      const list = readTestimonials();
      if(list.length >= MAX_TESTIMONIALS){ toast('Maximum ' + MAX_TESTIMONIALS + ' testimonials'); return; }
      content.testimonials = [...list, {quote:'', name:'', role:''}]; renderTestimonials();
      const rows = $$('#testimonials-list .testimonial-row'); rows[rows.length - 1].querySelector('textarea').focus();
    }
    else if(a === 'remove-testimonial'){ const list = readTestimonials(); list.splice(Number(t.dataset.i), 1); content.testimonials = list; renderTestimonials(); }
    else if(a === 'save-testimonials') saveTestimonials();
    else if(a === 'review-use') useReview(t.dataset.id, false);
    else if(a === 'review-drop') useReview(t.dataset.id, true);
    else if(a === 'copy-review-msg'){ try{ await navigator.clipboard.writeText($('#review-msg').textContent); toast('Copied. Paste it into WhatsApp.'); }catch(err){ toast('Select the text and copy it'); } }
    else if(a === 'save-film-url'){
      const raw = $('#film-url').value.trim();
      let ok = false; try{ ok = new URL(raw).protocol === 'https:'; }catch(err){}
      if(!ok){ toast('Paste a full https:// link from YouTube, Vimeo, Google Drive or Instagram'); return; }
      const entry = caseEntry(), list = caseVideos(entry);
      if(list.some(v => v.url === raw)){ toast('That video is already on this work.'); return; }
      if(list.length >= MAX_VIDEOS){ toast('This work already has ' + MAX_VIDEOS + ' videos.'); return; }
      const info = videoInfo(raw);
      setVideos(entry, list.concat({type: 'link', url: raw, title: ''}));
      $('#film-url').value = '';
      renderCases(); saveCases(info.kind === 'Link' ? 'Link saved. It is not YouTube, Vimeo, Google Drive or Instagram, so the page shows a “Watch” button.' : info.kind + ' video added. Live on the site.');
    }
    else if(a === 'remove-film'){
      const entry = caseEntry(), list = caseVideos(entry), i = +t.dataset.i, v = list[i]; if(!v) return;
      if(!confirm('Remove this video from the work?')) return;
      if(v.type === 'file'){ api.removeFile(v.url).catch(()=>{}); if(v.poster) api.removeFile(v.poster).catch(()=>{}); }
      list.splice(i, 1); setVideos(entry, list); renderCases(); saveCases('Video removed.');
    }
    else if(a === 'film-move'){
      const entry = caseEntry(), list = caseVideos(entry), i = +t.dataset.i, j = i + +t.dataset.d;
      if(j < 0 || j >= list.length) return;
      const [v] = list.splice(i, 1); list.splice(j, 0, v); setVideos(entry, list); renderVideos(false, entry); saveCases(j === 0 ? 'Main video changed.' : 'Order saved.');
    }
    else if(a === 'photo-move'){ const i = Number(t.dataset.i); movePhoto(i, i + Number(t.dataset.d)); }
    else if(a === 'remove-photo'){
      const i = Number(t.dataset.i), entry = caseEntry(), p = entry.photos[i];
      if(!p || !confirm('Remove photo ' + (i + 1) + ' from the case study?')) return;
      entry.photos.splice(i, 1);
      // the cover or thumbnail was this photo: move them to the next photo, so the removed one is gone everywhere
      const same = u => u && (u === p.url || u === p.sm);
      let note = '';
      if(entry.cover && same(entry.cover.url)){ const n = entry.photos[Math.min(i, entry.photos.length - 1)]; entry.cover = n ? {url: n.url, sm: n.sm || '', pos: '50% 50%', contain: false} : null; note = n ? ' The next photo is now the cover.' : ' This work has no cover now.'; }
      if(entry.card && same(entry.card.url)){ const n = entry.cover || entry.photos[0]; entry.card = n ? {url: n.sm || n.url} : null; delete entry.card_custom; }
      if(/\/storage\/v1\/object\/public\/media\//.test(p.url) && !Object.values(content.case_studies || {}).some(e => e && (e.photos || []).some(x => x.url === p.url))) api.removeFile(p.url).catch(()=>{});
      rebuildCaseList(); renderCases(); saveCases('Photo removed.' + note);
    }
    else if(a === 'open-case'){ if(e.target.closest('a')) return; openCase(t.dataset.slug); }
    else if(a === 'back-cases'){ if(!leaveOK()) return; renderCaseList(); showCaseView('list'); }
    else if(a === 'prev-case'){ if(!leaveOK()) return; stepCase(-1); }
    else if(a === 'next-case'){ stepCase(1); }
    else if(a === 'case-filter'){ caseFilter = t.dataset.g; renderCaseList(); }
    else if(a === 'ce-save'){ saveAll(); }
    else if(a === 'ce-discard'){ discardTyped(); toast('Changes discarded.'); }
    else if(a === 'cat-toggle'){
      const entry = caseEntry(), list = t.dataset.list, on = entryCats(entry, list), id = t.dataset.id, i = on.indexOf(id);
      if(i >= 0){ if(list === 'services' && on.length === 1){ toast('A work needs at least one service category'); return; } on.splice(i, 1); } else on.push(id);
      redrawCats(); saveCases('Categories saved. Live on the website.');
    }
    else if(a === 'cat-add'){ addCat(t.dataset.list); }
    else if(a === 'sec-toggle'){
      const entry = caseEntry(), l = entrySections(entry), id = t.dataset.id;
      if(id === l[0]){ toast('That is the main section. Change “Section” under Title and summary first.'); return; }
      entry.sections = l.includes(id) ? l.filter(x => x !== id) : l.concat(id);
      redrawCats(); saveCases('Work page sections saved. Live on the website.');
    }
    else if(a === 'cat-manage'){ catManage = !catManage; redrawCats(); }
    else if(a === 'cat-delete'){ const W = content.work_categories = wcats(), c = W[t.dataset.list][+t.dataset.i]; if(!c || catUse(t.dataset.list, c.id)) return; if(!confirm('Delete “' + c.name + '”? No work uses it.')) return; W[t.dataset.list].splice(+t.dataset.i, 1); redrawCats(); saveCats('Deleted.'); }
    else if(a === 'add-work'){ addWork(); }
    else if(a === 'create-work'){ createWork(); }
    else if(a === 'cancel-work'){ $('#new-work').hidden = true; }
    else if(a === 'delete-case'){ deleteCase(); }
    else if(a === 'ph-crop'){ const e2 = caseEntry(), ph = (e2.photos || [])[+t.dataset.i]; photoMenu(-1); if(ph && window.CRT_FOCUS) window.CRT_FOCUS.open(ph.url, {place: isCoverPh(e2, ph) ? 'cover' : '', readOnly: !isAdmin()}); }
    else if(a === 'ph-menu'){ const i = +t.dataset.i; photoMenu(menuAt === i ? -1 : i); }
    else if(a === 'pick-open'){ pickOpen = pickOpen === t.dataset.kind ? '' : t.dataset.kind; renderPicks(); if(pickOpen){ const st = $('#pick-strip'); const on = st.querySelector('.pick-opt.is-on:not(.pick-special)'); if(on) on.scrollIntoView({block: 'nearest', inline: 'center'}); } }
    else if(a === 'pick-scroll'){ const sc = $('#pick-strip .pick-scroll'); if(sc) sc.scrollBy({left: +t.dataset.d * sc.clientWidth * 0.8, behavior: 'smooth'}); }
    else if(a === 'pick-thumb'){ const entry = caseEntry(), ph = (entry.photos || [])[+t.dataset.i]; if(ph){ entry.card = {url: ph.sm || ph.url}; entry.card_custom = 1; rebuildCaseList(); photoMenu(-1); renderDetails(!isAdmin(), entry); paintGrid(); saveCases('Thumbnail saved. Live on the website.'); } }
    else if(a === 'thumb-reset'){ const entry = caseEntry(); delete entry.card_custom; const sd = caseSeed[caseSlug]; entry.card = (sd && sd.card) ? JSON.parse(JSON.stringify(sd.card)) : (entry.cover ? {url: entry.cover.sm || entry.cover.url} : null); rebuildCaseList(); renderDetails(!isAdmin(), entry); paintGrid(); saveCases('The thumbnail now follows the cover.'); }
    else if(a === 'pick-cover'){ const entry = caseEntry(), ph = (entry.photos || [])[+t.dataset.i]; if(ph){ entry.cover = {url: ph.url, sm: ph.sm || '', pos: '50% 50%', contain: false}; if(!entry.card_custom) entry.card = {url: ph.sm || ph.url}; rebuildCaseList(); photoMenu(-1); renderDetails(!isAdmin(), entry); paintGrid(); saveCases('Cover photo saved. Live on the website.'); } }
    else if(a === 'reset-details'){ const sd = caseSeed[caseSlug]; if(!sd){ toast('This work was added in the dashboard, so there is no earlier version.'); return; } if(!confirm('Put back the text and photos this work had when it moved into the dashboard?')) return; const keep = caseEntry(); content.case_studies[caseSlug] = Object.assign(JSON.parse(JSON.stringify(sd)), {seeded: 1, v: 2, published: keep.published}); rebuildCaseList(); renderCases(); saveCases('Restored.'); }
    else if(a === 'remove-review'){ ['#review-quote', '#review-name', '#review-role'].forEach(x => { $(x).value = ''; }); $('#review-count').textContent = '0 / 600'; setDirty(true); }
    else if(a === 'add-credit'){
      setDirty(true); const entry = caseEntry(); entry.credits = readCredits(); entry.credits.push({name:'', role:''}); renderCredits(false, entry);
      const rows = $$('#credit-rows .credit-row'); const last = rows[rows.length - 1]; (last.querySelector('.credit-name-sel') || last.querySelector('.credit-name')).focus();
    }
    else if(a === 'remove-credit'){ setDirty(true); const entry = caseEntry(); entry.credits = readCredits(); entry.credits.splice(Number(t.dataset.i), 1); renderCredits(false, entry); }
    else if(a === 'credit-up'){ setDirty(true); const entry = caseEntry(), list = readCredits(), i = Number(t.dataset.i); if(i > 0){ [list[i - 1], list[i]] = [list[i], list[i - 1]]; } entry.credits = list; renderCredits(false, entry); }
    else if(a === 'credit-lists'){ const entry = caseEntry(); entry.credits = readCredits(); const c = entry.credits[+t.dataset.i]; if(c){ delete c.manual; if(!creditPeople().includes(c.name)) c.name = ''; if(!creditRoles().includes(c.role)) c.role = ''; } renderCredits(false, entry); }
    else if(a === 'credit-add-save'){ saveCreditAdd(t.closest('.credit-row')); }
    else if(a === 'credit-add-cancel'){ const b = t.closest('.credit-add'); b.hidden = true; b.innerHTML = ''; }
    else if(a === 'remove-member'){
      const uid = t.closest('tr').dataset.uid, m = team.find(x => x.user_id === uid) || {};
      if(!confirm('Remove ' + (m.name || 'this person') + '? Their account is deleted and they can no longer sign in.')) return;
      try{ await api.removeMember(uid); team = team.filter(x => x.user_id !== uid); renderTeam(); toast('Removed'); }catch(err){ toast(teamErr(err)); }
    }
    else if(a === 'reset-member'){
      const uid = t.closest('tr').dataset.uid, m = team.find(x => x.user_id === uid) || {};
      if(!confirm('Give ' + (m.name || 'this person') + ' a new one-time password? Their current password stops working.')) return;
      try{ const r = await api.teamFn({action: 'reset_password', user_id: uid}); showMade(m.name || '', m.email || '', r.password); $('#team-made').scrollIntoView({behavior: 'smooth', block: 'center'}); }catch(err){ toast(teamErr(err)); }
    }
    else if(a === 'conn-test'){
      try{ const r = await api.teamFn({action: 'test_sms'}); toast('Test text sent to ' + (r.phone_hint || 'your phone')); }
      catch(err){ toast(err.code === 'no_phone' ? 'Add your phone number in the table first.' : err.code === 'sms_failed' ? 'The text didn’t go out: ' + ((err.info && err.info.detail) || 'check the keys') : teamErr(err)); }
    }
    else if(a === 'copy-made'){ try{ await navigator.clipboard.writeText($('#made-msg').textContent); toast('Copied'); }catch(err){ toast('Select the message and copy it'); } }
    else if(a === 'sec-on'){
      try{
        if(!security || !security.code_ok){ await askCode(security || {}); show('view-app'); }
        security = Object.assign(security || {}, await api.teamFn({action: 'set_security', require_code: true}), {code_ok: true});
        renderSecurity(); toast('Sign-in codes are on for everyone.');
      }catch(err){ show('view-app'); toast(teamErr(err)); }
    }
    else if(a === 'app-setup'){ try{ await setupApp(false); show('view-app'); security = await api.teamFn({action: 'status'}); renderSecurity(); toast('Authenticator app is set up.'); }catch(err){ show('view-app'); if(err && err.message !== 'cancel') toast(teamErr(err)); } }
    else if(a === 'reset-app'){ const uid = t.closest('tr').dataset.uid, m = team.find(x => x.user_id === uid) || {}; if(!confirm('Reset ' + (m.name || 'this person') + '’s authenticator app (lost phone)? They set it up again at their next sign-in.')) return; try{ await api.teamFn({action: 'app_remove', user_id: uid}); toast('Reset. They will scan a new code at their next sign-in.'); }catch(err){ toast(teamErr(err)); } }
    else if(a === 'sec-off'){
      if(!confirm('Switch off sign-in codes? A password alone will be enough again.')) return;
      try{ security = Object.assign(security || {}, await api.teamFn({action: 'set_security', require_code: false})); renderSecurity(); toast('Sign-in codes are off.'); }catch(err){ toast(teamErr(err)); }
    }
  });
  document.addEventListener('change', async e => {
    const el = e.target;
    if(el.id === 'case-select'){ caseSlug = el.value; renderCases(); return; }
    if(el.id === 'film-file' && el.files[0]){ const fs = [...el.files]; el.value = ''; uploadFilm(fs); return; }
    if(el.classList.contains('film-title')){ const entry = caseEntry(), v = caseVideos(entry)[+el.dataset.vi]; if(v){ v.title = el.value.trim().slice(0, 80); setVideos(entry, caseVideos(entry)); saveCases('Video title saved.'); } return; }
    if(el.dataset && el.dataset.photo !== undefined && el.files && el.files.length){ const files = [...el.files]; el.value = ''; addPhotos(files); return; }
    if(el.classList && el.classList.contains('slot-group')){
      const entry = caseEntry(), p = entry.photos[Number(el.dataset.i)];
      if(p){ if(el.value) p.group = el.value; else delete p.group; saveCases('Photo group saved.'); }
      return;
    }
    if(el.classList && el.classList.contains('slot-caption')){
      const entry = caseEntry(), p = entry.photos[Number(el.dataset.i)];
      if(p){ p.caption = el.value.trim().slice(0, 160); saveCases('Caption saved.'); }
      return;
    }
    const f = el.closest('#team-table [data-field]'); if(!f) return;
    const uid = f.closest('tr').dataset.uid, v = f.dataset.field === 'phone' ? f.value.replace(/[\s()-]/g, '') : f.value.trim(), patch = {[f.dataset.field]: v};
    try{ await api.updateMember(uid, patch); Object.assign(team.find(m => m.user_id === uid), patch); if(uid === me.user_id && f.dataset.field === 'phone' && security) security.has_phone = !!v; renderSecurity(); toast('Team updated'); }catch(err){ toast(teamErr(err)); }
  });
  $('#drawer-scrim').addEventListener('click', closeDrawer);
  document.addEventListener('keydown', e => { if(e.key === 'Escape' && openId) closeDrawer(); });
  $('#search').addEventListener('input', e => { query = e.target.value; renderLeads(); });
  $('#team-form').addEventListener('submit', async e => {
    e.preventDefault();
    const name = $('#tm-name').value.trim(), email = $('#tm-email').value.trim(), phone = $('#tm-phone').value.replace(/[\s()-]/g, ''), role = $('#tm-role').value;
    const btn = e.target.querySelector('button[type="submit"]'); btn.disabled = true;
    try{
      const r = await api.teamFn({action: 'create_member', name, email, phone, role});
      team.push({user_id: r.user_id || ('demo-' + Date.now()), name, email, phone: phone || null, role}); renderTeam();
      showMade(name, email, r.password); e.target.reset(); toast('Account created');
    }catch(err){ toast(teamErr(err)); }
    btn.disabled = false;
  });
  $('#login-form').addEventListener('submit', async e => {
    e.preventDefault();
    const email = $('#login-email').value.trim(), msg = $('#login-msg');
    const btn = e.target.querySelector('button[type="submit"]');
    msg.textContent = 'Signing in…'; btn.disabled = true;
    let error = null;
    try{ ({error} = await api.signIn(email, $('#login-password').value)); }catch(err){ error = err; }
    btn.disabled = false;
    if(error){ msg.textContent = /invalid/i.test(error.message || '') ? 'Wrong email or password.' : 'Couldn’t sign in: ' + (error.message || 'please try again') + '.'; return; }
    msg.textContent = '';
    $('#login-password').value = '';
    if(!LIVE) boot();
  });
  $$('#prices-form').forEach(f => f.addEventListener('submit', e => e.preventDefault()));
  if(LIVE) sb.auth.onAuthStateChange((ev) => { if(ev === 'SIGNED_IN' && !started) boot(); });

  boot();
})();

// Leads v2: inline status, filters, selection and bulk changes (2026-11-25)
document.addEventListener('change', e => {
  const A = window.CRT_ADMIN; if(!A || !A._leads) return; A._leads(e);
});
