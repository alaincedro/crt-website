-- CRT finance on WhatsApp, version 3: the assistant remembers the question it just asked
-- ("How much was it?", "Did it come in or go out?") and the entry it just booked, so the next message can answer or correct it.
-- Run once in Supabase → SQL Editor. Safe to run again. Needs finance-setup.sql and finance-whatsapp-v2.sql (already run).
alter table public.fin_whatsapp_senders add column if not exists state jsonb;
