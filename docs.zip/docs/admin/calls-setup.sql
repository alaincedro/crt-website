-- CRT · Call booking on crt.rw (2026-11-25): replaces cal.com. Free tier, no other service.
-- Run once in Supabase → SQL Editor. Safe to run again.
--   Visitors pick a free time on /call/; book_call() checks it against the hours set in
--   admin → Settings → Call booking (site_content.call_settings), saves the call, and adds a lead
--   (service "20-minute call"), so it lands in Leads and in the hello@ mailbox like every enquiry.

create table if not exists public.calls (
  id          bigint generated always as identity primary key,
  created_at  timestamptz not null default now(),
  starts_at   timestamptz not null,
  minutes     int not null default 20 check (minutes between 10 and 120),
  name        text not null check (char_length(name) between 1 and 120),
  contact     text not null check (char_length(contact) between 3 and 160),
  email       text check (char_length(email) <= 160),
  how         text not null default 'whatsapp' check (how in ('whatsapp', 'phone', 'video')),
  topic       text check (char_length(topic) <= 1000),
  status      text not null default 'booked' check (status in ('booked', 'done', 'cancelled')),
  video_link  text,
  lead_id     bigint references public.leads(id) on delete set null,
  token       text not null default replace(gen_random_uuid()::text, '-', '')
);
create unique index if not exists calls_one_per_slot on public.calls (starts_at) where status = 'booked';
create index if not exists calls_starts_idx on public.calls (starts_at);

alter table public.calls enable row level security;
revoke all on public.calls from anon;
grant select, update, delete on public.calls to authenticated;
drop policy if exists "team reads calls" on public.calls;
create policy "team reads calls" on public.calls for select to authenticated using (true);
drop policy if exists "admins change calls" on public.calls;
create policy "admins change calls" on public.calls for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admins delete calls" on public.calls;
create policy "admins delete calls" on public.calls for delete to authenticated using (public.is_admin());

-- Taken times only (no names or numbers), for the public booking page.
create or replace function public.call_busy(p_from timestamptz, p_to timestamptz)
returns setof timestamptz language sql stable security definer set search_path = public as $$
  select starts_at from public.calls where status = 'booked' and starts_at >= p_from and starts_at < p_to
$$;
revoke all on function public.call_busy(timestamptz, timestamptz) from public;
grant execute on function public.call_busy(timestamptz, timestamptz) to anon, authenticated;

-- Book one free time. Errors: too_soon, too_far, closed, not_a_slot, taken, missing.
create or replace function public.book_call(p_starts timestamptz, p_name text, p_contact text, p_email text, p_how text, p_topic text)
returns json language plpgsql security definer set search_path = public as $$
declare
  s jsonb; mins int; d date; t time; dow int; w jsonb; ok boolean := false; v_lead bigint; link text; c public.calls;
  hours jsonb := '{"1":[["09:00","17:00"]],"2":[["09:00","17:00"]],"3":[["09:00","17:00"]],"4":[["09:00","17:00"]],"5":[["09:00","17:00"]],"6":[["10:00","13:00"]],"7":[]}';
  how text := case when p_how in ('whatsapp', 'phone', 'video') then p_how else 'whatsapp' end;
begin
  if coalesce(trim(p_name), '') = '' or coalesce(trim(p_contact), '') = '' then raise exception 'missing'; end if;
  select value into s from public.site_content where key = 'call_settings';
  s := coalesce(s, '{}'::jsonb);
  mins := coalesce((s->>'minutes')::int, 20);
  if s ? 'hours' then hours := s->'hours'; end if;
  if p_starts < now() + make_interval(mins => coalesce((s->>'notice_min')::int, 120)) then raise exception 'too_soon'; end if;
  if p_starts > now() + make_interval(days => coalesce((s->>'days_ahead')::int, 21)) then raise exception 'too_far'; end if;
  d := (p_starts at time zone 'Africa/Kigali')::date;
  t := (p_starts at time zone 'Africa/Kigali')::time;
  dow := extract(isodow from d)::int;
  if coalesce(s->'blocked', '[]'::jsonb) ? d::text then raise exception 'closed'; end if;
  for w in select * from jsonb_array_elements(coalesce(hours->(dow::text), '[]'::jsonb)) loop
    if t >= (w->>0)::time and t + make_interval(mins => mins) <= (w->>1)::time
       and (extract(epoch from (t - (w->>0)::time)) / 60)::int % mins = 0 then ok := true; end if;
  end loop;
  if not ok then raise exception 'not_a_slot'; end if;
  if how = 'video' then link := 'https://meet.jit.si/CRT-call-' || left(replace(gen_random_uuid()::text, '-', ''), 10); end if;
  begin
    insert into public.calls (starts_at, minutes, name, contact, email, how, topic, video_link)
    values (p_starts, mins, left(trim(p_name), 120), left(trim(p_contact), 160), nullif(left(trim(coalesce(p_email, '')), 160), ''), how, nullif(left(trim(coalesce(p_topic, '')), 1000), ''), link)
    returning * into c;
  exception when unique_violation then raise exception 'taken';
  end;
  insert into public.leads (name, contact, service, offer, event_date, details, page, source)
  values (c.name, left(coalesce(c.email, c.contact) || case when c.email is not null then ' · ' || c.contact else '' end, 160),
          mins || '-minute call',
          case how when 'video' then 'Video call' when 'phone' then 'Phone call' else 'WhatsApp call' end,
          to_char(p_starts at time zone 'Africa/Kigali', 'Dy DD Mon YYYY, HH24:MI') || ' Kigali time',
          left('Call booked on crt.rw.' || coalesce(E'\n\n' || c.topic, '') || coalesce(E'\nVideo link: ' || link, ''), 2000),
          '/call/', 'Call booking')
  returning id into v_lead;
  update public.calls set lead_id = v_lead where id = c.id;
  return json_build_object('id', c.id, 'starts_at', c.starts_at, 'minutes', mins, 'how', how, 'video_link', link, 'token', c.token);
end $$;
revoke all on function public.book_call(timestamptz, text, text, text, text, text) from public;
grant execute on function public.book_call(timestamptz, text, text, text, text, text) to anon, authenticated;

-- The visitor can cancel with the link they get after booking (/call/?cancel=<id>.<token>).
create or replace function public.cancel_call(p_id bigint, p_token text)
returns boolean language plpgsql security definer set search_path = public as $$
begin
  update public.calls set status = 'cancelled' where id = p_id and token = p_token and status = 'booked' and starts_at > now();
  if found then
    update public.leads set notes = left(coalesce(notes || E'\n', '') || 'Call cancelled by the client on crt.rw.', 5000) where id = (select lead_id from public.calls where id = p_id);
  end if;
  return found;
end $$;
revoke all on function public.cancel_call(bigint, text) from public;
grant execute on function public.cancel_call(bigint, text) to anon, authenticated;
