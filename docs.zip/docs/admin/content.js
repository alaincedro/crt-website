/* CRT admin: Content. Edit the words, buttons, links and photos of any page by clicking them in a live preview,
   plus the site-wide details (contact details, announcement bar).
   Plugs into admin.js through window.CRT_ADMIN. Saves to Supabase site_content (page_edits, site_settings),
   which site.js reads on every page. In demo mode nothing leaves this browser tab. */
(function(){
  'use strict';
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];
  const clone = o => JSON.parse(JSON.stringify(o || {}));
  const PAGES = [
    ['/', 'Home'], ['/business', 'For businesses'], ['/events', 'Events'], ['/weddings', 'Weddings'],
    ['/commercial-photography-video', 'Commercial photo & video'], ['/branding-graphic-design', 'Branding & design'],
    ['/social-media-content', 'Social media & content'], ['/web-digital', 'Web & digital'],
    ['/offers', 'Offers'], ['/work', 'Our work'], ['/about', 'About'], ['/contact', 'Contact'],
    ['/guides', 'Price guides'], ['/print', 'Print'], ['/book', 'Book']
  ];
  const CACHE = 'crt-content-v1', DEMO = 'crt-demo-content';
  let A = null, esc = s => s, ro = true;
  let store = {page_edits: {}, site_settings: {}}, work = {};
  // Client logos on the home page. The last value is the link built into the page (empty = no link).
  const LOGOS = [
    ['oryx-energies', 'ORYX Energies', '../assets/clients/oryx-energies.svg', '/work-oryx-energies/'],
    ['sanlamallianz', 'SanlamAllianz', '../assets/clients/sanlamallianz.svg', '/work-sanlam-allianz-agents-day/'],
    ['old-mutual', 'Old Mutual', '../assets/clients/old-mutual.svg', '/work-old-mutual-year-end/'],
    ['rmb', 'Rwanda Mines, Petroleum and Gas Board', '../assets/clients/rmb.png', '/work-rwanda-mining-week/'],
    ['norrsken', 'Norrsken', '../assets/norrsken.png', ''],
    ['growth-africa', 'Growth Africa', '../assets/growth-africa-light-bg.png', ''],
    ['systemic-innovation', 'Systemic Innovation', '../assets/systemic-innovation.png', '']
  ];
  let caseList = null;
  let pane = 'cms:overview', page = '/', device = 'desktop';
  let frame = null, doc = null, ED = null, sel = null, hover = null, keepScroll = 0;

  // ------------------------------------------------------------------ data
  async function load(){
    if(A.LIVE){
      const {data, error} = await A.sb.from('site_content').select('key,value').in('key', ['page_edits', 'site_settings', 'client_logos', 'client_list', 'price_map', 'prices_v2']);
      if(error) throw error;
      (data || []).forEach(r => { store[r.key] = r.value || {}; });
    } else {
      try{ Object.assign(store, JSON.parse(sessionStorage.getItem(DEMO) || '{}')); }catch(e){}
    }
    store.page_edits = store.page_edits || {}; store.site_settings = store.site_settings || {};
    work = clone(store.page_edits);
  }
  async function save(key, value){
    if(A.LIVE){
      const {error} = await A.sb.from('site_content').upsert({key, value, updated_by: A.me.user_id});
      if(error) throw error;
    }
    store[key] = clone(value);
    try{
      if(!A.LIVE) sessionStorage.setItem(DEMO, JSON.stringify(store));
      else localStorage.setItem(CACHE, JSON.stringify(store));   // this browser sees the change at once
    }catch(e){}
  }
  async function upload(file, folder){
    if(!A.LIVE) return URL.createObjectURL(file);   // demo: local preview only
    const ext = (file.name.match(/\.[a-z0-9]+$/i) || [''])[0].toLowerCase() || (file.type === 'image/webp' ? '.webp' : '');
    const path = folder + '/' + Date.now() + '-' + Math.random().toString(36).slice(2, 8) + ext;
    const {error} = await A.sb.storage.from('media').upload(path, file, {upsert: false, contentType: file.type || 'application/octet-stream', cacheControl: '31536000'});
    if(error) throw error;
    return A.sb.storage.from('media').getPublicUrl(path).data.publicUrl;
  }
  // Photos are resized in the browser before upload, so a 12 MB camera file never reaches visitors.
  function shrink(file){
    return new Promise(res => {
      if(!/^image\/(jpeg|png|webp)$/.test(file.type)) return res(file);
      const img = new Image(), url = URL.createObjectURL(file);
      img.onload = () => {
        const k = Math.min(1, 2000 / Math.max(img.naturalWidth, img.naturalHeight));
        const c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url);
        c.toBlob(b => res(b && b.size < file.size ? new File([b], file.name.replace(/\.[a-z0-9]+$/i, '') + '.webp', {type: 'image/webp'}) : file), 'image/webp', .84);
      };
      img.onerror = () => { URL.revokeObjectURL(url); res(file); };
      img.src = url;
    });
  }

  // ------------------------------------------------------------------ edits model
  const listFor = p => [].concat(work['*'] || [], work[p] || []);
  const countFor = p => (work[p] || []).length;
  const total = () => Object.keys(work).reduce((n, k) => n + (work[k] || []).length, 0);
  const dirty = () => JSON.stringify(work) !== JSON.stringify(store.page_edits || {});
  function getEdit(k, from){
    for(const scope of ['*', page]){ const e = (work[scope] || []).find(x => x.k === k && x.from === from); if(e) return {scope, to: e.to}; }
    return null;
  }
  function putEdit(k, from, to, scope){
    ['*', page].forEach(s => { if(work[s]){ work[s] = work[s].filter(x => !(x.k === k && x.from === from)); if(!work[s].length) delete work[s]; } });
    if(to !== from && to !== ''){ (work[scope] = work[scope] || []).push({k, from, to}); }
    paintStatus();
  }
  function dropEdit(scope, k, from){
    if(work[scope]){ work[scope] = work[scope].filter(x => !(x.k === k && x.from === from)); if(!work[scope].length) delete work[scope]; }
    paintStatus();
  }

  // ------------------------------------------------------------------ shell
  function build(){
    const tab = $('#tab-content'); if(!tab || $('#ct-nav')) return;
    const head = tab.querySelector('.page-head');
    if(head) head.querySelector('div').innerHTML = '<h1>Content</h1><p class="muted">Everything visitors see. Pick what to change on the left; it reaches the website when you press Publish or Save.</p>';
    const panels = $$(':scope > .panel', tab);
    const names = ['prices', 'testimonials'];
    const wrap = document.createElement('div'); wrap.className = 'ct';
    wrap.innerHTML = '<nav class="ct-nav" id="ct-nav" aria-label="Content sections"></nav><div class="ct-main" id="ct-main"></div>';
    tab.appendChild(wrap);
    const main = $('#ct-main');
    main.insertAdjacentHTML('beforeend', '<div class="ct-pane" data-cpane="page" hidden></div><div class="ct-pane" data-cpane="cms" hidden></div>');
    if(window.CRT_CMS) window.CRT_CMS.mount($('[data-cpane="cms"]'));
    window.CRT_CONTENT_GO = n => go(n); window.CRT_CONTENT_NAV = () => paintNav(); window.CRT_CONTENT_PAGES = PAGES;
    panels.forEach((p, i) => { p.dataset.cpane = names[i] || 'x' + i; p.classList.add('ct-pane'); p.hidden = true; main.appendChild(p); });
    ['logos', 'announcement', 'changes'].forEach(n => main.insertAdjacentHTML('beforeend', `<div class="panel ct-pane" data-cpane="${n}" hidden></div>`));
    buildEditor(); buildSettings(); buildLogos(); buildPrices();
    $('#ct-nav').addEventListener('click', e => { if(e.target.closest('#ct-k')){ if(window.CRT_CMS) window.CRT_CMS.openK(); return; } const b = e.target.closest('[data-go]'); if(b) go(b.dataset.go); });
    // The top bar's lead search and "+ New lead" belong to Leads: on Content they step aside.
    const ctx = name => document.body.classList.toggle('on-content', name === 'content');
    document.addEventListener('crt:tab', e => ctx(e.detail));
    ctx(($('.tab.is-active') || {dataset: {}}).dataset.tab);
    try{ pane = localStorage.getItem('crt-admin-cpane') || pane; }catch(e){}
    paintNav(); go(pane, true);
  }
  function paintNav(){
    const nav = $('#ct-nav'); if(!nav) return;
        const item = (go, label, n) => `<button type="button" class="ct-item${pane === go ? ' is-on' : ''}" data-go="${go}"${pane === go ? ' aria-current="true"' : ''}><span>${esc(label)}</span>${n === '' || n == null ? '' : `<em>${n}</em>`}</button>`;
    const tCount = $$('#testimonials-list .testimonial-row').length;
    const M = window.CRT_CMS, I = k => M ? M.icon(k) : '';
    const cms = c => M ? ['cms:' + c, M.C[c].title, '', M.dirty(c), M.C[c].icon] : null;
    const on = x => pane === x[0] || (x[0] === 'page' && (pane.indexOf('page:') === 0 || pane === 'changes'));
    const row = x => x ? `<button type="button" class="ct-item${on(x) ? ' is-on' : ''}" data-go="${x[0] === 'page' ? 'page:' + page : x[0]}"${on(x) ? ' aria-current="true"' : ''}>${x[4] ? I(x[4]) : ''}<span>${esc(x[1])}</span>${x[3] ? '<i class="ct-dot" title="Unpublished changes"></i>' : ''}${x[2] === '' || x[2] == null ? '' : `<em>${x[2]}</em>`}</button>` : '';
    const sect = (title, rows) => (title ? `<p class="ct-group">${title}</p>` : '') + rows.map(row).join('');
    const html =
      sect('', [['cms:overview', 'Overview', '', false, 'home']]) +
      sect('Sell', [cms('offers'), cms('packages'), ['prices', 'All prices', '', false, 'tag'], cms('availability'), cms('print')]) +
      sect('Pages', [['page', 'Edit any page', '', dirty(), 'globe'], cms('hero')]) +
      sect('Site', [['trust', 'Reviews & client logos', '', false, 'star'], ['site', 'Announcement bar', '', false, 'q'], cms('seo')]);
    if(!$('#ct-k', nav) && M) nav.insertAdjacentHTML('afterbegin', '<button type="button" class="ct-k" id="ct-k"><span>Find anything</span><kbd>⌘K</kbd></button>');
    let list = $('#ct-list', nav);
    if(!list){ nav.insertAdjacentHTML('beforeend', '<div id="ct-list"></div>'); list = $('#ct-list', nav); }
    list.innerHTML = html || '<p class="muted small ct-none">Nothing matches.</p>';
    const pick = $('#ed-page'); if(pick && pick.value !== page) pick.value = page;
  }
  // one menu item can show several small panes together
  const GROUPS = {trust: ['testimonials', 'logos'], site: ['announcement']};   // contact details moved to Settings
  const OLD = {testimonials: 'trust', logos: 'trust', announcement: 'site'};
  function go(name, first){
    name = OLD[name] || name;
    if(name === 'cases'){ const t = $('.tab[data-tab="cases"]'); if(t) t.click(); return; }
    pane = name; try{ localStorage.setItem('crt-admin-cpane', name); }catch(e){}
    const isPage = name.indexOf('page:') === 0, isCms = name.indexOf('cms:') === 0;
    if(isCms && !window.CRT_CMS) return go('page:/', first);
    if(!isCms){ const ct = $('.ct'); if(ct) ct.classList.remove('cm-focus'); }
    const show = isPage ? ['page'] : isCms ? ['cms'] : GROUPS[name] || [name];
    $$('#ct-main .ct-pane').forEach(p => p.hidden = !show.includes(p.dataset.cpane));
    if(isCms) window.CRT_CMS.open(name.slice(4));
    if(isPage){ const next = name.slice(5); if(next !== page || !frame.dataset.loaded || first) { page = next; openPage(); } }
    if(name === 'changes'){ paintChanges(); const bk = $('[data-go-back]'); if(bk) bk.onclick = () => go('page:' + page); }
    paintNav();
  }

  // ------------------------------------------------------------------ page editor
  function buildEditor(){
    const p = $('[data-cpane="page"]');
    p.innerHTML = `
      <div class="ed-bar">
        <div class="ed-title"><b id="ed-name"></b><select id="ed-page" aria-label="Page to edit">${PAGES.map(([k, l]) => `<option value="${k}">${esc(l)}</option>`).join('')}</select><a id="ed-open" class="link small" target="_blank" rel="noopener">Open page ↗</a></div>
        <div class="seg" role="group" aria-label="Preview size"><button type="button" class="seg-btn is-active" data-dev="desktop" aria-pressed="true">Desktop</button><button type="button" class="seg-btn" data-dev="phone" aria-pressed="false">Phone</button></div>
        <button type="button" class="btn secondary small" id="ed-wide" aria-pressed="false" title="Hide the list of pages to give the preview more room">Bigger preview</button>
        <span class="ed-status" id="ed-status" role="status"></span>
        <button type="button" class="link small" id="ed-all" hidden>All changes</button>
        <button type="button" class="btn secondary small" id="ed-discard" hidden>Discard</button>
        <button type="button" class="btn small" id="ed-save" disabled title="No changes yet">Save changes</button>
      </div>
      <div class="ed-body">
        <div class="ed-stage" id="ed-stage"><iframe id="ed-frame" title="Page preview" loading="lazy"></iframe><div class="ed-load" id="ed-load">Loading the page…</div></div>
        <aside class="ed-ins" id="ed-ins" aria-label="Edit the selected item"></aside>
      </div>`;
    frame = $('#ed-frame');
    frame.addEventListener('load', onFrame);
    if('ResizeObserver' in window) new ResizeObserver(fit).observe($('#ed-stage')); else window.addEventListener('resize', fit);
    document.addEventListener('crt:tab', () => setTimeout(fit, 0));
    p.addEventListener('click', e => {
      const d = e.target.closest('[data-dev]');
      if(d){ device = d.dataset.dev; $$('[data-dev]', p).forEach(b => { const on = b === d; b.classList.toggle('is-active', on); b.setAttribute('aria-pressed', on); }); $('#ed-stage').classList.toggle('is-phone', device === 'phone'); fit(); return; }
      if(e.target.id === 'ed-wide'){ const on = $('.ct').classList.toggle('is-wide'); e.target.setAttribute('aria-pressed', on); e.target.textContent = on ? 'Show page list' : 'Bigger preview'; fit(); return; }
      if(e.target.id === 'ed-save') return saveEdits();
      if(e.target.id === 'ed-all') return go('changes');
      if(e.target.id === 'ed-discard'){ if(confirm('Discard the changes you have not saved?')){ work = clone(store.page_edits); select(null); reload(); paintStatus(); } return; }
      insClick(e);
    });
    $('#ed-ins').addEventListener('input', insInput);
    $('#ed-ins').addEventListener('change', insChange);
    $('#ed-page').addEventListener('change', e => go('page:' + e.target.value));
    document.addEventListener('keydown', e => {
      if($('#tab-content').hidden || pane.indexOf('page:') !== 0) return;
      if((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 's'){ e.preventDefault(); if(dirty()) saveEdits(); }
      else if(e.key === 'Escape' && sel) select(null);
    });
    window.addEventListener('beforeunload', e => { if(dirty()){ e.preventDefault(); e.returnValue = ''; } });
  }
  // The preview is drawn at a real screen width (1280px desktop, 390px phone) and scaled to fit the space,
  // so the page looks the way visitors see it instead of collapsing to its tablet layout.
  function fit(){
    const st = $('#ed-stage'); if(!st || !frame || !st.clientWidth) return;
    const phone = device === 'phone', W = phone ? 390 : 1280, pad = phone ? 28 : 0;
    const k = Math.min(1, (st.clientWidth - (phone ? 24 : 0)) / W);
    frame.style.width = W + 'px'; frame.style.height = Math.round((st.clientHeight - pad) / k) + 'px';
    frame.style.transform = 'translateX(-50%) scale(' + k + ')';
  }
  const urlOf = p => '../' + (p === '/' ? '' : p.slice(1) + '/') + 'index.html';
  function openPage(){
    const label = (PAGES.find(x => x[0] === page) || [page, page])[1];
    $('#ed-name').textContent = label; $('#ed-open').href = urlOf(page); fit();
    select(null); keepScroll = 0; reload();
  }
  function reload(){
    try{ if(frame.contentWindow && doc) keepScroll = frame.contentWindow.scrollY || 0; }catch(e){}
    doc = null; ED = null; $('#ed-load').hidden = false; frame.dataset.loaded = '';
    frame.src = urlOf(page) + '?crt_edit=1&t=' + Date.now();
  }
  function onFrame(){
    let w = null; try{ w = frame.contentWindow; doc = frame.contentDocument; ED = w.__CRT_EDITOR; }catch(e){ doc = null; }
    $('#ed-load').hidden = true;
    if(!doc || !ED){ $('#ed-ins').innerHTML = '<p class="muted small">This page can’t be edited here yet. Upload the latest website files first, then try again.</p>'; return; }
    frame.dataset.loaded = '1';
    const st = doc.createElement('style');
    st.textContent = '[data-crt-h]{outline:2px dashed #dd1c5f!important;outline-offset:3px!important;cursor:pointer!important}[data-crt-s]{outline:2px solid #dd1c5f!important;outline-offset:3px!important;box-shadow:0 0 0 6px rgba(221,28,95,.16)!important}.consent,.action-bar,.whatsapp-float,.mobile-booking{display:none!important}*{scroll-behavior:auto!important}[data-crt-pulse] :is(h1,h2,h3,p,li,.btn,img,figcaption,summary,small,strong){outline:1.5px dashed rgba(221,28,95,.55);outline-offset:2px}';
    doc.head.appendChild(st);
    const again = () => { if(ED && doc) { ED.stamp(); ED.apply(listFor(page)); } };
    doc.documentElement.setAttribute('data-crt-pulse', ''); setTimeout(() => { if(doc) doc.documentElement.removeAttribute('data-crt-pulse'); }, 2400);
    if(window.CRT_FOCUS && ED.focus) window.CRT_FOCUS.load().then(m => { if(ED && ED.focus) ED.focus(m); }).catch(() => {});   // the saved crops, also in the demo
    again(); setTimeout(again, 700); setTimeout(() => { again(); if(!sel) paintIns(); }, 2200);
    if(keepScroll) w.scrollTo(0, keepScroll);
    doc.addEventListener('mousemove', e => { const u = unitAt(e); setHover(u ? u.el : null); }, true);
    doc.addEventListener('mouseleave', () => setHover(null), true);
    ['click', 'submit', 'mousedown', 'auxclick'].forEach(t => doc.addEventListener(t, e => {
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      if(t === 'click'){ const u = unitAt(e); select(u); }
    }, true));
    paintIns(); paintStatus();
  }
  function setHover(el){ if(hover === el) return; if(hover) hover.removeAttribute('data-crt-h'); hover = el && !(sel && sel.el === el) ? el : null; if(hover) hover.setAttribute('data-crt-h', ''); }
  function unitAt(e){
    const t = e.target; if(!t || t.nodeType !== 1 || !ED) return null;
    if(t.tagName === 'IMG') return {type: 'img', el: t};
    let node = null, r = null;
    try{
      if(doc.caretRangeFromPoint) r = doc.caretRangeFromPoint(e.clientX, e.clientY);
      else if(doc.caretPositionFromPoint){ const p = doc.caretPositionFromPoint(e.clientX, e.clientY); if(p) r = {startContainer: p.offsetNode}; }
    }catch(err){}
    if(r && r.startContainer && r.startContainer.nodeType === 3 && r.startContainer.nodeValue.trim() && t.contains(r.startContainer)) node = r.startContainer;
    if(!node) node = [...t.childNodes].find(n => n.nodeType === 3 && n.nodeValue.trim()) || null;
    if(!node){
      const img = t.querySelector(':scope > img, :scope > picture > img');
      if(img && !t.textContent.trim()) return {type: 'img', el: img};
      if(t.closest('a,button')){ const tn = ED.textNodes(t.closest('a,button')); if(tn.length) node = tn[0]; }
    }
    if(!node || !node.parentElement || node.parentElement.closest('script,style,svg')) return null;
    return {type: 'text', el: node.parentElement};
  }
  function select(u){
    if(sel && sel.el) sel.el.removeAttribute('data-crt-s');
    sel = u || null;
    if(sel){
      setHover(null); sel.el.setAttribute('data-crt-s', '');
      if(sel.type === 'text'){
        sel.nodes = [...sel.el.childNodes].filter(n => n.nodeType === 3 && n.nodeValue.trim());
        sel.nodes.forEach(n => { if(n._crtFrom === undefined) n._crtFrom = ED.norm(n.nodeValue); });
        sel.a = sel.el.closest('a[href]');
        if(sel.a && sel.a._crtFrom === undefined) sel.a._crtFrom = ED.keyOfLink(sel.a);
      } else if(sel.el._crtFrom === undefined) sel.el._crtFrom = ED.keyOfImg(sel.el);
      const keys = sel.type === 'img' ? [['img', sel.el._crtFrom]] : sel.nodes.map(n => ['text', n._crtFrom]).concat(sel.a ? [['link', sel.a._crtFrom]] : []);
      const had = keys.map(([k, f]) => getEdit(k, f)).find(Boolean);
      sel.scope = had ? had.scope : (sel.el.closest('header,footer,.site-header,.footer,.mm-panel,.nav-links,.season-bar') ? '*' : page);
    }
    paintIns();
  }
  const kindOf = el => { const t = el.tagName; return /^H[1-6]$/.test(t) ? 'Heading' : (el.closest('a.btn,button,.btn') ? 'Button' : (el.closest('a') ? 'Link' : (t === 'LI' ? 'List item' : 'Text'))); };
  function paintIns(){
    const box = $('#ed-ins'); if(!box) return;
    if(!sel){
      const edits = listFor(page), imgs = doc ? $$('img', doc).filter(i => i.getAttribute('src') && i.getBoundingClientRect().width > 40) : [];
      box.innerHTML = `
        <h2>Edit this page</h2>
        <p class="muted small">Click any heading, sentence, button or photo in the preview to change it. Nothing is live until you press <b>Save changes</b>.</p>
        ${ro ? '<p class="notice small">Only admins can change content. You can look around.</p>' : ''}
        <h3>Changes on this page <em>${edits.length}</em></h3>
        ${edits.length ? '<ul class="ch-list">' + edits.map(e => chRow(e, (work['*'] || []).includes(e) ? '*' : page)).join('') + '</ul>' : '<p class="muted small">No changes yet. The page shows its original content.</p>'}
        <details class="ins-imgs"><summary>Photos on this page <em>${imgs.length}</em></summary><div class="img-grid">${imgs.map((im, i) => `<button type="button" data-pick-img="${i}" title="${esc(im.alt || 'Photo')}"><img src="${esc(im.currentSrc || im.src)}" alt="" loading="lazy"></button>`).join('')}</div></details>`;
      box._imgs = imgs; return;
    }
    const scopeUi = `<fieldset class="ins-scope"><legend>Show this change on</legend>
      <label><input type="radio" name="scope" value="page"${sel.scope !== '*' ? ' checked' : ''}${ro ? ' disabled' : ''}> This page only</label>
      <label><input type="radio" name="scope" value="*"${sel.scope === '*' ? ' checked' : ''}${ro ? ' disabled' : ''}> <span>Every page<small>Best for the menu, the footer and buttons that repeat.</small></span></label></fieldset>`;
    if(sel.type === 'img'){
      const from = sel.el._crtFrom, ed = getEdit('img', from);
      box.innerHTML = `<div class="ins-head"><span class="ins-type">Photo</span><button type="button" class="link small" data-ins="done">Done</button></div>
        <div class="ins-thumb"><img src="${esc(sel.el.currentSrc || sel.el.src)}" alt=""></div>
        ${window.CRT_FOCUS ? '<button type="button" class="btn small ins-crop" data-ins="crop">Adjust crop</button><p class="muted small">Choose what stays in view when the website trims this photo to fit.</p>' : ''}
        <label class="btn secondary small upload-btn${ro ? ' is-off' : ''}">Replace photo<input type="file" accept="image/jpeg,image/png,image/webp" data-ins="file" hidden${ro ? ' disabled' : ''}></label>
        <p class="muted small">JPG, PNG or WebP. It is resized for the web automatically. Use a photo with the same shape as the one it replaces.</p>
        <div class="field"><label for="ins-src">Or paste a photo address</label><input id="ins-src" data-ins="src" type="url" inputmode="url" placeholder="https://…" value="${ed ? esc(ed.to) : ''}"${ro ? ' disabled' : ''}></div>
        ${ed ? '<p class="ins-orig">This photo was changed. <button type="button" class="link" data-ins="reset-img">Restore the original</button></p>' : ''}${scopeUi}`;
      return;
    }
    const rows = sel.nodes.map((n, i) => {
      const cur = ED.norm(n.nodeValue), changed = cur !== n._crtFrom;
      return `<div class="field"><label for="ins-t${i}">${sel.nodes.length > 1 ? 'Line ' + (i + 1) : esc(kindOf(sel.el))}</label>
        <textarea id="ins-t${i}" data-ins="text" data-i="${i}" rows="${Math.min(8, Math.max(2, Math.ceil(cur.length / 34)))}"${ro ? ' disabled' : ''}>${esc(cur)}</textarea>
        <p class="ins-orig" data-orig="${i}"${changed ? '' : ' hidden'}>Original: “${esc(n._crtFrom)}” <button type="button" class="link" data-ins="reset-text" data-i="${i}">Restore</button></p></div>`;
    }).join('');
    let link = '';
    if(sel.a){
      const from = sel.a._crtFrom, ed = getEdit('link', from);
      link = `<div class="field"><label for="ins-link">Where it goes</label><input id="ins-link" data-ins="link" value="${esc(ed ? ed.to : pretty(from))}" spellcheck="false"${ro ? ' disabled' : ''}>
        <small class="muted">A page on this site starts with /, for example /contact. Other sites start with https://</small>
        <p class="ins-orig" data-orig="link"${ed ? '' : ' hidden'}>Original: ${esc(pretty(from))} <button type="button" class="link" data-ins="reset-link">Restore</button></p></div>`;
    }
    box.innerHTML = `<div class="ins-head"><span class="ins-type">${esc(kindOf(sel.el))}</span><button type="button" class="link small" data-ins="done">Done</button></div>${rows}${link}${scopeUi}`;
    const ta = $('textarea', box); if(ta && !ro){ ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length); }
  }
  const pretty = k => String(k).replace(/(^|\/)index\.html(?=$|[?#])/, '$1');   // '/contact/index.html' reads as '/contact/'
  const short = (s, n) => { s = String(s); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
  function chRow(e, scope){
    const what = e.k === 'img' ? 'Photo' : e.k === 'link' ? 'Link' : 'Text';
    return `<li><span class="ch-kind">${what}${scope === '*' ? ' · every page' : ''}</span><span class="ch-from">${esc(short(e.k === 'img' ? e.from.split('/').pop() : e.k === 'link' ? pretty(e.from) : e.from, 60))}</span><span class="ch-to">${esc(short(e.k === 'img' ? 'New photo' : e.to, 80))}</span>${ro ? '' : `<button type="button" class="link small" data-undo="${esc(scope)}" data-k="${e.k}" data-from="${esc(e.from)}">Undo</button>`}</li>`;
  }
  function insInput(e){
    const t = e.target; if(!sel || ro) return;
    if(t.dataset.ins === 'text'){
      const n = sel.nodes[+t.dataset.i], from = n._crtFrom, to = ED.norm(t.value) || from;
      putEdit('text', from, to, sel.scope);
      ED.apply([{k: 'text', from, to}]);
      const o = $(`[data-orig="${t.dataset.i}"]`); if(o) o.hidden = to === from;
    } else if(t.dataset.ins === 'link'){
      const from = sel.a._crtFrom; let to = t.value.trim(); if(to === pretty(from)) to = from;
      const ok = /^(\/(?!\/)|https?:\/\/|mailto:|tel:|#)/.test(to);
      t.classList.toggle('is-bad', !ok && to !== '');
      if(ok || to === from){ putEdit('link', from, to, sel.scope); const o = $('[data-orig="link"]'); if(o) o.hidden = to === from; }
    }
  }
  async function insChange(e){
    const t = e.target; if(!sel || ro) return;
    if(t.name === 'scope'){
      sel.scope = t.value === '*' ? '*' : page;
      const keys = sel.type === 'img' ? [['img', sel.el._crtFrom]] : sel.nodes.map(n => ['text', n._crtFrom]).concat(sel.a ? [['link', sel.a._crtFrom]] : []);
      keys.forEach(([k, f]) => { const ed = getEdit(k, f); if(ed) putEdit(k, f, ed.to, sel.scope); });
    } else if(t.dataset.ins === 'file' && t.files[0]){
      const f = t.files[0];
      if(f.size > 25e6){ A.toast('That file is over 25 MB. Choose a smaller photo.'); return; }
      try{ A.toast('Uploading the photo…'); const url = await upload(await shrink(f), 'site'); setImg(url); A.toast('Photo replaced. Press Save changes to publish it.'); }catch(err){ A.fail(err); }
    } else if(t.dataset.ins === 'src'){
      const v = t.value.trim(); if(/^https:\/\//.test(v)) setImg(v); else if(v) A.toast('The address needs to start with https://');
    }
  }
  function setImg(url){
    const from = sel.el._crtFrom; putEdit('img', from, url, sel.scope);
    sel.el.removeAttribute('srcset'); sel.el.removeAttribute('sizes'); sel.el.src = url; paintIns();
  }
  function insClick(e){
    const t = e.target;
    const pick = t.closest('[data-pick-img]');
    if(pick){ const im = ($('#ed-ins')._imgs || [])[+pick.dataset.pickImg]; if(im){ im.scrollIntoView({block: 'center'}); select({type: 'img', el: im}); } return; }
    const un = t.closest('[data-undo]');
    if(un){ dropEdit(un.dataset.undo, un.dataset.k, un.dataset.from); if(pane === 'changes') paintChanges(); select(null); if(frame.dataset.loaded) reload(); return; }
    const a = t.dataset && t.dataset.ins; if(!a) return;
    if(a === 'done') return select(null);
    if(a === 'crop' && sel && window.CRT_FOCUS) return window.CRT_FOCUS.open(sel.el.currentSrc || sel.el.src, {el: sel.el, place: ED && ED.placeOf ? ED.placeOf(sel.el) : '', readOnly: ro, onChange: m => { if(ED && ED.focus) ED.focus(m); }});
    if(ro || !sel) return;
    if(a === 'reset-text'){ const n = sel.nodes[+t.dataset.i]; putEdit('text', n._crtFrom, n._crtFrom, sel.scope); ED.apply([{k: 'text', from: n._crtFrom, to: n._crtFrom}]); paintIns(); }
    else if(a === 'reset-link'){ putEdit('link', sel.a._crtFrom, sel.a._crtFrom, sel.scope); paintIns(); }
    else if(a === 'reset-img'){ putEdit('img', sel.el._crtFrom, sel.el._crtFrom, sel.scope); select(null); reload(); }
  }
  function paintStatus(){
    const d = dirty(), s = $('#ed-status'); if(!s) return;
    s.textContent = d ? 'Changes not saved yet' : (countFor(page) ? countFor(page) + ' saved change' + (countFor(page) === 1 ? '' : 's') + ' on this page' : '');
    s.classList.toggle('is-dirty', d);
    const all = $('#ed-all'); if(all){ const n = total(); all.hidden = !n; all.textContent = 'All changes (' + n + ')'; }
    $('#ed-save').disabled = !d || ro; $('#ed-save').title = ro ? 'Only admins can save' : (d ? 'Publish your changes (Ctrl or Cmd + S)' : 'No changes yet'); $('#ed-discard').hidden = !d;
    paintNav();
  }
  async function saveEdits(){
    if(ro) return;
    const b = $('#ed-save'); b.disabled = true; b.textContent = 'Saving…';
    try{ await save('page_edits', work); A.toast(A.LIVE ? 'Saved. Your changes are live on the website.' : 'Saved in this demo. Nothing was published.'); }
    catch(e){ A.fail(e); }
    b.textContent = 'Save changes'; paintStatus(); if(!sel) paintIns();
  }
  function paintChanges(){
    const p = $('[data-cpane="changes"]'); if(!p) return;
    const scopes = Object.keys(work).filter(k => (work[k] || []).length).sort((a, b) => a === '*' ? -1 : b === '*' ? 1 : a.localeCompare(b));
    const name = k => k === '*' ? 'Every page' : (PAGES.find(x => x[0] === k) || [k, k])[1];
    p.innerHTML = `<button type="button" class="link small" data-go-back="1">← Back to the page editor</button><h2>All changes</h2><p class="muted small">Every word, link and photo you have changed from the original website. Undo one to bring the original back.${dirty() ? ' <b>Some changes are not saved yet.</b>' : ''}</p>` +
      (scopes.length ? scopes.map(k => `<h3>${esc(name(k))} <em>${work[k].length}</em></h3><ul class="ch-list">${work[k].map(e => chRow(e, k)).join('')}</ul>`).join('') +
        (ro ? '' : `<div class="row-end"><button type="button" class="btn small" data-set="save-changes"${dirty() ? '' : ' disabled'}>Save</button></div>`)
        : '<p class="muted small">Nothing has been changed. The website shows its original content.</p>');
  }

  // ------------------------------------------------------------------ whole-site settings
  function buildSettings(){
    const st = store.site_settings || {}, c = st.contact || {}, an = st.announcement;
    const dis = ro ? ' disabled' : '';
    $('#set-business').innerHTML = `
      <h2>Contact details</h2>
      <p class="muted small">Shown in the header, footer, contact page and every WhatsApp button. Leave a field empty to keep the current one.</p>
      <div class="price-grid">
        <div class="field"><label for="set-phone">Phone and WhatsApp number</label><input id="set-phone" inputmode="tel" placeholder="+250 796 356 035" value="${esc(c.phone || '')}"${dis}><small class="muted">With the country code, written the way visitors should see it.</small></div>
        <div class="field"><label for="set-email">Public email</label><input id="set-email" type="email" placeholder="hello@crt.rw" value="${esc(c.email || '')}"${dis}><small class="muted">The address shown to visitors. Enquiry forms keep going to the team inbox.</small></div>
      </div>
      <div class="row-end"><button type="button" class="btn" data-set="save-contact"${dis}>Save contact details</button></div>`;
    const mode = !an ? 'auto' : (an.on === false ? 'off' : 'on');
    $('[data-cpane="announcement"]').innerHTML = `
      <h2>Announcement bar</h2>
      <p class="muted small">The thin message under the menu. One bar for the whole site: a live offer switched to “Show in the bar” (Content → Offers) takes its place while it runs.</p>
      <div class="field"><label for="set-an-mode">What to show</label><select id="set-an-mode"${dis}>
        <option value="auto"${mode === 'auto' ? ' selected' : ''}>The seasonal message built into the site</option>
        <option value="on"${mode === 'on' ? ' selected' : ''}>My own message</option>
        <option value="off"${mode === 'off' ? ' selected' : ''}>Nothing</option></select></div>
      <div id="set-an-own"${mode === 'on' ? '' : ' hidden'}>
        <div class="field"><label for="set-an-text">Message</label><input id="set-an-text" maxlength="120" placeholder="Book your 2027 wedding now and save 30%." value="${esc(an && an.text || '')}"${dis}><small class="muted">One short sentence, up to 120 characters.</small></div>
        <div class="price-grid">
          <div class="field"><label for="set-an-link">Link words (optional)</label><input id="set-an-link" maxlength="40" placeholder="See the offer" value="${esc(an && an.link || '')}"${dis}></div>
          <div class="field"><label for="set-an-href">Link goes to</label><input id="set-an-href" placeholder="/offer-wedding-early-booking" value="${esc(an && an.href || '')}"${dis}></div>
        </div>
      </div>
      <div class="row-end"><button type="button" class="btn" data-set="save-announcement"${dis}>Save announcement</button></div>`;
    paintChanges();
  }
  async function saveSettings(patch, msg){
    const next = Object.assign(clone(store.site_settings), patch);
    Object.keys(next).forEach(k => { if(next[k] == null) delete next[k]; });
    try{ await save('site_settings', next); buildSettings(); A.toast(A.LIVE ? msg : 'Saved in this demo. Nothing was published.'); }catch(e){ A.fail(e); }
  }
  // ------------------------------------------------------------------ prices
  // Every amount on the website, from data/prices.json (made by tools/price_catalogue.py). A new amount changes it
  // everywhere it appears: pages, menus, guides, offers, the Book page, the project builder and the print shop.
  // Saved as site_content.price_map {old: new}. The wedding early-booking prices (30% off) follow their package.
  let priceCat = null;
  const fmtN = n => Number(n).toLocaleString('en-US');
  const priceCount = () => priceCat ? Object.keys(priceCat).length : '';
  const EARLY = {840000: 1200000, 1400000: 2000000, 2100000: 3000000, 3150000: 4500000};
  function priceMap(){
    if(store.price_map) return store.price_map;
    const v2 = store.prices_v2, B = {basic: 1200000, standard: 2000000, premium: 3000000, vip: 4500000}, m = {};
    if(v2) Object.keys(B).forEach(k => { if(+v2[k] > 0 && +v2[k] !== B[k]) m[B[k]] = +v2[k]; });
    return m;
  }
  async function buildPrices(){
    const panel = $('[data-cpane="prices"]'); if(!panel) return;
    if(!priceCat){ try{ priceCat = await (await fetch('../data/prices.json', {cache: 'no-cache'})).json(); }catch(e){ priceCat = {}; } }
    const m = priceMap(), dis = ro ? ' disabled' : '';
    const order = ['Weddings', 'Events', 'Business & offers', 'Print'];
    const groups = order.map(g => [g, Object.keys(priceCat).filter(a => priceCat[a].section === g)]).filter(([, a]) => a.length);
    const row = a => {
      const info = priceCat[a], names = [...new Set(info.uses.map(u => u.label))], pages = [...new Set(info.uses.map(u => u.page))];
      const cur = m[a] || +a, early = EARLY[a];
      const shared = names.length > 1;
      return `<div class="pr-row${+cur !== +a ? ' is-changed' : ''}" data-amt="${a}">
        <div class="pr-what"><b>${esc(names[0] || fmtN(a) + ' RWF')}</b>
          <small>${shared ? 'Also: ' + esc(names.slice(1, 6).join(' · ')) + (names.length > 6 ? ' and more' : '') + '<br>' : ''}On ${pages.length} page${pages.length === 1 ? '' : 's'}: ${esc(pages.slice(0, 5).join(', '))}${pages.length > 5 ? '…' : ''}</small>
          ${shared && !early ? '<span class="pr-shared">Shared amount: changing it changes all of these</span>' : ''}
          ${early ? `<span class="pr-shared is-auto">Early booking (30% off ${fmtN(early)}): follows that package automatically</span>` : ''}</div>
        <label class="pr-input"><span class="sr-only">New amount</span><input type="text" inputmode="numeric" value="${fmtN(early && m[early] ? Math.round(m[early] * 0.7 / 1000) * 1000 : cur)}" data-orig="${a}"${early ? ' disabled' : dis}><em>RWF</em></label>
        ${!early && +cur !== +a && !ro ? `<button type="button" class="link small" data-set="price-reset" data-amt="${a}">Back to ${fmtN(a)}</button>` : '<span></span>'}
      </div>`;
    };
    panel.innerHTML = `<h2>Prices</h2>
      <p class="muted small">Every price on the website. Type a new amount and save: it changes everywhere that amount appears, on every page, the Book page, the project builder and the price guides. Rows marked “Shared amount” are used by more than one thing.</p>
      ${groups.map(([g, amts]) => `<h3>${esc(g)} <em>${amts.length}</em></h3><div class="pr-list">${amts.map(row).join('')}</div>`).join('')}
      ${ro ? '' : '<div class="row-end"><button type="button" class="btn" data-set="save-prices2">Save prices</button></div>'}
      <div id="prices-form" hidden></div>`;
    paintNav();
  }
  async function savePrices2(){
    const m = Object.assign({}, priceMap()), changed = [];
    $$('.pr-row input:not([disabled])').forEach(inp => {
      const a = +inp.dataset.orig, v = parseInt(inp.value.replace(/\D/g, ''), 10);
      if(!(v > 0)){ inp.classList.add('is-bad'); return; }
      const before = m[a] || a;
      if(v === a) delete m[a]; else m[a] = v;
      if(v !== before) changed.push([a, v]);
    });
    if($$('.pr-row input.is-bad').length){ A.toast('Every price needs a number'); return; }
    if(!changed.length){ A.toast('No price changed'); return; }
    const sharedHit = changed.filter(([a]) => new Set((priceCat[a] || {uses: []}).uses.map(u => u.label)).size > 1);
    if(sharedHit.length && !confirm('Some of these amounts are shared, so all of these change:\n\n' + sharedHit.map(([a, v]) => fmtN(a) + ' → ' + fmtN(v) + ': ' + [...new Set(priceCat[a].uses.map(u => u.label))].slice(0, 6).join(', ')).join('\n') + '\n\nSave?')) return;
    try{
      await save('price_map', m); store.price_map = m;
      try{ localStorage.setItem('crt-price-map', JSON.stringify(m)); }catch(e){}
      A.toast(A.LIVE ? 'Prices saved. Live on every page.' : 'Saved in this demo. Nothing was published.');
      buildPrices();
    }catch(e){ A.fail(e); }
  }

  // ------------------------------------------------------------------ client logos
  const logoLink = l => { const m = store.client_logos || {}; return (l[0] in m) ? String(m[l[0]] || '') : l[3]; };
  async function cases(){
    if(caseList) return caseList;
    try{
      const d = await (await fetch('../data/case-studies.json', {cache: 'no-cache'})).json();
      caseList = Object.keys(d).map(slug => { const f = (d[slug] && d[slug].fields) || {}; return ['/' + slug + '/', (d[slug] && d[slug].title) || f.client || f.headline || slug.replace(/^work-/, '').replace(/-/g, ' ')]; })
        .sort((a, b) => a[1].localeCompare(b[1]));
    }catch(e){ caseList = []; }
    return caseList;
  }
  // ---- Client logos (2026-11-24): the whole list is editable. site_content.client_list =
  // [{id, name, src, link, white, hidden}], in order. Shown on the home page, About, Book and Offers.
  // Until it is saved once, the built-in seven (with the links saved in client_logos) are used.
  const srcAdmin = u => /^(https?:|blob:|data:)/.test(u || '') ? u : '..' + (String(u || '').startsWith('/') ? '' : '/') + u;
  function defaultLogos(){
    return LOGOS.map(l => ({id: l[0], name: l[1], src: l[2].replace(/^\.\./, ''), link: logoLink(l), white: l[0] === 'norrsken', hidden: false}));
  }
  let logoDraft = null, logoBound = false;
  async function buildLogos(){
    const p = $('[data-cpane="logos"]'); if(!p) return;
    const list = await cases(), dis = ro ? ' disabled' : '';
    if(!logoDraft) logoDraft = clone(Array.isArray(store.client_list) ? store.client_list : defaultLogos());
    const rows = logoDraft.map((l, i) => {
      const cur = l.link || '', isCase = list.some(c => c[0] === cur), custom = !!cur && !isCase, local = cur && cur[0] === '/';
      const opts = '<option value="">No link (logo only)</option>' +
        '<optgroup label="Case studies">' + list.map(c => `<option value="${esc(c[0])}"${c[0] === cur ? ' selected' : ''}>${esc(c[1])}</option>`).join('') + '</optgroup>' +
        `<option value="custom"${custom ? ' selected' : ''}>Another page or website…</option>`;
      return `<li class="lg-row${l.hidden ? ' is-hidden' : ''}" data-i="${i}">
        <span class="lg-move">${ro ? '' : `<button type="button" class="ph-btn" data-lgo="up" aria-label="Move ${esc(l.name || 'logo')} up"${i ? '' : ' disabled'}>↑</button><button type="button" class="ph-btn" data-lgo="down" aria-label="Move ${esc(l.name || 'logo')} down"${i < logoDraft.length - 1 ? '' : ' disabled'}>↓</button>`}</span>
        <label class="lg-thumb${l.white ? ' is-white' : ''}" title="${ro ? '' : 'Upload a new logo'}">${l.src ? `<img src="${esc(srcAdmin(l.src))}" alt="">` : '<span class="lg-up">+ Upload logo</span>'}${ro ? '' : '<input type="file" accept="image/svg+xml,image/png,image/webp" data-lgo="file" hidden>'}</label>
        <span class="lg-name"><input data-lgo="name" value="${esc(l.name || '')}" placeholder="Client name" aria-label="Client name"${dis}>
          <span class="lg-flags"><label><input type="checkbox" data-lgo="white"${l.white ? ' checked' : ''}${dis}> White logo</label><label><input type="checkbox" data-lgo="show"${l.hidden ? '' : ' checked'}${dis}> Show on the site</label></span></span>
        <span class="lg-pick"><select data-lgo="pick" aria-label="Where the logo goes"${dis}>${opts}</select>
        <input data-lgo="url" type="text" inputmode="url" placeholder="/work-… or https://…" value="${custom ? esc(cur) : ''}" aria-label="Link"${custom ? '' : ' hidden'}${dis}>
        ${local ? `<a class="link small" href="${esc('..' + cur)}" target="_blank" rel="noopener">Open the page ↗</a>` : ''}</span>
        ${ro ? '' : '<button type="button" class="link danger small" data-lgo="remove">Remove</button>'}
      </li>`;
    }).join('');
    p.innerHTML = `<h2>Client logos</h2>
      <p class="muted small">Shown on the home page, About, Book and Offers, in this order. Upload an SVG or a PNG with a see-through background. Tick “White logo” for a logo drawn in white, so it shows on light backgrounds too. A logo with a link shows “See the work ›” on the home page.</p>
      <ul class="lg-list">${rows || '<li class="lg-row"><span class="muted small">No logos yet.</span></li>'}</ul>
      <div class="row-end">${ro ? '' : '<button type="button" class="btn secondary" data-lgo="add">+ Add a client</button>'}<a class="link small" href="/" target="_blank" rel="noopener">See it on the home page ↗</a>${ro ? '' : '<button type="button" class="btn" data-lgo="save">Save logos</button>'}</div>`;
    if(!logoBound && !ro){
      logoBound = true;
      const row = t => { const r = t.closest('.lg-row'); return r && r.dataset.i != null ? logoDraft[+r.dataset.i] : null; };
      p.addEventListener('input', e => { const l = row(e.target); if(!l) return; const a = e.target.dataset.lgo;
        if(a === 'name') l.name = e.target.value; if(a === 'url') l.link = e.target.value.trim(); });
      p.addEventListener('change', async e => {
        const t = e.target, a = t.dataset.lgo, l = row(t); if(!a || !l) return;
        if(a === 'white'){ l.white = t.checked; return buildLogos(); }
        if(a === 'show'){ l.hidden = !t.checked; return buildLogos(); }
        if(a === 'pick'){ l.link = t.value === 'custom' ? '' : t.value; buildLogos().then(() => { if(t.value === 'custom'){ const u = $(`.lg-row[data-i="${logoDraft.indexOf(l)}"] [data-lgo="url"]`, p); if(u){ u.hidden = false; u.focus(); } } }); return; }
        if(a === 'file' && t.files[0]){
          const f = t.files[0]; if(f.size > 2e6){ A.toast('That file is over 2 MB. Use an SVG or a smaller PNG.'); return; }
          try{ A.toast('Uploading…'); l.src = await upload(f, 'site/clients'); if(!l.name) l.name = f.name.replace(/\.[a-z0-9]+$/i, '').replace(/[-_]+/g, ' '); buildLogos(); A.toast('Logo uploaded. Press Save logos to publish.'); }catch(err){ A.fail(err); }
        }
      });
      p.addEventListener('click', async e => {
        const b = e.target.closest('[data-lgo]'); if(!b || b.tagName === 'INPUT' || b.tagName === 'SELECT') return;
        const a = b.dataset.lgo, l = row(b), i = l ? logoDraft.indexOf(l) : -1;
        if(a === 'up' && i > 0){ logoDraft.splice(i - 1, 0, logoDraft.splice(i, 1)[0]); buildLogos(); }
        else if(a === 'down' && i > -1 && i < logoDraft.length - 1){ logoDraft.splice(i + 1, 0, logoDraft.splice(i, 1)[0]); buildLogos(); }
        else if(a === 'remove' && l){ if(confirm('Remove ' + (l.name || 'this logo') + ' from the website?')){ logoDraft.splice(i, 1); buildLogos(); } }
        else if(a === 'add'){ logoDraft.push({id: 'c' + Date.now().toString(36), name: '', src: '', link: '', white: false, hidden: false}); await buildLogos(); const fi = p.querySelector('.lg-row:last-child [data-lgo="file"]'); if(fi) fi.click(); }
        else if(a === 'save') saveLogos();
      });
    }
  }
  async function saveLogos(){
    const bad = logoDraft.find(l => !String(l.name || '').trim() || !l.src);
    if(bad){ A.toast(bad.src ? 'Give each logo the client’s name.' : 'Upload a logo for ' + (bad.name || 'the new client') + ', or remove it.'); return; }
    const badLink = logoDraft.find(l => l.link && !/^(\/(?!\/)|https:\/\/)/.test(l.link));
    if(badLink){ A.toast('The link for ' + badLink.name + ' needs to start with / (a page on this site) or https://'); return; }
    const list = logoDraft.map(l => { let v = l.link || ''; if(v && v[0] === '/' && !/[?#.]/.test(v) && !v.endsWith('/')) v += '/';
      return {id: l.id, name: String(l.name).trim().slice(0, 80), src: l.src, link: v, white: !!l.white, hidden: !!l.hidden}; });
    try{ await save('client_list', list); logoDraft = clone(list); await buildLogos(); paintNav(); A.toast(A.LIVE ? 'Logos saved. Live on the website.' : 'Saved in this demo. Nothing was published.'); }catch(err){ A.fail(err); }
  }
  async function onSettings(e){
    const a = e.target.dataset && e.target.dataset.set; if(!a || ro) return;
    if(a === 'save-prices2'){ return savePrices2(); }
    if(a === 'price-reset'){ const inp = $(`.pr-row[data-amt="${e.target.dataset.amt}"] input`); if(inp){ inp.value = fmtN(e.target.dataset.amt); } return; }
    if(a === 'save-changes') return saveEdits().then(paintChanges);
    if(a === 'save-contact'){
      const phone = $('#set-phone').value.trim(), email = $('#set-email').value.trim();
      if(phone && phone.replace(/\D/g, '').length < 10){ A.toast('Write the full number with the country code, for example +250 796 356 035'); return; }
      if(email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)){ A.toast('That email address does not look right'); return; }
      return saveSettings({contact: (phone || email) ? {phone, email} : null}, 'Contact details saved. Live on the website.');
    }
    if(a === 'save-announcement'){
      const mode = $('#set-an-mode').value;
      if(mode === 'auto') return saveSettings({announcement: null}, 'Saved. The site shows its seasonal message.');
      if(mode === 'off') return saveSettings({announcement: {on: false}}, 'Saved. The announcement bar is off.');
      const text = $('#set-an-text').value.trim(), link = $('#set-an-link').value.trim(), href = $('#set-an-href').value.trim();
      if(!text){ A.toast('Write the message first'); return; }
      if(href && !/^(\/(?!\/)|https:\/\/)/.test(href)){ A.toast('The link needs to start with / or https://'); return; }
      if(link && !href){ A.toast('Add where the link goes, or remove the link words'); return; }
      return saveSettings({announcement: {on: true, text, link, href}}, 'Announcement saved. Live on the home page.');
    }
  }
  async function onSettingsChange(e){
    if(e.target.dataset && e.target.dataset.lg === 'pick'){
      const r = e.target.closest('.lg-row'), url = r.querySelector('[data-lg="url"]'), custom = e.target.value === 'custom';
      url.hidden = !custom; if(custom) url.focus();
      const st = r.querySelector('.lg-state'), on = custom ? !!url.value.trim() : !!e.target.value;
      st.textContent = on ? 'Clickable' : 'Not clickable'; st.classList.toggle('is-on', on);
      const t = r.querySelector('.lg-test'); if(!custom && e.target.value){ t.href = '..' + e.target.value; t.hidden = false; } else t.hidden = true;
      return;
    }
    if(e.target.id === 'set-an-mode'){ $('#set-an-own').hidden = e.target.value !== 'on'; return; }
  }

  // ------------------------------------------------------------------ boot
  async function start(){
    if(A || !window.CRT_ADMIN) return;
    A = window.CRT_ADMIN; esc = A.esc; ro = !A.isAdmin();
    try{ await load(); }catch(e){ A.fail(e); }
    build();
    if(window.CRT_CMS) window.CRT_CMS.start(A).then(paintNav);
    const main = $('#ct-main');
    const sb = $('#set-business'); if(sb){ sb.addEventListener('click', onSettings); sb.addEventListener('change', onSettingsChange); }
    if(main){ main.addEventListener('click', e => { if(!e.target.closest('[data-cpane="page"],[data-cpane="cms"]')){ insClick(e); onSettings(e); } }); main.addEventListener('change', e => { if(!e.target.closest('[data-cpane="cms"]')) onSettingsChange(e); }); }
    // counts in the side list follow the collections edited elsewhere on this tab
    const tl = $('#testimonials-list');
    if(tl && 'MutationObserver' in window) new MutationObserver(paintNav).observe(tl, {childList: true});
    setTimeout(paintNav, 1500);
  }
  document.addEventListener('crt:ready', start);
  if(window.CRT_ADMIN) start();
})();
