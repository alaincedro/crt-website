/* CRT admin: Content. Edit the words, buttons, links and photos of any page by clicking them in a live preview,
   plus the site-wide details (contact, announcement bar, home showreel).
   Plugs into admin.js through window.CRT_ADMIN. Saves to Supabase site_content (page_edits, site_settings),
   which site.js reads on every page. In demo mode nothing leaves this browser tab. */
(function(){
  'use strict';
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];
  const clone = o => JSON.parse(JSON.stringify(o || {}));
  const PAGES = [
    ['/', 'Home'], ['/business', 'For businesses'], ['/events', 'Events'], ['/weddings', 'Weddings'],
    ['/commercial-photography-video', 'Commercial photo & video'], ['/branding-graphic-design', 'Branding & design'],
    ['/social-media-content', 'Social media & content'], ['/web-digital', 'Web & digital'],
    ['/deals', 'Offers'], ['/work', 'Our work'], ['/about', 'About'], ['/contact', 'Contact'],
    ['/guides', 'Price guides'], ['/shop', 'Shop']
  ];
  const CACHE = 'crt-content-v1', DEMO = 'crt-demo-content';
  let A = null, esc = s => s, ro = true;
  let store = {page_edits: {}, site_settings: {}}, work = {};
  let pane = 'page:/', page = '/', device = 'desktop', find = '';
  let frame = null, doc = null, ED = null, sel = null, hover = null, keepScroll = 0;

  // ------------------------------------------------------------------ data
  async function load(){
    if(A.LIVE){
      const {data, error} = await A.sb.from('site_content').select('key,value').in('key', ['page_edits', 'site_settings']);
      if(error) throw error;
      (data || []).forEach(r => { store[r.key] = r.value || {}; });
    } else {
      try{ Object.assign(store, JSON.parse(sessionStorage.getItem(DEMO) || '{}')); }catch(e){}
    }
    store.page_edits = store.page_edits || {}; store.site_settings = store.site_settings || {};
    work = clone(store.page_edits);
  }
  async function save(key, value){
    if(A.LIVE){
      const {error} = await A.sb.from('site_content').upsert({key, value, updated_by: A.me.user_id});
      if(error) throw error;
    }
    store[key] = clone(value);
    try{
      if(!A.LIVE) sessionStorage.setItem(DEMO, JSON.stringify(store));
      else localStorage.setItem(CACHE, JSON.stringify(store));   // this browser sees the change at once
    }catch(e){}
  }
  async function upload(file, folder){
    if(!A.LIVE) return URL.createObjectURL(file);   // demo: local preview only
    const ext = (file.name.match(/\.[a-z0-9]+$/i) || [''])[0].toLowerCase() || (file.type === 'image/webp' ? '.webp' : '');
    const path = folder + '/' + Date.now() + '-' + Math.random().toString(36).slice(2, 8) + ext;
    const {error} = await A.sb.storage.from('media').upload(path, file, {upsert: true, contentType: file.type, cacheControl: '31536000'});
    if(error) throw error;
    return A.sb.storage.from('media').getPublicUrl(path).data.publicUrl;
  }
  // Photos are resized in the browser before upload, so a 12 MB camera file never reaches visitors.
  function shrink(file){
    return new Promise(res => {
      if(!/^image\/(jpeg|png|webp)$/.test(file.type)) return res(file);
      const img = new Image(), url = URL.createObjectURL(file);
      img.onload = () => {
        const k = Math.min(1, 2000 / Math.max(img.naturalWidth, img.naturalHeight));
        const c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url);
        c.toBlob(b => res(b && b.size < file.size ? new File([b], file.name.replace(/\.[a-z0-9]+$/i, '') + '.webp', {type: 'image/webp'}) : file), 'image/webp', .84);
      };
      img.onerror = () => { URL.revokeObjectURL(url); res(file); };
      img.src = url;
    });
  }

  // ------------------------------------------------------------------ edits model
  const listFor = p => [].concat(work['*'] || [], work[p] || []);
  const countFor = p => (work[p] || []).length;
  const total = () => Object.keys(work).reduce((n, k) => n + (work[k] || []).length, 0);
  const dirty = () => JSON.stringify(work) !== JSON.stringify(store.page_edits || {});
  function getEdit(k, from){
    for(const scope of ['*', page]){ const e = (work[scope] || []).find(x => x.k === k && x.from === from); if(e) return {scope, to: e.to}; }
    return null;
  }
  function putEdit(k, from, to, scope){
    ['*', page].forEach(s => { if(work[s]){ work[s] = work[s].filter(x => !(x.k === k && x.from === from)); if(!work[s].length) delete work[s]; } });
    if(to !== from && to !== ''){ (work[scope] = work[scope] || []).push({k, from, to}); }
    paintStatus();
  }
  function dropEdit(scope, k, from){
    if(work[scope]){ work[scope] = work[scope].filter(x => !(x.k === k && x.from === from)); if(!work[scope].length) delete work[scope]; }
    paintStatus();
  }

  // ------------------------------------------------------------------ shell
  function build(){
    const tab = $('#tab-content'); if(!tab || $('#ct-nav')) return;
    const head = tab.querySelector('.page-head');
    if(head) head.querySelector('div').innerHTML = '<h1>Content</h1><p class="muted">Change anything on the website. Saved changes are live the next time a page loads.</p>';
    const panels = $$(':scope > .panel', tab);
    const names = ['prices', 'packages', 'testimonials'];
    const wrap = document.createElement('div'); wrap.className = 'ct';
    wrap.innerHTML = '<nav class="ct-nav" id="ct-nav" aria-label="Content sections"></nav><div class="ct-main" id="ct-main"></div>';
    tab.appendChild(wrap);
    const main = $('#ct-main');
    main.insertAdjacentHTML('beforeend', '<div class="ct-pane" data-cpane="page" hidden></div>');
    panels.forEach((p, i) => { p.dataset.cpane = names[i] || 'x' + i; p.classList.add('ct-pane'); p.hidden = true; main.appendChild(p); });
    ['contact', 'announcement', 'showreel', 'changes'].forEach(n => main.insertAdjacentHTML('beforeend', `<div class="panel ct-pane" data-cpane="${n}" hidden></div>`));
    buildEditor(); buildSettings();
    $('#ct-nav').addEventListener('click', e => { const b = e.target.closest('[data-go]'); if(b) go(b.dataset.go); });
    $('#ct-nav').addEventListener('input', e => { if(e.target.id === 'ct-search'){ find = e.target.value; paintNav(); } });
    // The top bar's lead search and "+ New lead" belong to Leads: on Content they step aside.
    const ctx = name => document.body.classList.toggle('on-content', name === 'content');
    document.addEventListener('crt:tab', e => ctx(e.detail));
    ctx(($('.tab.is-active') || {dataset: {}}).dataset.tab);
    // The genuine quote that is built into the home page is listed too, so the count never reads as "lost".
    const tl = $('#testimonials-list');
    if(tl && !$('#ct-builtin')) tl.insertAdjacentHTML('beforebegin', '<div class="ct-builtin" id="ct-builtin"><b>Oreste Mukiza</b>, Public Relations and Communication Specialist, Rwanda Mines Board<small>Built into the home page and always shown. Quotes you add below appear after it.</small></div>');
    try{ pane = localStorage.getItem('crt-admin-cpane') || pane; }catch(e){}
    paintNav(); go(pane, true);
  }
  function paintNav(){
    const nav = $('#ct-nav'); if(!nav) return;
    const q = find.trim().toLowerCase(), hit = l => !q || l.toLowerCase().indexOf(q) > -1;
    const item = (go, label, n) => `<button type="button" class="ct-item${pane === go ? ' is-on' : ''}" data-go="${go}"${pane === go ? ' aria-current="true"' : ''}><span>${esc(label)}</span>${n === '' || n == null ? '' : `<em>${n}</em>`}</button>`;
    const tCount = $$('#testimonials-list .testimonial-row').length + 1, cCount = ($('#case-select') || {options: []}).options.length;
    const sect = (title, rows) => { const r = rows.filter(x => hit(x[1])); return r.length ? `<p class="ct-group">${title}</p>` + r.map(x => item(x[0], x[1], x[2])).join('') : ''; };
    const html =
      sect('Pages', PAGES.map(([k, l]) => ['page:' + k, l, countFor(k) || ''])) +
      sect('Collections', [['testimonials', 'Testimonials', tCount], ['prices', 'Wedding prices', 4], ['packages', 'Wedding packages', 4], ['cases', 'Case studies', cCount || '']]) +
      sect('Whole site', [['contact', 'Contact details', ''], ['announcement', 'Announcement bar', ''], ['showreel', 'Home showreel', ''], ['changes', 'All changes', total() || '']]);
    let list = $('#ct-list', nav);
    if(!list){ nav.innerHTML = '<input id="ct-search" type="search" placeholder="Search pages…" aria-label="Search pages and sections"><div id="ct-list"></div>'; list = $('#ct-list', nav); }
    list.innerHTML = html || '<p class="muted small ct-none">Nothing matches.</p>';
    const pick = $('#ed-page'); if(pick && pick.value !== page) pick.value = page;
  }
  function go(name, first){
    if(name === 'cases'){ const t = $('.tab[data-tab="cases"]'); if(t) t.click(); return; }
    pane = name; try{ localStorage.setItem('crt-admin-cpane', name); }catch(e){}
    const isPage = name.indexOf('page:') === 0;
    $$('#ct-main .ct-pane').forEach(p => p.hidden = p.dataset.cpane !== (isPage ? 'page' : name));
    if(isPage){ const next = name.slice(5); if(next !== page || !frame.dataset.loaded || first) { page = next; openPage(); } }
    if(name === 'changes') paintChanges();
    paintNav();
  }

  // ------------------------------------------------------------------ page editor
  function buildEditor(){
    const p = $('[data-cpane="page"]');
    p.innerHTML = `
      <div class="ed-bar">
        <div class="ed-title"><b id="ed-name"></b><select id="ed-page" aria-label="Page to edit">${PAGES.map(([k, l]) => `<option value="${k}">${esc(l)}</option>`).join('')}</select><a id="ed-open" class="link small" target="_blank" rel="noopener">Open page ↗</a></div>
        <div class="seg" role="group" aria-label="Preview size"><button type="button" class="seg-btn is-active" data-dev="desktop" aria-pressed="true">Desktop</button><button type="button" class="seg-btn" data-dev="phone" aria-pressed="false">Phone</button></div>
        <button type="button" class="btn secondary small" id="ed-wide" aria-pressed="false" title="Hide the list of pages to give the preview more room">Bigger preview</button>
        <span class="ed-status" id="ed-status" role="status"></span>
        <button type="button" class="btn secondary small" id="ed-discard" hidden>Discard</button>
        <button type="button" class="btn small" id="ed-save" disabled title="No changes yet">Save changes</button>
      </div>
      <div class="ed-body">
        <div class="ed-stage" id="ed-stage"><iframe id="ed-frame" title="Page preview" loading="lazy"></iframe><div class="ed-load" id="ed-load">Loading the page…</div></div>
        <aside class="ed-ins" id="ed-ins" aria-label="Edit the selected item"></aside>
      </div>`;
    frame = $('#ed-frame');
    frame.addEventListener('load', onFrame);
    if('ResizeObserver' in window) new ResizeObserver(fit).observe($('#ed-stage')); else window.addEventListener('resize', fit);
    document.addEventListener('crt:tab', () => setTimeout(fit, 0));
    p.addEventListener('click', e => {
      const d = e.target.closest('[data-dev]');
      if(d){ device = d.dataset.dev; $$('[data-dev]', p).forEach(b => { const on = b === d; b.classList.toggle('is-active', on); b.setAttribute('aria-pressed', on); }); $('#ed-stage').classList.toggle('is-phone', device === 'phone'); fit(); return; }
      if(e.target.id === 'ed-wide'){ const on = $('.ct').classList.toggle('is-wide'); e.target.setAttribute('aria-pressed', on); e.target.textContent = on ? 'Show page list' : 'Bigger preview'; fit(); return; }
      if(e.target.id === 'ed-save') return saveEdits();
      if(e.target.id === 'ed-discard'){ if(confirm('Discard the changes you have not saved?')){ work = clone(store.page_edits); select(null); reload(); paintStatus(); } return; }
      insClick(e);
    });
    $('#ed-ins').addEventListener('input', insInput);
    $('#ed-ins').addEventListener('change', insChange);
    $('#ed-page').addEventListener('change', e => go('page:' + e.target.value));
    document.addEventListener('keydown', e => {
      if($('#tab-content').hidden || pane.indexOf('page:') !== 0) return;
      if((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 's'){ e.preventDefault(); if(dirty()) saveEdits(); }
      else if(e.key === 'Escape' && sel) select(null);
    });
    window.addEventListener('beforeunload', e => { if(dirty()){ e.preventDefault(); e.returnValue = ''; } });
  }
  // The preview is drawn at a real screen width (1280px desktop, 390px phone) and scaled to fit the space,
  // so the page looks the way visitors see it instead of collapsing to its tablet layout.
  function fit(){
    const st = $('#ed-stage'); if(!st || !frame || !st.clientWidth) return;
    const phone = device === 'phone', W = phone ? 390 : 1280, pad = phone ? 28 : 0;
    const k = Math.min(1, (st.clientWidth - (phone ? 24 : 0)) / W);
    frame.style.width = W + 'px'; frame.style.height = Math.round((st.clientHeight - pad) / k) + 'px';
    frame.style.transform = 'translateX(-50%) scale(' + k + ')';
  }
  const urlOf = p => '../' + (p === '/' ? '' : p.slice(1) + '/') + 'index.html';
  function openPage(){
    const label = (PAGES.find(x => x[0] === page) || [page, page])[1];
    $('#ed-name').textContent = label; $('#ed-open').href = urlOf(page); fit();
    select(null); keepScroll = 0; reload();
  }
  function reload(){
    try{ if(frame.contentWindow && doc) keepScroll = frame.contentWindow.scrollY || 0; }catch(e){}
    doc = null; ED = null; $('#ed-load').hidden = false; frame.dataset.loaded = '';
    frame.src = urlOf(page) + '?crt_edit=1&t=' + Date.now();
  }
  function onFrame(){
    let w = null; try{ w = frame.contentWindow; doc = frame.contentDocument; ED = w.__CRT_EDITOR; }catch(e){ doc = null; }
    $('#ed-load').hidden = true;
    if(!doc || !ED){ $('#ed-ins').innerHTML = '<p class="muted small">This page can’t be edited here yet. Upload the latest website files first, then try again.</p>'; return; }
    frame.dataset.loaded = '1';
    const st = doc.createElement('style');
    st.textContent = '[data-crt-h]{outline:2px dashed #dd1c5f!important;outline-offset:3px!important;cursor:pointer!important}[data-crt-s]{outline:2px solid #dd1c5f!important;outline-offset:3px!important;box-shadow:0 0 0 6px rgba(221,28,95,.16)!important}.consent,.action-bar,.whatsapp-float,.mobile-booking{display:none!important}*{scroll-behavior:auto!important}[data-crt-pulse] :is(h1,h2,h3,p,li,.btn,img,figcaption,summary,small,strong){outline:1.5px dashed rgba(221,28,95,.55);outline-offset:2px}';
    doc.head.appendChild(st);
    const again = () => { if(ED && doc) { ED.stamp(); ED.apply(listFor(page)); } };
    doc.documentElement.setAttribute('data-crt-pulse', ''); setTimeout(() => { if(doc) doc.documentElement.removeAttribute('data-crt-pulse'); }, 2400);
    again(); setTimeout(again, 700); setTimeout(() => { again(); if(!sel) paintIns(); }, 2200);
    if(keepScroll) w.scrollTo(0, keepScroll);
    doc.addEventListener('mousemove', e => { const u = unitAt(e); setHover(u ? u.el : null); }, true);
    doc.addEventListener('mouseleave', () => setHover(null), true);
    ['click', 'submit', 'mousedown', 'auxclick'].forEach(t => doc.addEventListener(t, e => {
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      if(t === 'click'){ const u = unitAt(e); select(u); }
    }, true));
    paintIns(); paintStatus();
  }
  function setHover(el){ if(hover === el) return; if(hover) hover.removeAttribute('data-crt-h'); hover = el && !(sel && sel.el === el) ? el : null; if(hover) hover.setAttribute('data-crt-h', ''); }
  function unitAt(e){
    const t = e.target; if(!t || t.nodeType !== 1 || !ED) return null;
    if(t.tagName === 'IMG') return {type: 'img', el: t};
    let node = null, r = null;
    try{
      if(doc.caretRangeFromPoint) r = doc.caretRangeFromPoint(e.clientX, e.clientY);
      else if(doc.caretPositionFromPoint){ const p = doc.caretPositionFromPoint(e.clientX, e.clientY); if(p) r = {startContainer: p.offsetNode}; }
    }catch(err){}
    if(r && r.startContainer && r.startContainer.nodeType === 3 && r.startContainer.nodeValue.trim() && t.contains(r.startContainer)) node = r.startContainer;
    if(!node) node = [...t.childNodes].find(n => n.nodeType === 3 && n.nodeValue.trim()) || null;
    if(!node){
      const img = t.querySelector(':scope > img, :scope > picture > img');
      if(img && !t.textContent.trim()) return {type: 'img', el: img};
      if(t.closest('a,button')){ const tn = ED.textNodes(t.closest('a,button')); if(tn.length) node = tn[0]; }
    }
    if(!node || !node.parentElement || node.parentElement.closest('script,style,svg')) return null;
    return {type: 'text', el: node.parentElement};
  }
  function select(u){
    if(sel && sel.el) sel.el.removeAttribute('data-crt-s');
    sel = u || null;
    if(sel){
      setHover(null); sel.el.setAttribute('data-crt-s', '');
      if(sel.type === 'text'){
        sel.nodes = [...sel.el.childNodes].filter(n => n.nodeType === 3 && n.nodeValue.trim());
        sel.nodes.forEach(n => { if(n._crtFrom === undefined) n._crtFrom = ED.norm(n.nodeValue); });
        sel.a = sel.el.closest('a[href]');
        if(sel.a && sel.a._crtFrom === undefined) sel.a._crtFrom = ED.keyOfLink(sel.a);
      } else if(sel.el._crtFrom === undefined) sel.el._crtFrom = ED.keyOfImg(sel.el);
      const keys = sel.type === 'img' ? [['img', sel.el._crtFrom]] : sel.nodes.map(n => ['text', n._crtFrom]).concat(sel.a ? [['link', sel.a._crtFrom]] : []);
      const had = keys.map(([k, f]) => getEdit(k, f)).find(Boolean);
      sel.scope = had ? had.scope : (sel.el.closest('header,footer,.site-header,.footer,.mm-panel,.nav-links,.season-bar') ? '*' : page);
    }
    paintIns();
  }
  const kindOf = el => { const t = el.tagName; return /^H[1-6]$/.test(t) ? 'Heading' : (el.closest('a.btn,button,.btn') ? 'Button' : (el.closest('a') ? 'Link' : (t === 'LI' ? 'List item' : 'Text'))); };
  function paintIns(){
    const box = $('#ed-ins'); if(!box) return;
    if(!sel){
      const edits = listFor(page), imgs = doc ? $$('img', doc).filter(i => i.getAttribute('src') && i.getBoundingClientRect().width > 40) : [];
      box.innerHTML = `
        <h2>Edit this page</h2>
        <p class="muted small">Click any heading, sentence, button or photo in the preview to change it. Nothing is live until you press <b>Save changes</b>.</p>
        ${ro ? '<p class="notice small">Only admins can change content. You can look around.</p>' : ''}
        <h3>Changes on this page <em>${edits.length}</em></h3>
        ${edits.length ? '<ul class="ch-list">' + edits.map(e => chRow(e, (work['*'] || []).includes(e) ? '*' : page)).join('') + '</ul>' : '<p class="muted small">No changes yet. The page shows its original content.</p>'}
        <details class="ins-imgs"><summary>Photos on this page <em>${imgs.length}</em></summary><div class="img-grid">${imgs.map((im, i) => `<button type="button" data-pick-img="${i}" title="${esc(im.alt || 'Photo')}"><img src="${esc(im.currentSrc || im.src)}" alt="" loading="lazy"></button>`).join('')}</div></details>`;
      box._imgs = imgs; return;
    }
    const scopeUi = `<fieldset class="ins-scope"><legend>Show this change on</legend>
      <label><input type="radio" name="scope" value="page"${sel.scope !== '*' ? ' checked' : ''}${ro ? ' disabled' : ''}> This page only</label>
      <label><input type="radio" name="scope" value="*"${sel.scope === '*' ? ' checked' : ''}${ro ? ' disabled' : ''}> <span>Every page<small>Best for the menu, the footer and buttons that repeat.</small></span></label></fieldset>`;
    if(sel.type === 'img'){
      const from = sel.el._crtFrom, ed = getEdit('img', from);
      box.innerHTML = `<div class="ins-head"><span class="ins-type">Photo</span><button type="button" class="link small" data-ins="done">Done</button></div>
        <div class="ins-thumb"><img src="${esc(sel.el.currentSrc || sel.el.src)}" alt=""></div>
        <label class="btn secondary small upload-btn${ro ? ' is-off' : ''}">Replace photo<input type="file" accept="image/jpeg,image/png,image/webp" data-ins="file" hidden${ro ? ' disabled' : ''}></label>
        <p class="muted small">JPG, PNG or WebP. It is resized for the web automatically. Use a photo with the same shape as the one it replaces.</p>
        <div class="field"><label for="ins-src">Or paste a photo address</label><input id="ins-src" data-ins="src" type="url" inputmode="url" placeholder="https://…" value="${ed ? esc(ed.to) : ''}"${ro ? ' disabled' : ''}></div>
        ${ed ? '<p class="ins-orig">This photo was changed. <button type="button" class="link" data-ins="reset-img">Restore the original</button></p>' : ''}${scopeUi}`;
      return;
    }
    const rows = sel.nodes.map((n, i) => {
      const cur = ED.norm(n.nodeValue), changed = cur !== n._crtFrom;
      return `<div class="field"><label for="ins-t${i}">${sel.nodes.length > 1 ? 'Line ' + (i + 1) : esc(kindOf(sel.el))}</label>
        <textarea id="ins-t${i}" data-ins="text" data-i="${i}" rows="${Math.min(8, Math.max(2, Math.ceil(cur.length / 34)))}"${ro ? ' disabled' : ''}>${esc(cur)}</textarea>
        <p class="ins-orig" data-orig="${i}"${changed ? '' : ' hidden'}>Original: “${esc(n._crtFrom)}” <button type="button" class="link" data-ins="reset-text" data-i="${i}">Restore</button></p></div>`;
    }).join('');
    let link = '';
    if(sel.a){
      const from = sel.a._crtFrom, ed = getEdit('link', from);
      link = `<div class="field"><label for="ins-link">Where it goes</label><input id="ins-link" data-ins="link" value="${esc(ed ? ed.to : pretty(from))}" spellcheck="false"${ro ? ' disabled' : ''}>
        <small class="muted">A page on this site starts with /, for example /contact. Other sites start with https://</small>
        <p class="ins-orig" data-orig="link"${ed ? '' : ' hidden'}>Original: ${esc(pretty(from))} <button type="button" class="link" data-ins="reset-link">Restore</button></p></div>`;
    }
    box.innerHTML = `<div class="ins-head"><span class="ins-type">${esc(kindOf(sel.el))}</span><button type="button" class="link small" data-ins="done">Done</button></div>${rows}${link}${scopeUi}`;
    const ta = $('textarea', box); if(ta && !ro){ ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length); }
  }
  const pretty = k => String(k).replace(/(^|\/)index\.html(?=$|[?#])/, '$1');   // '/contact/index.html' reads as '/contact/'
  const short = (s, n) => { s = String(s); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
  function chRow(e, scope){
    const what = e.k === 'img' ? 'Photo' : e.k === 'link' ? 'Link' : 'Text';
    return `<li><span class="ch-kind">${what}${scope === '*' ? ' · every page' : ''}</span><span class="ch-from">${esc(short(e.k === 'img' ? e.from.split('/').pop() : e.k === 'link' ? pretty(e.from) : e.from, 60))}</span><span class="ch-to">${esc(short(e.k === 'img' ? 'New photo' : e.to, 80))}</span>${ro ? '' : `<button type="button" class="link small" data-undo="${esc(scope)}" data-k="${e.k}" data-from="${esc(e.from)}">Undo</button>`}</li>`;
  }
  function insInput(e){
    const t = e.target; if(!sel || ro) return;
    if(t.dataset.ins === 'text'){
      const n = sel.nodes[+t.dataset.i], from = n._crtFrom, to = ED.norm(t.value) || from;
      putEdit('text', from, to, sel.scope);
      ED.apply([{k: 'text', from, to}]);
      const o = $(`[data-orig="${t.dataset.i}"]`); if(o) o.hidden = to === from;
    } else if(t.dataset.ins === 'link'){
      const from = sel.a._crtFrom; let to = t.value.trim(); if(to === pretty(from)) to = from;
      const ok = /^(\/(?!\/)|https?:\/\/|mailto:|tel:|#)/.test(to);
      t.classList.toggle('is-bad', !ok && to !== '');
      if(ok || to === from){ putEdit('link', from, to, sel.scope); const o = $('[data-orig="link"]'); if(o) o.hidden = to === from; }
    }
  }
  async function insChange(e){
    const t = e.target; if(!sel || ro) return;
    if(t.name === 'scope'){
      sel.scope = t.value === '*' ? '*' : page;
      const keys = sel.type === 'img' ? [['img', sel.el._crtFrom]] : sel.nodes.map(n => ['text', n._crtFrom]).concat(sel.a ? [['link', sel.a._crtFrom]] : []);
      keys.forEach(([k, f]) => { const ed = getEdit(k, f); if(ed) putEdit(k, f, ed.to, sel.scope); });
    } else if(t.dataset.ins === 'file' && t.files[0]){
      const f = t.files[0];
      if(f.size > 25e6){ A.toast('That file is over 25 MB. Choose a smaller photo.'); return; }
      try{ A.toast('Uploading the photo…'); const url = await upload(await shrink(f), 'site'); setImg(url); A.toast('Photo replaced. Press Save changes to publish it.'); }catch(err){ A.fail(err); }
    } else if(t.dataset.ins === 'src'){
      const v = t.value.trim(); if(/^https:\/\//.test(v)) setImg(v); else if(v) A.toast('The address needs to start with https://');
    }
  }
  function setImg(url){
    const from = sel.el._crtFrom; putEdit('img', from, url, sel.scope);
    sel.el.removeAttribute('srcset'); sel.el.removeAttribute('sizes'); sel.el.src = url; paintIns();
  }
  function insClick(e){
    const t = e.target;
    const pick = t.closest('[data-pick-img]');
    if(pick){ const im = ($('#ed-ins')._imgs || [])[+pick.dataset.pickImg]; if(im){ im.scrollIntoView({block: 'center'}); select({type: 'img', el: im}); } return; }
    const un = t.closest('[data-undo]');
    if(un){ dropEdit(un.dataset.undo, un.dataset.k, un.dataset.from); if(pane === 'changes') paintChanges(); select(null); if(frame.dataset.loaded) reload(); return; }
    const a = t.dataset && t.dataset.ins; if(!a) return;
    if(a === 'done') return select(null);
    if(ro || !sel) return;
    if(a === 'reset-text'){ const n = sel.nodes[+t.dataset.i]; putEdit('text', n._crtFrom, n._crtFrom, sel.scope); ED.apply([{k: 'text', from: n._crtFrom, to: n._crtFrom}]); paintIns(); }
    else if(a === 'reset-link'){ putEdit('link', sel.a._crtFrom, sel.a._crtFrom, sel.scope); paintIns(); }
    else if(a === 'reset-img'){ putEdit('img', sel.el._crtFrom, sel.el._crtFrom, sel.scope); select(null); reload(); }
  }
  function paintStatus(){
    const d = dirty(), s = $('#ed-status'); if(!s) return;
    s.textContent = d ? 'Changes not saved yet' : (countFor(page) ? countFor(page) + ' saved change' + (countFor(page) === 1 ? '' : 's') + ' on this page' : '');
    s.classList.toggle('is-dirty', d);
    $('#ed-save').disabled = !d || ro; $('#ed-save').title = ro ? 'Only admins can save' : (d ? 'Publish your changes (Ctrl or Cmd + S)' : 'No changes yet'); $('#ed-discard').hidden = !d;
    paintNav();
  }
  async function saveEdits(){
    if(ro) return;
    const b = $('#ed-save'); b.disabled = true; b.textContent = 'Saving…';
    try{ await save('page_edits', work); A.toast(A.LIVE ? 'Saved. Your changes are live on the website.' : 'Saved in this demo. Nothing was published.'); }
    catch(e){ A.fail(e); }
    b.textContent = 'Save changes'; paintStatus(); if(!sel) paintIns();
  }
  function paintChanges(){
    const p = $('[data-cpane="changes"]'); if(!p) return;
    const scopes = Object.keys(work).filter(k => (work[k] || []).length).sort((a, b) => a === '*' ? -1 : b === '*' ? 1 : a.localeCompare(b));
    const name = k => k === '*' ? 'Every page' : (PAGES.find(x => x[0] === k) || [k, k])[1];
    p.innerHTML = `<h2>All changes</h2><p class="muted small">Every word, link and photo you have changed from the original website. Undo one to bring the original back.${dirty() ? ' <b>Some changes are not saved yet.</b>' : ''}</p>` +
      (scopes.length ? scopes.map(k => `<h3>${esc(name(k))} <em>${work[k].length}</em></h3><ul class="ch-list">${work[k].map(e => chRow(e, k)).join('')}</ul>`).join('') +
        (ro ? '' : `<div class="row-end"><button type="button" class="btn small" data-set="save-changes"${dirty() ? '' : ' disabled'}>Save</button></div>`)
        : '<p class="muted small">Nothing has been changed. The website shows its original content.</p>');
  }

  // ------------------------------------------------------------------ whole-site settings
  function buildSettings(){
    const st = store.site_settings || {}, c = st.contact || {}, an = st.announcement, sr = st.showreel || {};
    const dis = ro ? ' disabled' : '';
    $('[data-cpane="contact"]').innerHTML = `
      <h2>Contact details</h2>
      <p class="muted small">Shown in the header, footer, contact page and every WhatsApp button. Leave a field empty to keep the current one.</p>
      <div class="price-grid">
        <div class="field"><label for="set-phone">Phone and WhatsApp number</label><input id="set-phone" inputmode="tel" placeholder="+250 796 356 035" value="${esc(c.phone || '')}"${dis}><small class="muted">With the country code, written the way visitors should see it.</small></div>
        <div class="field"><label for="set-email">Public email</label><input id="set-email" type="email" placeholder="hello@crt.rw" value="${esc(c.email || '')}"${dis}><small class="muted">The address shown to visitors. Enquiry forms keep going to the team inbox.</small></div>
      </div>
      <div class="row-end"><button type="button" class="btn" data-set="save-contact"${dis}>Save contact details</button></div>`;
    const mode = !an ? 'auto' : (an.on === false ? 'off' : 'on');
    $('[data-cpane="announcement"]').innerHTML = `
      <h2>Announcement bar</h2>
      <p class="muted small">The thin message above the menu on the home page. Visitors can close it.</p>
      <div class="field"><label for="set-an-mode">What to show</label><select id="set-an-mode"${dis}>
        <option value="auto"${mode === 'auto' ? ' selected' : ''}>The seasonal message built into the site</option>
        <option value="on"${mode === 'on' ? ' selected' : ''}>My own message</option>
        <option value="off"${mode === 'off' ? ' selected' : ''}>Nothing</option></select></div>
      <div id="set-an-own"${mode === 'on' ? '' : ' hidden'}>
        <div class="field"><label for="set-an-text">Message</label><input id="set-an-text" maxlength="120" placeholder="Book your 2027 wedding now and save 30%." value="${esc(an && an.text || '')}"${dis}><small class="muted">One short sentence, up to 120 characters.</small></div>
        <div class="price-grid">
          <div class="field"><label for="set-an-link">Link words (optional)</label><input id="set-an-link" maxlength="40" placeholder="See the offer" value="${esc(an && an.link || '')}"${dis}></div>
          <div class="field"><label for="set-an-href">Link goes to</label><input id="set-an-href" placeholder="/offer-wedding-early-booking" value="${esc(an && an.href || '')}"${dis}></div>
        </div>
      </div>
      <div class="row-end"><button type="button" class="btn" data-set="save-announcement"${dis}>Save announcement</button></div>`;
    $('[data-cpane="showreel"]').innerHTML = `
      <h2>Home showreel</h2>
      <p class="muted small">A short silent video that plays behind the home page headline. While there is none, the home page shows moving photos instead.</p>
      <ul class="tips"><li>6 to 10 seconds, landscape 1920×1080, MP4</li><li>No sound and no text on screen (it plays muted)</li><li>Keep the file under 6 MB so the page stays fast. The limit is 50 MB.</li><li>Keep faces away from the middle of the frame: the headline sits there</li></ul>
      <p id="set-sr-now" class="notice small"${sr.mp4 ? '' : ' hidden'}>A showreel is live: <a href="${esc(sr.mp4 || '#')}" target="_blank" rel="noopener">watch the file ↗</a></p>
      <div class="film-row">
        <input id="set-sr-url" type="url" inputmode="url" placeholder="https://… (address of an MP4 file)" value="${esc(sr.mp4 || '')}" aria-label="Showreel file address"${dis}>
        <label class="btn secondary small upload-btn">Upload video<input type="file" id="set-sr-file" accept="video/mp4,video/webm" hidden${dis}></label>
      </div>
      <div class="row-end">${sr.mp4 && !ro ? '<button type="button" class="link danger" data-set="remove-showreel">Remove the showreel</button>' : ''}<button type="button" class="btn" data-set="save-showreel"${dis}>Save showreel</button></div>`;
    paintChanges();
  }
  async function saveSettings(patch, msg){
    const next = Object.assign(clone(store.site_settings), patch);
    Object.keys(next).forEach(k => { if(next[k] == null) delete next[k]; });
    try{ await save('site_settings', next); buildSettings(); A.toast(A.LIVE ? msg : 'Saved in this demo. Nothing was published.'); }catch(e){ A.fail(e); }
  }
  async function onSettings(e){
    const a = e.target.dataset && e.target.dataset.set; if(!a || ro) return;
    if(a === 'save-changes') return saveEdits().then(paintChanges);
    if(a === 'save-contact'){
      const phone = $('#set-phone').value.trim(), email = $('#set-email').value.trim();
      if(phone && phone.replace(/\D/g, '').length < 10){ A.toast('Write the full number with the country code, for example +250 796 356 035'); return; }
      if(email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)){ A.toast('That email address does not look right'); return; }
      return saveSettings({contact: (phone || email) ? {phone, email} : null}, 'Contact details saved. Live on the website.');
    }
    if(a === 'save-announcement'){
      const mode = $('#set-an-mode').value;
      if(mode === 'auto') return saveSettings({announcement: null}, 'Saved. The site shows its seasonal message.');
      if(mode === 'off') return saveSettings({announcement: {on: false}}, 'Saved. The announcement bar is off.');
      const text = $('#set-an-text').value.trim(), link = $('#set-an-link').value.trim(), href = $('#set-an-href').value.trim();
      if(!text){ A.toast('Write the message first'); return; }
      if(href && !/^(\/(?!\/)|https:\/\/)/.test(href)){ A.toast('The link needs to start with / or https://'); return; }
      if(link && !href){ A.toast('Add where the link goes, or remove the link words'); return; }
      return saveSettings({announcement: {on: true, text, link, href}}, 'Announcement saved. Live on the home page.');
    }
    if(a === 'save-showreel'){
      const url = $('#set-sr-url').value.trim();
      if(!url) return saveSettings({showreel: null}, 'Saved. The home page shows moving photos.');
      if(!/^https:\/\//.test(url)){ A.toast('The address needs to start with https://'); return; }
      return saveSettings({showreel: {mp4: url}}, 'Showreel saved. Live on the home page.');
    }
    if(a === 'remove-showreel'){ if(confirm('Remove the showreel from the home page?')) return saveSettings({showreel: null}, 'Showreel removed.'); }
  }
  async function onSettingsChange(e){
    if(e.target.id === 'set-an-mode'){ $('#set-an-own').hidden = e.target.value !== 'on'; return; }
    if(e.target.id === 'set-sr-file' && e.target.files[0] && !ro){
      const f = e.target.files[0];
      if(f.size > 50e6){ A.toast('That video is over 50 MB. Export a shorter or smaller file.'); return; }
      if(f.size > 8e6 && !confirm('This video is ' + Math.round(f.size / 1e6) + ' MB. Under 6 MB keeps the home page fast. Upload it anyway?')) return;
      try{ A.toast('Uploading the video…'); const url = await upload(f, 'site/showreel'); $('#set-sr-url').value = url; await saveSettings({showreel: {mp4: url}}, 'Showreel uploaded. Live on the home page.'); }catch(err){ A.fail(err); }
    }
  }

  // ------------------------------------------------------------------ boot
  async function start(){
    if(A || !window.CRT_ADMIN) return;
    A = window.CRT_ADMIN; esc = A.esc; ro = !A.isAdmin();
    try{ await load(); }catch(e){ A.fail(e); }
    build();
    const main = $('#ct-main');
    if(main){ main.addEventListener('click', e => { if(!e.target.closest('[data-cpane="page"]')){ insClick(e); onSettings(e); } }); main.addEventListener('change', onSettingsChange); }
    // counts in the side list follow the collections edited elsewhere on this tab
    // The built-in quote is always live, so the empty state must not say the section is hidden.
    const tl = $('#testimonials-list');
    const emptyNote = () => { const p = tl && tl.querySelector(':scope > p.muted'); if(p && /No testimonials yet/.test(p.textContent)) p.textContent = 'No added testimonials yet. Oreste’s quote shows on its own until you add more.'; };
    emptyNote();
    if(tl && 'MutationObserver' in window) new MutationObserver(() => { emptyNote(); paintNav(); }).observe(tl, {childList: true});
    setTimeout(paintNav, 1500);
  }
  document.addEventListener('crt:ready', start);
  if(window.CRT_ADMIN) start();
})();
