// CRT mail receiver: a Cloudflare Email Worker. Cloudflare → Email Routing → Routing rules → Catch-all → "Send to a Worker".
// It hands every message sent to @crt.rw to the dashboard's "mail" function, which stores it in your mailboxes.
// The dashboard (Inbox → Mail settings) gives you this file with the three values below already filled in.
const ENDPOINT = "PASTE_ENDPOINT";       // https://….supabase.co/functions/v1/mail
const RECEIVING_KEY = "PASTE_KEY";        // from Inbox → Mail settings
const PUBLIC_KEY = "PASTE_PUBLIC_KEY";    // the site's public Supabase key (already in crt-config.js)

export default {
  async email(message, env, ctx) {
    const raw = new Uint8Array(await new Response(message.raw).arrayBuffer());
    let s = ""; for (let i = 0; i < raw.length; i += 0x8000) s += String.fromCharCode(...raw.subarray(i, i + 0x8000));
    const r = await fetch(ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-crt-mail-secret": RECEIVING_KEY, Authorization: "Bearer " + PUBLIC_KEY, apikey: PUBLIC_KEY },
      body: JSON.stringify({ to: message.to, from: message.from, raw: btoa(s) }),
    });
    if (r.status === 404) message.setReject("No such mailbox at crt.rw");
    else if (!r.ok) throw new Error("CRT mail store failed: " + r.status);   // Cloudflare retries later, so nothing is lost
    // a copy to Gmail (or any app) when the mailbox asks for it; Cloudflare needs each address verified once
    const d = await r.json().catch(() => ({}));
    for (const to of d.forward || []) { try { await message.forward(to); } catch (e) { console.log("forward failed", to, String(e)); } }
  },
};
