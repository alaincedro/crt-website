/* CRT admin: Settings (2026-11-24). One place for everything that configures the dashboard:
   Appearance (this device), Team, Sign-in & security, the website's contact details, and the connections
   (Mail, WhatsApp books, text messages & keys). The panes are filled by the scripts that own them:
   admin.js (team, security, keys), content.js (contact details), mail.js (mail), fin-whatsapp.js (WhatsApp). */
(function(){
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  let A = null, pane = 'appearance';
  const owner = () => A && A.me && A.me.role === 'owner';
  const allowed = b => !b.hidden;
  function go(name){
    const nav = $('#set-nav'); if(!nav) return;
    let b = $(`[data-set-go="${name}"]`, nav);
    if(!b || !allowed(b)) b = $$('[data-set-go]', nav).find(allowed);
    if(!b) return;
    pane = b.dataset.setGo;
    $$('[data-set-go]', nav).forEach(x => x.toggleAttribute('aria-current', x === b));
    $$('[data-set-pane]').forEach(p => p.hidden = p.dataset.setPane !== pane);
    document.dispatchEvent(new CustomEvent('crt:settings', {detail: pane}));
    try{ history.replaceState(null, '', '#settings/' + pane); }catch(e){}
  }
  // Appearance: light, dark or the device's own setting (admin.js applies it at start)
  function paintTheme(){
    let t = 'auto'; try{ t = localStorage.getItem('crt-admin-theme') || 'auto'; }catch(e){}
    $$('input[name="set-theme"]').forEach(i => i.checked = i.value === t);
  }
  function ready(){
    A = window.CRT_ADMIN;
    $$('[data-set-owner]').forEach(el => { if(!owner()) el.hidden = true; });
    paintTheme();
    $('#set-nav').addEventListener('click', e => { const b = e.target.closest('[data-set-go]'); if(b) go(b.dataset.setGo); });
    document.addEventListener('change', e => { if(e.target.name === 'set-theme' && window.CRT_THEME){ window.CRT_THEME(e.target.value); paintTheme(); } });
    document.addEventListener('crt:tab', e => { document.body.classList.toggle('on-settings', e.detail === 'settings'); if(e.detail === 'settings') go(pane); });   // the lead search bar steps aside here
    window.CRT_SETTINGS = {open: name => { const t = $('.tab[data-tab="settings"]'); if(t) t.click(); go(name); }};
    const m = location.hash.match(/^#settings\/([a-z]+)/); if(m){ pane = m[1]; const t = $('.tab[data-tab="settings"]'); if(t) setTimeout(() => t.click(), 0); }
  }
  if(window.CRT_ADMIN) ready(); else document.addEventListener('crt:ready', ready);
})();
