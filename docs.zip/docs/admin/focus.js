/* CRT admin: photo crop and focus (2026-11-24).
   One dialog, opened from any photo (Content → Edit any page, and a work's photos):
   drag the point that must stay in view, zoom if needed, and see every place on the website
   where photos are cropped, at its real shape. A place can get its own crop.
   Saved in Supabase site_content.photo_focus {key: {x, y, z, at: {place: {x, y, z}}}}; site.js applies it.
   window.CRT_FOCUS.open(src, {place, el, onChange}) */
(function(){
  const PLACES = [
    // id, name, preview shapes [ratio, label]  (measured on crt.rw at computer and phone width)
    ['hero', 'Page banner', [[2.08, 'Computer'], [0.78, 'Phone']]],
    ['carousel', 'Home work showcase', [[1.33, '']]],
    ['tiles', 'Home tiles', [[1.36, '']]],
    ['cards', 'Work page cards', [[0.8, '']]],
    ['cover', 'Work cover', [[1.78, '']]],
    ['more', '“More work” cards', [[1.6, '']]],
    ['offers', 'Offer cards', [[1.6, '']]],
    ['menu', 'Menu pictures', [[1.6, '']]],
    ['team', 'Team photos', [[1, '']]]];
  const NAME = Object.fromEntries(PLACES.map(p => [p[0], p[1]]));
  const SITE = new URL('../', location.href).href;
  const key = src => { let u = String(src || ''); try{ u = new URL(u, location.href).href; }catch(e){}
    if(u.startsWith(SITE)) u = '/' + u.slice(SITE.length); u = u.replace(/^https?:\/\/(www\.)?crt\.rw\//, '/');
    return u.split(/[?#]/)[0].replace(/-\d{2,4}w?(?=\.[a-z0-9]+$)/i, '').replace(/\.[a-z0-9]+$/i, ''); };
  const DEMO = 'crt-focus-demo';
  const A = () => window.CRT_ADMIN || {};
  let MAP = null;
  async function load(){
    const a = A();
    if(a.LIVE && a.sb){ const {data, error} = await a.sb.from('site_content').select('value').eq('key', 'photo_focus').maybeSingle(); if(error) throw error; MAP = (data && data.value) || {}; }
    else { try{ MAP = JSON.parse(sessionStorage.getItem(DEMO) || '{}'); }catch(e){ MAP = {}; } }
    return MAP;
  }
  async function store(k, entry){
    const a = A(); await load();                      // start from what is saved now, so two people don't undo each other
    if(entry) MAP[k] = entry; else delete MAP[k];
    if(a.LIVE && a.sb){ const {error} = await a.sb.from('site_content').upsert({key: 'photo_focus', value: MAP, updated_by: a.me && a.me.user_id}); if(error) throw error; }
    else sessionStorage.setItem(DEMO, JSON.stringify(MAP));
    return MAP;
  }
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const r1 = v => Math.round(v), z2 = v => Math.round(v * 20) / 20;
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));

  let dlg, st = null;   // st: {k, src, x, y, z, at, target, onChange, ratio}
  function build(){
    dlg = document.createElement('dialog'); dlg.className = 'fx'; dlg.setAttribute('aria-labelledby', 'fx-title');
    dlg.innerHTML = `<form method="dialog" class="fx-in">
      <header class="fx-head"><div><h2 id="fx-title">Crop and focus</h2><p class="muted small" id="fx-sub"></p></div><button type="button" class="fx-x" data-fx="close" aria-label="Close">×</button></header>
      <div class="fx-body">
        <div class="fx-left">
          <div class="fx-tabs" role="tablist" aria-label="Which crop you are changing" id="fx-tabs"></div>
          <div class="fx-stage"><div class="fx-photo" id="fx-photo"><img alt="" id="fx-img" draggable="false"><span class="fx-shade" id="fx-shade" hidden></span><span class="fx-frame" id="fx-frame" hidden></span><button type="button" class="fx-dot" id="fx-dot" role="slider" aria-label="Focus point. Arrow keys move it." aria-valuetext=""></button></div></div>
          <div class="fx-tools">
            <label class="fx-zoom"><span>Zoom</span><input type="range" min="1" max="2.5" step="0.05" id="fx-z"><output id="fx-zv">1×</output></label>
            <button type="button" class="link small" data-fx="centre">Centre</button>
          </div>
          <p class="fx-hint muted small" id="fx-hint"></p>
        </div>
        <div class="fx-right"><p class="fx-ptitle">How it looks on the website</p><div class="fx-grid" id="fx-grid"></div></div>
      </div>
      <footer class="fx-foot"><button type="button" class="link small" data-fx="reset" id="fx-reset">Undo all crops for this photo</button><span class="fx-sp"></span><button type="button" class="btn secondary small" data-fx="close">Cancel</button><button type="button" class="btn small" data-fx="save" id="fx-save">Save</button></footer>
    </form>`;
    document.body.appendChild(dlg);
    dlg.addEventListener('click', onClick);
    dlg.addEventListener('cancel', e => { e.preventDefault(); close(); });
    const photo = dlg.querySelector('#fx-photo');
    photo.addEventListener('pointerdown', onDown);
    dlg.querySelector('#fx-dot').addEventListener('keydown', onKey);
    dlg.querySelector('#fx-z').addEventListener('input', e => { cur().z = z2(+e.target.value); paint(true); });
    dlg.querySelector('#fx-grid').addEventListener('mouseover', e => { const b = e.target.closest('[data-pv]'); hoverRatio = b ? +b.dataset.r : 0; paintFrame(); });
    dlg.querySelector('#fx-grid').addEventListener('mouseleave', () => { hoverRatio = 0; paintFrame(); });
    window.addEventListener('resize', () => { if(dlg.open) paintFrame(); });
  }
  let hoverRatio = 0;
  // the crop being changed: the main one, or one place's own
  const cur = () => st.target ? st.at[st.target] : st;
  const valOf = id => st.at[id] || st;
  function entry(){
    const e = {x: r1(st.x), y: r1(st.y), z: z2(st.z)}, at = {};
    Object.keys(st.at).forEach(id => { const v = st.at[id], o = {x: r1(v.x), y: r1(v.y), z: z2(v.z)}; if(o.x !== e.x || o.y !== e.y || o.z !== e.z) at[id] = o; });   // an own crop equal to the main one is dropped
    if(Object.keys(at).length) e.at = at;
    return (e.x === 50 && e.y === 50 && e.z === 1 && !e.at) ? null : e;
  }
  function preview(){ if(st.onChange){ const m = Object.assign({}, MAP || {}); const e = entry(); if(e) m[st.k] = e; else delete m[st.k]; try{ st.onChange(m); }catch(err){} } }

  async function open(src, o){
    o = o || {}; if(!dlg) build();
    const k = key(src);
    try{ await load(); }catch(e){ MAP = MAP || {}; }
    const saved = MAP[k] || null;
    let x = 50, y = 50;
    if(!saved && o.el){ try{ const p = getComputedStyle(o.el).objectPosition.split(' ').map(v => parseFloat(v)); if(isFinite(p[0]) && isFinite(p[1]) && /%/.test(getComputedStyle(o.el).objectPosition)){ x = p[0]; y = p[1]; } }catch(e){} }
    st = {k, src, x: saved ? +saved.x : x, y: saved ? +saved.y : y, z: saved ? +saved.z || 1 : 1, at: {}, target: '', onChange: o.onChange, ratio: 1, place: o.place || '', ro: !!o.readOnly, before: JSON.stringify(saved)};
    if(saved && saved.at) Object.keys(saved.at).forEach(id => { if(NAME[id]) st.at[id] = {x: +saved.at[id].x, y: +saved.at[id].y, z: +saved.at[id].z || 1}; });
    const img = dlg.querySelector('#fx-img');
    img.onload = () => { st.ratio = img.naturalWidth / img.naturalHeight || 1; paint(); };
    img.src = src;
    dlg.querySelector('#fx-sub').textContent = st.place ? 'This photo appears here in: ' + NAME[st.place] + '. Changes apply wherever it is used.' : 'Changes apply wherever this photo is used on the website.';
    dlg.querySelector('#fx-save').disabled = st.ro;
    dlg.showModal();
    paint();
    dlg.querySelector('#fx-dot').focus();
  }
  function close(){ if(!dlg || !dlg.open) return; if(st && st.onChange){ try{ st.onChange(MAP || {}); }catch(e){} } dlg.close(); st = null; }

  function paint(fromZoom){
    if(!st) return;
    const v = cur();
    // tabs: the main crop, plus each place that has its own
    const own = Object.keys(st.at);
    dlg.querySelector('#fx-tabs').innerHTML = `<button type="button" role="tab" aria-selected="${!st.target}" data-fx="tab" data-id="">Everywhere</button>`
      + own.map(id => `<button type="button" role="tab" aria-selected="${st.target === id}" data-fx="tab" data-id="${id}">${esc(NAME[id])}<span class="fx-tx" data-fx="drop" data-id="${id}" role="button" aria-label="Remove the own crop for ${esc(NAME[id])}" title="Use the main crop here again">×</span></button>`).join('');
    dlg.querySelector('#fx-hint').innerHTML = st.target
      ? `Only <b>${esc(NAME[st.target])}</b> changes. Drag the frame or the point.`
      : 'Drag the point onto what must stay in view, like a face. Every crop keeps it in the picture.';
    const dot = dlg.querySelector('#fx-dot');
    dot.style.left = v.x + '%'; dot.style.top = v.y + '%';
    dot.setAttribute('aria-valuetext', `${r1(v.x)}% across, ${r1(v.y)}% down`);
    if(!fromZoom){ dlg.querySelector('#fx-z').value = v.z; }
    dlg.querySelector('#fx-zv').textContent = (Math.round(v.z * 100) / 100) + '×';
    // previews: every place where the site crops photos, at its real shape
    const grid = dlg.querySelector('#fx-grid');
    const order = PLACES.slice().sort((a, b) => (b[0] === st.place) - (a[0] === st.place));
    grid.innerHTML = order.map(([id, name, shapes]) => {
      const w = valOf(id), mine = !!st.at[id], sel = st.target === id, here = st.place === id;
      const pos = w.x + '% ' + w.y + '%', sc = w.z > 1 ? `scale:${w.z};transform-origin:${pos};` : '';
      return `<div class="fx-pv${sel ? ' is-sel' : ''}${here ? ' is-here' : ''}">
        <button type="button" class="fx-pvb" data-fx="place" data-id="${id}" aria-pressed="${sel}" title="${mine ? 'Change this crop' : 'Give this place its own crop'}">
          <span class="fx-shapes">${shapes.map(([r, l]) => `<span class="fx-pvi" data-pv data-r="${r}" style="aspect-ratio:${r}"><img src="${esc(st.src)}" alt="" draggable="false" style="object-position:${pos};${sc}">${l ? `<i>${l}</i>` : ''}</span>`).join('')}</span>
          <span class="fx-pvn">${esc(name)}${here ? ' <em>this one</em>' : ''}</span>
          <span class="fx-pvs">${mine ? 'Own crop' : sel ? '' : 'Same as everywhere'}</span>
        </button></div>`;
    }).join('');
    dlg.querySelector('#fx-reset').hidden = st.ro || (!entry() && st.before === 'null');
    paintFrame(); preview();
  }
  // the frame on the big photo: what the chosen place (or the hovered preview) shows
  function frameOf(ratio, v){
    let fw = 1, fh = 1; if(ratio > st.ratio) fh = st.ratio / ratio; else fw = ratio / st.ratio;
    fw /= v.z; fh /= v.z;
    return {fw, fh, l: v.x / 100 * (1 - fw), t: v.y / 100 * (1 - fh)};
  }
  function paintFrame(){
    if(!st) return;
    const fr = dlg.querySelector('#fx-frame'), sh = dlg.querySelector('#fx-shade');
    const ratio = hoverRatio || (st.target ? (PLACES.find(p => p[0] === st.target) || [0, 0, [[0]]])[2][0][0] : 0);
    if(!ratio){ fr.hidden = sh.hidden = true; return; }
    const pv = hoverRatio ? dlg.querySelector('[data-pv]:hover') : null, id = pv ? pv.closest('[data-id]').dataset.id : st.target;
    const f = frameOf(ratio, valOf(id));
    fr.hidden = sh.hidden = false;
    Object.assign(fr.style, {left: f.l * 100 + '%', top: f.t * 100 + '%', width: f.fw * 100 + '%', height: f.fh * 100 + '%'});
    sh.style.clipPath = `polygon(0 0,100% 0,100% 100%,0 100%,0 0,${f.l * 100}% ${f.t * 100}%,${f.l * 100}% ${(f.t + f.fh) * 100}%,${(f.l + f.fw) * 100}% ${(f.t + f.fh) * 100}%,${(f.l + f.fw) * 100}% ${f.t * 100}%,${f.l * 100}% ${f.t * 100}%)`;
  }
  function onDown(e){
    if(!st || st.ro || e.button > 0) return;
    const photo = dlg.querySelector('#fx-photo'), box = photo.getBoundingClientRect();
    const v = cur(), inFrame = st.target && e.target.id === 'fx-frame';
    const ratio = st.target ? PLACES.find(p => p[0] === st.target)[2][0][0] : 0;
    const f0 = ratio ? frameOf(ratio, v) : null, sx = e.clientX, sy = e.clientY;
    const set = ev => {
      if(inFrame){   // move the frame itself
        const l = f0.l + (ev.clientX - sx) / box.width, t = f0.t + (ev.clientY - sy) / box.height;
        if(f0.fw < 1) v.x = clamp(l / (1 - f0.fw) * 100, 0, 100);
        if(f0.fh < 1) v.y = clamp(t / (1 - f0.fh) * 100, 0, 100);
      } else { v.x = clamp((ev.clientX - box.left) / box.width * 100, 0, 100); v.y = clamp((ev.clientY - box.top) / box.height * 100, 0, 100); }
      paintLive();
    };
    e.preventDefault(); photo.setPointerCapture(e.pointerId); photo.classList.add('is-drag');
    set(e);
    const mv = ev => set(ev);
    const up = () => { photo.removeEventListener('pointermove', mv); photo.removeEventListener('pointerup', up); photo.removeEventListener('pointercancel', up); photo.classList.remove('is-drag'); paint(); dlg.querySelector('#fx-dot').focus(); };
    photo.addEventListener('pointermove', mv); photo.addEventListener('pointerup', up); photo.addEventListener('pointercancel', up);
  }
  // while dragging: move the point, the frame and the previews without rebuilding them
  let raf = 0;
  function paintLive(){
    if(raf) return;
    raf = requestAnimationFrame(() => {
      raf = 0; if(!st) return;
      const v = cur(), dot = dlg.querySelector('#fx-dot'); dot.style.left = v.x + '%'; dot.style.top = v.y + '%';
      dlg.querySelectorAll('.fx-pvb').forEach(b => { const w = valOf(b.dataset.id), pos = w.x + '% ' + w.y + '%';
        b.querySelectorAll('img').forEach(i => { i.style.objectPosition = pos; i.style.transformOrigin = w.z > 1 ? pos : ''; i.style.scale = w.z > 1 ? w.z : ''; }); });
      paintFrame(); preview();
    });
  }
  function onKey(e){
    if(!st || st.ro) return;
    const d = e.shiftKey ? 10 : 1, v = cur(), m = {ArrowLeft: [-d, 0], ArrowRight: [d, 0], ArrowUp: [0, -d], ArrowDown: [0, d]}[e.key];
    if(!m) return; e.preventDefault();
    v.x = clamp(v.x + m[0], 0, 100); v.y = clamp(v.y + m[1], 0, 100); paintLive();
  }
  async function onClick(e){
    const t = e.target.closest('[data-fx]'); if(!t || !st) return;
    const a = t.dataset.fx;
    if(a === 'close') return close();
    if(st.ro && a !== 'tab' && a !== 'place') return;
    if(a === 'drop'){ e.stopPropagation(); delete st.at[t.dataset.id]; if(st.target === t.dataset.id) st.target = ''; return paint(); }
    if(a === 'tab'){ st.target = t.dataset.id; return paint(); }
    if(a === 'place'){
      const id = t.dataset.id;
      if(st.target === id){ st.target = ''; return paint(); }
      if(!st.ro && !st.at[id]) st.at[id] = {x: st.x, y: st.y, z: st.z};
      st.target = st.at[id] ? id : ''; return paint();
    }
    if(a === 'centre'){ const v = cur(); v.x = 50; v.y = 50; v.z = 1; return paint(); }
    if(a === 'reset'){ st.x = 50; st.y = 50; st.z = 1; st.at = {}; st.target = ''; return paint(); }
    if(a === 'save'){
      const b = dlg.querySelector('#fx-save'); b.disabled = true; b.textContent = 'Saving…';
      try{
        await store(st.k, entry());
        const a2 = A(); if(a2.toast) a2.toast(a2.LIVE ? 'Crop saved. Live on the website.' : 'Saved in this demo. Nothing was published.');
        close();
      }catch(err){ const a2 = A(); if(a2.fail) a2.fail(err); else console.error(err); }
      finally{ b.disabled = false; b.textContent = 'Save'; }
    }
  }
  window.CRT_FOCUS = {open, key, load, places: PLACES, get map(){ return MAP; }};
})();
