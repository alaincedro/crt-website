-- CRT mail: your own @crt.rw mailboxes inside the dashboard (replaces Zoho Mail).  Run once in Supabase → SQL Editor.
-- Safe to run again. Nothing changes for visitors, and Zoho keeps working until the domain is switched over.
-- Who reads what: the main admin reads every mailbox; other team members read the mailboxes they are given.

create table if not exists public.mailboxes (
  local        text primary key check (local ~ '^[a-z0-9][a-z0-9._-]{0,40}$'),   -- the part before @crt.rw
  display_name text not null default '',
  members      uuid[] not null default '{}',
  catch_all    boolean not null default false,   -- gets mail sent to addresses that don't exist
  forward_to   text[] not null default '{}',     -- also deliver a copy to Gmail or any other address
  created_at   timestamptz not null default now()
);

create table if not exists public.mail_messages (
  id          bigint generated always as identity primary key,
  created_at  timestamptz not null default now(),
  mailbox     text not null references public.mailboxes(local) on update cascade on delete cascade,
  folder      text not null default 'inbox' check (folder in ('inbox','sent','archive','trash')),
  direction   text not null check (direction in ('in','out')),
  from_addr   text not null default '',
  from_name   text not null default '',
  to_addrs    text[] not null default '{}',
  cc_addrs    text[] not null default '{}',
  subject     text not null default '',
  text_body   text not null default '',
  html_body   text not null default '',
  message_id  text,
  in_reply_to text,
  attachments jsonb not null default '[]',      -- [{name, path, size, type}] in the private "mail" bucket
  unread      boolean not null default true,
  sent_by     uuid references auth.users(id) on delete set null
);
alter table public.mailboxes add column if not exists forward_to text[] not null default '{}';
create index if not exists mail_box_folder_idx on public.mail_messages (mailbox, folder, created_at desc);
create unique index if not exists mail_message_id_idx on public.mail_messages (mailbox, message_id) where message_id is not null;

create or replace function public.can_read_mailbox(box text) returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_owner() or (public.is_team() and exists (select 1 from public.mailboxes where local = box and auth.uid() = any(members)))
$$;

alter table public.mailboxes enable row level security;
alter table public.mail_messages enable row level security;
drop policy if exists "team sees its mailboxes" on public.mailboxes;
create policy "team sees its mailboxes" on public.mailboxes for select to authenticated using (public.can_read_mailbox(local));
drop policy if exists "owner manages mailboxes" on public.mailboxes;
create policy "owner manages mailboxes" on public.mailboxes for all to authenticated using (public.is_owner()) with check (public.is_owner());
drop policy if exists "readers see mail" on public.mail_messages;
create policy "readers see mail" on public.mail_messages for select to authenticated using (public.can_read_mailbox(mailbox));
drop policy if exists "readers file mail" on public.mail_messages;
create policy "readers file mail" on public.mail_messages for update to authenticated using (public.can_read_mailbox(mailbox)) with check (public.can_read_mailbox(mailbox));
drop policy if exists "owner deletes mail" on public.mail_messages;
create policy "owner deletes mail" on public.mail_messages for delete to authenticated using (public.can_read_mailbox(mailbox) and folder = 'trash');
-- new mail is only ever added by the "mail" server function (receiving and sending)

-- attachments: private bucket, files reached through short-lived links from the "mail" server function
insert into storage.buckets (id, name, public, file_size_limit) values ('mail', 'mail', false, 26214400)
on conflict (id) do update set public = false, file_size_limit = 26214400;

-- the two addresses you use today; the main admin is a member of both
insert into public.mailboxes (local, display_name, members, catch_all)
select 'hello', 'CRT Media Agency', array(select user_id from public.team where role = 'owner'), true
on conflict (local) do nothing;
insert into public.mailboxes (local, display_name, members)
select 'alain', coalesce((select name from public.team where role = 'owner' limit 1), 'Alain'), array(select user_id from public.team where role = 'owner')
on conflict (local) do nothing;

select local, display_name, catch_all, cardinality(members) as members from public.mailboxes order by local;
